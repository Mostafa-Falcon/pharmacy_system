import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../reusables/reusable_text.dart';
import '../../constants/app_strings.dart';
import '../../services/sound_service.dart';
import '../../theme/sidebar_theme.dart';
import '../../theme/app_sizes.dart';
import '../../theme/app_colors.dart';

class SidebarItem {
  final String id;
  final IconData icon;
  final String label;
  final List<SidebarItem>? children;
  final bool initiallyExpanded;

  const SidebarItem({
    required this.id,
    required this.icon,
    required this.label,
    this.children,
    this.initiallyExpanded = false,
  });
}

class SidebarGroup {
  final String label;
  final List<SidebarItem> children;

  const SidebarGroup({required this.label, required this.children});
}

class BranchOption {
  final String id;
  final String label;

  const BranchOption({required this.id, required this.label});
}

// ─── Main Sidebar Widget ───────────────────────────────────────

class HomeSidebar extends StatelessWidget {
  final bool isDrawer;
  final bool isSidebarVisible;
  final int selectedIndex;
  final List<SidebarGroup> groups;
  final List<BranchOption> branches;
  final String activeBranchId;
  final ValueChanged<int>? onNavigate;
  final ValueChanged<String>? onBranchChanged;

  const HomeSidebar({
    super.key,
    this.isDrawer = false,
    required this.isSidebarVisible,
    required this.selectedIndex,
    required this.groups,
    required this.onNavigate,
    this.branches = const [],
    this.activeBranchId = '',
    this.onBranchChanged,
  });

  @override
  Widget build(BuildContext context) {
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;
    final isDark = AppColors.isDark(context);

    if (isDrawer) {
      return Drawer(
        width: 260.w,
        elevation: 12,
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: sidebarTheme.backgroundColor,
            borderRadius: BorderRadiusDirectional.only(
              topEnd: Radius.circular(AppRadius.lg.r), // توحيد الحواف بـ .r
              bottomEnd: Radius.circular(AppRadius.lg.r),
            ),
          ),
          child: SafeArea(
            child: _SidebarBody(
              selectedIndex: selectedIndex,
              groups: groups,
              onNavigate: onNavigate,
              branches: branches,
              activeBranchId: activeBranchId,
              onBranchChanged: onBranchChanged,
              isCollapsed: false,
            ),
          ),
        ),
      );
    }

    final collapsed = !isSidebarVisible;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200), // سرعة نقلة انسيابية وناعمة
      curve: Curves.easeInOut,
      width: collapsed ? 68.w : 260.w,
      decoration: BoxDecoration(
        color: sidebarTheme.backgroundColor,
        border: BorderDirectional(
          end: BorderSide(
            color: sidebarTheme.dividerColor.withValues(alpha: isDark ? 0.2 : 0.4),
            width: 1.w,
          ),
        ),
      ),
      child: _SidebarBody(
        selectedIndex: selectedIndex,
        groups: groups,
        onNavigate: onNavigate,
        branches: branches,
        activeBranchId: activeBranchId,
        onBranchChanged: onBranchChanged,
        isCollapsed: collapsed,
      ),
    );
  }
}

// ─── Sidebar Body ──────────────────────────────────────────────

class _SidebarBody extends StatefulWidget {
  final int selectedIndex;
  final List<SidebarGroup> groups;
  final ValueChanged<int>? onNavigate;
  final List<BranchOption> branches;
  final String activeBranchId;
  final ValueChanged<String>? onBranchChanged;
  final bool isCollapsed;

  const _SidebarBody({
    required this.selectedIndex,
    required this.groups,
    required this.onNavigate,
    this.branches = const [],
    this.activeBranchId = '',
    this.onBranchChanged,
    this.isCollapsed = false,
  });

  @override
  State<_SidebarBody> createState() => _SidebarBodyState();
}

class _SidebarBodyState extends State<_SidebarBody> {
  final ScrollController _scrollController = ScrollController();
  final Set<String> _expandedItemIds = <String>{};
  late Map<String, int> _destinationIndexById;

  @override
  void initState() {
    super.initState();
    _expandedItemIds.addAll(
      widget.groups
          .expand((group) => group.children)
          .where((item) => item.initiallyExpanded)
          .map((item) => item.id),
    );
    _rebuildIndexMap();
    _expandSelectedPath();
  }

  @override
  void didUpdateWidget(covariant _SidebarBody oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.groups, widget.groups)) {
      _rebuildIndexMap();
    }
    if (oldWidget.selectedIndex != widget.selectedIndex || oldWidget.isCollapsed != widget.isCollapsed) {
      _expandSelectedPath(rebuild: true);
    }
  }

  void _rebuildIndexMap() {
    _destinationIndexById = <String, int>{};
    var index = 0;
    for (final group in widget.groups) {
      for (final item in group.children) {
        _destinationIndexById[item.id] = index;
        index++;
        if (item.children != null) {
          for (final child in item.children!) {
            _destinationIndexById[child.id] = index;
            index++;
          }
        }
      }
    }
  }

  void _expandSelectedPath({bool rebuild = false}) {
    if (widget.selectedIndex < 0) return;

    final selectedId = _destinationIndexById.keys.firstWhere(
          (id) => _destinationIndexById[id] == widget.selectedIndex,
      orElse: () => '',
    );
    if (selectedId.isEmpty) return;

    final parentIds = <String>{};
    for (final group in widget.groups) {
      for (final item in group.children) {
        if (item.id == selectedId) break;
        if (item.children != null && item.children!.any((c) => c.id == selectedId)) {
          parentIds.add(item.id);
        }
      }
    }

    final hasChanges = parentIds.any((id) => !_expandedItemIds.contains(id));
    if (!hasChanges) return;

    void update() => _expandedItemIds.addAll(parentIds);
    if (rebuild && mounted) {
      setState(update);
    } else {
      update();
    }
  }

  void _toggle(String itemId) {
    if (mounted) {
      setState(() {
        if (!_expandedItemIds.add(itemId)) {
          _expandedItemIds.remove(itemId);
        }
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;
    final isDark = AppColors.isDark(context);

    return Column(
      children: [
        _SidebarHeader(isCollapsed: widget.isCollapsed),
        Divider(
          color: sidebarTheme.dividerColor.withValues(alpha: isDark ? 0.2 : 0.4),
          height: 1.h,
        ),
        Expanded(
          child: ListView(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsetsDirectional.fromSTEB(
              widget.isCollapsed ? 4.w : 8.w,
              AppSpacing.xs.h,
              widget.isCollapsed ? 4.w : 12.w,
              AppSpacing.lg.h,
            ),
            children: [
              for (final group in widget.groups) ...[
                if (!widget.isCollapsed) _SidebarSectionLabel(label: group.label),
                for (final item in group.children) _buildNavigationItem(item, depth: 0),
              ],
            ],
          ),
        ),
        Divider(
          color: sidebarTheme.dividerColor.withValues(alpha: isDark ? 0.2 : 0.4),
          height: 1.h,
        ),
        if (!widget.isCollapsed)
          _SidebarBranchSwitcher(
            branches: widget.branches,
            activeBranchId: widget.activeBranchId,
            onChanged: widget.onBranchChanged,
          )
        else
          _SidebarBranchCollapsed(
            branches: widget.branches,
            activeBranchId: widget.activeBranchId,
            onChanged: widget.onBranchChanged,
          ),
      ],
    );
  }

  Widget _buildNavigationItem(SidebarItem item, {int depth = 0}) {
    final destinationIndex = _destinationIndexById[item.id] ?? -1;
    final isSelected = destinationIndex == widget.selectedIndex;
    final isExpanded = _expandedItemIds.contains(item.id);
    final hasSelectedChild = _hasSelectedChild(item);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _SidebarTile(
          icon: item.icon,
          label: item.label,
          depth: depth,
          isSelected: isSelected,
          hasSelectedChild: hasSelectedChild,
          isExpandable: item.children != null && item.children!.isNotEmpty,
          isExpanded: isExpanded,
          isCollapsed: widget.isCollapsed,
          onTap: () {
            if (item.children != null && item.children!.isNotEmpty) {
              _toggle(item.id);
            } else if (destinationIndex >= 0) {
              HapticFeedback.lightImpact();
              SoundService.instance.play(SoundEffect.click);
              widget.onNavigate?.call(destinationIndex);
            }
          },
        ),
        if (item.children != null && item.children!.isNotEmpty && !widget.isCollapsed)
          ClipRect(
            child: AnimatedSize(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              alignment: AlignmentDirectional.topStart, // محاذاة ديناميكية ناعمة للـ RTL
              child: isExpanded
                  ? Padding(
                padding: EdgeInsetsDirectional.only(start: 4.w),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final child in item.children!) _buildNavigationItem(child, depth: depth + 1),
                  ],
                ),
              )
                  : const SizedBox.shrink(),
            ),
          ),
      ],
    );
  }

  bool _hasSelectedChild(SidebarItem item) {
    if (item.children == null) return false;
    for (final child in item.children!) {
      final childIndex = _destinationIndexById[child.id] ?? -1;
      if (childIndex == widget.selectedIndex) return true;
      if (_hasSelectedChild(child)) return true;
    }
    return false;
  }
}

// ─── Sidebar Header ────────────────────────────────────────────

class _SidebarHeader extends StatelessWidget {
  final bool isCollapsed;

  const _SidebarHeader({required this.isCollapsed});

  @override
  Widget build(BuildContext context) {
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;
    final scheme = Theme.of(context).colorScheme;

    return SizedBox(
      height: 70.h,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: isCollapsed ? 4.w : AppSpacing.md.w),
        child: Row(
          mainAxisAlignment: isCollapsed ? MainAxisAlignment.center : MainAxisAlignment.start,
          children: [
            Container(
              width: 38.w,
              height: 38.w,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    scheme.primary,
                    scheme.primary.withValues(alpha: 0.75),
                  ],
                ),
                borderRadius: BorderRadius.circular(AppRadius.md.r), // تعديل للـ .r لثبات الحواف
                boxShadow: [
                  BoxShadow(
                    color: scheme.primary.withValues(alpha: 0.16),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(
                Icons.local_pharmacy_rounded,
                color: Colors.white,
                size: 18.sp,
              ),
            ),
            if (!isCollapsed) ...[
              SizedBox(width: 12.w),
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: AlignmentDirectional.centerStart,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ReusableText(
                        AppStrings.appName,
                        style: TextStyle(
                          color: sidebarTheme.textColor,
                          fontSize: 14.5.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      ReusableText(
                        AppStrings.pharmacyManagement,
                        style: TextStyle(
                          color: sidebarTheme.mutedColor,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Section Label ─────────────────────────────────────────────

class _SidebarSectionLabel extends StatelessWidget {
  final String label;

  const _SidebarSectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;

    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(AppSpacing.sm.w, AppSpacing.md.h, AppSpacing.sm.w, 4.h),
      child: ReusableText(
        label,
        style: TextStyle(
          color: sidebarTheme.mutedColor,
          fontSize: 10.sp,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.6,
        ),
      ),
    );
  }
}

// ─── Navigation Tile ───────────────────────────────────────────

class _SidebarTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final int depth;
  final bool isSelected;
  final bool hasSelectedChild;
  final bool isExpandable;
  final bool isExpanded;
  final bool isCollapsed;
  final VoidCallback? onTap;

  const _SidebarTile({
    required this.icon,
    required this.label,
    required this.depth,
    required this.isSelected,
    required this.hasSelectedChild,
    required this.isExpandable,
    required this.isExpanded,
    required this.isCollapsed,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;
    final isDark = AppColors.isDark(context);
    final isEmphasized = isSelected || hasSelectedChild;

    final foreground = isEmphasized ? sidebarTheme.selectedIndicatorColor : sidebarTheme.textColor;
    final tileBg = isSelected ? sidebarTheme.selectedBackgroundColor : Colors.transparent;
    final radius = BorderRadius.circular(AppRadius.sm.r); // الحواف الدائرية المستقرة بـ .r

    final tile = Container(
      margin: EdgeInsets.symmetric(vertical: 3.h, horizontal: isCollapsed ? 2.w : 0),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: radius,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        child: InkWell(
          onTap: onTap,
          hoverColor: sidebarTheme.hoverColor.withValues(alpha: isDark ? 0.3 : 0.5),
          splashColor: sidebarTheme.selectedIndicatorColor.withValues(alpha: 0.06),
          borderRadius: radius,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(
              isCollapsed ? AppSpacing.xs.w : (12 + (depth * 12)).w,
              depth == 0 ? 10.h : 8.h,
              isCollapsed ? AppSpacing.xs.w : 12.w,
              depth == 0 ? 10.h : 8.h,
            ),
            child: Row(
              mainAxisAlignment: isCollapsed ? MainAxisAlignment.center : MainAxisAlignment.start,
              children: [
                // مؤشر خلفي صغير وناعم ومخفي لو العنصر مش متحدد
                if (!isCollapsed && depth == 0)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    width: 3.w,
                    height: isSelected ? 16.0 : 0.0,
                    margin: EdgeInsetsDirectional.only(end: isSelected ? 8.w : 0),
                    decoration: BoxDecoration(
                      color: sidebarTheme.selectedIndicatorColor,
                      borderRadius: BorderRadius.circular(AppRadius.sm.r),
                    ),
                  ),
                Icon(
                  icon,
                  size: depth == 0 ? 19.sp : 17.sp,
                  color: foreground,
                ),
                if (!isCollapsed) ...[
                  SizedBox(width: 10.w),
                  Expanded(
                    child: ReusableText(
                      label,
                      style: TextStyle(
                        color: foreground,
                        fontSize: depth == 0 ? 13.sp : 12.sp,
                        fontWeight: isEmphasized ? FontWeight.bold : FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (isExpandable)
                    AnimatedRotation(
                      turns: isExpanded ? 0.5 : 0,
                      duration: const Duration(milliseconds: 180),
                      curve: Curves.easeInOut,
                      child: Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: isEmphasized ? sidebarTheme.selectedIndicatorColor : sidebarTheme.mutedColor,
                        size: 18.sp,
                      ),
                    )
                  else if (isSelected && depth > 0)
                    Container(
                      width: 5.w,
                      height: 5.w,
                      decoration: BoxDecoration(
                        color: sidebarTheme.selectedIndicatorColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                ],
              ],
            ),
          ),
        ),
      ),
    );

    if (isCollapsed) {
      return Tooltip(
        message: label,
        preferBelow: false,
        waitDuration: const Duration(milliseconds: 200),
        child: tile,
      );
    }

    return tile;
  }
}

// ─── Branch Switcher (expanded) ────────────────────────────────

class _SidebarBranchSwitcher extends StatelessWidget {
  final List<BranchOption> branches;
  final String activeBranchId;
  final ValueChanged<String>? onChanged;

  const _SidebarBranchSwitcher({
    required this.branches,
    required this.activeBranchId,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final sidebarTheme = Theme.of(context).extension<SidebarTheme>()!;
    final isDark = AppColors.isDark(context);

    final activeBranch = branches.firstWhere(
          (b) => b.id == activeBranchId,
      orElse: () => const BranchOption(id: '', label: AppStrings.mainBranchLabel),
    );

    final radius = BorderRadius.circular(AppRadius.md.r); // تعديل هندسي للـ .r

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.all(AppSpacing.md.w),
        child: PopupMenuButton<String>(
          tooltip: AppStrings.switchBranchTooltip,
          position: PopupMenuPosition.over,
          surfaceTintColor: Colors.transparent,
          constraints: BoxConstraints(minWidth: 180.w, maxWidth: 230.w),
          shape: RoundedRectangleBorder(
            borderRadius: radius,
            side: BorderSide(
              color: AppColors.borderOf(context).withValues(alpha: 0.25),
              width: 1.w,
            ),
          ),
          onSelected: onChanged,
          itemBuilder: (context) => [
            for (final branch in branches)
              PopupMenuItem<String>(
                value: branch.id,
                child: Row(
                  children: [
                    Icon(
                      branch.id == activeBranchId ? Icons.store_rounded : Icons.store_outlined,
                      size: 18.sp,
                      color: branch.id == activeBranchId ? scheme.primary : AppColors.textSecondaryOf(context),
                    ),
                    SizedBox(width: 10.w),
                    Expanded(
                      child: ReusableText(
                        branch.label,
                        style: TextStyle(
                          color: branch.id == activeBranchId ? scheme.primary : AppColors.textPrimaryOf(context),
                          fontWeight: branch.id == activeBranchId ? FontWeight.bold : FontWeight.w500,
                          fontSize: 12.5.sp,
                        ),
                      ),
                    ),
                    if (branch.id == activeBranchId) Icon(Icons.check_rounded, color: scheme.primary, size: 18.sp),
                  ],
                ),
              ),
          ],
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
            decoration: BoxDecoration(
              color: AppColors.surfaceHighOf(context),
              borderRadius: BorderRadius.circular(AppRadius.sm.r),
              border: Border.all(
                color: sidebarTheme.dividerColor.withValues(alpha: isDark ? 0.2 : 0.35),
                width: 1.w,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.1 : 0.015),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(6.w),
                  decoration: BoxDecoration(
                    color: scheme.primary.withValues(alpha: 0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.storefront_rounded,
                    color: scheme.primary,
                    size: 16.sp,
                  ),
                ),
                SizedBox(width: 10.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ReusableText(
                        AppStrings.currentBranchLabel,
                        style: TextStyle(
                          color: sidebarTheme.mutedColor,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      ReusableText(
                        activeBranch.label,
                        style: TextStyle(
                          color: sidebarTheme.textColor,
                          fontSize: 12.5.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: sidebarTheme.mutedColor,
                  size: 18.sp,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Branch Switcher (collapsed) ───────────────────────────────

class _SidebarBranchCollapsed extends StatelessWidget {
  final List<BranchOption> branches;
  final String activeBranchId;
  final ValueChanged<String>? onChanged;

  const _SidebarBranchCollapsed({
    required this.branches,
    required this.activeBranchId,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = AppColors.isDark(context);
    final radius = BorderRadius.circular(AppRadius.md.r);

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 12.h),
        child: PopupMenuButton<String>(
          tooltip: AppStrings.switchBranchTooltip,
          position: PopupMenuPosition.over,
          surfaceTintColor: Colors.transparent,
          constraints: BoxConstraints(minWidth: 180.w, maxWidth: 230.w),
          shape: RoundedRectangleBorder(
            borderRadius: radius,
            side: BorderSide(
              color: AppColors.borderOf(context).withValues(alpha: 0.25),
              width: 1.w,
            ),
          ),
          onSelected: onChanged,
          itemBuilder: (context) => [
            for (final branch in branches)
              PopupMenuItem<String>(
                value: branch.id,
                child: Row(
                  children: [
                    Icon(
                      branch.id == activeBranchId ? Icons.store_rounded : Icons.store_outlined,
                      size: 18.sp,
                      color: branch.id == activeBranchId ? scheme.primary : AppColors.textSecondaryOf(context),
                    ),
                    SizedBox(width: 10.w),
                    Expanded(
                      child: ReusableText(
                        branch.label,
                        style: TextStyle(
                          color: branch.id == activeBranchId ? scheme.primary : AppColors.textPrimaryOf(context),
                          fontWeight: branch.id == activeBranchId ? FontWeight.bold : FontWeight.w500,
                          fontSize: 12.5.sp,
                        ),
                      ),
                    ),
                    if (branch.id == activeBranchId) Icon(Icons.check_rounded, color: scheme.primary, size: 18.sp),
                  ],
                ),
              ),
          ],
          child: Container(
            padding: EdgeInsets.all(10.w),
            decoration: BoxDecoration(
              color: AppColors.surfaceHighOf(context),
              borderRadius: BorderRadius.circular(AppRadius.sm.r),
              border: Border.all(
                color: AppColors.borderOf(context).withValues(alpha: isDark ? 0.2 : 0.35),
                width: 1.w,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: isDark ? 0.1 : 0.015),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(
              Icons.storefront_rounded,
              color: scheme.primary,
              size: 18.sp,
            ),
          ),
        ),
      ),
    );
  }
}