import 'package:flutter/material.dart';
import 'package:toastification/toastification.dart';

import 'reusable_text.dart';

/// المكون الموحد لإظهار الـ Snackbar ضمن مكتبة المكونات المشتركة (Reusables).
class ReusableSnackbar {
  ReusableSnackbar._();

  static void show(
    String title, 
    String message, {
    required Color primaryColor,
    ToastificationType type = ToastificationType.info,
    Alignment alignment = Alignment.topCenter,
    Duration duration = const Duration(seconds: 4),
  }) {
    toastification.show(
      type: type,
      style: ToastificationStyle.minimal,
      primaryColor: primaryColor,
      title: ReusableText(
        title,
        fontSizeOverride: 13,
        fontWeight: FontWeight.w700,
      ),
      description: ReusableText(
        message,
        fontSizeOverride: 11,
        fontWeight: FontWeight.w500,
      ),
      alignment: alignment,
      direction: TextDirection.rtl,
      autoCloseDuration: duration,
      showProgressBar: true,
      closeButton: const ToastCloseButton(),
      dragToClose: true,
      animationDuration: const Duration(milliseconds: 300),
    );
  }
}
