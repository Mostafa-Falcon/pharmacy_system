import 'package:flutter/material.dart';

import '../../../core/theme/app_sizes.dart';
import 'index.dart';

class ReusableStateView extends StatelessWidget {
  const ReusableStateView({
    super.key,
    required this.message,
    this.icon,
    this.title,
    this.action,
    this.compact = false,
  });

  const ReusableStateView.empty({
    super.key,
    required this.message,
    this.title,
    this.icon = Icons.inbox_outlined,
    this.action,
    this.compact = false,
  });

  const ReusableStateView.permissionDenied({
    super.key,
    required this.message,
    this.title,
    this.icon = Icons.lock_outline_rounded,
    this.action,
    this.compact = false,
  });

  final String? title;
  final String message;
  final IconData? icon;
  final Widget? action;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: EdgeInsets.all(compact ? AppSpacing.md : AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: compact ? 36 : 52, color: scheme.outline),
                SizedBox(height: compact ? AppSpacing.sm : AppSpacing.md),
              ],
              if (title != null && title!.trim().isNotEmpty) ...[
                ReusableText.subtitle(
                  title!,
                  textAlign: TextAlign.center,
                  fontWeight: FontWeight.w800,
                ),
                SizedBox(height: AppSpacing.xs),
              ],
              ReusableText.body(
                message,
                textAlign: TextAlign.center,
                color: scheme.onSurfaceVariant,
                height: 1.45,
              ),
              if (action != null) ...[
                SizedBox(height: AppSpacing.md),
                action!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}