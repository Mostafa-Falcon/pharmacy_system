import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import 'index.dart';

enum ReusableBadgeTone { success, warning, danger, neutral, info }

class ReusableBadge extends StatelessWidget {
  const ReusableBadge.tone({
    super.key,
    required this.label,
    required this.tone,
    this.fontSize,
  }) : color = null;

  const ReusableBadge.color({
    super.key,
    required this.label,
    required this.color,
    this.fontSize,
  }) : tone = null;

  final String label;
  final ReusableBadgeTone? tone;
  final Color? color;
  final double? fontSize;

  (Color foreground, Color background) _resolveFromTone(
    BuildContext context,
    ReusableBadgeTone tone,
  ) {
    final scheme = Theme.of(context).colorScheme;
    return switch (tone) {
      ReusableBadgeTone.success => (
          AppColors.success,
          AppColors.successSoftOf(context),
        ),
      ReusableBadgeTone.warning => (
          AppColors.warning,
          AppColors.warningSoftOf(context),
        ),
      ReusableBadgeTone.danger => (
          AppColors.error,
          AppColors.errorSoftOf(context),
        ),
      ReusableBadgeTone.info => (AppColors.info, AppColors.infoSoftOf(context)),
      ReusableBadgeTone.neutral => (
          scheme.onSurfaceVariant,
          scheme.surfaceContainerHigh,
        ),
    };
  }

  @override
  Widget build(BuildContext context) {
    final Color foreground;
    final Color background;

    final selectedTone = tone;
    final directColor = color;

    if (selectedTone != null) {
      (foreground, background) = _resolveFromTone(context, selectedTone);
    } else {
      foreground = directColor!;
      background = directColor.withValues(alpha: 0.10);
    }

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.xxs,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: ReusableText(
        label,
        color: foreground,
        fontWeight: FontWeight.w800,
        fontSize: fontSize ?? 11,
      ),
    );
  }
}