import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';

class FormCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double? maxWidth;

  const FormCard({
    super.key,
    required this.child,
    this.padding,
    this.maxWidth,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = AppColors.isDark(context);

    // توحيد الحواف بـ .r لضمان Responsiveness كامل للحواف
    final radius = (AppRadius.lg + 4).r;

    return Center( // لضمان إن الكارت يفضل في النص بالظبط لو الـ maxWidth اتحقق على الشاشات الكبيرة
      child: Container(
        width: double.infinity,
        constraints: maxWidth != null ? BoxConstraints(maxWidth: maxWidth!.w) : null, // إضافة .w للـ maxWidth لضمان التناسق
        padding: padding ?? EdgeInsets.all(AppSpacing.lg.w),
        decoration: BoxDecoration(
          color: AppColors.surfaceOf(context),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(
            color: AppColors.borderOf(context).withValues(alpha: isDark ? 0.25 : 0.35),
            width: 1.w,
          ),
          boxShadow: [
            // ظلال ناعمة جداً تمنح عمقاً بصرياً فخماً دون تشويه التصميم
            BoxShadow(
              color: scheme.shadow.withValues(alpha: isDark ? 0.2 : 0.03),
              blurRadius: 16,
              spreadRadius: 0, // شيلنا الـ spread عشان الظل يفرش بنعومة وانسيابية
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: child,
      ),
    );
  }
}