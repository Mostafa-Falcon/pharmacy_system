import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../theme/app_colors.dart'; // سحبنا كلاس الألوان للأمان والديناميكية مع الدارك مود
import '../../theme/app_sizes.dart';  // عشان الـ Radius الموحد للسيستم
import 'reusable_text.dart';

class Tag extends StatelessWidget {
  final String label;
  final Color color;

  const Tag({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    final isDark = AppColors.isDark(context);

    // استخدام حواف ناعمة ودائرية تليق بالتاجات العصرية
    final radius = BorderRadius.circular(AppRadius.sm.w);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 3.h),
      decoration: BoxDecoration(
        // بنزود الـ alpha تكة في الدارك مود عشان التاج ينور وميطفيش
        color: color.withValues(alpha: isDark ? 0.12 : 0.06),
        borderRadius: radius,
        border: Border.all(
          color: color.withValues(alpha: isDark ? 0.25 : 0.15),
          width: 0.8.w, // برودر رفيع جداً وناعم عشان ميبقاش حاد
        ),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: ReusableText(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 10.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
      ),
    );
  }
}
