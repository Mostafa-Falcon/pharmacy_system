import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../models/sales/sale_model.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import '../../utils/format_utils.dart';
import '../../constants/app_strings.dart';
import 'reusable_dialog.dart';
import 'reusable_text.dart';
import 'reusable_button.dart';

class SaleDetailsDialog extends StatelessWidget {
  final SaleModel sale;

  const SaleDetailsDialog({super.key, required this.sale});

  static void show(BuildContext context, SaleModel sale) {
    showDialog(
      context: context,
      builder: (ctx) => SaleDetailsDialog(sale: sale),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ReusableDialog(
      title: AppStrings.saleDetailsTitle.replaceFirst('%s', sale.id.substring(0, 8).toUpperCase()),
      maxWidth: 950.w,
      children: [
        // Top Info
        Wrap(
          spacing: 24.w,
          runSpacing: 12.h,
          children: [
            _infoItem(AppStrings.invoiceNumberLabel, '#${sale.id.substring(0, 8).toUpperCase()}'),
            _infoItem(AppStrings.date, formatDateTime(sale.createdAt)),
            _infoItem(AppStrings.status, AppStrings.invoiceLabelSales),
            _infoItem(AppStrings.customerNameLabel, sale.customerName ?? AppStrings.cashCustomer),
            _infoItem(AppStrings.paymentMethodLabel, sale.paymentMethod),
          ],
        ),
        SizedBox(height: AppSpacing.lg.h),
        // Items Table
        const ReusableText(AppStrings.itemsTitle, style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: AppSpacing.sm.h),
        _buildItemsTable(context),
        SizedBox(height: AppSpacing.lg.h),
        // Totals and Payments
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Totals column
            Expanded(
              flex: 1,
              child: Column(
                children: [
                  _totalRow(AppStrings.total, formatMoney(sale.totalAmount)),
                  _totalRow(AppStrings.discount, '- ${formatMoney(sale.discount ?? 0)}'),
                  _totalRow(AppStrings.tax, '+ ${formatMoney(sale.taxAmount ?? 0)}'),
                  _totalRow('شحن وتوصيل', '+ ${formatMoney(0)}'), 
                  const Divider(),
                  _totalRow(AppStrings.finalTotal, formatMoney(sale.finalAmount), isBold: true),
                  _totalRow('مدفوعات المبيعات', formatMoney(sale.paidAmount ?? sale.finalAmount)),
                  _totalRow('المتبقي', formatMoney(sale.dueAmount), color: sale.dueAmount > 0 ? AppColors.error : AppColors.success),
                ],
              ),
            ),
            SizedBox(width: AppSpacing.xl.w),
            // Payments column
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ReusableText(AppStrings.paymentInfo, style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: AppSpacing.sm.h),
                  _buildPaymentsTable(context),
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: AppSpacing.xl.h),
        // Footer Buttons
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ReusableButton(
              text: AppStrings.packing,
              prefixIcon: Icons.inventory_2_rounded,
              color: AppColors.success,
              onPressed: () {},
            ),
            SizedBox(width: 12.w),
            ReusableButton(
              text: AppStrings.printInvoice,
              prefixIcon: Icons.print_rounded,
              color: AppColors.info,
              onPressed: () {},
            ),
            SizedBox(width: 12.w),
            ReusableButton(
              text: AppStrings.close,
              type: ButtonType.outlined,
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      ],
    );
  }

  Widget _infoItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ReusableText(label, style: TextStyle(fontSize: 10.sp, color: Colors.grey.shade600)),
        ReusableText(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _totalRow(String label, String value, {bool isBold = false, Color? color}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ReusableText(label, style: TextStyle(fontSize: 12.sp, fontWeight: isBold ? FontWeight.bold : null)),
          ReusableText(value, style: TextStyle(fontSize: 12.sp, fontWeight: isBold ? FontWeight.w900 : FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  Widget _buildItemsTable(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.success.withValues(alpha: 0.5)),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Column(
        children: [
          Container(
            color: AppColors.success,
            padding: EdgeInsets.symmetric(vertical: 8.h),
            child: Row(
              children: [
                _headerCell('#', width: 40),
                _headerCell(AppStrings.cartProduct, flex: 3),
                _headerCell(AppStrings.cartQuantity, flex: 1),
                _headerCell('تاريخ الصلاحية', flex: 2),
                _headerCell(AppStrings.cartPrice, flex: 2),
                _headerCell(AppStrings.cartDiscount, flex: 1),
                _headerCell(AppStrings.tax, flex: 1),
                _headerCell('السعر شامل الضريبة', flex: 2),
                _headerCell(AppStrings.cartTotal, flex: 2),
              ],
            ),
          ),
          ...sale.items.asMap().entries.map((e) {
            final i = e.key;
            final item = e.value;
            return Container(
              padding: EdgeInsets.symmetric(vertical: 8.h),
              decoration: BoxDecoration(border: Border(top: BorderSide(color: scheme.outlineVariant.withValues(alpha: 0.3)))),
              child: Row(
                children: [
                  _itemCell('${i + 1}', width: 40),
                  _itemCell(item.medicineName, flex: 3, isBold: true),
                  _itemCell('${item.quantity} علبة', flex: 1),
                  _itemCell('2027-03-31', flex: 2), 
                  _itemCell(formatMoney(item.unitPrice), flex: 2),
                  _itemCell(formatMoney(0), flex: 1),
                  _itemCell(formatMoney(0), flex: 1),
                  _itemCell(formatMoney(item.unitPrice), flex: 2),
                  _itemCell(formatMoney(item.totalPrice), flex: 2, isBold: true),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildPaymentsTable(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.success.withValues(alpha: 0.5)),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Column(
        children: [
          Container(
            color: AppColors.success,
            padding: EdgeInsets.symmetric(vertical: 8.h),
            child: Row(
              children: [
                _headerCell('#', width: 40),
                _headerCell(AppStrings.date, flex: 2),
                _headerCell(AppStrings.invoiceNumberLabel, flex: 2),
                _headerCell(AppStrings.amountPaid, flex: 2),
                _headerCell(AppStrings.method, flex: 2),
                _headerCell(AppStrings.status, flex: 1),
                _headerCell('إجراءات', flex: 2),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.h),
            child: const Center(child: ReusableText('لا يوجد سجل')),
          ),
        ],
      ),
    );
  }

  Widget _headerCell(String text, {double? width, int? flex}) {
    final cell = ReusableText(text, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11.sp), textAlign: TextAlign.center);
    return flex != null ? Expanded(flex: flex, child: cell) : SizedBox(width: width?.w, child: cell);
  }

  Widget _itemCell(String text, {double? width, int? flex, bool isBold = false}) {
    final cell = ReusableText(text, style: TextStyle(fontSize: 11.sp, fontWeight: isBold ? FontWeight.bold : null), textAlign: TextAlign.center);
    return flex != null ? Expanded(flex: flex, child: cell) : SizedBox(width: width?.w, child: cell);
  }
}
