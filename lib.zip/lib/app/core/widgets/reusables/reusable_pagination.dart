import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/theme/app_sizes.dart';
import 'index.dart';

class ReusablePagination extends StatelessWidget {
  final int currentPage;
  final int pageCount;
  final VoidCallback onNextPage;
  final VoidCallback onPreviousPage;
  final int? pageSize;
  final List<int> pageSizeOptions;
  final ValueChanged<int>? onPageSizeChanged;
  final String? itemLabel;
  final bool showPageSizeSelector;

  const ReusablePagination({
    super.key,
    required this.currentPage,
    required this.pageCount,
    required this.onNextPage,
    required this.onPreviousPage,
    this.pageSize,
    this.pageSizeOptions = const [25, 50, 100, 250, 500, 1000],
    this.onPageSizeChanged,
    this.itemLabel,
    this.showPageSizeSelector = true,
  });

  @override
  Widget build(BuildContext context) {
    final page = currentPage + 1;
    final isMobile = MediaQuery.of(context).size.width < 600;

    final effectiveItemLabel = itemLabel ?? 'عنصر';

    final pageSizeSelector = showPageSizeSelector && onPageSizeChanged != null
        ? Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ReusableText(
                'عرض',
                style: TextStyle(
                  fontSize: 12.5.sp,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Cairo',
                ),
              ),
              SizedBox(width: AppSpacing.xs.w),
              ReusableDropdown<int>(
                value: pageSize,
                hintText: 'حجم الصفحة',
                items: pageSizeOptions,
                isCompact: true,
                itemAsString: (value) => '$value',
                onChanged: (value) {
                  if (value != null) onPageSizeChanged!(value);
                },
              ),
              SizedBox(width: AppSpacing.xs.w),
              ReusableText(
                effectiveItemLabel,
                style: TextStyle(
                  fontSize: 12.5.sp,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Cairo',
                ),
              ),
            ],
          )
        : const SizedBox.shrink();

    final navControls = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          tooltip: 'السابق',
          onPressed: currentPage > 0 ? onPreviousPage : null,
          icon: Icon(Icons.chevron_right_rounded, size: 22.sp),
          splashRadius: 20.r,
        ),
        ReusableText(
          'صفحة $page من $pageCount',
          style: TextStyle(
            fontSize: 12.5.sp,
            fontWeight: FontWeight.bold,
            fontFamily: 'Cairo',
          ),
        ),
        IconButton(
          tooltip: 'التالي',
          onPressed: page < pageCount ? onNextPage : null,
          icon: Icon(Icons.chevron_left_rounded, size: 22.sp),
          splashRadius: 20.r,
        ),
      ],
    );

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w, vertical: AppSpacing.xs.h),
      child: isMobile
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (pageSizeSelector is Row) Center(child: pageSizeSelector),
                if (pageSizeSelector is Row) SizedBox(height: AppSpacing.sm.h),
                Center(child: navControls),
              ],
            )
          : Wrap(
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: AppSpacing.sm.w,
              runSpacing: AppSpacing.sm.h,
              children: [pageSizeSelector, navControls],
            ),
    );
  }
}
