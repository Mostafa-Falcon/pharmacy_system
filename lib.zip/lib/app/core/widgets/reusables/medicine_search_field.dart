import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:collection/collection.dart';

import '../../theme/app_sizes.dart';
import '../../services/admin/branch_data_service.dart';
import '../../services/auth/auth_service.dart';
import '../../models/inventory/medicine_model.dart';
import '../../utils/format_utils.dart';
import 'reusable_barcode_scan_dialog.dart';
import 'reusable_input.dart';
import 'reusable_text.dart';

class MedicineSearchField extends StatefulWidget {
  final ValueChanged<MedicineModel> onSelected;
  final String label;
  final String hint;
  final bool autofocus;
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final List<MedicineModel>? customItems;
  final bool clearOnSelect;
  final ValueChanged<String>? onChanged;

  const MedicineSearchField({
    super.key,
    required this.onSelected,
    this.label = 'ابحث عن صنف أو امسح الباركود...',
    this.hint = 'اكتب اسم الصنف أو SKU...',
    this.autofocus = false,
    this.controller,
    this.focusNode,
    this.customItems,
    this.clearOnSelect = true,
    this.onChanged,
  });

  @override
  State<MedicineSearchField> createState() => _MedicineSearchFieldState();
}

class _MedicineSearchFieldState extends State<MedicineSearchField> {
  final LayerLink _layerLink = LayerLink();
  FocusNode? _internalFocusNode;
  late final TextEditingController _controller;
  OverlayEntry? _overlayEntry;
  List<MedicineModel> _results = [];
  int _selectedIndex = -1;
  bool _isOverlayOpen = false;

  FocusNode get _focusNode => widget.focusNode ?? (_internalFocusNode ??= FocusNode());

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TextEditingController();
    _focusNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    _focusNode.removeListener(_onFocusChange);
    _internalFocusNode?.dispose();
    if (widget.controller == null) _controller.dispose();
    _overlayEntry?.remove();
    _overlayEntry = null;
    super.dispose();
  }

  void _onFocusChange() {
    if (!_focusNode.hasFocus) {
      // Delay hiding to allow for clicks on results
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted && !_focusNode.hasFocus) {
          _hideOverlay();
        }
      });
    }
  }

  void _showOverlay() {
    if (_isOverlayOpen) {
      _overlayEntry?.markNeedsBuild();
      return;
    }

    final overlay = Overlay.of(context);
    _overlayEntry = _createOverlayEntry();
    overlay.insert(_overlayEntry!);
    setState(() => _isOverlayOpen = true);
  }

  void _hideOverlay() {
    if (!mounted) return;
    _overlayEntry?.remove();
    _overlayEntry = null;
    _isOverlayOpen = false;
    _selectedIndex = -1;
    if (mounted) {
      setState(() {});
    }
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 5),
          child: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(AppRadius.md.r),
            clipBehavior: Clip.antiAlias,
            child: Container(
              constraints: BoxConstraints(maxHeight: 350.h),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: _results.isEmpty
                  ? Padding(
                      padding: EdgeInsets.all(16.w),
                      child: const Center(child: ReusableText('لا توجد نتائج مطابقة')),
                    )
                  : ListView.separated(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      itemCount: _results.length,
                      separatorBuilder: (_, index) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final medicine = _results[index];
                        final isSelected = index == _selectedIndex;
                        return _buildItem(medicine, isSelected);
                      },
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildItem(MedicineModel medicine, bool isSelected) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () => _selectItem(medicine),
      child: Container(
        color: isSelected ? scheme.primary.withValues(alpha: 0.1) : null,
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Icon(Icons.medication_rounded, size: 20.sp, color: scheme.primary),
            ),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ReusableText(medicine.name, style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.bold)),
                  ReusableText(
                    'الباركود: ${medicine.barcodes.firstOrNull ?? "---"} | المخزون: ${medicine.quantity}',
                    style: TextStyle(fontSize: 11.sp, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                ReusableText(FormatUtils.currency(medicine.sellPrice), style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w900, color: scheme.primary)),
                if (medicine.buyPrice > 0)
                  ReusableText('شراء: ${FormatUtils.currency(medicine.buyPrice)}', style: TextStyle(fontSize: 10.sp, color: scheme.onSurfaceVariant)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _selectItem(MedicineModel medicine) {
    if (!mounted) return;
    widget.onSelected(medicine);
    if (widget.clearOnSelect) {
      _controller.clear();
      widget.onChanged?.call('');
    }
    _hideOverlay();
    _focusNode.requestFocus();
  }

  void _onChanged(String value) {
    widget.onChanged?.call(value);
    final query = value.trim().toLowerCase();
    if (query.isEmpty) {
      setState(() {
        _results = [];
      });
      _hideOverlay();
      return;
    }

    final allItems = widget.customItems ?? BranchDataService.getMedicines(branchId: AuthService.currentBranchId);
    final filteredResults = allItems.where((m) => !m.isDeleted && m.isActive).where((m) {
      return m.name.toLowerCase().contains(query) ||
             (m.nameEn?.toLowerCase().contains(query) ?? false) ||
             m.barcodes.any((b) => b.toLowerCase().contains(query));
    }).toList();

    setState(() {
      _results = filteredResults;
      _selectedIndex = _results.isNotEmpty ? 0 : -1;
    });

    // Check for exact barcode match to auto-select
    final exactMatch = _results.firstWhereOrNull((m) => m.barcodes.any((b) => b.toLowerCase() == query));
    if (exactMatch != null) {
      _selectItem(exactMatch);
      return;
    }

    _showOverlay();
  }

  KeyEventResult _onKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;

    if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      if (_results.isNotEmpty) {
        setState(() {
          _selectedIndex = (_selectedIndex + 1) % _results.length;
        });
        _overlayEntry?.markNeedsBuild();
        return KeyEventResult.handled;
      }
    } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      if (_results.isNotEmpty) {
        setState(() {
          _selectedIndex = (_selectedIndex - 1 + _results.length) % _results.length;
        });
        _overlayEntry?.markNeedsBuild();
        return KeyEventResult.handled;
      }
    } else if (event.logicalKey == LogicalKeyboardKey.enter) {
      if (_selectedIndex >= 0 && _selectedIndex < _results.length) {
        _selectItem(_results[_selectedIndex]);
        return KeyEventResult.handled;
      }
    } else if (event.logicalKey == LogicalKeyboardKey.escape) {
      _hideOverlay();
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: Focus(
        onKeyEvent: _onKeyEvent,
        child: ReusableInput(
          controller: _controller,
          focusNode: _focusNode,
          label: widget.label,
          hint: widget.hint,
          autofocus: widget.autofocus,
          onChanged: _onChanged,
          onFieldSubmitted: (v) {
            if (_selectedIndex >= 0 && _selectedIndex < _results.length) {
              _selectItem(_results[_selectedIndex]);
            }
          },
          prefixIcon: const Icon(Icons.search_rounded),
          suffixIcon: IconButton(
            icon: const Icon(Icons.qr_code_scanner_rounded),
            onPressed: () async {
              final code = await BarcodeScanDialog.show(context);
              if (code != null) {
                _controller.text = code;
                _onChanged(code);
              }
            },
          ),
        ),
      ),
    );
  }
}
