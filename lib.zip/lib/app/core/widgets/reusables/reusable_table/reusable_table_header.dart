import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../reusable_text.dart';
import 'reusable_table_column.dart';

class ReusableTableHeader<T> extends StatelessWidget {
  final List<ReusableTableColumn<T>> columns;
  final String? sortColumnId;
  final bool isSortAscending;
  final ValueChanged<String>? onSort;
  final bool showCheckbox;
  final bool isAllSelected;
  final ValueChanged<bool>? onToggleAll;
  final double rowHeight;
  final Color? backgroundColor;
  final Color? borderColor;
  final bool hasActions;

  const ReusableTableHeader({
    super.key,
    required this.columns,
    this.sortColumnId,
    this.isSortAscending = true,
    this.onSort,
    this.showCheckbox = false,
    this.isAllSelected = false,
    this.onToggleAll,
    required this.rowHeight,
    this.backgroundColor,
    this.borderColor,
    required this.hasActions,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final visibleColumns = columns.where((c) => c.isVisible).toList();

    return Container(
      height: rowHeight, // شيلنا الـ .h لثبات هندسة الـ Header
      decoration: BoxDecoration(
        color: backgroundColor ?? scheme.surfaceContainerLow,
        border: Border(
          bottom: BorderSide(color: borderColor ?? scheme.outline.withValues(alpha: 0.3), width: 1.2),
        ),
      ),
      child: Row(
        children: [
          if (showCheckbox)
            SizedBox(
              width: 56.w, // متناسقة بالملي
              child: Center(
                child: Transform.scale(
                  scale: 0.9,
                  child: Checkbox(
                    value: isAllSelected,
                    onChanged: (val) => onToggleAll?.call(val ?? false),
                    activeColor: scheme.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.r)),
                  ),
                ),
              ),
            ),
          if (hasActions) SizedBox(width: 100.w), // متناسق مع البودي - تم نقله للبداية
          for (int i = 0; i < visibleColumns.length; i++)
            visibleColumns[i].flex > 0
                ? Expanded(
                    flex: visibleColumns[i].flex,
                    child: _HeaderCell<T>(
                      column: visibleColumns[i],
                      isSorted: sortColumnId == visibleColumns[i].id,
                      isAscending: isSortAscending,
                      onSort: onSort,
                    ),
                  )
                : _HeaderCell<T>(
                    column: visibleColumns[i],
                    isSorted: sortColumnId == visibleColumns[i].id,
                    isAscending: isSortAscending,
                    onSort: onSort,
                  ),
        ],
      ),
    );
  }
}

class _HeaderCell<T> extends StatelessWidget {
  final ReusableTableColumn<T> column;
  final bool isSorted;
  final bool isAscending;
  final ValueChanged<String>? onSort;

  const _HeaderCell({
    required this.column,
    required this.isSorted,
    required this.isAscending,
    this.onSort,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isSortable = column.isSortable;

    return SizedBox(
      width: column.flex > 0 ? null : (column.width ?? 160.w),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isSortable ? () => onSort?.call(column.id) : null,
          hoverColor: scheme.primary.withValues(alpha: 0.04),
          child: Align(
            alignment: column.alignment ?? (column.isNumeric ? Alignment.centerLeft : Alignment.centerRight),
            child: Padding(
              padding: column.cellPadding ?? EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: ReusableText(
                      column.title,
                      style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.bold,
                        color: isSorted ? scheme.primary : scheme.onSurfaceVariant,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (isSortable) ...[
                    SizedBox(width: 6.w),
                    Icon(
                      isSorted
                          ? (isAscending ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded)
                          : Icons.unfold_more_rounded,
                      size: 16.sp,
                      color: isSorted ? scheme.primary : scheme.onSurfaceVariant.withValues(alpha: 0.5),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}