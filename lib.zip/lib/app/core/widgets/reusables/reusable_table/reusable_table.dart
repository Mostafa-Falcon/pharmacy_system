import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'reusable_table_column.dart';
import 'reusable_table_header.dart';
import 'reusable_table_body.dart';
import 'reusable_table_footer.dart';

import '../reusable_text.dart';

export 'reusable_table_column.dart';

class ReusableTable<T> extends StatefulWidget {
  final List<ReusableTableColumn<T>> columns;
  final List<T> items;
  final String? sortColumnId;
  final bool isSortAscending;
  final ValueChanged<String>? onSort;
  final bool showCheckbox;
  final Set<String> selectedIds;
  final ValueChanged<String>? onSelectRow;
  final ValueChanged<bool>? onToggleAll;
  final String Function(T item)? rowIdGetter;
  final ValueChanged<T>? onTapRow;
  final ValueChanged<T>? onLongPressRow;
  final Widget Function(T item)? rowActions;
  final bool showPagination;
  final int currentPage;
  final int totalPages;
  final int totalItems;
  final int pageSize;
  final List<int> pageSizeOptions;
  final ValueChanged<int>? onPageSizeChanged;
  final VoidCallback? onNextPage;
  final VoidCallback? onPreviousPage;
  final VoidCallback? onFirstPage;
  final VoidCallback? onLastPage;
  final ValueChanged<int>? onGoToPage;
  final String? itemLabel;
  final bool showGoToPage;
  final bool isLoading;
  final int shimmerRows;
  final Widget? emptyState;
  final double headerRowHeight;
  final double bodyRowHeight;
  final Color? headerBackgroundColor;
  final Color? borderColor;
  final BorderRadiusGeometry? borderRadius;
  final EdgeInsetsGeometry? padding;
  final Widget? headerTrailing;
  final Widget Function(BuildContext context, int index)? rowBuilder;
  final Widget Function(BuildContext context, T item, ReusableTableColumn<T> column)? cellOverrideBuilder;
  final List<Widget>? bulkActions;
  final Widget? tableFooter;

  const ReusableTable({
    super.key,
    required this.columns,
    required this.items,
    this.sortColumnId,
    this.isSortAscending = true,
    this.onSort,
    this.showCheckbox = false,
    this.selectedIds = const {},
    this.onSelectRow,
    this.onToggleAll,
    this.rowIdGetter,
    this.onTapRow,
    this.onLongPressRow,
    this.bulkActions,
    this.rowActions,
    this.tableFooter,
    this.showPagination = true,
    this.currentPage = 1,
    this.totalPages = 1,
    this.totalItems = 0,
    this.pageSize = 10,
    this.pageSizeOptions = const [5, 10, 20, 50, 100],
    this.onPageSizeChanged,
    this.onNextPage,
    this.onPreviousPage,
    this.onFirstPage,
    this.onLastPage,
    this.onGoToPage,
    this.itemLabel,
    this.showGoToPage = false,
    this.isLoading = false,
    this.shimmerRows = 5,
    this.emptyState,
    this.headerRowHeight = 52.0, // ارتفاع قياسي مريح ومناسب
    this.bodyRowHeight = 56.0,   // مساحة تنفس مثالية للصفوف
    this.headerBackgroundColor,
    this.borderColor,
    this.borderRadius,
    this.padding,
    this.headerTrailing,
    this.rowBuilder,
    this.cellOverrideBuilder,
  });

  @override
  State<ReusableTable<T>> createState() => _ReusableTableState<T>();
}

class _ReusableTableState<T> extends State<ReusableTable<T>> {
  final ScrollController _horizontalController = ScrollController();
  final ScrollController _verticalController = ScrollController();

  @override
  void dispose() {
    _horizontalController.dispose();
    _verticalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final columns = widget.columns;
    final items = widget.items;
    final sortColumnId = widget.sortColumnId;
    final isSortAscending = widget.isSortAscending;
    final onSort = widget.onSort;
    final showCheckbox = widget.showCheckbox;
    final selectedIds = widget.selectedIds;
    final onSelectRow = widget.onSelectRow;
    final onToggleAll = widget.onToggleAll;
    final rowIdGetter = widget.rowIdGetter;
    final onTapRow = widget.onTapRow;
    final onLongPressRow = widget.onLongPressRow;
    final rowActions = widget.rowActions;
    final bulkActions = widget.bulkActions;
    final showPagination = widget.showPagination;
    final currentPage = widget.currentPage;
    final totalPages = widget.totalPages;
    final totalItems = widget.totalItems;
    final pageSize = widget.pageSize;
    final pageSizeOptions = widget.pageSizeOptions;
    final onPageSizeChanged = widget.onPageSizeChanged;
    final onNextPage = widget.onNextPage;
    final onPreviousPage = widget.onPreviousPage;
    final onFirstPage = widget.onFirstPage;
    final onLastPage = widget.onLastPage;
    final onGoToPage = widget.onGoToPage;
    final itemLabel = widget.itemLabel;
    final showGoToPage = widget.showGoToPage;
    final isLoading = widget.isLoading;
    final shimmerRows = widget.shimmerRows;
    final emptyState = widget.emptyState;
    final headerRowHeight = widget.headerRowHeight;
    final bodyRowHeight = widget.bodyRowHeight;
    final headerBackgroundColor = widget.headerBackgroundColor;
    final borderColor = widget.borderColor;
    final borderRadius = widget.borderRadius;
    final padding = widget.padding;
    final headerTrailing = widget.headerTrailing;
    final rowBuilder = widget.rowBuilder;
    final cellOverrideBuilder = widget.cellOverrideBuilder;
    final scheme = Theme.of(context).colorScheme;
    final radius = borderRadius ?? BorderRadius.circular(12.r);
    final borderCol = borderColor ?? scheme.outline.withValues(alpha: 0.3);

    final isAllSelected = items.isNotEmpty && rowIdGetter != null && selectedIds.length == items.length;

    return LayoutBuilder(
      builder: (context, constraints) {
        // حساب إجمالي العرض الفعلي بدقة هندسية لمنع الـ Overflow والـ Layout Shifting
        double totalTableWidth = showCheckbox ? 56.w : 0; // تم زيادة مساحة الـ Checkbox لراحة المحاذاة
        for (final col in columns.where((c) => c.isVisible)) {
          totalTableWidth += col.width ?? 160.w; // زيادة طفيفة لضمان عدم حشر النصوص
        }
        if (rowActions != null) totalTableWidth += 100.w;

        // إذا كان العرض المتاح أكبر من العرض المحسوب، نستخدم العرض المتاح بالكامل
        final double finalTableWidth = totalTableWidth > constraints.maxWidth ? totalTableWidth : constraints.maxWidth;

        return Container(
          margin: padding ?? EdgeInsets.zero,
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: radius,
            border: Border.all(color: borderCol, width: 1),
            boxShadow: [
              BoxShadow(
                color: scheme.shadow.withValues(alpha: 0.03),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: radius,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: Scrollbar(
                    controller: _horizontalController,
                    interactive: true,
                    child: SingleChildScrollView(
                      controller: _horizontalController,
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      child: SizedBox(
                        width: finalTableWidth,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Header
                            Stack(
                              children: [
                                ReusableTableHeader<T>(
                                  columns: columns,
                                  sortColumnId: sortColumnId,
                                  isSortAscending: isSortAscending,
                                  onSort: onSort,
                                  showCheckbox: showCheckbox,
                                  isAllSelected: isAllSelected,
                                  onToggleAll: onToggleAll,
                                  rowHeight: headerRowHeight,
                                  backgroundColor: headerBackgroundColor ?? scheme.surfaceContainerLow.withValues(alpha: 0.6),
                                  borderColor: borderCol,
                                  hasActions: rowActions != null,
                                ),
                                if (headerTrailing != null)
                                  PositionedDirectional(
                                    end: 16.w,
                                    top: 0,
                                    bottom: 0,
                                    child: Center(child: headerTrailing),
                                  ),
                              ],
                            ),
                            // Body
                            Expanded(
                              child: Scrollbar(
                                controller: _verticalController,
                                child: SingleChildScrollView(
                                  controller: _verticalController,
                                  physics: const BouncingScrollPhysics(),
                                  child: ReusableTableBody<T>(
                                    items: items,
                                    columns: columns,
                                    showCheckbox: showCheckbox,
                                    selectedIds: selectedIds,
                                    onSelectRow: onSelectRow,
                                    onTapRow: onTapRow,
                                    onLongPressRow: onLongPressRow,
                                    rowActions: rowActions,
                                    emptyState: emptyState,
                                    isLoading: isLoading,
                                    shimmerRows: shimmerRows,
                                    rowIdGetter: rowIdGetter,
                                    rowBuilder: rowBuilder,
                                    cellOverrideBuilder: cellOverrideBuilder,
                                    rowHeight: bodyRowHeight,
                                    borderColor: borderCol,
                                  ),
                                ),
                              ),
                            ),
                            if (widget.tableFooter != null) widget.tableFooter!,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Bulk Actions Bar - Moved to bottom above footer
                if (bulkActions != null && selectedIds.isNotEmpty)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      color: scheme.surface,
                      border: Border(
                        top: BorderSide(
                          color: scheme.outlineVariant.withValues(alpha: 0.5),
                          width: 1,
                        ),
                      ),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
                    child: Row(
                      children: [
                        Icon(
                          Icons.check_circle_rounded,
                          color: scheme.primary,
                          size: 20.sp,
                        ),
                        SizedBox(width: 10.w),
                        ReusableText(
                          'تم تحديد ${selectedIds.length} ${itemLabel ?? 'عنصر'}',
                          style: TextStyle(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.bold,
                            color: scheme.onSurface,
                          ),
                        ),
                        const Spacer(),
                        Wrap(
                          spacing: 8.w,
                          children: bulkActions,
                        ),
                        SizedBox(width: 8.w),
                        IconButton(
                          icon: Icon(Icons.close_rounded, size: 18.sp, color: scheme.onSurfaceVariant),
                          onPressed: () => onToggleAll?.call(false),
                          tooltip: 'إلغاء التحديد',
                        ),
                      ],
                    ),
                  ),
                // Footer
                if (showPagination)
                  ReusableTableFooter(
                    totalItems: totalItems,
                    currentPage: currentPage,
                    totalPages: totalPages,
                    pageSize: pageSize,
                    pageSizeOptions: pageSizeOptions,
                    onPageSizeChanged: onPageSizeChanged,
                    onNextPage: onNextPage,
                    onPreviousPage: onPreviousPage,
                    onFirstPage: onFirstPage,
                    onLastPage: onLastPage,
                    onGoToPage: onGoToPage,
                    itemLabel: itemLabel,
                    showGoToPage: showGoToPage,
                    backgroundColor: scheme.surface,
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}