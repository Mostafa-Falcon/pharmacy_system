import 'package:flutter/material.dart';

class ReusableTableColumn<T> {
  final String id;
  final String title;
  final Widget Function(T item)? cellBuilder;
  final String Function(T item)? textBuilder;
  final double? width;
  final double? minWidth;
  final double? maxWidth;
  final int flex;
  final AlignmentGeometry? alignment;
  final bool isSortable;
  final bool isNumeric;
  final bool isVisible;
  final EdgeInsetsGeometry? cellPadding;
  final Widget? emptyCellWidget;

  const ReusableTableColumn({
    required this.id,
    required this.title,
    this.cellBuilder,
    this.textBuilder,
    this.width,
    this.minWidth,
    this.maxWidth,
    this.flex = 0,
    this.alignment,
    this.isSortable = false,
    this.isNumeric = false,
    this.isVisible = true,
    this.cellPadding,
    this.emptyCellWidget,
  });

  ReusableTableColumn<T> copyWith({
    String? id,
    String? title,
    Widget Function(T item)? cellBuilder,
    String Function(T item)? textBuilder,
    double? width,
    double? minWidth,
    double? maxWidth,
    int? flex,
    AlignmentGeometry? alignment,
    bool? isSortable,
    bool? isNumeric,
    bool? isVisible,
    EdgeInsetsGeometry? cellPadding,
    Widget? emptyCellWidget,
  }) {
    return ReusableTableColumn<T>(
      id: id ?? this.id,
      title: title ?? this.title,
      cellBuilder: cellBuilder ?? this.cellBuilder,
      textBuilder: textBuilder ?? this.textBuilder,
      width: width ?? this.width,
      minWidth: minWidth ?? this.minWidth,
      maxWidth: maxWidth ?? this.maxWidth,
      flex: flex ?? this.flex,
      alignment: alignment ?? this.alignment,
      isSortable: isSortable ?? this.isSortable,
      isNumeric: isNumeric ?? this.isNumeric,
      isVisible: isVisible ?? this.isVisible,
      cellPadding: cellPadding ?? this.cellPadding,
      emptyCellWidget: emptyCellWidget ?? this.emptyCellWidget,
    );
  }
}