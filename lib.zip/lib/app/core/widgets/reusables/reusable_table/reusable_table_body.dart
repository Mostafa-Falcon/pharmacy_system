import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../reusable_text.dart';
import 'reusable_table_column.dart';

class ReusableTableBody<T> extends StatelessWidget {
  final List<T> items;
  final List<ReusableTableColumn<T>> columns;
  final bool showCheckbox;
  final Set<String> selectedIds;
  final ValueChanged<String>? onSelectRow;
  final ValueChanged<T>? onTapRow;
  final ValueChanged<T>? onLongPressRow;
  final Widget Function(T item)? rowActions;
  final Widget? emptyState;
  final bool isLoading;
  final int shimmerRows;
  final double rowHeight;
  final Color? borderColor;
  final String Function(T item)? rowIdGetter;
  final Widget Function(BuildContext context, int index)? rowBuilder;
  final Widget Function(BuildContext context, T item, ReusableTableColumn<T> column)? cellOverrideBuilder;

  const ReusableTableBody({
    super.key,
    required this.items,
    required this.columns,
    this.showCheckbox = false,
    this.selectedIds = const {},
    this.onSelectRow,
    this.onTapRow,
    this.onLongPressRow,
    this.rowActions,
    this.emptyState,
    this.isLoading = false,
    this.shimmerRows = 5,
    required this.rowHeight,
    this.borderColor,
    this.rowIdGetter,
    this.rowBuilder,
    this.cellOverrideBuilder,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return _ShimmerBody<T>(
        columns: columns,
        rowCount: shimmerRows,
        showCheckbox: showCheckbox,
        rowHeight: rowHeight,
        hasActions: rowActions != null,
      );
    }

    if (items.isEmpty) {
      return emptyState ?? _DefaultEmptyState();
    }

    final borderCol = borderColor ?? Theme.of(context).colorScheme.outline.withValues(alpha: 0.2);
    final visibleColumns = columns.where((c) => c.isVisible).toList();

    return Column(
      children: [
        for (int i = 0; i < items.length; i++)
          rowBuilder != null
              ? rowBuilder!(context, i)
              : _TableRow<T>(
            item: items[i],
            columns: visibleColumns,
            index: i,
            showCheckbox: showCheckbox,
            isSelected: rowIdGetter != null && selectedIds.contains(rowIdGetter!(items[i])),
            onSelect: onSelectRow != null && rowIdGetter != null ? () => onSelectRow!(rowIdGetter!(items[i])) : null,
            onTap: onTapRow != null ? () => onTapRow!(items[i]) : null,
            onLongPress: onLongPressRow != null ? () => onLongPressRow!(items[i]) : null,
            rowActions: rowActions,
            isLast: i == items.length - 1,
            borderColor: borderCol,
            rowHeight: rowHeight,
            cellOverrideBuilder: cellOverrideBuilder,
          ),
      ],
    );
  }
}

class _TableRow<T> extends StatelessWidget {
  final T item;
  final List<ReusableTableColumn<T>> columns;
  final int index;
  final bool showCheckbox;
  final bool isSelected;
  final VoidCallback? onSelect;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Widget Function(T item)? rowActions;
  final bool isLast;
  final Color borderColor;
  final double rowHeight;
  final Widget Function(BuildContext context, T item, ReusableTableColumn<T> column)? cellOverrideBuilder;

  const _TableRow({
    required this.item,
    required this.columns,
    required this.index,
    required this.showCheckbox,
    required this.isSelected,
    this.onSelect,
    this.onTap,
    this.onLongPress,
    this.rowActions,
    required this.isLast,
    required this.borderColor,
    required this.rowHeight,
    this.cellOverrideBuilder,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isEven = index % 2 == 0;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      color: isSelected
          ? scheme.primary.withValues(alpha: 0.08)
          : isEven
          ? scheme.surface
          : scheme.surfaceContainerLowest.withValues(alpha: 0.4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          hoverColor: scheme.primary.withValues(alpha: 0.03),
          splashColor: scheme.primary.withValues(alpha: 0.06),
          child: Container(
            height: rowHeight, // شيلنا الـ .h عشان ارتفاع الصف بياخد مقاس الكود الثابت بدون لغبطة التمديد
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: borderColor, width: isLast ? 0 : 0.8),
              ),
            ),
            child: Row(
              children: [
                if (showCheckbox)
                  SizedBox(
                    width: 56.w, // متطابق مع الهيدر بالظبط
                    child: Center(
                      child: Transform.scale(
                        scale: 0.9,
                        child: Checkbox(
                          value: isSelected,
                          onChanged: (_) => onSelect?.call(),
                          activeColor: scheme.primary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.r)),
                        ),
                      ),
                    ),
                  ),
                if (rowActions != null)
                  SizedBox(
                    width: 100.w,
                    child: Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.w),
                        child: rowActions!(item),
                      ),
                    ),
                  ),
                for (final column in columns)
                  column.flex > 0
                      ? Expanded(
                          flex: column.flex,
                          child: _BodyCell<T>(
                            item: item,
                            column: column,
                            overrideBuilder: cellOverrideBuilder,
                          ),
                        )
                      : _BodyCell<T>(
                          item: item,
                          column: column,
                          overrideBuilder: cellOverrideBuilder,
                        ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BodyCell<T> extends StatelessWidget {
  final T item;
  final ReusableTableColumn<T> column;
  final Widget Function(BuildContext context, T item, ReusableTableColumn<T> column)? overrideBuilder;

  const _BodyCell({
    required this.item,
    required this.column,
    this.overrideBuilder,
  });

  @override
  Widget build(BuildContext context) {
    if (overrideBuilder != null) {
      return overrideBuilder!(context, item, column);
    }

    final scheme = Theme.of(context).colorScheme;

    final cellContent = column.cellBuilder != null
        ? column.cellBuilder!(item)
        : column.textBuilder != null
        ? ReusableText(
      column.textBuilder!(item),
      style: TextStyle(
        fontSize: 13.sp,
        fontWeight: FontWeight.w500,
        color: scheme.onSurface,
      ),
      textAlign: column.alignment != null ? null : (column.isNumeric ? TextAlign.left : TextAlign.right),
    )
        : column.emptyCellWidget ??
        ReusableText(
          '—',
          style: TextStyle(
            fontSize: 13.sp,
            color: scheme.onSurfaceVariant.withValues(alpha: 0.4),
          ),
        );

    return SizedBox(
      width: column.flex > 0 ? null : (column.width ?? 160.w),
      child: Align(
        alignment: column.alignment ?? (column.isNumeric ? Alignment.centerLeft : Alignment.centerRight),
        child: Padding(
          padding: column.cellPadding ?? EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
          child: cellContent,
        ),
      ),
    );
  }
}

class _ShimmerBody<T> extends StatelessWidget {
  final List<ReusableTableColumn<T>> columns;
  final int rowCount;
  final bool showCheckbox;
  final double rowHeight;
  final bool hasActions;

  const _ShimmerBody({
    required this.columns,
    required this.rowCount,
    required this.showCheckbox,
    required this.rowHeight,
    required this.hasActions,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final visibleColumns = columns.where((c) => c.isVisible).toList();

    return Column(
      children: List.generate(rowCount, (rowIndex) {
        return Container(
          height: rowHeight,
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: scheme.outline.withValues(alpha: 0.15), width: 0.8),
            ),
          ),
          child: Row(
            children: [
              if (showCheckbox)
                SizedBox(width: 56.w, child: const Center(child: _ShimmerBox(width: 18, height: 18))),
              if (hasActions) SizedBox(width: 100.w),
              for (final column in visibleColumns)
                column.flex > 0
                  ? Expanded(
                      flex: column.flex,
                      child: _ShimmerCell(column: column, rowIndex: rowIndex),
                    )
                  : _ShimmerCell(column: column, rowIndex: rowIndex),
            ],
          ),
        );
      }),
    );
  }
}

class _ShimmerCell<T> extends StatelessWidget {
  final ReusableTableColumn<T> column;
  final int rowIndex;

  const _ShimmerCell({required this.column, required this.rowIndex});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: column.flex > 0 ? null : (column.width ?? 160.w),
      child: Align(
        alignment: column.alignment ?? Alignment.centerRight,
        child: Padding(
          padding: column.cellPadding ?? EdgeInsets.symmetric(horizontal: 16.w),
          child: _ShimmerBox(
            width: column.width != null ? (column.width! * 0.5) : (80 + (rowIndex * 20) % 60).toDouble(),
            height: 12,
          ),
        ),
      ),
    );
  }
}

class _ShimmerBox extends StatefulWidget {
  final double width;
  final double height;
  const _ShimmerBox({required this.width, required this.height});

  @override
  State<_ShimmerBox> createState() => _ShimmerBoxState();
}

class _ShimmerBoxState extends State<_ShimmerBox> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Container(
          width: widget.width.w,
          height: widget.height.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6.r),
            gradient: LinearGradient(
              colors: [
                scheme.outline.withValues(alpha: 0.1),
                scheme.outline.withValues(alpha: 0.25),
                scheme.outline.withValues(alpha: 0.1),
              ],
              stops: [
                (_controller.value - 0.2).clamp(0.0, 1.0),
                _controller.value,
                (_controller.value + 0.2).clamp(0.0, 1.0),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _DefaultEmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 48.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                color: scheme.surfaceContainerLowest,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.inbox_rounded, size: 40.sp, color: scheme.onSurfaceVariant.withValues(alpha: 0.4)),
            ),
            SizedBox(height: 16.h),
            ReusableText(
              'لا توجد بيانات متاحة حالياً',
              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}