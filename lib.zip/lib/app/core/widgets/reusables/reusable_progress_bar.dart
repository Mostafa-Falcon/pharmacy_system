import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import 'reusable_text.dart';

class ReusableProgressBar extends StatelessWidget {
  final double progress;
  final String title;
  final String? subtitle;
  final bool showPercentage;
  final double height;
  final Color? color;

  const ReusableProgressBar({
    super.key,
    required this.progress,
    required this.title,
    this.subtitle,
    this.showPercentage = true,
    this.height = 8,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final clamped = progress.clamp(0.0, 1.0);
    final percentage = (clamped * 100).toInt();
    final barColor = color ?? scheme.primary;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: ReusableText(
                title,
                style: TextStyle(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimaryOf(context),
                ),
              ),
            ),
            if (showPercentage)
              ReusableText(
                '%$percentage',
                style: TextStyle(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w900,
                  color: barColor,
                ),
              ),
          ],
        ),
        if (subtitle != null) ...[
          SizedBox(height: 2.h),
          ReusableText(
            subtitle!,
            style: TextStyle(
              fontSize: 11.sp,
              color: AppColors.textSecondaryOf(context),
            ),
          ),
        ],
        SizedBox(height: 8.h),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.pill),
          child: LinearProgressIndicator(
            value: clamped,
            minHeight: height.h,
            backgroundColor: barColor.withValues(alpha: 0.12),
            valueColor: AlwaysStoppedAnimation<Color>(barColor),
          ),
        ),
      ],
    );
  }
}
