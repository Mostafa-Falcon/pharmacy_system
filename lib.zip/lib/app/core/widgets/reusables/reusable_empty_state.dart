import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theme/app_colors.dart';
import 'reusable_text.dart';

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 32.w, vertical: 24.h), // مسافة أمان رأسية وأفقية متناسقة
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            // تصميم الأيقونة المتدلعة جوة هالة دائرية مثالية هندسياً
            Container(
              width: 96.w,
              height: 96.w, // تثبيت الـ .w للارتفاع والعرض لضمان دائرية مثالية
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: scheme.primary.withValues(alpha: 0.04),
                shape: BoxShape.circle,
              ),
              child: Container(
                width: 72.w,
                height: 72.w, // دائرية داخلية متناسقة بالملي
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: scheme.primary.withValues(alpha: 0.08),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  size: 36.sp, // مقاس مثالي متناسق مع الهالة
                  color: scheme.primary, // تباين فخم وواضح على كل الشاشات والثيمز
                ),
              ),
            ),
            SizedBox(height: 20.h),

            // العنوان الرئيسي الشيك
            ReusableText(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.bold, // خط سميك يعطي حضور للمكون البصري
                color: AppColors.textPrimaryOf(context),
              ),
            ),

            // الـ Subtitle
            if (subtitle != null) ...[
              SizedBox(height: 8.h),
              ConstrainedBox(
                constraints: BoxConstraints(maxWidth: 260.w), // تحجيم العرض لضمان نزول مريح للسطور
                child: ReusableText(
                  subtitle!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13.sp,
                    height: 1.5,
                    color: AppColors.textSecondaryOf(context),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}