import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';

class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.backgroundColor,
    this.onTap,
    this.borderRadius,
    this.showBorder = true,
    this.maxWidth,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? backgroundColor;
  final VoidCallback? onTap;
  final double? borderRadius;
  final bool showBorder;
  final double? maxWidth;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    // ربط الـ Radius بالـ ScreenUtil لضمان الـ Responsiveness
    final radiusValue = borderRadius ?? AppRadius.lg;
    final radius = BorderRadius.circular(radiusValue.r);

    final cardDecoration = BoxDecoration(
      color: backgroundColor ?? AppColors.surfaceOf(context),
      borderRadius: radius,
      border: showBorder
          ? Border.all(
        color: AppColors.borderOf(context).withValues(alpha: 0.3),
        width: 1.w, // استخدام .w لعرض دقيق وموحد للحدود
      )
          : null,
      boxShadow: [
        BoxShadow(
          color: scheme.shadow.withValues(alpha: AppColors.isDark(context) ? 0.15 : 0.03),
          blurRadius: 12,
          offset: const Offset(0, 4),
        ),
      ],
    );

    // عزل الـ Content مع الـ InkWell في Widget منفصلة للحفاظ على نظافة الكود وفصل المنطق
    Widget cardContent = Padding(
      padding: padding ?? EdgeInsets.all(AppSpacing.lg.w), // استخدام الـ Spacing System المعتمد
      child: child,
    );

    // تفعيل تأثيرات الضغط فقط إذا كان الـ onTap ممرراً فعلياً
    if (onTap != null) {
      cardContent = Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          hoverColor: scheme.primary.withValues(alpha: 0.02),
          splashColor: scheme.primary.withValues(alpha: 0.05),
          highlightColor: Colors.transparent,
          child: cardContent,
        ),
      );
    }

    return Container(
      margin: margin,
      constraints: BoxConstraints(
        maxWidth: maxWidth?.w ?? double.infinity,
        minWidth: 140.w, // نضمن أقل عرض مقبول للبطاقة لتجنب الـ Overflow
      ),
      decoration: cardDecoration,
      child: ClipRRect(
        borderRadius: radius,
        child: cardContent,
      ),
    );
  }
}