import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import 'reusable_text.dart';

class TransactionCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final List<Widget> tags;
  final String amount;
  final String? amountSubtext;
  final String date;
  final List<PopupMenuEntry<String>>? menuItems;
  final void Function(String)? onMenuSelected;
  final VoidCallback? onTap;

  const TransactionCard({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.tags,
    required this.amount,
    this.amountSubtext,
    required this.date,
    this.menuItems,
    this.onMenuSelected,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = AppColors.isDark(context);

    // توحيد الحواف بـ .r لضمان استقرار هندسي كامل
    final radius = BorderRadius.circular(AppRadius.lg.r);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: radius,
        border: Border.all(
          color: AppColors.borderOf(context).withValues(alpha: isDark ? 0.25 : 0.4),
          width: 1.w,
        ),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isDark ? 0.15 : 0.02),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            hoverColor: iconColor.withValues(alpha: 0.02),
            splashColor: iconColor.withValues(alpha: 0.06),
            highlightColor: Colors.transparent,
            child: Padding(
              padding: EdgeInsets.all(AppSpacing.lg.w),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start, // تثبيت المحاذاة من الأعلى لضمان عدم اهتزاز العناصر لو الـ Tags زادت
                children: [
                  // الأيقونة المتدلعة بهالة ناعمة
                  Container(
                    padding: EdgeInsets.all(10.w),
                    decoration: BoxDecoration(
                      color: iconColor.withValues(alpha: isDark ? 0.12 : 0.05),
                      borderRadius: BorderRadius.circular(AppRadius.md.r), // ضبط الحواف بـ .r
                    ),
                    child: Icon(
                      icon,
                      size: 20.sp, // مقاس متناسق بالملي مع الخطوط
                      color: iconColor,
                    ),
                  ),
                  SizedBox(width: AppSpacing.md.w),

                  // بيانات المعاملة والـ Tags في المنتصف
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(height: 2.h), // ترحيل رأسي خفيف لسنترة العنوان مع محاذاة الأيقونة
                        ReusableText(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13.5.sp,
                            fontWeight: FontWeight.bold, // Cairo Bold المعتمد للعناوين
                            color: AppColors.textPrimaryOf(context),
                          ),
                        ),
                        if (tags.isNotEmpty) ...[
                          SizedBox(height: 8.h), // مسافة تنفس كافية ومريحة للـ Tags
                          Wrap(
                            spacing: 6.w,
                            runSpacing: 6.h, // تناسق مسافات النزول للسطر الجديد
                            children: tags,
                          ),
                        ],
                      ],
                    ),
                  ),
                  SizedBox(width: AppSpacing.md.w),

                  // الحسبة المالية والتاريخ على اليمين محاذاتهم مظبوطة بالملي
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(height: 2.h),
                      if (amountSubtext != null) ...[
                        ReusableText(
                          amountSubtext!,
                          style: TextStyle(
                            fontSize: 11.sp,
                            decoration: TextDecoration.lineThrough,
                            fontWeight: FontWeight.w500,
                            color: AppColors.textMutedOf(context).withValues(alpha: 0.7),
                          ),
                        ),
                        SizedBox(height: 2.h),
                      ],
                      ReusableText(
                        amount,
                        style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold, // إبراز الرقم المالي بوزن عريض فخم
                          color: iconColor,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      ReusableText(
                        date,
                        style: TextStyle(
                          fontSize: 10.5.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textSecondaryOf(context),
                        ),
                      ),
                    ],
                  ),

                  // القائمة المنبثقة للتحكم
                  if (menuItems != null) ...[
                    SizedBox(width: 8.w),
                    SizedBox(
                      width: 24.w,
                      height: 24.w, // حجز مساحة ضغط ملموسة ومتناسقة عمودياً
                      child: PopupMenuButton<String>(
                        onSelected: onMenuSelected ?? (_) {},
                        icon: Icon(
                          Icons.more_vert_rounded,
                          color: AppColors.textSecondaryOf(context).withValues(alpha: 0.7),
                          size: 20.sp,
                        ),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        itemBuilder: (_) => menuItems!,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}