import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';
import 'reusable_text.dart';

class StatChip extends StatelessWidget {
  final String label;
  final dynamic count;
  final Color color;
  final IconData icon;

  const StatChip({
    super.key,
    required this.label,
    required this.count,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppColors.isDark(context);

    // توحيد الحواف بـ .r لضمان هندسة دائرية مستقرة تماماً
    final radius = BorderRadius.circular(AppRadius.md.r);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h), // تظبيط مسافة الرأس والأجناب بالملي
      decoration: BoxDecoration(
        color: color.withValues(alpha: isDark ? 0.12 : 0.06),
        borderRadius: radius,
        border: Border.all(
          color: color.withValues(alpha: isDark ? 0.25 : 0.15),
          width: 1.w,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // الهالة الدائرية حول الأيقونة
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              size: 13.sp, // مقاس متناسق بالـ .sp مع حجم الخط
              color: color,
            ),
          ),
          SizedBox(width: 8.w),

          // النصوص متوزعة بنعومة كاملة وبفصل هندسي صريح
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ReusableText(
                label,
                style: TextStyle(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w600,
                  color: isDark
                      ? AppColors.textSecondaryOf(context)
                      : color.withValues(alpha: 0.85),
                ),
              ),
              SizedBox(width: 4.w), // فصل الرقم عن الوصف بـ SizedBox أفقي صريح بالـ .w لثبات المحاذاة
              ReusableText(
                count.toString(), // تأمين تحويل الـ dynamic لنص بأمان وكفاءة
                style: TextStyle(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.bold, // Cairo Bold المعتمد لإبراز الأرقام بهيبتها
                  color: color,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}