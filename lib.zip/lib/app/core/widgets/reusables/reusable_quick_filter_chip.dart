import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import 'reusable_text.dart';

class QuickFilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color? color;

  const QuickFilterChip({
    super.key,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = AppColors.isDark(context);

    // سحب اللون النشط بدقة من الثيم الديناميكي
    final activeColor = color ?? scheme.primary;

    // توحيد الحواف بـ .r لضمان هندسة دائرية مثالية للحواف
    final radius = BorderRadius.circular(AppRadius.md.r);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180), // سرعة نقلة بصرية ناعمة ومريحة
      margin: EdgeInsetsDirectional.only(end: 8.w),
      decoration: BoxDecoration(
        color: isSelected
            ? activeColor.withValues(alpha: isDark ? 0.12 : 0.06)
            : scheme.surfaceContainerLow.withValues(alpha: 0.4),
        borderRadius: radius,
        border: Border.all(
          color: isSelected
              ? activeColor
              : AppColors.borderOf(context).withValues(alpha: 0.25),
          width: 1.2.w, // استخدام .w لعرض موحد ودقيق للحدود
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: radius,
          hoverColor: activeColor.withValues(alpha: 0.02),
          splashColor: activeColor.withValues(alpha: 0.06),
          highlightColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 6.h), // مسافات تنفس متناسقة ومريحة للمس
            child: Center(
              widthFactor: 1.0, // بيخلي الـ Center يلم العرض على قد المحتوى بالظبط
              child: ReusableText(
                label,
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w600, // خط Cairo Bold للنشط لتمييز بصري فخم
                  color: isSelected
                      ? activeColor
                      : AppColors.textSecondaryOf(context),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}