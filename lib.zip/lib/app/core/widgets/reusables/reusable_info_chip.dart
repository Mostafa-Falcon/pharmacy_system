import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../theme/app_colors.dart';
import 'reusable_text.dart';

/// شريحة معلومة صغيرة (أيقونة + نص/قيمة) للاستخدام داخل الكروت والهيدرات.
/// بتلغي تكرار `_infoChip` / `_statItem` في الشاشات.
class InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  final Color? color;

  const InfoChip({
    super.key,
    required this.icon,
    required this.label,
    this.value,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textSecondaryOf(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14.sp, color: c),
        SizedBox(width: 5.w),
        ReusableText(
          label,
          style: TextStyle(
            fontSize: 11.sp,
            fontWeight: FontWeight.w500,
            color: AppColors.textSecondaryOf(context),
          ),
        ),
        if (value != null) ...[
          SizedBox(width: 4.w),
          ReusableText(
            value!,
            style: TextStyle(
              fontSize: 11.5.sp,
              fontWeight: FontWeight.w800,
              color: c,
            ),
          ),
        ],
      ],
    );
  }
}
