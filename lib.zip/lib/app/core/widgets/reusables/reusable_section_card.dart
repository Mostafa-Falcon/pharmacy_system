import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_sizes.dart';

/// كارت قسم موحّد (Container + Column) مع فواصل اختيارية بين العناصر.
/// بيلغي تكرار `_buildSection` / `_buildSectionContainer` في الإعدادات والبروفايل.
class SectionCard extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;
  final bool dividers;

  const SectionCard({
    super.key,
    required this.children,
    this.padding,
    this.backgroundColor,
    this.dividers = true,
  });

  @override
  Widget build(BuildContext context) {
    final List<Widget> content = [];
    for (var i = 0; i < children.length; i++) {
      content.add(children[i]);
      if (dividers && i < children.length - 1) {
        content.add(Divider(
          height: 1.h,
          thickness: 1,
          color: AppColors.dividerOf(context).withValues(alpha: 0.5),
        ));
      }
    }

    return Container(
      padding: padding ?? EdgeInsets.all(AppSpacing.md.w),
      decoration: BoxDecoration(
        color: backgroundColor ?? AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(
          color: AppColors.borderOf(context).withValues(alpha: 0.3),
          width: 1.w,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: content,
      ),
    );
  }
}
