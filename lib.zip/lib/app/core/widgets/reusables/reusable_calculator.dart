import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/theme/app_colors.dart';
import 'reusable_text.dart';

class ReusableCalculator {
  ReusableCalculator._();

  static void show(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
        clipBehavior: Clip.antiAliasWithSaveLayer,
        child: Container(
          width: 320.w, // مقاس مثالي ومناسب لعرض الأزرار الأربعة بالتساوي
          padding: EdgeInsets.all(16.w),
          color: Theme.of(context).colorScheme.surface,
          child: const _CalculatorDialog(),
        ),
      ),
    );
  }
}

class _CalculatorDialog extends StatefulWidget {
  const _CalculatorDialog();

  @override
  State<_CalculatorDialog> createState() => _CalculatorDialogState();
}

class _CalculatorDialogState extends State<_CalculatorDialog> {
  String _display = '0';
  String _history = '';
  double? _operand1;
  String? _operator;
  bool _shouldReset = false;

  final FocusNode _focusNode = FocusNode();

  static const _buttons = [
    'C', '⌫', '+/-', '/',
    '7', '8', '9', '*',
    '4', '5', '6', '-',
    '1', '2', '3', '+',
    '0', '00', '.', '=',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _focusNode.canRequestFocus) {
        _focusNode.requestFocus();
      }
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  void _handlePress(String v) {
    setState(() {
      if (v == 'C') {
        _display = '0';
        _history = '';
        _operand1 = null;
        _operator = null;
        _shouldReset = false;
      } else if (v == '⌫') {
        if (_display.length > 1) {
          _display = _display.substring(0, _display.length - 1);
        } else {
          _display = '0';
        }
      } else if (v == '+/-') {
        if (_display != '0') {
          _display = _display.startsWith('-')
              ? _display.substring(1)
              : '-$_display';
        }
      } else if (['/', '*', '-', '+'].contains(v)) {
        _onOperator(v);
      } else if (v == '=') {
        _calculate();
        _shouldReset = true;
      } else if (v == '.') {
        if (_shouldReset || _display == 'error') {
          _display = '0.';
          _shouldReset = false;
        } else if (!_display.contains('.')) {
          _display += '.';
        }
      } else {
        if (_shouldReset || _display == '0' || _display == 'error') {
          _display = v;
          _shouldReset = false;
        } else if (!(v == '00' && _display == '0')) {
          _display += v;
        }
      }
    });
  }

  void _onOperator(String op) {
    final cur = double.tryParse(_display);
    if (cur == null) return;
    if (_operand1 != null && _operator != null && !_shouldReset) {
      _calculate();
      _operand1 = double.tryParse(_display);
    } else {
      _operand1 = cur;
    }
    _operator = op;
    _history = '${_formatNum(_operand1!)} $op';
    _shouldReset = true;
  }

  void _calculate() {
    if (_operand1 == null || _operator == null) return;
    final cur = double.tryParse(_display);
    if (cur == null) return;
    double r;
    switch (_operator) {
      case '+': r = _operand1! + cur; break;
      case '-': r = _operand1! - cur; break;
      case '*': r = _operand1! * cur; break;
      case '/':
        if (cur == 0) {
          _display = 'error';
          _history = '';
          _operand1 = null;
          _operator = null;
          return;
        }
        r = _operand1! / cur;
        break;
      default: return;
    }
    _history = '${_formatNum(_operand1!)} $_operator ${_formatNum(cur)} =';
    _display = _formatNum(r);
    _operand1 = null;
    _operator = null;
  }

  String _formatNum(double v) {
    if (v == v.toInt()) return v.toInt().toString();
    var s = v.toStringAsFixed(8);
    while (s.contains('.') && (s.endsWith('0') || s.endsWith('.'))) {
      s = s.substring(0, s.length - 1);
    }
    return s;
  }

  void _handleKey(KeyEvent e) {
    if (e is! KeyDownEvent) return;
    final char = e.character;
    final key = e.logicalKey;
    if (char != null && RegExp(r'^[0-9]$').hasMatch(char)) {
      _handlePress(char);
    } else if (key == LogicalKeyboardKey.period || char == '.') {
      _handlePress('.');
    } else if (key == LogicalKeyboardKey.numpadAdd || char == '+') {
      _handlePress('+');
    } else if (key == LogicalKeyboardKey.numpadSubtract || char == '-') {
      _handlePress('-');
    } else if (key == LogicalKeyboardKey.numpadMultiply || char == '*' || char == 'x' || char == 'X') {
      _handlePress('*');
    } else if (key == LogicalKeyboardKey.numpadDivide || char == '/') {
      _handlePress('/');
    } else if (key == LogicalKeyboardKey.enter || key == LogicalKeyboardKey.numpadEnter || char == '=') {
      _handlePress('=');
    } else if (key == LogicalKeyboardKey.backspace) {
      _handlePress('⌫');
    } else if (key == LogicalKeyboardKey.escape || char == 'c' || char == 'C') {
      _handlePress('C');
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return KeyboardListener(
      focusNode: _focusNode,
      autofocus: true,
      onKeyEvent: _handleKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.calculate_outlined, color: AppColors.primary, size: 20.sp),
              SizedBox(width: 8.w),
              ReusableText(
                'آلة حاسبة',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimaryOf(context),
                ),
              ),
              const Spacer(),
              IconButton(
                icon: Icon(Icons.close_rounded, size: 20.sp),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
          Divider(height: 16.h, thickness: 0.8),
          SizedBox(height: 4.h),

          // شاشة عرض الأرقام (Display Screen)
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerLow,
              borderRadius: BorderRadius.circular(10.r),
              border: Border.all(color: scheme.outlineVariant.withValues(alpha: 0.4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                ReusableText(
                  _history.isEmpty ? ' ' : _history,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: scheme.onSurfaceVariant.withValues(alpha: 0.7),
                    height: 1.2,
                  ),
                ),
                SizedBox(height: 6.h),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  reverse: true,
                  child: ReusableText(
                    _display,
                    style: TextStyle(
                      fontSize: 24.sp,
                      fontWeight: FontWeight.bold,
                      color: scheme.onSurface,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16.h),

          // لوحة الأزرار (Buttons Grid)
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            mainAxisSpacing: 8.h,
            crossAxisSpacing: 8.w,
            childAspectRatio: 1.2, // نسبة عرض لارتفاع ممتازة ومريحة للمس باليد
            children: [for (final btn in _buttons) _buildBtn(btn)],
          ),
        ],
      ),
    );
  }

  Widget _buildBtn(String label) {
    final scheme = Theme.of(context).colorScheme;
    final isOp = ['/', '*', '-', '+'].contains(label);
    final isEq = label == '=';
    final isAct = ['C', '⌫', '+/-'].contains(label);

    Color bg;
    Color fg;

    if (isEq) {
      bg = AppColors.primary;
      fg = Colors.white;
    } else if (isOp) {
      bg = AppColors.primary.withValues(alpha: 0.1);
      fg = AppColors.primary;
    } else if (isAct) {
      bg = scheme.surfaceContainerHigh;
      fg = scheme.onSurfaceVariant;
    } else {
      bg = scheme.surfaceContainerLow;
      fg = scheme.onSurface;
    }

    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(8.r),
      child: InkWell(
        borderRadius: BorderRadius.circular(8.r),
        onTap: () => _handlePress(label),
        hoverColor: isEq ? Colors.white.withValues(alpha: 0.05) : scheme.primary.withValues(alpha: 0.03),
        splashColor: isEq ? Colors.white.withValues(alpha: 0.1) : scheme.primary.withValues(alpha: 0.06),
        child: Center(
          child: label == '⌫'
              ? Icon(Icons.backspace_outlined, size: 18.sp, color: fg)
              : ReusableText(
            label,
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: fg,
            ),
          ),
        ),
      ),
    );
  }
}