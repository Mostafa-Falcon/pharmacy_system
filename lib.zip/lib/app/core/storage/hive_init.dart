import 'package:hive_flutter/hive_flutter.dart';
import '../utils/app_utils.dart';
import '../models/security/user_model_adapter.dart';
import '../models/security/branch_model_adapter.dart';
import '../models/security/permission_model_adapter.dart';
import '../models/base/sync_queue_item_adapter.dart';
import '../models/inventory/medicine_model_adapter.dart';
import '../models/sales/sale_model_adapter.dart';
import '../models/sales/purchase_model_adapter.dart';
import '../models/inventory/inventory_model_adapter.dart';
import '../models/sales/return_model_adapter.dart';
import '../models/base/lookup_model_adapter.dart';
import '../models/inventory/medicine_unit_model_adapter.dart';
import '../models/supplier/supplier_model_adapter.dart';
import '../models/customer/customer_ledger_model.dart';
import '../models/supplier/supplier_ledger_model.dart';
import '../models/crm/crm_model.dart';
import '../models/inventory/stocktaking_model.dart';
import '../models/customer/customer_model_adapter.dart';
import '../models/customer/customer_group_model_adapter.dart';
import '../models/customer/customer_supplier_model_adapter.dart';
import '../models/sales/cashier_shift_model.dart';
import '../models/sales/quote_model.dart';
import '../models/inventory/item_batch_model.dart';
import '../models/tasks/task_models.dart';
import '../models/inventory/stocktaking_period_model.dart';
import '../models/archive/archive_record_model.dart';
import '../models/inventory/promotion_model.dart';
import '../models/inventory/promotion_model_adapter.dart';
import '../models/inventory/damaged_stock_model.dart';
import '../models/inventory/damaged_stock_model_adapter.dart';
import '../models/inventory/opening_stock_model.dart';
import '../models/inventory/opening_stock_model_adapter.dart';

// استيرام الـ adapters اللي تم إنشاؤها تلقائياً (.g.dart)

Future<Box> _openBoxSafe<T>(String name) async {
  try {
    return await Hive.openBox<T>(name);
  } catch (e) {
    safeDebugPrint('Hive box "$name" corrupted, attempting recovery: $e');
    try {
      await Hive.deleteBoxFromDisk(name);
    } catch (e) {
      safeDebugPrint('Hive: فشل حذف الصندوق التالف "$name" من القرص: $e');
    }
    return await Hive.openBox<T>(name);
  }
}

Future<void> initHive() async {
  await Hive.initFlutter();

  // Models Adapters Registration
  Hive.registerAdapter(UserModelAdapter());
  Hive.registerAdapter(BranchModelAdapter());
  Hive.registerAdapter(PermissionModelAdapter());
  Hive.registerAdapter(SyncQueueItemAdapter());
  Hive.registerAdapter(ManualMedicineModelAdapter());
  Hive.registerAdapter(ManualSaleItemModelAdapter());
  Hive.registerAdapter(ManualSaleModelAdapter());
  Hive.registerAdapter(ManualPurchaseItemModelAdapter());
  Hive.registerAdapter(ManualPurchaseModelAdapter());
  Hive.registerAdapter(ManualInventoryItemModelAdapter());
  Hive.registerAdapter(ManualReturnItemModelAdapter());
  Hive.registerAdapter(ManualReturnReasonAdapter());
  Hive.registerAdapter(ManualReturnModelAdapter());
  Hive.registerAdapter(ManualLookupModelAdapter());
  Hive.registerAdapter(ManualMedicineUnitModelAdapter());
  Hive.registerAdapter(ManualSupplierModelAdapter());

  // New Adapters for Ledgers
  Hive.registerAdapter(CustomerLedgerEntryTypeAdapter());
  Hive.registerAdapter(CustomerLedgerModelAdapter());
  Hive.registerAdapter(SupplierLedgerEntryTypeAdapter());
  Hive.registerAdapter(SupplierLedgerModelAdapter());

  // New Adapters for CRM
  Hive.registerAdapter(CrmLeadStatusAdapter());
  Hive.registerAdapter(CrmLeadModelAdapter());
  Hive.registerAdapter(CrmFollowUpModelAdapter());

  // New Adapters for Customer
  Hive.registerAdapter(ManualCustomerKindAdapter());
  Hive.registerAdapter(ManualCustomerModelAdapter());

  // New Adapters for Customer Groups
  Hive.registerAdapter(ManualCustomerGroupModelAdapter());

  // New Adapters for Customer Suppliers
  Hive.registerAdapter(ManualCustomerSupplierModelAdapter());

  // New Adapters for Stocktaking
  Hive.registerAdapter(StocktakingItemModelAdapter());
  Hive.registerAdapter(StocktakingStatusAdapter());
  Hive.registerAdapter(StocktakingModelAdapter());

  // New Adapters for Cashier Shifts
  Hive.registerAdapter(CashierShiftModelAdapter());

  // New Adapters for Quotes
  Hive.registerAdapter(QuoteModelAdapter());

  // New Adapter for Item Batches
  Hive.registerAdapter(ItemBatchModelAdapter());

  // New Adapters for Tasks Module (Tasks, Notes, Reminders, Messages)
  Hive.registerAdapter(TaskModelAdapter());
  Hive.registerAdapter(NoteModelAdapter());
  Hive.registerAdapter(ReminderModelAdapter());
  Hive.registerAdapter(MessageModelAdapter());

  // New Adapters for Stocktaking Upgrade (Period + Count)
  Hive.registerAdapter(StocktakingPeriodModelAdapter());
  Hive.registerAdapter(StocktakingCountModelAdapter());

  // New Adapter for Archive Records
  Hive.registerAdapter(ArchiveRecordModelAdapter());

  // New Adapters for Promotions, Damaged Stock, Opening Stock
  Hive.registerAdapter(PromotionModelAdapter());
  Hive.registerAdapter(DamagedStockModelAdapter());
  Hive.registerAdapter(OpeningStockModelAdapter());

  // Opening Hive Boxes
  await _openBoxSafe('auth');
  await _openBoxSafe('users');
  await _openBoxSafe('branches');
  await _openBoxSafe('permissions');
  await _openBoxSafe('sync_queue');
  await _openBoxSafe('medicines');
  await _openBoxSafe('sales');
  await _openBoxSafe('purchases');
  await _openBoxSafe('inventory');
  await _openBoxSafe('returns');
  await _openBoxSafe('settings');
  await _openBoxSafe('lookups');
  await _openBoxSafe('suppliers');
  await _openBoxSafe('customers');

  // New Boxes for CRM
  await _openBoxSafe('crm_leads');
  await _openBoxSafe('crm_followups');
  await _openBoxSafe('corrections');
  await _openBoxSafe('customer_groups');
  await _openBoxSafe('customer_suppliers');
  await _openBoxSafe('cashier_shifts');
  await _openBoxSafe('quotes');

  // Ledger Boxes (for web compatibility)
  await _openBoxSafe('customer_ledgers');
  await _openBoxSafe('supplier_ledgers');

  // Accounting Boxes
  await _openBoxSafe('journal_entries');
  await _openBoxSafe('expenses');
  await _openBoxSafe('party_payments');

  // Suspended Sales Box
  await _openBoxSafe('suspended_sales');

  // Stock Transfers Box (dynamic JSON box)
  await _openBoxSafe('stock_transfers');

  // Admin Boxes (Settings, Roles, Members, Audit Logs)
  await _openBoxSafe('app_settings');
  await _openBoxSafe('admin_roles');
  await _openBoxSafe('admin_members');
  await _openBoxSafe('admin_audit_logs');

  // Item Batches Box (for batch/lot tracking)
  await _openBoxSafe<ItemBatchModel>('medicine_batches');

  // Tasks Module Boxes
  await _openBoxSafe<TaskModel>('tasks');
  await _openBoxSafe<NoteModel>('notes');
  await _openBoxSafe<ReminderModel>('reminders');
  await _openBoxSafe<MessageModel>('messages');

  // Stocktaking Upgrade Boxes
  await _openBoxSafe<StocktakingPeriodModel>('stocktaking_periods');
  await _openBoxSafe<StocktakingCountModel>('stocktaking_counts');

  // Brands, Price Groups, and Variants Boxes (dynamic JSON)
  await _openBoxSafe('medicine_brands');
  await _openBoxSafe('price_groups');
  await _openBoxSafe('medicine_variants');

  // HR Module Boxes
  await _openBoxSafe('hr_employees');
  await _openBoxSafe('hr_attendance');
  await _openBoxSafe('hr_leave_records');
  await _openBoxSafe('hr_payroll');
  await _openBoxSafe('hr_payroll_lines');
  await _openBoxSafe('hr_departments');

  // Archive Records Box
  await _openBoxSafe('archive_records');

  // Promotions Box
  await _openBoxSafe<PromotionModel>('promotions');

  // Damaged Stock Box
  await _openBoxSafe<DamagedStockModel>('damaged_stock');

  // Opening Stock Box
  await _openBoxSafe<OpeningStockModel>('opening_stock');
}
