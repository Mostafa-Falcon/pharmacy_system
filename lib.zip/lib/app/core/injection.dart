import 'package:get_it/get_it.dart';

// ── Repositories ──
import 'repositories/base_repository.dart';
import 'repositories/medicines_repository.dart';
import 'repositories/customers_repository.dart';
import 'repositories/sales_repository.dart';
import 'repositories/purchases_repository.dart';
import 'repositories/sales_return_repository.dart';

// ── Auth ──
import 'package:pharmacy_system/app/modules/auth/bloc/auth_bloc.dart';

// ── Core Services ──
import 'package:pharmacy_system/app/core/services/lookup_service.dart';
import 'package:pharmacy_system/app/core/services/customer/customer_service.dart';
import 'package:pharmacy_system/app/core/services/customer/customer_group_service.dart';
import 'package:pharmacy_system/app/core/services/supplier/supplier_service.dart';
import 'package:pharmacy_system/app/core/services/admin/branch_service.dart';
import 'package:pharmacy_system/app/core/services/inventory/batch_service.dart';
import 'package:pharmacy_system/app/core/services/tasks/task_service.dart';
import 'package:pharmacy_system/app/core/services/inventory/stocktaking_service.dart';
import 'package:pharmacy_system/app/core/services/operations/void_operations_service.dart';

// ── Admin Services ──
import 'package:pharmacy_system/app/modules/admin/services/settings_service.dart';
import 'package:pharmacy_system/app/modules/admin/services/admin_service.dart';
import 'package:pharmacy_system/app/modules/admin/services/access_control_service.dart';

// ── Inventory Services ──
import 'package:pharmacy_system/app/modules/inventory/services/inventory_transaction_service.dart';
import 'package:pharmacy_system/app/modules/inventory/services/inventory_reconciliation_service.dart';
import 'package:pharmacy_system/app/modules/inventory/services/inventory_projection_service.dart';

// ── Blocs: Core & Layout ──
import 'package:pharmacy_system/app/modules/contacts/customers/bloc/customers_bloc.dart';
import 'package:pharmacy_system/app/modules/contacts/suppliers/bloc/suppliers_bloc.dart';
import 'package:pharmacy_system/app/modules/layout/bloc/shell_bloc.dart';
import 'package:pharmacy_system/app/modules/layout/bloc/shell_event.dart';
import 'package:pharmacy_system/app/modules/home/bloc/monitoring_dashboard_bloc.dart';
import 'package:pharmacy_system/app/modules/employee/bloc/employee_bloc.dart';
import 'package:pharmacy_system/app/modules/notifications/bloc/notifications_bloc.dart';

// ── Blocs: Inventory ──
import 'package:pharmacy_system/app/modules/inventory/bloc/medicines_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/import_medicines_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/brands_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/price_groups_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/barcode_label_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/stock_transfer_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/barcode_settings_bloc.dart';
import 'package:pharmacy_system/app/modules/inventory/bloc/items_archive_bloc.dart';

// ── Blocs: Core ──
import 'package:pharmacy_system/app/core/bloc/import_data_bloc.dart';

// ── Blocs: Admin ──
import 'package:pharmacy_system/app/modules/admin/bloc/branches_bloc.dart';
import 'package:pharmacy_system/app/modules/admin/bloc/settings_bloc.dart';
import 'package:pharmacy_system/app/modules/admin/bloc/employees_bloc.dart';

// ── Blocs: Modules ──
import 'package:pharmacy_system/app/modules/contacts/customer_groups/bloc/customer_groups_bloc.dart';
import 'package:pharmacy_system/app/modules/quotes/bloc/quotes_bloc.dart';
import 'package:pharmacy_system/app/modules/crm/bloc/crm_bloc.dart';
import 'package:pharmacy_system/app/modules/contacts/customer_suppliers/bloc/customer_suppliers_bloc.dart';
import 'package:pharmacy_system/app/modules/hr/bloc/hr_bloc.dart';
import 'package:pharmacy_system/app/modules/returns/bloc/sales_return_bloc.dart';
import 'package:pharmacy_system/app/modules/returns/bloc/purchase_return_bloc.dart';
import 'package:pharmacy_system/app/modules/purchases/bloc/purchases_bloc.dart';

// ── Blocs: Accounting ──
import 'package:pharmacy_system/app/modules/accounting/bloc/accounting_bloc.dart';
import 'package:pharmacy_system/app/modules/accounting/bloc/party_payments_bloc.dart';

// ── Blocs: Sales ──
import 'package:pharmacy_system/app/modules/sales/bloc/pos_bloc.dart';
import 'package:pharmacy_system/app/modules/sales/bloc/sales_bloc.dart';
import 'package:pharmacy_system/app/modules/sales/bloc/cashier_shift_bloc.dart';

// ── Blocs: Tasks / Reports / Stocktaking ──
import 'package:pharmacy_system/app/modules/tasks/bloc/tasks_bloc.dart';
import 'package:pharmacy_system/app/modules/reports/bloc/reports_bloc.dart';
import 'package:pharmacy_system/app/modules/reports/bloc/extra_reports_bloc.dart';
import 'package:pharmacy_system/app/modules/stocktaking/bloc/stocktaking_bloc.dart';
// ── Blocs: Archive ──
import 'package:pharmacy_system/app/modules/archive/bloc/archive_bloc.dart';

final sl = GetIt.instance;

Future<void> initInjection() async {
  sl.allowReassignment = true;

  _registerRepositories();
  await _registerServices();
  _registerBlocs();
}

void _registerRepositories() {
  _registerLazySingleton<MedicinesRepository>(
    () => const MedicinesRepository(),
  );
  _registerLazySingleton<CustomersRepository>(
    () => const CustomersRepository(),
  );
  _registerLazySingleton<SalesRepository>(() => const SalesRepository());
  _registerLazySingleton<PurchasesRepository>(
    () => const PurchasesRepository(),
  );
  _registerLazySingleton<SalesReturnRepository>(
    () => const SalesReturnRepository(),
  );
}

Future<void> _registerServices() async {
  _registerLazySingleton<LookupService>(() => LookupService());
  _registerLazySingleton<SupplierService>(() => SupplierService());
  _registerLazySingleton<CustomerService>(() => CustomerService());
  _registerLazySingleton<CustomerGroupService>(() => CustomerGroupService());
  _registerLazySingleton<BranchService>(() => BranchService());

  if (!sl.isRegistered<BatchService>()) {
    final s = BatchService();
    sl.registerSingleton<BatchService>(s);
    await s.init();
  }
  if (!sl.isRegistered<TaskService>()) {
    final s = TaskService();
    sl.registerSingleton<TaskService>(s);
    await s.init();
  }
  if (!sl.isRegistered<StocktakingService>()) {
    final s = StocktakingService();
    sl.registerSingleton<StocktakingService>(s);
    await s.init();
  }
  _registerSingleton<VoidOperationsService>(() => VoidOperationsService());

  _registerLazySingleton<SettingsService>(() => SettingsService());
  _registerLazySingleton<AdminService>(() => AdminService());
  _registerLazySingleton<AccessControlService>(() => AccessControlService());

  _registerLazySingleton<InventoryTransactionService>(
    () => InventoryTransactionService(),
  );
  _registerLazySingleton<InventoryReconciliationService>(
    () => InventoryReconciliationService(),
  );
  _registerLazySingleton<InventoryProjectionService>(
    () => InventoryProjectionService(),
  );
}

void _registerBlocs() {
  // Auth & Layout
  _registerLazySingleton<AuthBloc>(() => AuthBloc());
  _registerLazySingleton<ShellBloc>(() => ShellBloc()..add(const LoadShell()));
  _registerLazySingleton<MonitoringDashboardBloc>(() => MonitoringDashboardBloc());
  _registerLazySingleton<EmployeeBloc>(() => EmployeeBloc());
  _registerLazySingleton<NotificationsBloc>(() => NotificationsBloc());
  _registerLazySingleton<ImportDataBloc>(() => ImportDataBloc());

  // Core & Inventory Blocs
  _registerLazySingleton<CustomersBloc>(() => CustomersBloc());
  _registerLazySingleton<SuppliersBloc>(() => SuppliersBloc());
  _registerLazySingleton<MedicinesBloc>(() => MedicinesBloc());
  _registerLazySingleton<ImportMedicinesBloc>(() => ImportMedicinesBloc());
  _registerLazySingleton<BrandsBloc>(() => BrandsBloc());
  _registerLazySingleton<PriceGroupsBloc>(() => PriceGroupsBloc());
  _registerLazySingleton<BarcodeLabelBloc>(() => BarcodeLabelBloc());
  _registerLazySingleton<StockTransferBloc>(() => StockTransferBloc());
  _registerLazySingleton<BarcodeSettingsBloc>(() => BarcodeSettingsBloc());
  _registerLazySingleton<ItemsArchiveBloc>(() => ItemsArchiveBloc());

  // Admin Blocs
  _registerLazySingleton<BranchesBloc>(() => BranchesBloc());
  _registerLazySingleton<SettingsBloc>(() => SettingsBloc());
  _registerLazySingleton<EmployeesBloc>(() => EmployeesBloc());

  // Sales Blocs
  _registerLazySingleton<PosBloc>(() => PosBloc());
  _registerLazySingleton<SalesBloc>(() => SalesBloc());
  _registerLazySingleton<CashierShiftBloc>(() => CashierShiftBloc());

  // Module Blocs
  _registerLazySingleton<CustomerGroupsBloc>(() => CustomerGroupsBloc());
  _registerLazySingleton<QuotesBloc>(() => QuotesBloc());
  _registerLazySingleton<CrmBloc>(() => CrmBloc());
  _registerLazySingleton<CustomerSuppliersBloc>(() => CustomerSuppliersBloc());
  _registerLazySingleton<SalesReturnBloc>(() => SalesReturnBloc());
  _registerLazySingleton<PurchaseReturnBloc>(() => PurchaseReturnBloc());
  _registerLazySingleton<PurchasesBloc>(() => PurchasesBloc());
  _registerLazySingleton<AccountingBloc>(() => AccountingBloc());
  _registerLazySingleton<PartyPaymentsBloc>(() => PartyPaymentsBloc());
  _registerLazySingleton<HrBloc>(() => HrBloc());
  _registerLazySingleton<TasksBloc>(() => TasksBloc());
  _registerLazySingleton<ReportsBloc>(() => ReportsBloc());
  _registerLazySingleton<ExtraReportsBloc>(() => ExtraReportsBloc());
  _registerLazySingleton<StocktakingBloc>(() => StocktakingBloc());
  _registerLazySingleton<ArchiveBloc>(() => ArchiveBloc());
}

Future<void> disposeInjection() async {
  await sl.reset();
  BaseRepository.dispose();
}

void _registerLazySingleton<T extends Object>(T Function() factory) {
  if (!sl.isRegistered<T>()) {
    sl.registerLazySingleton<T>(factory);
  }
}

Future<void> _registerSingleton<T extends Object>(T Function() factory) async {
  if (!sl.isRegistered<T>()) {
    sl.registerSingleton<T>(factory());
  }
}
