class AppImages {
  AppImages._();

  static const String pharmacyHero = 'assets/images/pharmacy-hero.png';
  static const String itemPlaceholder = 'assets/images/item-placeholder.png';
}
