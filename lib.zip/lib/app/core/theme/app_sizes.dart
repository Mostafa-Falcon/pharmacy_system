import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppSpacing {
  // UTF-8 Force Refresh
  AppSpacing._();

  // توحيد المسافات لتعمل بالـ ScreenUtil تلقائياً لراحة اليد والعين أثناء بناء الـ UI
  static double get xxs => 4.w;
  static double get xs => 8.w;
  static double get sm => 12.w;
  static double get md => 16.w;
  static double get lg => 20.w;
  static double get xl => 24.w;
  static double get xxl => 32.w;
  static double get xxxl => 40.w;

  // اختصارات الارتفاع الرأسي لراحتك
  static double get xsH => 8.h;
  static double get smH => 12.h;
  static double get mdH => 16.h;
  static double get lgH => 20.h;
  static double get xlH => 24.h;
}

class AppRadius {
  AppRadius._();

  // ربط الحواف الناعمة بالامتداد .r المخصص للحواف المتناسقة من المكتبة
  static double get xs => 4.r;
  static double get sm => 8.r;
  static double get md => 12.r;
  static double get lg => 16.r;
  static double get xl => 20.r;
  static double get pill => 999.r;
}

class AppDimensions {
  AppDimensions._();

  // ── Layout Dimensions ──
  static double get sidebarWidth => 260.w;
  static double get sidebarCollapsedWidth => 72.w;
  static double get navbarHeight => 64.h;
  static double get headerHeight => 86.h;

  // ── Icons Scale ──
  static double get iconSize => 21.sp;
  static double get iconSizeSmall => 18.sp;
  static double get iconSizeLarge => 24.sp;

  // ── Master Border Radius ──
  static double get borderRadiusSmall => AppRadius.sm;
  static double get borderRadius => AppRadius.md;
  static double get borderRadiusLarge => AppRadius.lg;

  // ── Unified Spacing Aliases ──
  static double get spacingXS => AppSpacing.xs;
  static double get spacingSM => AppSpacing.sm;
  static double get spacingMD => AppSpacing.md;
  static double get spacingLG => AppSpacing.lg;
  static double get spacingXL => AppSpacing.xl;

  // ── Misc ──
  static double get dividerThickness => 1.0;
  static double get scrollbarThickness => 5.w;
}

/// Backward-compatible alias for AppDimensions (تأمين كامل لمنع ضربات الكومبايلر)
class AppSizes {
  AppSizes._();
  static double get sidebarWidth => AppDimensions.sidebarWidth;
  static double get sidebarCollapsedWidth => AppDimensions.sidebarCollapsedWidth;
  static double get navbarHeight => AppDimensions.navbarHeight;
  static double get headerHeight => AppDimensions.headerHeight;
  static double get iconSize => AppDimensions.iconSize;
  static double get iconSizeSmall => AppDimensions.iconSizeSmall;
  static double get borderRadius => AppDimensions.borderRadius;
  static double get borderRadiusSmall => AppDimensions.borderRadiusSmall;
  static double get borderRadiusLarge => AppDimensions.borderRadiusLarge;
  static double get spacingXS => AppDimensions.spacingXS;
  static double get spacingSM => AppDimensions.spacingSM;
  static double get spacingMD => AppDimensions.spacingMD;
  static double get spacingLG => AppDimensions.spacingLG;
  static double get spacingXL => AppDimensions.spacingXL;
  static double get dividerThickness => AppDimensions.dividerThickness;
  static double get scrollbarThickness => AppDimensions.scrollbarThickness;
}
