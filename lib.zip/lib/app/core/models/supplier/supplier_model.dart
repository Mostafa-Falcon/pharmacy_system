import 'package:hive/hive.dart';

part 'supplier_model.g.dart';

enum SupplierType { supplier, customerSupplier }

enum SupplierPartyType { company, individual }

extension SupplierPartyTypeExtension on SupplierPartyType {
  String get label => switch (this) {
    SupplierPartyType.company => 'شركة',
    SupplierPartyType.individual => 'فرد',
  };
}

@HiveType(typeId: 16)
class SupplierModel extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  SupplierType type;

  @HiveField(3)
  String? phone;

  @HiveField(4)
  String? address;

  @HiveField(5)
  bool isActive;

  @HiveField(15)
  bool isDeleted;

  @HiveField(6)
  DateTime lastModified;

  @HiveField(7)
  SupplierPartyType partyType;

  @HiveField(8)
  String? companyName;

  @HiveField(9)
  String? email;

  @HiveField(10)
  String? taxId;

  @HiveField(11)
  double creditLimit;

  @HiveField(12)
  double discountPercent;

  @HiveField(13)
  int paymentTermDays;

  @HiveField(14)
  String? notes;

  SupplierModel({
    required this.id,
    required this.name,
    required this.type,
    this.phone,
    this.address,
    this.isActive = true,
    this.isDeleted = false,
    DateTime? lastModified,
    this.partyType = SupplierPartyType.company,
    this.companyName,
    this.email,
    this.taxId,
    this.creditLimit = 0,
    this.discountPercent = 0,
    this.paymentTermDays = 0,
    this.notes,
  }) : lastModified = lastModified ?? DateTime.now();

  String get typeName => switch (type) {
    SupplierType.supplier => 'مورد',
    SupplierType.customerSupplier => 'عميل/مورد',
  };

  String get partyTypeName => switch (partyType) {
    SupplierPartyType.company => 'شركة',
    SupplierPartyType.individual => 'فرد',
  };

  bool get isArchived => isDeleted;

  String get displayName => name;

  String get identityPhone => phone ?? '';
  String get identityEmail => email ?? '';
  String get identityAddress => address ?? '';
  String get identityCompanyName => companyName ?? '';

  SupplierModel copyWith({
    String? id,
    String? name,
    SupplierType? type,
    String? phone,
    String? address,
    bool? isActive,
    bool? isDeleted,
    SupplierPartyType? partyType,
    String? companyName,
    String? email,
    String? taxId,
    double? creditLimit,
    double? discountPercent,
    int? paymentTermDays,
    String? notes,
  }) {
    return SupplierModel(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      partyType: partyType ?? this.partyType,
      companyName: companyName ?? this.companyName,
      email: email ?? this.email,
      taxId: taxId ?? this.taxId,
      creditLimit: creditLimit ?? this.creditLimit,
      discountPercent: discountPercent ?? this.discountPercent,
      paymentTermDays: paymentTermDays ?? this.paymentTermDays,
      notes: notes ?? this.notes,
      lastModified: lastModified,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type.name,
    'party_type': partyType.name,
    'phone': phone,
    'address': address,
    'is_active': isActive,
    'is_deleted': isDeleted,
    'last_modified': lastModified.toIso8601String(),
    'company_name': companyName,
    'email': email,
    'tax_id': taxId,
    'credit_limit': creditLimit,
    'discount_percent': discountPercent,
    'payment_term_days': paymentTermDays,
    'notes': notes,
  };

  factory SupplierModel.fromJson(Map<String, dynamic> json) => SupplierModel(
    id: json['id'] as String,
    name: json['name'] as String,
    type: SupplierType.values.firstWhere(
      (e) => e.name == json['type'],
      orElse: () => SupplierType.supplier,
    ),
    partyType: SupplierPartyType.values.firstWhere(
      (e) => e.name == json['party_type'],
      orElse: () => SupplierPartyType.company,
    ),
    phone: json['phone'] as String?,
    address: json['address'] as String?,
    isActive: json['is_active'] as bool? ?? true,
    isDeleted: json['is_deleted'] as bool? ?? false,
    lastModified: json['last_modified'] != null
        ? DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now()
        : DateTime.now(),
    companyName: json['company_name'] as String?,
    email: json['email'] as String?,
    taxId: json['tax_id'] as String?,
    creditLimit: (json['credit_limit'] as num?)?.toDouble() ?? 0,
    discountPercent: (json['discount_percent'] as num?)?.toDouble() ?? 0,
    paymentTermDays: json['payment_term_days'] as int? ?? 0,
    notes: json['notes'] as String?,
  );
}
