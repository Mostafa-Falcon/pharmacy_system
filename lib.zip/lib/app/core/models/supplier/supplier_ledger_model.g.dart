// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supplier_ledger_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class SupplierLedgerModelAdapter extends TypeAdapter<SupplierLedgerModel> {
  @override
  final int typeId = 20;

  @override
  SupplierLedgerModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SupplierLedgerModel(
      id: fields[0] as String,
      supplierId: fields[1] as String,
      branchId: fields[2] as String,
      type: fields[3] as SupplierLedgerEntryType,
      debit: fields[4] as double,
      credit: fields[5] as double,
      balanceAfter: fields[6] as double,
      referenceId: fields[7] as String?,
      referenceNumber: fields[8] as String?,
      notes: fields[9] as String?,
      createdBy: fields[10] as String?,
      entryDate: fields[11] as DateTime,
      syncVersion: fields[12] as int,
      lastModified: fields[13] as DateTime?,
      isDeleted: fields[14] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, SupplierLedgerModel obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.supplierId)
      ..writeByte(2)
      ..write(obj.branchId)
      ..writeByte(3)
      ..write(obj.type)
      ..writeByte(4)
      ..write(obj.debit)
      ..writeByte(5)
      ..write(obj.credit)
      ..writeByte(6)
      ..write(obj.balanceAfter)
      ..writeByte(7)
      ..write(obj.referenceId)
      ..writeByte(8)
      ..write(obj.referenceNumber)
      ..writeByte(9)
      ..write(obj.notes)
      ..writeByte(10)
      ..write(obj.createdBy)
      ..writeByte(11)
      ..write(obj.entryDate)
      ..writeByte(12)
      ..write(obj.syncVersion)
      ..writeByte(13)
      ..write(obj.lastModified)
      ..writeByte(14)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SupplierLedgerModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class SupplierLedgerEntryTypeAdapter
    extends TypeAdapter<SupplierLedgerEntryType> {
  @override
  final int typeId = 19;

  @override
  SupplierLedgerEntryType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return SupplierLedgerEntryType.openingBalance;
      case 1:
        return SupplierLedgerEntryType.purchaseInvoice;
      case 2:
        return SupplierLedgerEntryType.supplierPayment;
      case 3:
        return SupplierLedgerEntryType.purchaseVoid;
      case 4:
        return SupplierLedgerEntryType.manualAdjustment;
      case 5:
        return SupplierLedgerEntryType.additionNotice;
      case 6:
        return SupplierLedgerEntryType.discountNotice;
      case 7:
        return SupplierLedgerEntryType.checkReceipt;
      case 8:
        return SupplierLedgerEntryType.checkPayment;
      default:
        return SupplierLedgerEntryType.openingBalance;
    }
  }

  @override
  void write(BinaryWriter writer, SupplierLedgerEntryType obj) {
    switch (obj) {
      case SupplierLedgerEntryType.openingBalance:
        writer.writeByte(0);
        break;
      case SupplierLedgerEntryType.purchaseInvoice:
        writer.writeByte(1);
        break;
      case SupplierLedgerEntryType.supplierPayment:
        writer.writeByte(2);
        break;
      case SupplierLedgerEntryType.purchaseVoid:
        writer.writeByte(3);
        break;
      case SupplierLedgerEntryType.manualAdjustment:
        writer.writeByte(4);
        break;
      case SupplierLedgerEntryType.additionNotice:
        writer.writeByte(5);
        break;
      case SupplierLedgerEntryType.discountNotice:
        writer.writeByte(6);
        break;
      case SupplierLedgerEntryType.checkReceipt:
        writer.writeByte(7);
        break;
      case SupplierLedgerEntryType.checkPayment:
        writer.writeByte(8);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SupplierLedgerEntryTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
