import 'package:hive/hive.dart';
import 'supplier_model.dart';

class ManualSupplierModelAdapter extends TypeAdapter<SupplierModel> {
  @override
  final int typeId = 16;

  @override
  SupplierModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SupplierModel(
      id: fields[0] as String,
      name: fields[1] as String,
      type: SupplierType.values[fields[2] as int],
      phone: fields[3] as String?,
      address: fields[4] as String?,
      isActive: fields[5] as bool? ?? true,
      isDeleted: fields[15] as bool? ?? false,
      lastModified: fields[6] != null
          ? DateTime.fromMillisecondsSinceEpoch(fields[6] as int)
          : DateTime.now(),
      partyType: fields[7] != null
          ? SupplierPartyType.values[fields[7] as int]
          : SupplierPartyType.company,
      companyName: fields[8] as String?,
      email: fields[9] as String?,
      taxId: fields[10] as String?,
      creditLimit: fields[11] as double? ?? 0,
      discountPercent: fields[12] as double? ?? 0,
      paymentTermDays: fields[13] as int? ?? 0,
      notes: fields[14] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, SupplierModel obj) {
    writer.writeByte(16);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.name);
    writer.writeByte(2); writer.write(obj.type.index);
    writer.writeByte(3); writer.write(obj.phone);
    writer.writeByte(4); writer.write(obj.address);
    writer.writeByte(5); writer.write(obj.isActive);
    writer.writeByte(15); writer.write(obj.isDeleted);
    writer.writeByte(6); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(7); writer.write(obj.partyType.index);
    writer.writeByte(8); writer.write(obj.companyName);
    writer.writeByte(9); writer.write(obj.email);
    writer.writeByte(10); writer.write(obj.taxId);
    writer.writeByte(11); writer.write(obj.creditLimit);
    writer.writeByte(12); writer.write(obj.discountPercent);
    writer.writeByte(13); writer.write(obj.paymentTermDays);
    writer.writeByte(14); writer.write(obj.notes);
  }
}
