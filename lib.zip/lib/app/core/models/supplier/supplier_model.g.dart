// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'supplier_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class SupplierModelAdapter extends TypeAdapter<SupplierModel> {
  @override
  final int typeId = 16;

  @override
  SupplierModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SupplierModel(
      id: fields[0] as String,
      name: fields[1] as String,
      type: fields[2] as SupplierType,
      phone: fields[3] as String?,
      address: fields[4] as String?,
      isActive: fields[5] as bool,
      isDeleted: fields[15] as bool,
      lastModified: fields[6] as DateTime?,
      partyType: fields[7] as SupplierPartyType,
      companyName: fields[8] as String?,
      email: fields[9] as String?,
      taxId: fields[10] as String?,
      creditLimit: fields[11] as double,
      discountPercent: fields[12] as double,
      paymentTermDays: fields[13] as int,
      notes: fields[14] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, SupplierModel obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.type)
      ..writeByte(3)
      ..write(obj.phone)
      ..writeByte(4)
      ..write(obj.address)
      ..writeByte(5)
      ..write(obj.isActive)
      ..writeByte(15)
      ..write(obj.isDeleted)
      ..writeByte(6)
      ..write(obj.lastModified)
      ..writeByte(7)
      ..write(obj.partyType)
      ..writeByte(8)
      ..write(obj.companyName)
      ..writeByte(9)
      ..write(obj.email)
      ..writeByte(10)
      ..write(obj.taxId)
      ..writeByte(11)
      ..write(obj.creditLimit)
      ..writeByte(12)
      ..write(obj.discountPercent)
      ..writeByte(13)
      ..write(obj.paymentTermDays)
      ..writeByte(14)
      ..write(obj.notes);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SupplierModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
