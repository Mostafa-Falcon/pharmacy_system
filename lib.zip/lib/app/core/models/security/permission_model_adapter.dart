import 'package:hive/hive.dart';
import 'permission_model.dart';

class PermissionModelAdapter extends TypeAdapter<PermissionModel> {
  @override
  final int typeId = 3;

  @override
  PermissionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime parseDateTime(dynamic value) {
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return DateTime.now();
    }

    return PermissionModel(
      id: fields[0] as String,
      userId: fields[1] as String,
      permissionKey: fields[2] as String,
      isAllowed: fields[3] as bool? ?? false,
      createdAt: parseDateTime(fields[4]),
      syncVersion: fields[5] as int? ?? 1,
      isDeleted: fields[6] as bool? ?? false,
      lastModified: parseDateTime(fields[7]),
    );
  }

  @override
  void write(BinaryWriter writer, PermissionModel obj) {
    writer.writeByte(8);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.userId);
    writer.writeByte(2); writer.write(obj.permissionKey);
    writer.writeByte(3); writer.write(obj.isAllowed);
    writer.writeByte(4); writer.write(obj.createdAt);
    writer.writeByte(5); writer.write(obj.syncVersion);
    writer.writeByte(6); writer.write(obj.isDeleted);
    writer.writeByte(7); writer.write(obj.lastModified);
  }
}
