import 'package:hive/hive.dart';
import 'branch_model.dart';

class BranchModelAdapter extends TypeAdapter<BranchModel> {
  @override
  final int typeId = 2;

  @override
  BranchModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime parseDateTime(dynamic value) {
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return DateTime.now();
    }

    return BranchModel(
      id: fields[0] as String,
      name: fields[1] as String,
      address: fields[2] as String?,
      phone: fields[3] as String?,
      isActive: fields[4] as bool? ?? true,
      createdAt: parseDateTime(fields[5]),
      syncVersion: fields[6] as int? ?? 1,
      lastModified: parseDateTime(fields[7]),
      isDeleted: fields[8] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, BranchModel obj) {
    writer.writeByte(9);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.name);
    writer.writeByte(2); writer.write(obj.address);
    writer.writeByte(3); writer.write(obj.phone);
    writer.writeByte(4); writer.write(obj.isActive);
    writer.writeByte(5); writer.write(obj.createdAt);
    writer.writeByte(6); writer.write(obj.syncVersion);
    writer.writeByte(7); writer.write(obj.lastModified);
    writer.writeByte(8); writer.write(obj.isDeleted);
  }
}
