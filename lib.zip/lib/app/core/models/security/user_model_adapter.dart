import 'package:hive/hive.dart';
import 'user_model.dart';

class UserModelAdapter extends TypeAdapter<UserModel> {
  @override
  final int typeId = 1;

  @override
  UserModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime parseDateTime(dynamic value) {
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return DateTime.now();
    }

    DateTime? parseDateTimeNullable(dynamic value) {
      if (value == null) return null;
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return null;
    }

    return UserModel(
      id: fields[0] as String,
      name: fields[1] as String,
      email: fields[2] as String,
      passwordHash: fields[3] as String,
      role: UserRole.values[fields[4] is int ? fields[4] as int : 1],
      assignedBranchId: fields[5] as String?,
      isActive: fields[6] as bool? ?? true,
      createdAt: parseDateTime(fields[7]),
      lastLogin: parseDateTimeNullable(fields[8]),
      syncVersion: fields[9] as int? ?? 1,
      lastModified: parseDateTime(fields[10]),
      isDeleted: fields[11] as bool? ?? false,
      activeDeviceId: fields[12] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, UserModel obj) {
    writer.writeByte(13);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.name);
    writer.writeByte(2); writer.write(obj.email);
    writer.writeByte(3); writer.write(obj.passwordHash);
    writer.writeByte(4); writer.write(obj.role.index);
    writer.writeByte(5); writer.write(obj.assignedBranchId);
    writer.writeByte(6); writer.write(obj.isActive);
    writer.writeByte(7); writer.write(obj.createdAt);
    writer.writeByte(8); writer.write(obj.lastLogin);
    writer.writeByte(9); writer.write(obj.syncVersion);
    writer.writeByte(10); writer.write(obj.lastModified);
    writer.writeByte(11); writer.write(obj.isDeleted);
    writer.writeByte(12); writer.write(obj.activeDeviceId);
  }
}
