// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'permission_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class PermissionModelAdapter extends TypeAdapter<PermissionModel> {
  @override
  final int typeId = 3;

  @override
  PermissionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PermissionModel(
      id: fields[0] as String,
      userId: fields[1] as String,
      permissionKey: fields[2] as String,
      isAllowed: fields[3] as bool,
      createdAt: fields[4] as DateTime,
      syncVersion: fields[5] as int,
      isDeleted: fields[6] as bool,
      lastModified: fields[7] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, PermissionModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.userId)
      ..writeByte(2)
      ..write(obj.permissionKey)
      ..writeByte(3)
      ..write(obj.isAllowed)
      ..writeByte(4)
      ..write(obj.createdAt)
      ..writeByte(5)
      ..write(obj.syncVersion)
      ..writeByte(6)
      ..write(obj.isDeleted)
      ..writeByte(7)
      ..write(obj.lastModified);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PermissionModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
