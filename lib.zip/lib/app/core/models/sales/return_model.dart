import 'package:hive/hive.dart';

part 'return_model.g.dart';

@HiveType(typeId: 11)
class ReturnItemModel {
  @HiveField(0)
  String medicineId;

  @HiveField(1)
  String medicineName;

  @HiveField(2)
  int quantity;

  @HiveField(3)
  double unitPrice;

  @HiveField(4)
  double totalPrice;

  @HiveField(5)
  String? reason;

  // تكلفة شراء الوحدة — لحساب تكلفة البضاعة المرتجعة (COGS) بدقة.
  @HiveField(6)
  double costPrice;

  ReturnItemModel({
    required this.medicineId,
    required this.medicineName,
    required this.quantity,
    required this.unitPrice,
    required this.totalPrice,
    this.reason,
    this.costPrice = 0,
  });

  Map<String, dynamic> toJson() => {
        'medicine_id': medicineId,
        'medicine_name': medicineName,
        'quantity': quantity,
        'unit_price': unitPrice,
        'total_price': totalPrice,
        'reason': reason,
        'cost_price': costPrice,
      };

  factory ReturnItemModel.fromJson(Map<String, dynamic> json) => ReturnItemModel(
        medicineId: json['medicine_id'] as String,
        medicineName: json['medicine_name'] as String,
        quantity: json['quantity'] as int,
        unitPrice: (json['unit_price'] as num).toDouble(),
        totalPrice: (json['total_price'] as num).toDouble(),
        reason: json['reason'] as String?,
        costPrice: (json['cost_price'] as num?)?.toDouble() ?? 0,
      );
}

@HiveType(typeId: 12)
enum ReturnReason {
  @HiveField(0)
  expired,

  @HiveField(1)
  damaged,

  @HiveField(2)
  wrongItem,

  @HiveField(3)
  customerReturn,

  @HiveField(4)
  other,
}

@HiveType(typeId: 13)
class ReturnModel extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String branchId;

  @HiveField(2)
  String? saleId; // original sale id if return from sale

  @HiveField(3)
  String? purchaseId; // original purchase id if return to supplier

  @HiveField(4)
  List<ReturnItemModel> items;

  @HiveField(5)
  double totalAmount;

  @HiveField(6)
  ReturnReason reason;

  @HiveField(7)
  String? notes;

  @HiveField(8)
  String createdBy; // userId

  @HiveField(9)
  DateTime createdAt;

  @HiveField(10)
  int syncVersion;

  @HiveField(11)
  DateTime lastModified;

  @HiveField(12)
  bool isDeleted;

  ReturnModel({
    required this.id,
    required this.branchId,
    this.saleId,
    this.purchaseId,
    required this.items,
    required this.totalAmount,
    required this.reason,
    this.notes,
    required this.createdBy,
    required this.createdAt,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : lastModified = lastModified ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'branch_id': branchId,
    'sale_id': saleId,
    'purchase_id': purchaseId,
    'items': items.map((e) => e.toJson()).toList(),
    'total_amount': totalAmount,
    'reason': reason.name,
    'notes': notes,
    'created_by': createdBy,
    'created_at': createdAt.toIso8601String(),
    'sync_version': syncVersion,
    'last_modified': lastModified.toIso8601String(),
    'is_deleted': isDeleted,
  };

  factory ReturnModel.fromJson(Map<String, dynamic> json) => ReturnModel(
    id: json['id'] as String,
    branchId: json['branch_id'] as String,
    saleId: json['sale_id'] as String?,
    purchaseId: json['purchase_id'] as String?,
    items: (json['items'] as List<dynamic>?)
            ?.map((e) => ReturnItemModel.fromJson(e as Map<String, dynamic>))
            .toList() ??
        [],
    totalAmount: (json['total_amount'] as num).toDouble(),
    reason: ReturnReason.values.firstWhere(
      (r) => r.name == json['reason'],
      orElse: () => ReturnReason.other,
    ),
    notes: json['notes'] as String?,
    createdBy: json['created_by'] as String,
    createdAt: DateTime.tryParse(json['created_at'] as String) ?? DateTime.now(),
    syncVersion: json['sync_version'] as int? ?? 1,
    lastModified: json['last_modified'] != null
        ? DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now()
        : DateTime.now(),
    isDeleted: json['is_deleted'] as bool? ?? false,
  );
}
