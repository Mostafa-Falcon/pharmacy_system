import 'package:hive/hive.dart';
import 'purchase_model.dart';

class ManualPurchaseItemModelAdapter extends TypeAdapter<PurchaseItemModel> {
  @override
  final int typeId = 8;

  @override
  PurchaseItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PurchaseItemModel(
      medicineId: fields[0] as String,
      medicineName: fields[1] as String,
      quantity: fields[2] as int,
      unitPrice: fields[3] as double,
      totalPrice: fields[4] as double,
      batchNumber: fields[5] as String?,
      expiryDate: fields[6] != null
          ? DateTime.fromMillisecondsSinceEpoch(fields[6] as int)
          : null,
      discount: fields[7] as double?,
      discountType: fields[8] as String?,
      taxAmount: fields[9] as double?,
      previousUnitPrice: fields[10] as double?,
      unitId: fields[11] as String?,
      unitName: fields[12] as String?,
      taxType: fields[13] as String?,
      invoiceDiscountShare: fields[14] as double?,
      invoiceTaxShare: fields[15] as double?,
    );
  }

  @override
  void write(BinaryWriter writer, PurchaseItemModel obj) {
    writer.writeByte(16);
    writer.writeByte(0); writer.write(obj.medicineId);
    writer.writeByte(1); writer.write(obj.medicineName);
    writer.writeByte(2); writer.write(obj.quantity);
    writer.writeByte(3); writer.write(obj.unitPrice);
    writer.writeByte(4); writer.write(obj.totalPrice);
    writer.writeByte(5); writer.write(obj.batchNumber);
    writer.writeByte(6); writer.write(obj.expiryDate?.millisecondsSinceEpoch);
    writer.writeByte(7); writer.write(obj.discount);
    writer.writeByte(8); writer.write(obj.discountType);
    writer.writeByte(9); writer.write(obj.taxAmount);
    writer.writeByte(10); writer.write(obj.previousUnitPrice);
    writer.writeByte(11); writer.write(obj.unitId);
    writer.writeByte(12); writer.write(obj.unitName);
    writer.writeByte(13); writer.write(obj.taxType);
    writer.writeByte(14); writer.write(obj.invoiceDiscountShare);
    writer.writeByte(15); writer.write(obj.invoiceTaxShare);
  }
}

class ManualPurchaseModelAdapter extends TypeAdapter<PurchaseModel> {
  @override
  final int typeId = 9;

  @override
  PurchaseModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PurchaseModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      supplierName: fields[2] as String,
      supplierPhone: fields[3] as String?,
      items: (fields[4] as List).cast<PurchaseItemModel>(),
      totalAmount: fields[5] as double,
      discount: fields[6] as double?,
      finalAmount: fields[7] as double,
      paymentMethod: fields[8] as String,
      paidAmount: fields[9] as double?,
      notes: fields[10] as String?,
      createdBy: fields[11] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[12] as int),
      syncVersion: fields[13] as int,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[14] as int),
      isDeleted: fields[15] as bool,
      status: fields[16] as String? ?? 'completed',
      supplierId: fields[17] as String?,
      sourceType: fields[18] as String?,
      tax: fields[19] as double?,
      receiptNumber: fields[20] as String?,
      shippingAmount: fields[21] as double?,
      deliveryAmount: fields[22] as double?,
      supplierPartyType: fields[23] as String?,
      invoiceDiscountType: fields[24] as String?,
      invoiceDiscountValue: fields[25] as double?,
      invoiceDiscountAmount: fields[26] as double?,
      invoiceTaxType: fields[27] as String?,
      invoiceTaxValue: fields[28] as double?,
      invoiceTaxAmount: fields[29] as double?,
      paymentAccountId: fields[30] as String?,
      paymentAccountName: fields[31] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, PurchaseModel obj) {
    writer.writeByte(32);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.supplierName);
    writer.writeByte(3); writer.write(obj.supplierPhone);
    writer.writeByte(4); writer.write(obj.items);
    writer.writeByte(5); writer.write(obj.totalAmount);
    writer.writeByte(6); writer.write(obj.discount);
    writer.writeByte(7); writer.write(obj.finalAmount);
    writer.writeByte(8); writer.write(obj.paymentMethod);
    writer.writeByte(9); writer.write(obj.paidAmount);
    writer.writeByte(10); writer.write(obj.notes);
    writer.writeByte(11); writer.write(obj.createdBy);
    writer.writeByte(12); writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(13); writer.write(obj.syncVersion);
    writer.writeByte(14); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(15); writer.write(obj.isDeleted);
    writer.writeByte(16); writer.write(obj.status);
    writer.writeByte(17); writer.write(obj.supplierId);
    writer.writeByte(18); writer.write(obj.sourceType);
    writer.writeByte(19); writer.write(obj.tax);
    writer.writeByte(20); writer.write(obj.receiptNumber);
    writer.writeByte(21); writer.write(obj.shippingAmount);
    writer.writeByte(22); writer.write(obj.deliveryAmount);
    writer.writeByte(23); writer.write(obj.supplierPartyType);
    writer.writeByte(24); writer.write(obj.invoiceDiscountType);
    writer.writeByte(25); writer.write(obj.invoiceDiscountValue);
    writer.writeByte(26); writer.write(obj.invoiceDiscountAmount);
    writer.writeByte(27); writer.write(obj.invoiceTaxType);
    writer.writeByte(28); writer.write(obj.invoiceTaxValue);
    writer.writeByte(29); writer.write(obj.invoiceTaxAmount);
    writer.writeByte(30); writer.write(obj.paymentAccountId);
    writer.writeByte(31); writer.write(obj.paymentAccountName);
  }
}
