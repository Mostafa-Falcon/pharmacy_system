// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ReturnItemModelAdapter extends TypeAdapter<ReturnItemModel> {
  @override
  final int typeId = 11;

  @override
  ReturnItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ReturnItemModel(
      medicineId: fields[0] as String,
      medicineName: fields[1] as String,
      quantity: fields[2] as int,
      unitPrice: fields[3] as double,
      totalPrice: fields[4] as double,
      reason: fields[5] as String?,
      costPrice: fields[6] as double,
    );
  }

  @override
  void write(BinaryWriter writer, ReturnItemModel obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.medicineId)
      ..writeByte(1)
      ..write(obj.medicineName)
      ..writeByte(2)
      ..write(obj.quantity)
      ..writeByte(3)
      ..write(obj.unitPrice)
      ..writeByte(4)
      ..write(obj.totalPrice)
      ..writeByte(5)
      ..write(obj.reason)
      ..writeByte(6)
      ..write(obj.costPrice);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ReturnItemModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ReturnModelAdapter extends TypeAdapter<ReturnModel> {
  @override
  final int typeId = 13;

  @override
  ReturnModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ReturnModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      saleId: fields[2] as String?,
      purchaseId: fields[3] as String?,
      items: (fields[4] as List).cast<ReturnItemModel>(),
      totalAmount: fields[5] as double,
      reason: fields[6] as ReturnReason,
      notes: fields[7] as String?,
      createdBy: fields[8] as String,
      createdAt: fields[9] as DateTime,
      syncVersion: fields[10] as int,
      lastModified: fields[11] as DateTime?,
      isDeleted: fields[12] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ReturnModel obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.branchId)
      ..writeByte(2)
      ..write(obj.saleId)
      ..writeByte(3)
      ..write(obj.purchaseId)
      ..writeByte(4)
      ..write(obj.items)
      ..writeByte(5)
      ..write(obj.totalAmount)
      ..writeByte(6)
      ..write(obj.reason)
      ..writeByte(7)
      ..write(obj.notes)
      ..writeByte(8)
      ..write(obj.createdBy)
      ..writeByte(9)
      ..write(obj.createdAt)
      ..writeByte(10)
      ..write(obj.syncVersion)
      ..writeByte(11)
      ..write(obj.lastModified)
      ..writeByte(12)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ReturnModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ReturnReasonAdapter extends TypeAdapter<ReturnReason> {
  @override
  final int typeId = 12;

  @override
  ReturnReason read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return ReturnReason.expired;
      case 1:
        return ReturnReason.damaged;
      case 2:
        return ReturnReason.wrongItem;
      case 3:
        return ReturnReason.customerReturn;
      case 4:
        return ReturnReason.other;
      default:
        return ReturnReason.expired;
    }
  }

  @override
  void write(BinaryWriter writer, ReturnReason obj) {
    switch (obj) {
      case ReturnReason.expired:
        writer.writeByte(0);
        break;
      case ReturnReason.damaged:
        writer.writeByte(1);
        break;
      case ReturnReason.wrongItem:
        writer.writeByte(2);
        break;
      case ReturnReason.customerReturn:
        writer.writeByte(3);
        break;
      case ReturnReason.other:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ReturnReasonAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
