// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'purchase_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class PurchaseItemModelAdapter extends TypeAdapter<PurchaseItemModel> {
  @override
  final int typeId = 8;

  @override
  PurchaseItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PurchaseItemModel(
      medicineId: fields[0] as String,
      medicineName: fields[1] as String,
      quantity: fields[2] as int,
      unitPrice: fields[3] as double,
      totalPrice: fields[4] as double,
      batchNumber: fields[5] as String?,
      expiryDate: fields[6] as DateTime?,
      discount: fields[7] as double?,
      discountType: fields[8] as String?,
      taxAmount: fields[9] as double?,
      previousUnitPrice: fields[10] as double?,
      unitId: fields[11] as String?,
      unitName: fields[12] as String?,
      taxType: fields[13] as String?,
      invoiceDiscountShare: fields[14] as double?,
      invoiceTaxShare: fields[15] as double?,
    );
  }

  @override
  void write(BinaryWriter writer, PurchaseItemModel obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)
      ..write(obj.medicineId)
      ..writeByte(1)
      ..write(obj.medicineName)
      ..writeByte(2)
      ..write(obj.quantity)
      ..writeByte(3)
      ..write(obj.unitPrice)
      ..writeByte(4)
      ..write(obj.totalPrice)
      ..writeByte(5)
      ..write(obj.batchNumber)
      ..writeByte(6)
      ..write(obj.expiryDate)
      ..writeByte(7)
      ..write(obj.discount)
      ..writeByte(8)
      ..write(obj.discountType)
      ..writeByte(9)
      ..write(obj.taxAmount)
      ..writeByte(10)
      ..write(obj.previousUnitPrice)
      ..writeByte(11)
      ..write(obj.unitId)
      ..writeByte(12)
      ..write(obj.unitName)
      ..writeByte(13)
      ..write(obj.taxType)
      ..writeByte(14)
      ..write(obj.invoiceDiscountShare)
      ..writeByte(15)
      ..write(obj.invoiceTaxShare);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PurchaseItemModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class PurchaseModelAdapter extends TypeAdapter<PurchaseModel> {
  @override
  final int typeId = 9;

  @override
  PurchaseModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PurchaseModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      supplierName: fields[2] as String,
      supplierPhone: fields[3] as String?,
      items: (fields[4] as List).cast<PurchaseItemModel>(),
      totalAmount: fields[5] as double,
      discount: fields[6] as double?,
      tax: fields[19] as double?,
      finalAmount: fields[7] as double,
      paymentMethod: fields[8] as String,
      paidAmount: fields[9] as double?,
      notes: fields[10] as String?,
      createdBy: fields[11] as String,
      createdAt: fields[12] as DateTime,
      syncVersion: fields[13] as int,
      lastModified: fields[14] as DateTime?,
      isDeleted: fields[15] as bool,
      status: fields[16] as String,
      supplierId: fields[17] as String?,
      sourceType: fields[18] as String?,
      receiptNumber: fields[20] as String?,
      shippingAmount: fields[21] as double?,
      deliveryAmount: fields[22] as double?,
      supplierPartyType: fields[23] as String?,
      invoiceDiscountType: fields[24] as String?,
      invoiceDiscountValue: fields[25] as double?,
      invoiceDiscountAmount: fields[26] as double?,
      invoiceTaxType: fields[27] as String?,
      invoiceTaxValue: fields[28] as double?,
      invoiceTaxAmount: fields[29] as double?,
      paymentAccountId: fields[30] as String?,
      paymentAccountName: fields[31] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, PurchaseModel obj) {
    writer
      ..writeByte(32)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.branchId)
      ..writeByte(2)
      ..write(obj.supplierName)
      ..writeByte(3)
      ..write(obj.supplierPhone)
      ..writeByte(4)
      ..write(obj.items)
      ..writeByte(5)
      ..write(obj.totalAmount)
      ..writeByte(6)
      ..write(obj.discount)
      ..writeByte(7)
      ..write(obj.finalAmount)
      ..writeByte(8)
      ..write(obj.paymentMethod)
      ..writeByte(9)
      ..write(obj.paidAmount)
      ..writeByte(10)
      ..write(obj.notes)
      ..writeByte(11)
      ..write(obj.createdBy)
      ..writeByte(12)
      ..write(obj.createdAt)
      ..writeByte(13)
      ..write(obj.syncVersion)
      ..writeByte(14)
      ..write(obj.lastModified)
      ..writeByte(15)
      ..write(obj.isDeleted)
      ..writeByte(16)
      ..write(obj.status)
      ..writeByte(17)
      ..write(obj.supplierId)
      ..writeByte(18)
      ..write(obj.sourceType)
      ..writeByte(19)
      ..write(obj.tax)
      ..writeByte(20)
      ..write(obj.receiptNumber)
      ..writeByte(21)
      ..write(obj.shippingAmount)
      ..writeByte(22)
      ..write(obj.deliveryAmount)
      ..writeByte(23)
      ..write(obj.supplierPartyType)
      ..writeByte(24)
      ..write(obj.invoiceDiscountType)
      ..writeByte(25)
      ..write(obj.invoiceDiscountValue)
      ..writeByte(26)
      ..write(obj.invoiceDiscountAmount)
      ..writeByte(27)
      ..write(obj.invoiceTaxType)
      ..writeByte(28)
      ..write(obj.invoiceTaxValue)
      ..writeByte(29)
      ..write(obj.invoiceTaxAmount)
      ..writeByte(30)
      ..write(obj.paymentAccountId)
      ..writeByte(31)
      ..write(obj.paymentAccountName);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PurchaseModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
