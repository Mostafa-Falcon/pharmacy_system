import 'package:hive/hive.dart';

enum QuoteStatus { draft, sent, accepted, rejected }

class QuoteModel extends HiveObject {
  String id;
  String branchId;
  int number;
  String customerName;
  String? notes;
  List<Map<String, dynamic>> items;
  double subtotal;
  double discount;
  double total;
  QuoteStatus status;
  DateTime createdAt;
  int syncVersion;
  DateTime lastModified;
  bool isDeleted;

  QuoteModel({
    required this.id,
    required this.branchId,
    required this.number,
    required this.customerName,
    this.notes,
    this.items = const [],
    this.subtotal = 0,
    this.discount = 0,
    this.total = 0,
    this.status = QuoteStatus.draft,
    required this.createdAt,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : lastModified = lastModified ?? DateTime.now();

  QuoteModel copyWith({
    String? id,
    String? branchId,
    int? number,
    String? customerName,
    String? notes,
    List<Map<String, dynamic>>? items,
    double? subtotal,
    double? discount,
    double? total,
    QuoteStatus? status,
    DateTime? createdAt,
    int? syncVersion,
    DateTime? lastModified,
    bool? isDeleted,
  }) {
    return QuoteModel(
      id: id ?? this.id,
      branchId: branchId ?? this.branchId,
      number: number ?? this.number,
      customerName: customerName ?? this.customerName,
      notes: notes ?? this.notes,
      items: items ?? this.items,
      subtotal: subtotal ?? this.subtotal,
      discount: discount ?? this.discount,
      total: total ?? this.total,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      syncVersion: syncVersion ?? this.syncVersion + 1,
      lastModified: lastModified ?? DateTime.now(),
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'branch_id': branchId,
        'number': number,
        'customer_name': customerName,
        'notes': notes,
        'items': items
            .map((e) => {
                  'name': e['name'],
                  'qty': e['qty'],
                  'unit_price': e['unit_price'],
                  'total': e['total'],
                })
            .toList(),
        'subtotal': subtotal,
        'discount': discount,
        'total': total,
        'status': status.name,
        'created_at': createdAt.toIso8601String(),
        'sync_version': syncVersion,
        'last_modified': lastModified.toIso8601String(),
        'is_deleted': isDeleted,
      };

  factory QuoteModel.fromJson(Map<String, dynamic> json) => QuoteModel(
        id: json['id'] as String,
        branchId: json['branch_id'] as String,
        number: json['number'] as int? ?? 1,
        customerName: json['customer_name'] as String? ?? '',
        notes: json['notes'] as String?,
        items: (json['items'] as List?)
                ?.cast<Map<String, dynamic>>()
                .map((e) => {
                      'name': e['name'],
                      'qty': e['qty'],
                      'unit_price': e['unit_price'],
                      'total': e['total'],
                    })
                .toList() ??
            [],
        subtotal: (json['subtotal'] as num?)?.toDouble() ?? 0,
        discount: (json['discount'] as num?)?.toDouble() ?? 0,
        total: (json['total'] as num?)?.toDouble() ?? 0,
        status: QuoteStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => QuoteStatus.draft,
        ),
        createdAt: json['created_at'] != null
            ? DateTime.tryParse(json['created_at'] as String) ?? DateTime.now()
            : DateTime.now(),
        syncVersion: json['sync_version'] as int? ?? 1,
        lastModified: json['last_modified'] != null
            ? DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now()
            : DateTime.now(),
        isDeleted: json['is_deleted'] as bool? ?? false,
      );
}

class QuoteModelAdapter extends TypeAdapter<QuoteModel> {
  @override
  final int typeId = 32;

  @override
  QuoteModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return QuoteModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      number: fields[2] as int? ?? 1,
      customerName: fields[3] as String? ?? '',
      notes: fields[4] as String?,
      items: (fields[5] as List?)?.cast<Map<String, dynamic>>() ?? [],
      subtotal: (fields[6] as num?)?.toDouble() ?? 0,
      discount: (fields[7] as num?)?.toDouble() ?? 0,
      total: (fields[8] as num?)?.toDouble() ?? 0,
      status: QuoteStatus.values[fields[9] as int? ?? 0],
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[10] as int? ?? DateTime.now().millisecondsSinceEpoch),
      syncVersion: fields[11] as int? ?? 1,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[12] as int? ?? DateTime.now().millisecondsSinceEpoch),
      isDeleted: fields[13] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, QuoteModel obj) {
    writer.writeByte(14);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.number);
    writer.writeByte(3); writer.write(obj.customerName);
    writer.writeByte(4); writer.write(obj.notes);
    writer.writeByte(5); writer.write(obj.items);
    writer.writeByte(6); writer.write(obj.subtotal);
    writer.writeByte(7); writer.write(obj.discount);
    writer.writeByte(8); writer.write(obj.total);
    writer.writeByte(9); writer.write(obj.status.index);
    writer.writeByte(10); writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(11); writer.write(obj.syncVersion);
    writer.writeByte(12); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(13); writer.write(obj.isDeleted);
  }
}
