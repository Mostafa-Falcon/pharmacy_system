import 'package:hive/hive.dart';
import 'return_model.dart';

class ManualReturnItemModelAdapter extends TypeAdapter<ReturnItemModel> {
  @override
  final int typeId = 11;

  @override
  ReturnItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ReturnItemModel(
      medicineId: fields[0] as String,
      medicineName: fields[1] as String,
      quantity: fields[2] as int,
      unitPrice: fields[3] as double,
      totalPrice: fields[4] as double,
      reason: fields[5] as String?,
      costPrice: (fields[6] as double?) ?? 0,
    );
  }

  @override
  void write(BinaryWriter writer, ReturnItemModel obj) {
    writer.writeByte(7);
    writer.writeByte(0);
    writer.write(obj.medicineId);
    writer.writeByte(1);
    writer.write(obj.medicineName);
    writer.writeByte(2);
    writer.write(obj.quantity);
    writer.writeByte(3);
    writer.write(obj.unitPrice);
    writer.writeByte(4);
    writer.write(obj.totalPrice);
    writer.writeByte(5);
    writer.write(obj.reason);
    writer.writeByte(6);
    writer.write(obj.costPrice);
  }
}

class ManualReturnReasonAdapter extends TypeAdapter<ReturnReason> {
  @override
  final int typeId = 12;

  @override
  ReturnReason read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return ReturnReason.expired;
      case 1:
        return ReturnReason.damaged;
      case 2:
        return ReturnReason.wrongItem;
      case 3:
        return ReturnReason.customerReturn;
      default:
        return ReturnReason.other;
    }
  }

  @override
  void write(BinaryWriter writer, ReturnReason obj) {
    switch (obj) {
      case ReturnReason.expired:
        writer.writeByte(0);
        break;
      case ReturnReason.damaged:
        writer.writeByte(1);
        break;
      case ReturnReason.wrongItem:
        writer.writeByte(2);
        break;
      case ReturnReason.customerReturn:
        writer.writeByte(3);
        break;
      case ReturnReason.other:
        writer.writeByte(4);
        break;
    }
  }
}

class ManualReturnModelAdapter extends TypeAdapter<ReturnModel> {
  @override
  final int typeId = 13;

  @override
  ReturnModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ReturnModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      saleId: fields[2] as String?,
      purchaseId: fields[3] as String?,
      items: (fields[4] as List).cast<ReturnItemModel>(),
      totalAmount: fields[5] as double,
      reason: fields[6] as ReturnReason,
      notes: fields[7] as String?,
      createdBy: fields[8] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[9] as int),
      syncVersion: fields[10] as int,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[11] as int),
      isDeleted: fields[12] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ReturnModel obj) {
    writer.writeByte(13);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.branchId);
    writer.writeByte(2);
    writer.write(obj.saleId);
    writer.writeByte(3);
    writer.write(obj.purchaseId);
    writer.writeByte(4);
    writer.write(obj.items);
    writer.writeByte(5);
    writer.write(obj.totalAmount);
    writer.writeByte(6);
    writer.write(obj.reason);
    writer.writeByte(7);
    writer.write(obj.notes);
    writer.writeByte(8);
    writer.write(obj.createdBy);
    writer.writeByte(9);
    writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(10);
    writer.write(obj.syncVersion);
    writer.writeByte(11);
    writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(12);
    writer.write(obj.isDeleted);
  }
}
