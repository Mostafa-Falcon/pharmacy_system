import 'package:hive/hive.dart';

enum CashierShiftStatus { open, closed }

class CashierShiftModel extends HiveObject {
  String id;
  String branchId;
  int shiftNumber;
  String cashierId;
  String cashierName;
  String deviceId;
  DateTime openedAt;
  double openingCash;
  CashierShiftStatus status;
  DateTime? closedAt;
  double? expectedCash;
  double? countedCash;
  double? difference;
  String? notes;
  int syncVersion;
  DateTime lastModified;
  bool isDeleted;

  CashierShiftModel({
    required this.id,
    required this.branchId,
    required this.shiftNumber,
    required this.cashierId,
    required this.cashierName,
    required this.deviceId,
    required this.openedAt,
    this.openingCash = 0,
    this.status = CashierShiftStatus.open,
    this.closedAt,
    this.expectedCash,
    this.countedCash,
    this.difference,
    this.notes,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : lastModified = lastModified ?? DateTime.now();

  CashierShiftModel copyWith({
    String? id,
    String? branchId,
    int? shiftNumber,
    String? cashierId,
    String? cashierName,
    String? deviceId,
    DateTime? openedAt,
    double? openingCash,
    CashierShiftStatus? status,
    DateTime? closedAt,
    double? expectedCash,
    double? countedCash,
    double? difference,
    String? notes,
    int? syncVersion,
    DateTime? lastModified,
    bool? isDeleted,
  }) {
    return CashierShiftModel(
      id: id ?? this.id,
      branchId: branchId ?? this.branchId,
      shiftNumber: shiftNumber ?? this.shiftNumber,
      cashierId: cashierId ?? this.cashierId,
      cashierName: cashierName ?? this.cashierName,
      deviceId: deviceId ?? this.deviceId,
      openedAt: openedAt ?? this.openedAt,
      openingCash: openingCash ?? this.openingCash,
      status: status ?? this.status,
      closedAt: closedAt ?? this.closedAt,
      expectedCash: expectedCash ?? this.expectedCash,
      countedCash: countedCash ?? this.countedCash,
      difference: difference ?? this.difference,
      notes: notes ?? this.notes,
      syncVersion: syncVersion ?? this.syncVersion + 1,
      lastModified: lastModified ?? DateTime.now(),
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'branch_id': branchId,
    'shift_number': shiftNumber,
    'cashier_id': cashierId,
    'cashier_name': cashierName,
    'device_id': deviceId,
    'opened_at': openedAt.toIso8601String(),
    'opening_cash': openingCash,
    'status': status.name,
    'closed_at': closedAt?.toIso8601String(),
    'expected_cash': expectedCash,
    'counted_cash': countedCash,
    'difference': difference,
    'notes': notes,
    'sync_version': syncVersion,
    'last_modified': lastModified.toIso8601String(),
    'is_deleted': isDeleted,
  };

  factory CashierShiftModel.fromJson(Map<String, dynamic> json) =>
      CashierShiftModel(
        id: json['id'] as String,
        branchId: json['branch_id'] as String,
        shiftNumber: json['shift_number'] as int? ?? 1,
        cashierId: json['cashier_id'] as String,
        cashierName: json['cashier_name'] as String? ?? '',
        deviceId: json['device_id'] as String? ?? '',
        openedAt: DateTime.tryParse(json['opened_at'] as String) ??
            DateTime.now(),
        openingCash: (json['opening_cash'] as num?)?.toDouble() ?? 0,
        status: CashierShiftStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => CashierShiftStatus.open,
        ),
        closedAt: json['closed_at'] != null
            ? DateTime.tryParse(json['closed_at'] as String)
            : null,
        expectedCash: (json['expected_cash'] as num?)?.toDouble(),
        countedCash: (json['counted_cash'] as num?)?.toDouble(),
        difference: (json['difference'] as num?)?.toDouble(),
        notes: json['notes'] as String?,
        syncVersion: json['sync_version'] as int? ?? 1,
        lastModified: json['last_modified'] != null
            ? DateTime.tryParse(json['last_modified'] as String) ??
                DateTime.now()
            : DateTime.now(),
        isDeleted: json['is_deleted'] as bool? ?? false,
      );
}

class CashierShiftModelAdapter extends TypeAdapter<CashierShiftModel> {
  @override
  final int typeId = 31;

  @override
  CashierShiftModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CashierShiftModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      shiftNumber: fields[2] as int,
      cashierId: fields[3] as String,
      cashierName: fields[4] as String? ?? '',
      deviceId: fields[5] as String? ?? '',
      openedAt: DateTime.fromMillisecondsSinceEpoch(fields[6] as int),
      openingCash: (fields[7] as num?)?.toDouble() ?? 0,
      status: CashierShiftStatus.values[fields[8] as int? ?? 0],
      closedAt: fields[9] != null
          ? DateTime.fromMillisecondsSinceEpoch(fields[9] as int)
          : null,
      expectedCash: (fields[10] as num?)?.toDouble(),
      countedCash: (fields[11] as num?)?.toDouble(),
      difference: (fields[12] as num?)?.toDouble(),
      notes: fields[13] as String?,
      syncVersion: fields[14] as int? ?? 1,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[15] as int? ?? DateTime.now().millisecondsSinceEpoch),
      isDeleted: fields[16] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, CashierShiftModel obj) {
    writer.writeByte(17);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.shiftNumber);
    writer.writeByte(3); writer.write(obj.cashierId);
    writer.writeByte(4); writer.write(obj.cashierName);
    writer.writeByte(5); writer.write(obj.deviceId);
    writer.writeByte(6); writer.write(obj.openedAt.millisecondsSinceEpoch);
    writer.writeByte(7); writer.write(obj.openingCash);
    writer.writeByte(8); writer.write(obj.status.index);
    writer.writeByte(9); writer.write(obj.closedAt?.millisecondsSinceEpoch);
    writer.writeByte(10); writer.write(obj.expectedCash);
    writer.writeByte(11); writer.write(obj.countedCash);
    writer.writeByte(12); writer.write(obj.difference);
    writer.writeByte(13); writer.write(obj.notes);
    writer.writeByte(14); writer.write(obj.syncVersion);
    writer.writeByte(15); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(16); writer.write(obj.isDeleted);
  }
}
