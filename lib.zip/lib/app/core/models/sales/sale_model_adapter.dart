import 'package:hive/hive.dart';
import 'sale_model.dart';

class ManualSaleItemModelAdapter extends TypeAdapter<SaleItemModel> {
  @override
  final int typeId = 6;

  @override
  SaleItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SaleItemModel(
      medicineId: fields[0] as String,
      medicineName: fields[1] as String,
      quantity: fields[2] as int,
      unitPrice: (fields[3] as num).toDouble(),
      totalPrice: (fields[4] as num).toDouble(),
      costPrice: (fields[5] as num?)?.toDouble() ?? 0.0,
    );
  }

  @override
  void write(BinaryWriter writer, SaleItemModel obj) {
    writer.writeByte(6);
    writer.writeByte(0); writer.write(obj.medicineId);
    writer.writeByte(1); writer.write(obj.medicineName);
    writer.writeByte(2); writer.write(obj.quantity);
    writer.writeByte(3); writer.write(obj.unitPrice);
    writer.writeByte(4); writer.write(obj.totalPrice);
    writer.writeByte(5); writer.write(obj.costPrice);
  }
}

class ManualSaleModelAdapter extends TypeAdapter<SaleModel> {
  @override
  final int typeId = 7;

  @override
  SaleModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime parseDateTime(dynamic value) {
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return DateTime.now();
    }

    return SaleModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      customerId: fields[2] as String?,
      customerName: fields[3] as String?,
      items: (fields[4] as List).cast<SaleItemModel>(),
      totalAmount: (fields[5] as num).toDouble(),
      discount: (fields[6] as num?)?.toDouble(),
      finalAmount: (fields[7] as num).toDouble(),
      paymentMethod: fields[8] as String,
      notes: fields[9] as String?,
      createdBy: fields[10] as String,
      createdAt: parseDateTime(fields[11]),
      syncVersion: fields[12] as int,
      lastModified: parseDateTime(fields[13]),
      isDeleted: fields[14] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, SaleModel obj) {
    writer.writeByte(15);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.customerId);
    writer.writeByte(3); writer.write(obj.customerName);
    writer.writeByte(4); writer.write(obj.items);
    writer.writeByte(5); writer.write(obj.totalAmount);
    writer.writeByte(6); writer.write(obj.discount);
    writer.writeByte(7); writer.write(obj.finalAmount);
    writer.writeByte(8); writer.write(obj.paymentMethod);
    writer.writeByte(9); writer.write(obj.notes);
    writer.writeByte(10); writer.write(obj.createdBy);
    writer.writeByte(11); writer.write(obj.createdAt);
    writer.writeByte(13); writer.write(obj.lastModified);
    writer.writeByte(12); writer.write(obj.syncVersion);
    writer.writeByte(14); writer.write(obj.isDeleted);
  }
}
