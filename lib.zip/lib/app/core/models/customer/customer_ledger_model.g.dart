// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'customer_ledger_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CustomerLedgerModelAdapter extends TypeAdapter<CustomerLedgerModel> {
  @override
  final int typeId = 18;

  @override
  CustomerLedgerModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CustomerLedgerModel(
      id: fields[0] as String,
      customerId: fields[1] as String,
      branchId: fields[2] as String,
      type: fields[3] as CustomerLedgerEntryType,
      debit: fields[4] as double,
      credit: fields[5] as double,
      balanceAfter: fields[6] as double,
      referenceId: fields[7] as String?,
      referenceNumber: fields[8] as String?,
      notes: fields[9] as String?,
      createdBy: fields[10] as String?,
      entryDate: fields[11] as DateTime,
      syncVersion: fields[12] as int,
      lastModified: fields[13] as DateTime?,
      isDeleted: fields[14] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, CustomerLedgerModel obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.customerId)
      ..writeByte(2)
      ..write(obj.branchId)
      ..writeByte(3)
      ..write(obj.type)
      ..writeByte(4)
      ..write(obj.debit)
      ..writeByte(5)
      ..write(obj.credit)
      ..writeByte(6)
      ..write(obj.balanceAfter)
      ..writeByte(7)
      ..write(obj.referenceId)
      ..writeByte(8)
      ..write(obj.referenceNumber)
      ..writeByte(9)
      ..write(obj.notes)
      ..writeByte(10)
      ..write(obj.createdBy)
      ..writeByte(11)
      ..write(obj.entryDate)
      ..writeByte(12)
      ..write(obj.syncVersion)
      ..writeByte(13)
      ..write(obj.lastModified)
      ..writeByte(14)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomerLedgerModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class CustomerLedgerEntryTypeAdapter
    extends TypeAdapter<CustomerLedgerEntryType> {
  @override
  final int typeId = 17;

  @override
  CustomerLedgerEntryType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return CustomerLedgerEntryType.openingBalance;
      case 1:
        return CustomerLedgerEntryType.saleInvoice;
      case 2:
        return CustomerLedgerEntryType.saleReturn;
      case 3:
        return CustomerLedgerEntryType.customerPayment;
      case 4:
        return CustomerLedgerEntryType.saleVoid;
      case 5:
        return CustomerLedgerEntryType.manualAdjustment;
      case 6:
        return CustomerLedgerEntryType.additionNotice;
      case 7:
        return CustomerLedgerEntryType.discountNotice;
      case 8:
        return CustomerLedgerEntryType.checkReceipt;
      case 9:
        return CustomerLedgerEntryType.checkPayment;
      default:
        return CustomerLedgerEntryType.openingBalance;
    }
  }

  @override
  void write(BinaryWriter writer, CustomerLedgerEntryType obj) {
    switch (obj) {
      case CustomerLedgerEntryType.openingBalance:
        writer.writeByte(0);
        break;
      case CustomerLedgerEntryType.saleInvoice:
        writer.writeByte(1);
        break;
      case CustomerLedgerEntryType.saleReturn:
        writer.writeByte(2);
        break;
      case CustomerLedgerEntryType.customerPayment:
        writer.writeByte(3);
        break;
      case CustomerLedgerEntryType.saleVoid:
        writer.writeByte(4);
        break;
      case CustomerLedgerEntryType.manualAdjustment:
        writer.writeByte(5);
        break;
      case CustomerLedgerEntryType.additionNotice:
        writer.writeByte(6);
        break;
      case CustomerLedgerEntryType.discountNotice:
        writer.writeByte(7);
        break;
      case CustomerLedgerEntryType.checkReceipt:
        writer.writeByte(8);
        break;
      case CustomerLedgerEntryType.checkPayment:
        writer.writeByte(9);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomerLedgerEntryTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
