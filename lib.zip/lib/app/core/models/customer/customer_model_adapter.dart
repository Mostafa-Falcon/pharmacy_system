import 'package:hive/hive.dart';
import 'customer_model.dart';

class ManualCustomerModelAdapter extends TypeAdapter<CustomerModel> {
  @override
  final int typeId = 25;

  @override
  CustomerModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime parseDateTime(dynamic value) {
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return DateTime.now();
    }

    return CustomerModel(
      id: fields[0] as String,
      name: fields[1] as String,
      phone: fields[2] as String?,
      address: fields[3] as String?,
      isActive: fields[4] as bool? ?? true,
      kind: CustomerKind.values[fields[5] is int ? fields[5] as int : 0],
      companyName: fields[6] as String?,
      email: fields[7] as String?,
      taxId: fields[8] as String?,
      creditLimit: (fields[9] as num?)?.toDouble() ?? 0.0,
      discountPercent: (fields[10] as num?)?.toDouble() ?? 0.0,
      paymentTermDays: fields[11] as int? ?? 0,
      notes: fields[12] as String?,
      lastModified: parseDateTime(fields[13]),
    );
  }

  @override
  void write(BinaryWriter writer, CustomerModel obj) {
    writer.writeByte(14);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.name);
    writer.writeByte(2); writer.write(obj.phone);
    writer.writeByte(3); writer.write(obj.address);
    writer.writeByte(4); writer.write(obj.isActive);
    writer.writeByte(5); writer.write(obj.kind.index);
    writer.writeByte(6); writer.write(obj.companyName);
    writer.writeByte(7); writer.write(obj.email);
    writer.writeByte(8); writer.write(obj.taxId);
    writer.writeByte(9); writer.write(obj.creditLimit);
    writer.writeByte(10); writer.write(obj.discountPercent);
    writer.writeByte(11); writer.write(obj.paymentTermDays);
    writer.writeByte(12); writer.write(obj.notes);
    writer.writeByte(13); writer.write(obj.lastModified);
  }
}

class ManualCustomerKindAdapter extends TypeAdapter<CustomerKind> {
  @override
  final int typeId = 24;

  @override
  CustomerKind read(BinaryReader reader) =>
      CustomerKind.values[reader.readByte()];

  @override
  void write(BinaryWriter writer, CustomerKind obj) =>
      writer.writeByte(obj.index);
}
