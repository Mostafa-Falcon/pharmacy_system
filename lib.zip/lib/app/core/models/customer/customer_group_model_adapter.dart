import 'package:hive/hive.dart';
import 'customer_group_model.dart';

class ManualCustomerGroupModelAdapter extends TypeAdapter<CustomerGroupModel> {
  @override
  final int typeId = 26;

  @override
  CustomerGroupModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CustomerGroupModel(
      id: fields[0] as String,
      name: fields[1] as String,
      discountPercent: (fields[2] as num?)?.toDouble() ?? 0,
      priceGroupId: fields[3] as String?,
      description: fields[4] as String?,
      isActive: fields[5] as bool,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[6] as int),
    );
  }

  @override
  void write(BinaryWriter writer, CustomerGroupModel obj) {
    writer.writeByte(7);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.name);
    writer.writeByte(2);
    writer.write(obj.discountPercent);
    writer.writeByte(3);
    writer.write(obj.priceGroupId);
    writer.writeByte(4);
    writer.write(obj.description);
    writer.writeByte(5);
    writer.write(obj.isActive);
    writer.writeByte(6);
    writer.write(obj.lastModified.millisecondsSinceEpoch);
  }
}
