import 'package:hive/hive.dart';
import 'customer_supplier_model.dart';

class ManualCustomerSupplierModelAdapter extends TypeAdapter<CustomerSupplierModel> {
  @override
  final int typeId = 27;

  @override
  CustomerSupplierModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CustomerSupplierModel(
      id: fields[0] as String,
      name: fields[1] as String,
      phone: fields[2] as String?,
      address: fields[3] as String?,
      email: fields[4] as String?,
      companyName: fields[5] as String?,
      taxId: fields[6] as String?,
      isActive: fields[7] as bool,
      notes: fields[8] as String?,
      customerKindIndex: fields[9] as int,
      creditLimit: (fields[10] as num?)?.toDouble() ?? 0,
      discountPercent: (fields[11] as num?)?.toDouble() ?? 0,
      paymentTermDays: fields[12] as int,
      supplierPartyTypeIndex: fields[13] as int,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[14] as int),
    );
  }

  @override
  void write(BinaryWriter writer, CustomerSupplierModel obj) {
    writer.writeByte(15);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.name);
    writer.writeByte(2);
    writer.write(obj.phone);
    writer.writeByte(3);
    writer.write(obj.address);
    writer.writeByte(4);
    writer.write(obj.email);
    writer.writeByte(5);
    writer.write(obj.companyName);
    writer.writeByte(6);
    writer.write(obj.taxId);
    writer.writeByte(7);
    writer.write(obj.isActive);
    writer.writeByte(8);
    writer.write(obj.notes);
    writer.writeByte(9);
    writer.write(obj.customerKindIndex);
    writer.writeByte(10);
    writer.write(obj.creditLimit);
    writer.writeByte(11);
    writer.write(obj.discountPercent);
    writer.writeByte(12);
    writer.write(obj.paymentTermDays);
    writer.writeByte(13);
    writer.write(obj.supplierPartyTypeIndex);
    writer.writeByte(14);
    writer.write(obj.lastModified.millisecondsSinceEpoch);
  }
}
