import 'package:hive/hive.dart';

part 'customer_ledger_model.g.dart';

@HiveType(typeId: 17)
enum CustomerLedgerEntryType {
  @HiveField(0)
  openingBalance,

  @HiveField(1)
  saleInvoice,

  @HiveField(2)
  saleReturn,

  @HiveField(3)
  customerPayment,

  @HiveField(4)
  saleVoid,

  @HiveField(5)
  manualAdjustment,

  @HiveField(6)
  additionNotice,

  @HiveField(7)
  discountNotice,

  @HiveField(8)
  checkReceipt,

  @HiveField(9)
  checkPayment,
}

@HiveType(typeId: 18)
class CustomerLedgerModel extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String customerId;

  @HiveField(2)
  String branchId;

  @HiveField(3)
  CustomerLedgerEntryType type;

  @HiveField(4)
  double debit;

  @HiveField(5)
  double credit;

  @HiveField(6)
  double balanceAfter;

  @HiveField(7)
  String? referenceId;

  @HiveField(8)
  String? referenceNumber;

  @HiveField(9)
  String? notes;

  @HiveField(10)
  String? createdBy;

  @HiveField(11)
  DateTime entryDate;

  @HiveField(12)
  int syncVersion;

  @HiveField(13)
  DateTime lastModified;

  @HiveField(14)
  bool isDeleted;

  CustomerLedgerModel({
    required this.id,
    required this.customerId,
    required this.branchId,
    required this.type,
    required this.debit,
    required this.credit,
    required this.balanceAfter,
    this.referenceId,
    this.referenceNumber,
    this.notes,
    this.createdBy,
    required this.entryDate,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : lastModified = lastModified ?? DateTime.now();

  CustomerLedgerModel copyWith({
    String? id,
    String? customerId,
    String? branchId,
    CustomerLedgerEntryType? type,
    double? debit,
    double? credit,
    double? balanceAfter,
    String? referenceId,
    String? referenceNumber,
    String? notes,
    String? createdBy,
    DateTime? entryDate,
    int? syncVersion,
    DateTime? lastModified,
    bool? isDeleted,
  }) {
    return CustomerLedgerModel(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      branchId: branchId ?? this.branchId,
      type: type ?? this.type,
      debit: debit ?? this.debit,
      credit: credit ?? this.credit,
      balanceAfter: balanceAfter ?? this.balanceAfter,
      referenceId: referenceId ?? this.referenceId,
      referenceNumber: referenceNumber ?? this.referenceNumber,
      notes: notes ?? this.notes,
      createdBy: createdBy ?? this.createdBy,
      entryDate: entryDate ?? this.entryDate,
      syncVersion: syncVersion ?? this.syncVersion + 1,
      lastModified: lastModified ?? DateTime.now(),
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'customer_id': customerId,
    'branch_id': branchId,
    'type': type.name,
    'debit': debit,
    'credit': credit,
    'balance_after': balanceAfter,
    'reference_id': referenceId,
    'reference_number': referenceNumber,
    'notes': notes,
    'created_by': createdBy,
    'entry_date': entryDate.toIso8601String(),
    'sync_version': syncVersion,
    'last_modified': lastModified.toIso8601String(),
    'is_deleted': isDeleted,
  };

  factory CustomerLedgerModel.fromJson(Map<String, dynamic> json) =>
      CustomerLedgerModel(
        id: json['id'] as String,
        customerId: json['customer_id'] as String,
        branchId: json['branch_id'] as String,
        type: CustomerLedgerEntryType.values.firstWhere(
          (e) => e.name == json['type'],
          orElse: () => CustomerLedgerEntryType.saleInvoice,
        ),
        debit: (json['debit'] as num?)?.toDouble() ?? 0.0,
        credit: (json['credit'] as num?)?.toDouble() ?? 0.0,
        balanceAfter: (json['balance_after'] as num?)?.toDouble() ?? 0.0,
        referenceId: json['reference_id'] as String?,
        referenceNumber: json['reference_number'] as String?,
        notes: json['notes'] as String?,
        createdBy: json['created_by'] as String?,
        entryDate:
            DateTime.tryParse(json['entry_date'] as String) ?? DateTime.now(),
        syncVersion: json['sync_version'] as int? ?? 1,
        lastModified: json['last_modified'] != null
            ? DateTime.tryParse(json['last_modified'] as String) ??
                  DateTime.now()
            : DateTime.now(),
        isDeleted: json['is_deleted'] as bool? ?? false,
      );
}
