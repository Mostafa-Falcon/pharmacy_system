import 'package:hive/hive.dart';

class TaskModel extends HiveObject {
  String id;
  String branchId;
  String title;
  String? description;
  String priority; // low, medium, high, urgent
  String status; // pending, inProgress, completed, cancelled
  String? assignedTo;
  String? assignedName;
  DateTime? dueDate;
  DateTime? completedAt;
  DateTime createdAt;
  DateTime updatedAt;

  TaskModel({
    required this.id,
    required this.branchId,
    required this.title,
    this.description,
    this.priority = 'medium',
    this.status = 'pending',
    this.assignedTo,
    this.assignedName,
    this.dueDate,
    this.completedAt,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'branch_id': branchId, 'title': title,
    'description': description, 'priority': priority, 'status': status,
    'assigned_to': assignedTo, 'assigned_name': assignedName,
    'due_date': dueDate?.toIso8601String(),
    'completed_at': completedAt?.toIso8601String(),
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  factory TaskModel.fromJson(Map<String, dynamic> json) => TaskModel(
    id: json['id'] as String, branchId: json['branch_id'] as String,
    title: json['title'] as String,
    description: json['description'] as String?,
    priority: json['priority'] as String? ?? 'medium',
    status: json['status'] as String? ?? 'pending',
    assignedTo: json['assigned_to'] as String?,
    assignedName: json['assigned_name'] as String?,
    dueDate: json['due_date'] != null ? DateTime.tryParse(json['due_date'] as String) : null,
    completedAt: json['completed_at'] != null ? DateTime.tryParse(json['completed_at'] as String) : null,
    createdAt: DateTime.tryParse(json['created_at'] as String) ?? DateTime.now(),
    updatedAt: DateTime.tryParse(json['updated_at'] as String) ?? DateTime.now(),
  );

  TaskModel copyWith({String? id, String? title, String? description, String? priority, String? status, String? assignedTo, String? assignedName, DateTime? dueDate, DateTime? completedAt}) => TaskModel(
    id: id ?? this.id, branchId: branchId, title: title ?? this.title,
    description: description ?? this.description, priority: priority ?? this.priority,
    status: status ?? this.status, assignedTo: assignedTo ?? this.assignedTo,
    assignedName: assignedName ?? this.assignedName, dueDate: dueDate ?? this.dueDate,
    completedAt: completedAt ?? this.completedAt, createdAt: createdAt, updatedAt: DateTime.now(),
  );
}

class NoteModel extends HiveObject {
  String id;
  String branchId;
  String title;
  String content;
  bool pinned;
  String? color;
  DateTime createdAt;
  DateTime updatedAt;

  NoteModel({required this.id, required this.branchId, required this.title, required this.content, this.pinned = false, this.color, required this.createdAt, required this.updatedAt});

  Map<String, dynamic> toJson() => {
    'id': id, 'branch_id': branchId, 'title': title, 'content': content,
    'pinned': pinned, 'color': color, 'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  factory NoteModel.fromJson(Map<String, dynamic> json) => NoteModel(
    id: json['id'] as String, branchId: json['branch_id'] as String,
    title: json['title'] as String, content: json['content'] as String,
    pinned: json['pinned'] as bool? ?? false, color: json['color'] as String?,
    createdAt: DateTime.tryParse(json['created_at'] as String) ?? DateTime.now(),
    updatedAt: DateTime.tryParse(json['updated_at'] as String) ?? DateTime.now(),
  );

  NoteModel copyWith({String? title, String? content, bool? pinned, String? color}) => NoteModel(
    id: id, branchId: branchId, title: title ?? this.title,
    content: content ?? this.content, pinned: pinned ?? this.pinned,
    color: color ?? this.color, createdAt: createdAt, updatedAt: DateTime.now(),
  );
}

class ReminderModel extends HiveObject {
  String id;
  String branchId;
  String title;
  String message;
  DateTime remindAt;
  String repeat; // none, daily, weekly, monthly
  bool dismissed;
  DateTime? lastTriggered;
  DateTime createdAt;

  ReminderModel({required this.id, required this.branchId, required this.title, required this.message, required this.remindAt, this.repeat = 'none', this.dismissed = false, this.lastTriggered, required this.createdAt});
}

class MessageModel extends HiveObject {
  String id;
  String branchId;
  String fromUserId;
  String fromName;
  String toUserId;
  String toName;
  String subject;
  String body;
  String priority; // normal, high
  DateTime? readAt;
  DateTime createdAt;

  MessageModel({required this.id, required this.branchId, required this.fromUserId, required this.fromName, required this.toUserId, required this.toName, required this.subject, required this.body, this.priority = 'normal', this.readAt, required this.createdAt});
}

// ─── Hive Adapters ───

class TaskModelAdapter extends TypeAdapter<TaskModel> {
  @override final int typeId = 34;
  @override TaskModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return TaskModel(
      id: fields[0] as String, branchId: fields[1] as String, title: fields[2] as String,
      description: fields[3] as String?, priority: fields[4] as String? ?? 'medium',
      status: fields[5] as String? ?? 'pending', assignedTo: fields[6] as String?,
      assignedName: fields[7] as String?,
      dueDate: fields[8] != null ? DateTime.fromMillisecondsSinceEpoch(fields[8] as int) : null,
      completedAt: fields[9] != null ? DateTime.fromMillisecondsSinceEpoch(fields[9] as int) : null,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[10] as int? ?? DateTime.now().millisecondsSinceEpoch),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(fields[11] as int? ?? DateTime.now().millisecondsSinceEpoch),
    );
  }
  @override void write(BinaryWriter writer, TaskModel obj) {
    writer.writeByte(12);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.title);
    writer.writeByte(3); writer.write(obj.description);
    writer.writeByte(4); writer.write(obj.priority);
    writer.writeByte(5); writer.write(obj.status);
    writer.writeByte(6); writer.write(obj.assignedTo);
    writer.writeByte(7); writer.write(obj.assignedName);
    writer.writeByte(8); writer.write(obj.dueDate?.millisecondsSinceEpoch);
    writer.writeByte(9); writer.write(obj.completedAt?.millisecondsSinceEpoch);
    writer.writeByte(10); writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(11); writer.write(obj.updatedAt.millisecondsSinceEpoch);
  }
}

class NoteModelAdapter extends TypeAdapter<NoteModel> {
  @override final int typeId = 35;
  @override NoteModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return NoteModel(
      id: fields[0] as String, branchId: fields[1] as String, title: fields[2] as String,
      content: fields[3] as String, pinned: fields[4] as bool? ?? false,
      color: fields[5] as String?,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[6] as int? ?? DateTime.now().millisecondsSinceEpoch),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(fields[7] as int? ?? DateTime.now().millisecondsSinceEpoch),
    );
  }
  @override void write(BinaryWriter writer, NoteModel obj) {
    writer.writeByte(8);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.title);
    writer.writeByte(3); writer.write(obj.content);
    writer.writeByte(4); writer.write(obj.pinned);
    writer.writeByte(5); writer.write(obj.color);
    writer.writeByte(6); writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(7); writer.write(obj.updatedAt.millisecondsSinceEpoch);
  }
}

class ReminderModelAdapter extends TypeAdapter<ReminderModel> {
  @override final int typeId = 36;
  @override ReminderModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return ReminderModel(
      id: fields[0] as String, branchId: fields[1] as String, title: fields[2] as String,
      message: fields[3] as String, remindAt: DateTime.fromMillisecondsSinceEpoch(fields[4] as int),
      repeat: fields[5] as String? ?? 'none', dismissed: fields[6] as bool? ?? false,
      lastTriggered: fields[7] != null ? DateTime.fromMillisecondsSinceEpoch(fields[7] as int) : null,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[8] as int? ?? DateTime.now().millisecondsSinceEpoch),
    );
  }
  @override void write(BinaryWriter writer, ReminderModel obj) {
    writer.writeByte(9);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.title);
    writer.writeByte(3); writer.write(obj.message);
    writer.writeByte(4); writer.write(obj.remindAt.millisecondsSinceEpoch);
    writer.writeByte(5); writer.write(obj.repeat);
    writer.writeByte(6); writer.write(obj.dismissed);
    writer.writeByte(7); writer.write(obj.lastTriggered?.millisecondsSinceEpoch);
    writer.writeByte(8); writer.write(obj.createdAt.millisecondsSinceEpoch);
  }
}

class MessageModelAdapter extends TypeAdapter<MessageModel> {
  @override final int typeId = 37;
  @override MessageModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return MessageModel(
      id: fields[0] as String, branchId: fields[1] as String, fromUserId: fields[2] as String,
      fromName: fields[3] as String, toUserId: fields[4] as String, toName: fields[5] as String,
      subject: fields[6] as String, body: fields[7] as String, priority: fields[8] as String? ?? 'normal',
      readAt: fields[9] != null ? DateTime.fromMillisecondsSinceEpoch(fields[9] as int) : null,
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[10] as int? ?? DateTime.now().millisecondsSinceEpoch),
    );
  }
  @override void write(BinaryWriter writer, MessageModel obj) {
    writer.writeByte(11);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.fromUserId);
    writer.writeByte(3); writer.write(obj.fromName);
    writer.writeByte(4); writer.write(obj.toUserId);
    writer.writeByte(5); writer.write(obj.toName);
    writer.writeByte(6); writer.write(obj.subject);
    writer.writeByte(7); writer.write(obj.body);
    writer.writeByte(8); writer.write(obj.priority);
    writer.writeByte(9); writer.write(obj.readAt?.millisecondsSinceEpoch);
    writer.writeByte(10); writer.write(obj.createdAt.millisecondsSinceEpoch);
  }
}
