import 'package:hive/hive.dart';
import 'damaged_stock_model.dart';

class DamagedStockModelAdapter extends TypeAdapter<DamagedStockModel> {
  @override
  final int typeId = 32;

  @override
  DamagedStockModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DamagedStockModel(
      id: fields[0] as String,
      medicineId: fields[1] as String,
      medicineName: fields[2] as String,
      quantity: (fields[3] as num).toInt(),
      reason: fields[4] as String,
      notes: fields[5] as String?,
      branchId: fields[6] as String,
      recordedBy: fields[7] as String,
      recordedAt: fields[8] as DateTime,
      lastModified: fields[9] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, DamagedStockModel obj) {
    writer.writeByte(10);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.medicineId);
    writer.writeByte(2); writer.write(obj.medicineName);
    writer.writeByte(3); writer.write(obj.quantity);
    writer.writeByte(4); writer.write(obj.reason);
    writer.writeByte(5); writer.write(obj.notes);
    writer.writeByte(6); writer.write(obj.branchId);
    writer.writeByte(7); writer.write(obj.recordedBy);
    writer.writeByte(8); writer.write(obj.recordedAt);
    writer.writeByte(9); writer.write(obj.lastModified);
  }
}
