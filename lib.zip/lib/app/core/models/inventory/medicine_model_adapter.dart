import 'package:hive/hive.dart';
import 'medicine_model.dart';
import 'medicine_unit_model.dart';

class ManualMedicineModelAdapter extends TypeAdapter<MedicineModel> {
  @override
  final int typeId = 5;

  @override
  MedicineModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    DateTime? parseDateTime(dynamic value) {
      if (value == null) return null;
      if (value is DateTime) return value;
      if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
      return null;
    }

    return MedicineModel(
      id: fields[0] as String,
      name: fields[1] as String,
      nameEn: fields[2] as String?,
      category: fields[3] as String?,
      barcodes: (fields[4] as List<dynamic>?)?.map((e) => e as String).toList(),
      buyPrice: (fields[5] as num).toDouble(),
      sellPrice: (fields[6] as num).toDouble(),
      quantity: fields[7] as int,
      minStock: fields[8] as int,
      expiryDate: parseDateTime(fields[9]),
      manufacturer: fields[10] as String?,
      branchId: fields[11] as String,
      syncVersion: fields[12] as int,
      lastModified: parseDateTime(fields[13]) ?? DateTime.now(),
      isDeleted: fields[14] as bool,
      dosageForm: fields[15] as String?,
      strength: fields[16] as String?,
      packageSize: fields[17] as String?,
      expiryTrackingEnabled: fields[18] as bool? ?? false,
      supplierName: fields[19] as String?,
      description: fields[20] as String?,
      oldSellPrice: (fields[21] as num?)?.toDouble(),
      itemTypeId: fields[22] as String?,
      groupId: fields[23] as String?,
      units: (fields[24] as List<dynamic>?)
          ?.map((e) => e as MedicineUnitModel)
          .toList(),
      alertEnabled: fields[25] as bool? ?? false,
      dosageFormEnabled: fields[26] as bool? ?? false,
      imageUrl: fields[27] as String?,
      containerShape: fields[28] as String?,
      allowNegativeStock: fields[29] as bool? ?? false,
      isTaxable: fields[30] as bool? ?? false,
      taxType: fields[31] as String?,
      taxValue: (fields[32] as num?)?.toDouble(),
      pricesIncludeTax: fields[33] as bool? ?? false,
      location: fields[34] as String?,
      isActive: fields[35] as bool? ?? true,
    );
  }

  @override
  void write(BinaryWriter writer, MedicineModel obj) {
    writer.writeByte(36);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.name);
    writer.writeByte(2);
    writer.write(obj.nameEn);
    writer.writeByte(3);
    writer.write(obj.category);
    writer.writeByte(4);
    writer.write(obj.barcodes);
    writer.writeByte(5);
    writer.write(obj.buyPrice);
    writer.writeByte(6);
    writer.write(obj.sellPrice);
    writer.writeByte(7);
    writer.write(obj.quantity);
    writer.writeByte(8);
    writer.write(obj.minStock);
    writer.writeByte(9);
    writer.write(obj.expiryDate);
    writer.writeByte(10);
    writer.write(obj.manufacturer);
    writer.writeByte(11);
    writer.write(obj.branchId);
    writer.writeByte(12);
    writer.write(obj.syncVersion);
    writer.writeByte(13);
    writer.write(obj.lastModified);
    writer.writeByte(14);
    writer.write(obj.isDeleted);
    writer.writeByte(15);
    writer.write(obj.dosageForm);
    writer.writeByte(16);
    writer.write(obj.strength);
    writer.writeByte(17);
    writer.write(obj.packageSize);
    writer.writeByte(18);
    writer.write(obj.expiryTrackingEnabled);
    writer.writeByte(19);
    writer.write(obj.supplierName);
    writer.writeByte(20);
    writer.write(obj.description);
    writer.writeByte(21);
    writer.write(obj.oldSellPrice);
    writer.writeByte(22);
    writer.write(obj.itemTypeId);
    writer.writeByte(23);
    writer.write(obj.groupId);
    writer.writeByte(24);
    writer.write(obj.units);
    writer.writeByte(25);
    writer.write(obj.alertEnabled);
    writer.writeByte(26);
    writer.write(obj.dosageFormEnabled);
    writer.writeByte(27);
    writer.write(obj.imageUrl);
    writer.writeByte(28);
    writer.write(obj.containerShape);
    writer.writeByte(29);
    writer.write(obj.allowNegativeStock);
    writer.writeByte(30);
    writer.write(obj.isTaxable);
    writer.writeByte(31);
    writer.write(obj.taxType);
    writer.writeByte(32);
    writer.write(obj.taxValue);
    writer.writeByte(33);
    writer.write(obj.pricesIncludeTax);
    writer.writeByte(34);
    writer.write(obj.location);
    writer.writeByte(35);
    writer.write(obj.isActive);
  }
}
