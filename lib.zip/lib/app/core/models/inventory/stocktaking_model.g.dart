// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocktaking_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class StocktakingItemModelAdapter extends TypeAdapter<StocktakingItemModel> {
  @override
  final int typeId = 28;

  @override
  StocktakingItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return StocktakingItemModel(
      id: fields[0] as String,
      stocktakingId: fields[1] as String,
      medicineId: fields[2] as String,
      medicineName: fields[3] as String,
      systemQuantity: fields[4] as int,
      countedQuantity: fields[5] as int,
      difference: fields[6] as int?,
      notes: fields[7] as String?,
      syncVersion: fields[8] as int,
      lastModified: fields[9] as DateTime?,
      isDeleted: fields[10] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, StocktakingItemModel obj) {
    writer
      ..writeByte(11)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.stocktakingId)
      ..writeByte(2)
      ..write(obj.medicineId)
      ..writeByte(3)
      ..write(obj.medicineName)
      ..writeByte(4)
      ..write(obj.systemQuantity)
      ..writeByte(5)
      ..write(obj.countedQuantity)
      ..writeByte(6)
      ..write(obj.difference)
      ..writeByte(7)
      ..write(obj.notes)
      ..writeByte(8)
      ..write(obj.syncVersion)
      ..writeByte(9)
      ..write(obj.lastModified)
      ..writeByte(10)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is StocktakingItemModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class StocktakingModelAdapter extends TypeAdapter<StocktakingModel> {
  @override
  final int typeId = 30;

  @override
  StocktakingModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return StocktakingModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      startDate: fields[2] as DateTime,
      endDate: fields[3] as DateTime?,
      status: fields[4] as StocktakingStatus,
      notes: fields[5] as String?,
      createdBy: fields[6] as String,
      syncVersion: fields[7] as int,
      lastModified: fields[8] as DateTime?,
      isDeleted: fields[9] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, StocktakingModel obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.branchId)
      ..writeByte(2)
      ..write(obj.startDate)
      ..writeByte(3)
      ..write(obj.endDate)
      ..writeByte(4)
      ..write(obj.status)
      ..writeByte(5)
      ..write(obj.notes)
      ..writeByte(6)
      ..write(obj.createdBy)
      ..writeByte(7)
      ..write(obj.syncVersion)
      ..writeByte(8)
      ..write(obj.lastModified)
      ..writeByte(9)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is StocktakingModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class StocktakingStatusAdapter extends TypeAdapter<StocktakingStatus> {
  @override
  final int typeId = 29;

  @override
  StocktakingStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return StocktakingStatus.draft;
      case 1:
        return StocktakingStatus.confirmed;
      default:
        return StocktakingStatus.draft;
    }
  }

  @override
  void write(BinaryWriter writer, StocktakingStatus obj) {
    switch (obj) {
      case StocktakingStatus.draft:
        writer.writeByte(0);
        break;
      case StocktakingStatus.confirmed:
        writer.writeByte(1);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is StocktakingStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
