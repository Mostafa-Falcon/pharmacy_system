import 'package:hive/hive.dart';
import 'inventory_model.dart';

class ManualInventoryItemModelAdapter extends TypeAdapter<InventoryItemModel> {
  @override
  final int typeId = 10;

  @override
  InventoryItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return InventoryItemModel(
      id: fields[0] as String,
      medicineId: fields[1] as String,
      branchId: fields[2] as String,
      currentQuantity: fields[3] as int,
      minStock: fields[4] as int,
      maxStock: fields[5] as int,
      lastRestocked: DateTime.fromMillisecondsSinceEpoch(fields[6] as int),
      syncVersion: fields[7] as int,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[8] as int),
    );
  }

  @override
  void write(BinaryWriter writer, InventoryItemModel obj) {
    writer.writeByte(9);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.medicineId);
    writer.writeByte(2);
    writer.write(obj.branchId);
    writer.writeByte(3);
    writer.write(obj.currentQuantity);
    writer.writeByte(4);
    writer.write(obj.minStock);
    writer.writeByte(5);
    writer.write(obj.maxStock);
    writer.writeByte(6);
    writer.write(obj.lastRestocked.millisecondsSinceEpoch);
    writer.writeByte(7);
    writer.write(obj.syncVersion);
    writer.writeByte(8);
    writer.write(obj.lastModified.millisecondsSinceEpoch);
  }
}
