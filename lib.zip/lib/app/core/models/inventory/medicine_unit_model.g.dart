// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'medicine_unit_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class MedicineUnitModelAdapter extends TypeAdapter<MedicineUnitModel> {
  @override
  final int typeId = 15;

  @override
  MedicineUnitModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MedicineUnitModel(
      id: fields[0] as String,
      name: fields[1] as String,
      level: fields[2] as int,
      conversionFactor: fields[3] as double,
      buyPrice: fields[4] as double,
      sellPrice: fields[5] as double,
      oldSellPrice: fields[6] as double?,
      discountPercent: fields[7] as double?,
      allowSale: fields[8] as bool,
      quantity: fields[9] as int,
      barcode: fields[10] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, MedicineUnitModel obj) {
    writer
      ..writeByte(11)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.level)
      ..writeByte(3)
      ..write(obj.conversionFactor)
      ..writeByte(4)
      ..write(obj.buyPrice)
      ..writeByte(5)
      ..write(obj.sellPrice)
      ..writeByte(6)
      ..write(obj.oldSellPrice)
      ..writeByte(7)
      ..write(obj.discountPercent)
      ..writeByte(8)
      ..write(obj.allowSale)
      ..writeByte(9)
      ..write(obj.quantity)
      ..writeByte(10)
      ..write(obj.barcode);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MedicineUnitModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
