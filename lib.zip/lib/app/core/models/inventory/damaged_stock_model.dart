import 'package:hive/hive.dart';

@HiveType(typeId: 32)
class DamagedStockModel extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String medicineId;

  @HiveField(2)
  String medicineName;

  @HiveField(3)
  int quantity;

  @HiveField(4)
  String reason;

  @HiveField(5)
  String? notes;

  @HiveField(6)
  String branchId;

  @HiveField(7)
  String recordedBy;

  @HiveField(8)
  DateTime recordedAt;

  @HiveField(9)
  DateTime lastModified;

  DamagedStockModel({
    required this.id,
    required this.medicineId,
    required this.medicineName,
    required this.quantity,
    required this.reason,
    this.notes,
    required this.branchId,
    required this.recordedBy,
    DateTime? recordedAt,
    DateTime? lastModified,
  })  : recordedAt = recordedAt ?? DateTime.now(),
        lastModified = lastModified ?? DateTime.now();

  DamagedStockModel copyWith({
    String? id,
    String? medicineId,
    String? medicineName,
    int? quantity,
    String? reason,
    String? notes,
    String? branchId,
    String? recordedBy,
    DateTime? recordedAt,
    DateTime? lastModified,
  }) {
    return DamagedStockModel(
      id: id ?? this.id,
      medicineId: medicineId ?? this.medicineId,
      medicineName: medicineName ?? this.medicineName,
      quantity: quantity ?? this.quantity,
      reason: reason ?? this.reason,
      notes: notes ?? this.notes,
      branchId: branchId ?? this.branchId,
      recordedBy: recordedBy ?? this.recordedBy,
      recordedAt: recordedAt ?? this.recordedAt,
      lastModified: lastModified ?? this.lastModified,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'medicine_id': medicineId,
    'medicine_name': medicineName,
    'quantity': quantity,
    'reason': reason,
    'notes': notes,
    'branch_id': branchId,
    'recorded_by': recordedBy,
    'recorded_at': recordedAt.toIso8601String(),
    'last_modified': lastModified.toIso8601String(),
  };

  factory DamagedStockModel.fromJson(Map<String, dynamic> json) => DamagedStockModel(
    id: json['id'] as String,
    medicineId: json['medicine_id'] as String,
    medicineName: json['medicine_name'] as String,
    quantity: (json['quantity'] as num?)?.toInt() ?? 0,
    reason: json['reason'] as String? ?? '',
    notes: json['notes'] as String?,
    branchId: json['branch_id'] as String? ?? '',
    recordedBy: json['recorded_by'] as String? ?? '',
    recordedAt: json['recorded_at'] != null ? DateTime.tryParse(json['recorded_at'] as String) ?? DateTime.now() : DateTime.now(),
    lastModified: json['last_modified'] != null ? DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now() : DateTime.now(),
  );
}
