import 'package:hive/hive.dart';
import 'medicine_unit_model.dart';

class ManualMedicineUnitModelAdapter extends TypeAdapter<MedicineUnitModel> {
  @override
  final int typeId = 15;

  @override
  MedicineUnitModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MedicineUnitModel(
      id: fields[0] as String,
      name: fields[1] as String,
      level: fields[2] as int,
      conversionFactor: fields[3] as double,
      buyPrice: fields[4] as double,
      sellPrice: fields[5] as double,
      oldSellPrice: fields[6] as double?,
      discountPercent: fields[7] as double?,
      allowSale: fields[8] as bool,
      quantity: fields[9] as int,
      barcode: fields[10] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, MedicineUnitModel obj) {
    writer.writeByte(11);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.name);
    writer.writeByte(2);
    writer.write(obj.level);
    writer.writeByte(3);
    writer.write(obj.conversionFactor);
    writer.writeByte(4);
    writer.write(obj.buyPrice);
    writer.writeByte(5);
    writer.write(obj.sellPrice);
    writer.writeByte(6);
    writer.write(obj.oldSellPrice);
    writer.writeByte(7);
    writer.write(obj.discountPercent);
    writer.writeByte(8);
    writer.write(obj.allowSale);
    writer.writeByte(9);
    writer.write(obj.quantity);
    writer.writeByte(10);
    writer.write(obj.barcode);
  }
}
