// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'medicine_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class MedicineModelAdapter extends TypeAdapter<MedicineModel> {
  @override
  final int typeId = 5;

  @override
  MedicineModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MedicineModel(
      id: fields[0] as String,
      name: fields[1] as String,
      nameEn: fields[2] as String?,
      category: fields[3] as String?,
      barcodes: (fields[4] as List?)?.cast<String>(),
      buyPrice: fields[5] as double,
      sellPrice: fields[6] as double,
      quantity: fields[7] as int,
      minStock: fields[8] as int,
      expiryDate: fields[9] as DateTime?,
      manufacturer: fields[10] as String?,
      branchId: fields[11] as String,
      syncVersion: fields[12] as int,
      lastModified: fields[13] as DateTime?,
      isDeleted: fields[14] as bool,
      dosageForm: fields[15] as String?,
      strength: fields[16] as String?,
      packageSize: fields[17] as String?,
      expiryTrackingEnabled: fields[18] as bool,
      supplierName: fields[19] as String?,
      description: fields[20] as String?,
      oldSellPrice: fields[21] as double?,
      itemTypeId: fields[22] as String?,
      groupId: fields[23] as String?,
      units: (fields[24] as List?)?.cast<MedicineUnitModel>(),
      alertEnabled: fields[25] as bool,
      dosageFormEnabled: fields[26] as bool,
      imageUrl: fields[27] as String?,
      containerShape: fields[28] as String?,
      allowNegativeStock: fields[29] as bool,
      isTaxable: fields[30] as bool,
      taxType: fields[31] as String?,
      taxValue: fields[32] as double?,
      pricesIncludeTax: fields[33] as bool,
      location: fields[34] as String?,
      isActive: fields[35] as bool,
      createdAt: fields[36] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, MedicineModel obj) {
    writer
      ..writeByte(37)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.nameEn)
      ..writeByte(3)
      ..write(obj.category)
      ..writeByte(4)
      ..write(obj.barcodes)
      ..writeByte(5)
      ..write(obj.buyPrice)
      ..writeByte(6)
      ..write(obj.sellPrice)
      ..writeByte(7)
      ..write(obj.quantity)
      ..writeByte(8)
      ..write(obj.minStock)
      ..writeByte(9)
      ..write(obj.expiryDate)
      ..writeByte(10)
      ..write(obj.manufacturer)
      ..writeByte(11)
      ..write(obj.branchId)
      ..writeByte(12)
      ..write(obj.syncVersion)
      ..writeByte(13)
      ..write(obj.lastModified)
      ..writeByte(14)
      ..write(obj.isDeleted)
      ..writeByte(15)
      ..write(obj.dosageForm)
      ..writeByte(16)
      ..write(obj.strength)
      ..writeByte(17)
      ..write(obj.packageSize)
      ..writeByte(18)
      ..write(obj.expiryTrackingEnabled)
      ..writeByte(19)
      ..write(obj.supplierName)
      ..writeByte(20)
      ..write(obj.description)
      ..writeByte(21)
      ..write(obj.oldSellPrice)
      ..writeByte(22)
      ..write(obj.itemTypeId)
      ..writeByte(23)
      ..write(obj.groupId)
      ..writeByte(24)
      ..write(obj.units)
      ..writeByte(25)
      ..write(obj.alertEnabled)
      ..writeByte(26)
      ..write(obj.dosageFormEnabled)
      ..writeByte(27)
      ..write(obj.imageUrl)
      ..writeByte(28)
      ..write(obj.containerShape)
      ..writeByte(29)
      ..write(obj.allowNegativeStock)
      ..writeByte(30)
      ..write(obj.isTaxable)
      ..writeByte(31)
      ..write(obj.taxType)
      ..writeByte(32)
      ..write(obj.taxValue)
      ..writeByte(33)
      ..write(obj.pricesIncludeTax)
      ..writeByte(34)
      ..write(obj.location)
      ..writeByte(35)
      ..write(obj.isActive)
      ..writeByte(36)
      ..write(obj.createdAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MedicineModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
