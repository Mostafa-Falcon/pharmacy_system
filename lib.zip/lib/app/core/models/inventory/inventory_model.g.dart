// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'inventory_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class InventoryItemModelAdapter extends TypeAdapter<InventoryItemModel> {
  @override
  final int typeId = 10;

  @override
  InventoryItemModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return InventoryItemModel(
      id: fields[0] as String,
      medicineId: fields[1] as String,
      branchId: fields[2] as String,
      currentQuantity: fields[3] as int,
      minStock: fields[4] as int,
      maxStock: fields[5] as int,
      lastRestocked: fields[6] as DateTime,
      syncVersion: fields[7] as int,
      lastModified: fields[8] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, InventoryItemModel obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.medicineId)
      ..writeByte(2)
      ..write(obj.branchId)
      ..writeByte(3)
      ..write(obj.currentQuantity)
      ..writeByte(4)
      ..write(obj.minStock)
      ..writeByte(5)
      ..write(obj.maxStock)
      ..writeByte(6)
      ..write(obj.lastRestocked)
      ..writeByte(7)
      ..write(obj.syncVersion)
      ..writeByte(8)
      ..write(obj.lastModified);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is InventoryItemModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
