import 'package:hive/hive.dart';

class StocktakingPeriodModel extends HiveObject {
  String id;
  String branchId;
  String name;
  String status; // open, inProgress, closed, cancelled
  int totalItems;
  int countedItems;
  double totalDifference;
  DateTime startedAt;
  DateTime? closedAt;
  String? notes;
  String createdBy;
  int syncVersion;
  DateTime lastModified;
  bool isDeleted;

  StocktakingPeriodModel({
    required this.id,
    required this.branchId,
    required this.name,
    this.status = 'open',
    this.totalItems = 0,
    this.countedItems = 0,
    this.totalDifference = 0,
    required this.startedAt,
    this.closedAt,
    this.notes,
    required this.createdBy,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : lastModified = lastModified ?? DateTime.now();

  bool get isOpen => status == 'open';
  bool get isInProgress => status == 'inProgress';
  bool get isClosed => status == 'closed';
  bool get isCancelled => status == 'cancelled';

  Map<String, dynamic> toJson() => {
    'id': id, 'branch_id': branchId, 'name': name, 'status': status,
    'total_items': totalItems, 'counted_items': countedItems,
    'total_difference': totalDifference,
    'started_at': startedAt.toIso8601String(),
    'closed_at': closedAt?.toIso8601String(),
    'notes': notes, 'created_by': createdBy,
    'sync_version': syncVersion,
    'last_modified': lastModified.toIso8601String(),
    'is_deleted': isDeleted,
  };

  factory StocktakingPeriodModel.fromJson(Map<String, dynamic> json) => StocktakingPeriodModel(
    id: json['id'] as String, branchId: json['branch_id'] as String,
    name: json['name'] as String, status: json['status'] as String? ?? 'open',
    totalItems: json['total_items'] as int? ?? 0,
    countedItems: json['counted_items'] as int? ?? 0,
    totalDifference: (json['total_difference'] as num?)?.toDouble() ?? 0,
    startedAt: DateTime.tryParse(json['started_at'] as String) ?? DateTime.now(),
    closedAt: json['closed_at'] != null ? DateTime.tryParse(json['closed_at'] as String) : null,
    notes: json['notes'] as String?,
    createdBy: json['created_by'] as String,
    syncVersion: json['sync_version'] as int? ?? 1,
    lastModified: DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now(),
    isDeleted: json['is_deleted'] as bool? ?? false,
  );
}

class StocktakingCountModel extends HiveObject {
  String id;
  String periodId;
  String itemId;
  String itemName;
  String? sku;
  String unit;
  int systemQuantity;
  int actualQuantity;
  int difference;
  double buyPrice;
  double differenceValue;
  String? notes;
  DateTime countedAt;
  String createdBy;
  DateTime createdAt;
  DateTime updatedAt;
  int syncVersion;
  DateTime lastModified;
  bool isDeleted;

  StocktakingCountModel({
    required this.id,
    required this.periodId,
    required this.itemId,
    required this.itemName,
    this.sku,
    this.unit = 'وحدة',
    required this.systemQuantity,
    required this.actualQuantity,
    int? difference,
    this.buyPrice = 0,
    double? differenceValue,
    this.notes,
    DateTime? countedAt,
    required this.createdBy,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.syncVersion = 1,
    DateTime? lastModified,
    this.isDeleted = false,
  }) : difference = difference ?? (actualQuantity - systemQuantity),
       differenceValue = differenceValue ?? ((actualQuantity - systemQuantity) * buyPrice),
       countedAt = countedAt ?? DateTime.now(),
       createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now(),
       lastModified = lastModified ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id, 'period_id': periodId, 'item_id': itemId, 'item_name': itemName,
    'sku': sku, 'unit': unit, 'system_quantity': systemQuantity,
    'actual_quantity': actualQuantity, 'difference': difference,
    'buy_price': buyPrice, 'difference_value': differenceValue,
    'notes': notes, 'counted_at': countedAt.toIso8601String(),
    'created_by': createdBy, 'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
    'sync_version': syncVersion,
    'last_modified': lastModified.toIso8601String(),
    'is_deleted': isDeleted,
  };

  factory StocktakingCountModel.fromJson(Map<String, dynamic> json) => StocktakingCountModel(
    id: json['id'] as String, periodId: json['period_id'] as String,
    itemId: json['item_id'] as String, itemName: json['item_name'] as String,
    sku: json['sku'] as String?, unit: json['unit'] as String? ?? 'وحدة',
    systemQuantity: json['system_quantity'] as int? ?? 0,
    actualQuantity: json['actual_quantity'] as int? ?? 0,
    difference: json['difference'] as int?,
    buyPrice: (json['buy_price'] as num?)?.toDouble() ?? 0,
    differenceValue: (json['difference_value'] as num?)?.toDouble(),
    notes: json['notes'] as String?,
    countedAt: json['counted_at'] != null ? DateTime.tryParse(json['counted_at'] as String) : null,
    createdBy: json['created_by'] as String,
    createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at'] as String) : null,
    updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at'] as String) : null,
    syncVersion: json['sync_version'] as int? ?? 1,
    lastModified: json['last_modified'] != null ? DateTime.tryParse(json['last_modified'] as String) ?? DateTime.now() : DateTime.now(),
    isDeleted: json['is_deleted'] as bool? ?? false,
  );
}

// ─── Hive Adapters ───

class StocktakingPeriodModelAdapter extends TypeAdapter<StocktakingPeriodModel> {
  @override final int typeId = 38;
  @override StocktakingPeriodModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return StocktakingPeriodModel(
      id: fields[0] as String, branchId: fields[1] as String, name: fields[2] as String,
      status: fields[3] as String? ?? 'open', totalItems: fields[4] as int? ?? 0,
      countedItems: fields[5] as int? ?? 0, totalDifference: (fields[6] as num?)?.toDouble() ?? 0,
      startedAt: DateTime.fromMillisecondsSinceEpoch(fields[7] as int? ?? DateTime.now().millisecondsSinceEpoch),
      closedAt: fields[8] != null ? DateTime.fromMillisecondsSinceEpoch(fields[8] as int) : null,
      notes: fields[9] as String?, createdBy: fields[10] as String,
      syncVersion: fields[11] as int? ?? 1,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[12] as int? ?? DateTime.now().millisecondsSinceEpoch),
      isDeleted: fields[13] as bool? ?? false,
    );
  }
  @override void write(BinaryWriter writer, StocktakingPeriodModel obj) {
    writer.writeByte(14);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.branchId);
    writer.writeByte(2); writer.write(obj.name);
    writer.writeByte(3); writer.write(obj.status);
    writer.writeByte(4); writer.write(obj.totalItems);
    writer.writeByte(5); writer.write(obj.countedItems);
    writer.writeByte(6); writer.write(obj.totalDifference);
    writer.writeByte(7); writer.write(obj.startedAt.millisecondsSinceEpoch);
    writer.writeByte(8); writer.write(obj.closedAt?.millisecondsSinceEpoch);
    writer.writeByte(9); writer.write(obj.notes);
    writer.writeByte(10); writer.write(obj.createdBy);
    writer.writeByte(11); writer.write(obj.syncVersion);
    writer.writeByte(12); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(13); writer.write(obj.isDeleted);
  }
}
class StocktakingCountModelAdapter extends TypeAdapter<StocktakingCountModel> {
  @override final int typeId = 39;
  @override StocktakingCountModel read(BinaryReader reader) {
    final fields = <int, dynamic>{for (int i = 0; i < reader.readByte(); i++) reader.readByte(): reader.read()};
    return StocktakingCountModel(
      id: fields[0] as String, periodId: fields[1] as String,
      itemId: fields[2] as String, itemName: fields[3] as String,
      sku: fields[4] as String?, unit: fields[5] as String? ?? 'وحدة',
      systemQuantity: fields[6] as int? ?? 0, actualQuantity: fields[7] as int? ?? 0,
      difference: fields[8] as int?,
      buyPrice: (fields[9] as num?)?.toDouble() ?? 0,
      differenceValue: (fields[10] as num?)?.toDouble(),
      notes: fields[11] as String?,
      countedAt: fields[12] != null ? DateTime.fromMillisecondsSinceEpoch(fields[12] as int) : null,
      createdBy: fields[13] as String,
      createdAt: fields[14] != null ? DateTime.fromMillisecondsSinceEpoch(fields[14] as int) : null,
      updatedAt: fields[15] != null ? DateTime.fromMillisecondsSinceEpoch(fields[15] as int) : null,
      syncVersion: fields[16] as int? ?? 1,
      lastModified: fields[17] != null ? DateTime.fromMillisecondsSinceEpoch(fields[17] as int) : DateTime.now(),
      isDeleted: fields[18] as bool? ?? false,
    );
  }
  @override void write(BinaryWriter writer, StocktakingCountModel obj) {
    writer.writeByte(19);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.periodId);
    writer.writeByte(2); writer.write(obj.itemId);
    writer.writeByte(3); writer.write(obj.itemName);
    writer.writeByte(4); writer.write(obj.sku);
    writer.writeByte(5); writer.write(obj.unit);
    writer.writeByte(6); writer.write(obj.systemQuantity);
    writer.writeByte(7); writer.write(obj.actualQuantity);
    writer.writeByte(8); writer.write(obj.difference);
    writer.writeByte(9); writer.write(obj.buyPrice);
    writer.writeByte(10); writer.write(obj.differenceValue);
    writer.writeByte(11); writer.write(obj.notes);
    writer.writeByte(12); writer.write(obj.countedAt.millisecondsSinceEpoch);
    writer.writeByte(13); writer.write(obj.createdBy);
    writer.writeByte(14); writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(15); writer.write(obj.updatedAt.millisecondsSinceEpoch);
    writer.writeByte(16); writer.write(obj.syncVersion);
    writer.writeByte(17); writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(18); writer.write(obj.isDeleted);
  }
}
