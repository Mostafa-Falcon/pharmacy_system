import 'package:hive/hive.dart';
import 'package:collection/collection.dart';
import 'promotion_model.dart';

class PromotionModelAdapter extends TypeAdapter<PromotionModel> {
  @override
  final int typeId = 31;

  @override
  PromotionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PromotionModel(
      id: fields[0] as String,
      name: fields[1] as String,
      description: fields[2] as String?,
      type: PromotionType.values.firstWhereOrNull((e) => e.name == fields[3]) ?? PromotionType.discount,
      value: (fields[4] as num).toDouble(),
      isPercentage: fields[5] as bool,
      startDate: fields[6] as DateTime,
      endDate: fields[7] as DateTime,
      medicineIds: (fields[8] as List?)?.cast<String>() ?? [],
      categoryFilters: (fields[9] as List?)?.cast<String>() ?? [],
      customerGroupId: fields[10] as String?,
      branchId: fields[11] as String,
      isActive: fields[12] as bool,
      lastModified: fields[13] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, PromotionModel obj) {
    writer.writeByte(14);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.name);
    writer.writeByte(2); writer.write(obj.description);
    writer.writeByte(3); writer.write(obj.type.name);
    writer.writeByte(4); writer.write(obj.value);
    writer.writeByte(5); writer.write(obj.isPercentage);
    writer.writeByte(6); writer.write(obj.startDate);
    writer.writeByte(7); writer.write(obj.endDate);
    writer.writeByte(8); writer.write(obj.medicineIds);
    writer.writeByte(9); writer.write(obj.categoryFilters);
    writer.writeByte(10); writer.write(obj.customerGroupId);
    writer.writeByte(11); writer.write(obj.branchId);
    writer.writeByte(12); writer.write(obj.isActive);
    writer.writeByte(13); writer.write(obj.lastModified);
  }
}
