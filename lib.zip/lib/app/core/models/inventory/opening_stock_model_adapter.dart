import 'package:hive/hive.dart';
import 'opening_stock_model.dart';

class OpeningStockModelAdapter extends TypeAdapter<OpeningStockModel> {
  @override
  final int typeId = 33;

  @override
  OpeningStockModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return OpeningStockModel(
      id: fields[0] as String,
      medicineId: fields[1] as String,
      medicineName: fields[2] as String,
      quantity: (fields[3] as num).toInt(),
      buyPrice: (fields[4] as num).toDouble(),
      branchId: fields[5] as String,
      recordedBy: fields[6] as String,
      recordedAt: fields[7] as DateTime,
      lastModified: fields[8] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, OpeningStockModel obj) {
    writer.writeByte(9);
    writer.writeByte(0); writer.write(obj.id);
    writer.writeByte(1); writer.write(obj.medicineId);
    writer.writeByte(2); writer.write(obj.medicineName);
    writer.writeByte(3); writer.write(obj.quantity);
    writer.writeByte(4); writer.write(obj.buyPrice);
    writer.writeByte(5); writer.write(obj.branchId);
    writer.writeByte(6); writer.write(obj.recordedBy);
    writer.writeByte(7); writer.write(obj.recordedAt);
    writer.writeByte(8); writer.write(obj.lastModified);
  }
}
