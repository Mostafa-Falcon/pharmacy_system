import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

part 'error_log_model.g.dart';

/// مستوى خطورة الخطأ المزمن.
enum ErrorSeverity {
  /// خطأ يمنع عملية أو يُفقد بيانات (مزامنة، حفظ، استيراد).
  critical,

  /// خطأ منطقي أو سلوك غير متوقع لكن لا يوقف التطبيق.
  warning,

  /// ملاحظة تقنية لمراجعة لاحقة.
  info,
}

/// نموذج خطأ مزمن يُحفظ في Hive لعرضه لاحقاً في صفحة الأخطاء.
@HiveType(typeId: 90)
class ErrorLogModel extends Equatable {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String message;

  @HiveField(3)
  final String? source;

  @HiveField(4)
  final String? stackTrace;

  @HiveField(5)
  final ErrorSeverity severity;

  @HiveField(6)
  final DateTime createdAt;

  @HiveField(7)
  final bool isRead;

  const ErrorLogModel({
    required this.id,
    required this.title,
    required this.message,
    this.source,
    this.stackTrace,
    this.severity = ErrorSeverity.warning,
    required this.createdAt,
    this.isRead = false,
  });

  ErrorLogModel copyWith({bool? isRead}) {
    return ErrorLogModel(
      id: id,
      title: title,
      message: message,
      source: source,
      stackTrace: stackTrace,
      severity: severity,
      createdAt: createdAt,
      isRead: isRead ?? this.isRead,
    );
  }

  @override
  List<Object?> get props => [id];
}
