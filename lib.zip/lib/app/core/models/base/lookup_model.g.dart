// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lookup_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class LookupModelAdapter extends TypeAdapter<LookupModel> {
  @override
  final int typeId = 14;

  @override
  LookupModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return LookupModel(
      id: fields[0] as String,
      name: fields[1] as String,
      type: fields[2] as String,
      isActive: fields[3] as bool,
      branchId: fields[4] as String,
      syncVersion: fields[5] as int,
      lastModified: fields[6] as DateTime?,
      isDeleted: fields[7] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, LookupModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.type)
      ..writeByte(3)
      ..write(obj.isActive)
      ..writeByte(4)
      ..write(obj.branchId)
      ..writeByte(5)
      ..write(obj.syncVersion)
      ..writeByte(6)
      ..write(obj.lastModified)
      ..writeByte(7)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LookupModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
