// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'correction_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CorrectionEntry _$CorrectionEntryFromJson(Map<String, dynamic> json) {
  return _CorrectionEntry.fromJson(json);
}

/// @nodoc
mixin _$CorrectionEntry {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_type')
  CorrectionReferenceType get referenceType =>
      throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_id')
  String get referenceId => throw _privateConstructorUsedError;
  CorrectionAction get action => throw _privateConstructorUsedError;
  @JsonKey(name: 'user_id')
  String get userId => throw _privateConstructorUsedError;
  @JsonKey(name: 'user_display_name')
  String get userDisplayName => throw _privateConstructorUsedError;
  DateTime get timestamp => throw _privateConstructorUsedError;
  String? get details => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CorrectionEntryCopyWith<CorrectionEntry> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CorrectionEntryCopyWith<$Res> {
  factory $CorrectionEntryCopyWith(
          CorrectionEntry value, $Res Function(CorrectionEntry) then) =
      _$CorrectionEntryCopyWithImpl<$Res, CorrectionEntry>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'reference_type') CorrectionReferenceType referenceType,
      @JsonKey(name: 'reference_id') String referenceId,
      CorrectionAction action,
      @JsonKey(name: 'user_id') String userId,
      @JsonKey(name: 'user_display_name') String userDisplayName,
      DateTime timestamp,
      String? details});
}

/// @nodoc
class _$CorrectionEntryCopyWithImpl<$Res, $Val extends CorrectionEntry>
    implements $CorrectionEntryCopyWith<$Res> {
  _$CorrectionEntryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? referenceType = null,
    Object? referenceId = null,
    Object? action = null,
    Object? userId = null,
    Object? userDisplayName = null,
    Object? timestamp = null,
    Object? details = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      referenceType: null == referenceType
          ? _value.referenceType
          : referenceType // ignore: cast_nullable_to_non_nullable
              as CorrectionReferenceType,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String,
      action: null == action
          ? _value.action
          : action // ignore: cast_nullable_to_non_nullable
              as CorrectionAction,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
      userDisplayName: null == userDisplayName
          ? _value.userDisplayName
          : userDisplayName // ignore: cast_nullable_to_non_nullable
              as String,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      details: freezed == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CorrectionEntryImplCopyWith<$Res>
    implements $CorrectionEntryCopyWith<$Res> {
  factory _$$CorrectionEntryImplCopyWith(_$CorrectionEntryImpl value,
          $Res Function(_$CorrectionEntryImpl) then) =
      __$$CorrectionEntryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'reference_type') CorrectionReferenceType referenceType,
      @JsonKey(name: 'reference_id') String referenceId,
      CorrectionAction action,
      @JsonKey(name: 'user_id') String userId,
      @JsonKey(name: 'user_display_name') String userDisplayName,
      DateTime timestamp,
      String? details});
}

/// @nodoc
class __$$CorrectionEntryImplCopyWithImpl<$Res>
    extends _$CorrectionEntryCopyWithImpl<$Res, _$CorrectionEntryImpl>
    implements _$$CorrectionEntryImplCopyWith<$Res> {
  __$$CorrectionEntryImplCopyWithImpl(
      _$CorrectionEntryImpl _value, $Res Function(_$CorrectionEntryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? referenceType = null,
    Object? referenceId = null,
    Object? action = null,
    Object? userId = null,
    Object? userDisplayName = null,
    Object? timestamp = null,
    Object? details = freezed,
  }) {
    return _then(_$CorrectionEntryImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      referenceType: null == referenceType
          ? _value.referenceType
          : referenceType // ignore: cast_nullable_to_non_nullable
              as CorrectionReferenceType,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String,
      action: null == action
          ? _value.action
          : action // ignore: cast_nullable_to_non_nullable
              as CorrectionAction,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
      userDisplayName: null == userDisplayName
          ? _value.userDisplayName
          : userDisplayName // ignore: cast_nullable_to_non_nullable
              as String,
      timestamp: null == timestamp
          ? _value.timestamp
          : timestamp // ignore: cast_nullable_to_non_nullable
              as DateTime,
      details: freezed == details
          ? _value.details
          : details // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CorrectionEntryImpl extends _CorrectionEntry {
  const _$CorrectionEntryImpl(
      {required this.id,
      @JsonKey(name: 'reference_type') required this.referenceType,
      @JsonKey(name: 'reference_id') required this.referenceId,
      required this.action,
      @JsonKey(name: 'user_id') required this.userId,
      @JsonKey(name: 'user_display_name') required this.userDisplayName,
      required this.timestamp,
      this.details})
      : super._();

  factory _$CorrectionEntryImpl.fromJson(Map<String, dynamic> json) =>
      _$$CorrectionEntryImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'reference_type')
  final CorrectionReferenceType referenceType;
  @override
  @JsonKey(name: 'reference_id')
  final String referenceId;
  @override
  final CorrectionAction action;
  @override
  @JsonKey(name: 'user_id')
  final String userId;
  @override
  @JsonKey(name: 'user_display_name')
  final String userDisplayName;
  @override
  final DateTime timestamp;
  @override
  final String? details;

  @override
  String toString() {
    return 'CorrectionEntry(id: $id, referenceType: $referenceType, referenceId: $referenceId, action: $action, userId: $userId, userDisplayName: $userDisplayName, timestamp: $timestamp, details: $details)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CorrectionEntryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.referenceType, referenceType) ||
                other.referenceType == referenceType) &&
            (identical(other.referenceId, referenceId) ||
                other.referenceId == referenceId) &&
            (identical(other.action, action) || other.action == action) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.userDisplayName, userDisplayName) ||
                other.userDisplayName == userDisplayName) &&
            (identical(other.timestamp, timestamp) ||
                other.timestamp == timestamp) &&
            (identical(other.details, details) || other.details == details));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, referenceType, referenceId,
      action, userId, userDisplayName, timestamp, details);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CorrectionEntryImplCopyWith<_$CorrectionEntryImpl> get copyWith =>
      __$$CorrectionEntryImplCopyWithImpl<_$CorrectionEntryImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CorrectionEntryImplToJson(
      this,
    );
  }
}

abstract class _CorrectionEntry extends CorrectionEntry {
  const factory _CorrectionEntry(
      {required final String id,
      @JsonKey(name: 'reference_type')
      required final CorrectionReferenceType referenceType,
      @JsonKey(name: 'reference_id') required final String referenceId,
      required final CorrectionAction action,
      @JsonKey(name: 'user_id') required final String userId,
      @JsonKey(name: 'user_display_name') required final String userDisplayName,
      required final DateTime timestamp,
      final String? details}) = _$CorrectionEntryImpl;
  const _CorrectionEntry._() : super._();

  factory _CorrectionEntry.fromJson(Map<String, dynamic> json) =
      _$CorrectionEntryImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'reference_type')
  CorrectionReferenceType get referenceType;
  @override
  @JsonKey(name: 'reference_id')
  String get referenceId;
  @override
  CorrectionAction get action;
  @override
  @JsonKey(name: 'user_id')
  String get userId;
  @override
  @JsonKey(name: 'user_display_name')
  String get userDisplayName;
  @override
  DateTime get timestamp;
  @override
  String? get details;
  @override
  @JsonKey(ignore: true)
  _$$CorrectionEntryImplCopyWith<_$CorrectionEntryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
