// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'error_log_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ErrorLogModelAdapter extends TypeAdapter<ErrorLogModel> {
  @override
  final int typeId = 90;

  @override
  ErrorLogModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ErrorLogModel(
      id: fields[0] as String,
      title: fields[1] as String,
      message: fields[2] as String,
      source: fields[3] as String?,
      stackTrace: fields[4] as String?,
      severity: fields[5] as ErrorSeverity,
      createdAt: fields[6] as DateTime,
      isRead: fields[7] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ErrorLogModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.message)
      ..writeByte(3)
      ..write(obj.source)
      ..writeByte(4)
      ..write(obj.stackTrace)
      ..writeByte(5)
      ..write(obj.severity)
      ..writeByte(6)
      ..write(obj.createdAt)
      ..writeByte(7)
      ..write(obj.isRead);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ErrorLogModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
