import 'package:hive/hive.dart';
import 'lookup_model.dart';

class ManualLookupModelAdapter extends TypeAdapter<LookupModel> {
  @override
  final int typeId = 14;

  @override
  LookupModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return LookupModel(
      id: fields[0] as String,
      name: fields[1] as String,
      type: fields[2] as String,
      isActive: fields[3] as bool,
      branchId: fields[4] as String,
      syncVersion: fields[5] as int,
      lastModified: DateTime.fromMillisecondsSinceEpoch(fields[6] as int),
      isDeleted: fields[7] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, LookupModel obj) {
    writer.writeByte(8);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.name);
    writer.writeByte(2);
    writer.write(obj.type);
    writer.writeByte(3);
    writer.write(obj.isActive);
    writer.writeByte(4);
    writer.write(obj.branchId);
    writer.writeByte(5);
    writer.write(obj.syncVersion);
    writer.writeByte(6);
    writer.write(obj.lastModified.millisecondsSinceEpoch);
    writer.writeByte(7);
    writer.write(obj.isDeleted);
  }
}
