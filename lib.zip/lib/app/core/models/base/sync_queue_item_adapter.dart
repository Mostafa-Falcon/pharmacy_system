import 'package:hive/hive.dart';
import 'sync_queue_item.dart';

class SyncQueueItemAdapter extends TypeAdapter<SyncQueueItem> {
  @override
  final int typeId = 4;

  @override
  SyncQueueItem read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SyncQueueItem(
      id: fields[0] as String,
      operation: fields[1] as String,
      table: fields[2] as String,
      data: Map<String, dynamic>.from(fields[3] as Map),
      createdAt: DateTime.fromMillisecondsSinceEpoch(fields[4] as int),
      retryCount: fields[5] as int? ?? 0,
      lastError: fields[6] as String?,
      syncedAt: fields[7] != null ? DateTime.fromMillisecondsSinceEpoch(fields[7] as int) : null,
      branchId: fields[8] as String,
    );
  }

  @override
  void write(BinaryWriter writer, SyncQueueItem obj) {
    writer.writeByte(9);
    writer.writeByte(0);
    writer.write(obj.id);
    writer.writeByte(1);
    writer.write(obj.operation);
    writer.writeByte(2);
    writer.write(obj.table);
    writer.writeByte(3);
    writer.write(obj.data);
    writer.writeByte(4);
    writer.write(obj.createdAt.millisecondsSinceEpoch);
    writer.writeByte(5);
    writer.write(obj.retryCount);
    writer.writeByte(6);
    writer.write(obj.lastError);
    writer.writeByte(7);
    writer.write(obj.syncedAt?.millisecondsSinceEpoch);
    writer.writeByte(8);
    writer.write(obj.branchId);
  }
}
