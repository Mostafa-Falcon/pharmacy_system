import 'package:hive/hive.dart';

@HiveType(typeId: 4)
class SyncQueueItem extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String operation; // create, update, delete

  @HiveField(2)
  String table; // users, branches, permissions, medicines, sales, purchases, inventory, returns

  @HiveField(3)
  Map<String, dynamic> data;

  @HiveField(4)
  DateTime createdAt;

  @HiveField(5)
  int retryCount;

  @HiveField(6)
  String? lastError;

  @HiveField(7)
  DateTime? syncedAt;

  @HiveField(8)
  String branchId;

  SyncQueueItem({
    required this.id,
    required this.operation,
    required this.table,
    required this.data,
    required this.createdAt,
    this.retryCount = 0,
    this.lastError,
    this.syncedAt,
    required this.branchId,
  });

  SyncQueueItem copyWith({
    String? id,
    String? operation,
    String? table,
    Map<String, dynamic>? data,
    DateTime? createdAt,
    int? retryCount,
    String? lastError,
    DateTime? syncedAt,
    String? branchId,
  }) {
    return SyncQueueItem(
      id: id ?? this.id,
      operation: operation ?? this.operation,
      table: table ?? this.table,
      data: data ?? Map<String, dynamic>.from(this.data),
      createdAt: createdAt ?? this.createdAt,
      retryCount: retryCount ?? this.retryCount,
      lastError: lastError ?? this.lastError,
      syncedAt: syncedAt ?? this.syncedAt,
      branchId: branchId ?? this.branchId,
    );
  }
}
