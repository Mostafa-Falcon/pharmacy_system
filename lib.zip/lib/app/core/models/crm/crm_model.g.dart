// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CrmLeadModelAdapter extends TypeAdapter<CrmLeadModel> {
  @override
  final int typeId = 22;

  @override
  CrmLeadModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CrmLeadModel(
      id: fields[0] as String,
      branchId: fields[1] as String,
      name: fields[2] as String,
      phone: fields[3] as String?,
      email: fields[4] as String?,
      status: fields[5] as CrmLeadStatus,
      source: fields[6] as String?,
      notes: fields[7] as String?,
      assignedTo: fields[8] as String?,
      createdAt: fields[9] as DateTime,
      nextFollowUp: fields[10] as DateTime?,
      syncVersion: fields[11] as int,
      lastModified: fields[12] as DateTime?,
      isDeleted: fields[13] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, CrmLeadModel obj) {
    writer
      ..writeByte(14)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.branchId)
      ..writeByte(2)
      ..write(obj.name)
      ..writeByte(3)
      ..write(obj.phone)
      ..writeByte(4)
      ..write(obj.email)
      ..writeByte(5)
      ..write(obj.status)
      ..writeByte(6)
      ..write(obj.source)
      ..writeByte(7)
      ..write(obj.notes)
      ..writeByte(8)
      ..write(obj.assignedTo)
      ..writeByte(9)
      ..write(obj.createdAt)
      ..writeByte(10)
      ..write(obj.nextFollowUp)
      ..writeByte(11)
      ..write(obj.syncVersion)
      ..writeByte(12)
      ..write(obj.lastModified)
      ..writeByte(13)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CrmLeadModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class CrmFollowUpModelAdapter extends TypeAdapter<CrmFollowUpModel> {
  @override
  final int typeId = 23;

  @override
  CrmFollowUpModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CrmFollowUpModel(
      id: fields[0] as String,
      leadId: fields[1] as String,
      branchId: fields[2] as String,
      followUpDate: fields[3] as DateTime,
      notes: fields[4] as String,
      createdBy: fields[5] as String,
      syncVersion: fields[6] as int,
      lastModified: fields[7] as DateTime?,
      isDeleted: fields[8] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, CrmFollowUpModel obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.leadId)
      ..writeByte(2)
      ..write(obj.branchId)
      ..writeByte(3)
      ..write(obj.followUpDate)
      ..writeByte(4)
      ..write(obj.notes)
      ..writeByte(5)
      ..write(obj.createdBy)
      ..writeByte(6)
      ..write(obj.syncVersion)
      ..writeByte(7)
      ..write(obj.lastModified)
      ..writeByte(8)
      ..write(obj.isDeleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CrmFollowUpModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class CrmLeadStatusAdapter extends TypeAdapter<CrmLeadStatus> {
  @override
  final int typeId = 21;

  @override
  CrmLeadStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return CrmLeadStatus.newLead;
      case 1:
        return CrmLeadStatus.contacted;
      case 2:
        return CrmLeadStatus.interested;
      case 3:
        return CrmLeadStatus.converted;
      case 4:
        return CrmLeadStatus.notInterested;
      default:
        return CrmLeadStatus.newLead;
    }
  }

  @override
  void write(BinaryWriter writer, CrmLeadStatus obj) {
    switch (obj) {
      case CrmLeadStatus.newLead:
        writer.writeByte(0);
        break;
      case CrmLeadStatus.contacted:
        writer.writeByte(1);
        break;
      case CrmLeadStatus.interested:
        writer.writeByte(2);
        break;
      case CrmLeadStatus.converted:
        writer.writeByte(3);
        break;
      case CrmLeadStatus.notInterested:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CrmLeadStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
