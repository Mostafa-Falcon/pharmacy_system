import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../utils/app_utils.dart';

/// خدمة الثيم — ChangeNotifier مستقلة (معمارية BLoC).
/// استخدم [ThemeService.instance] للوصول للنسخة الوحيدة.
class ThemeService extends ChangeNotifier {
  static final ThemeService instance = ThemeService._();
  ThemeService._();

  late final Box _settingsBox;
  ThemeMode _themeMode = ThemeMode.light;

  ThemeMode get currentThemeMode => _themeMode;

  bool get isDark {
    if (_themeMode == ThemeMode.system) {
      return PlatformDispatcher.instance.platformBrightness == Brightness.dark;
    }
    return _themeMode == ThemeMode.dark;
  }

  Future<void> init() async {
    try {
      _settingsBox = await Hive.openBox('settings');
      final saved = _settingsBox.get('themeMode', defaultValue: 'light') as String;
      _themeMode = _themeModeFromString(saved);
      safeDebugPrint('ThemeService: Initialized with mode: $_themeMode');
    } catch (e) {
      safeDebugPrint('ThemeService: Init error: $e');
      _settingsBox = Hive.box('settings');
      final saved = _settingsBox.get('themeMode', defaultValue: 'light') as String;
      _themeMode = _themeModeFromString(saved);
    }
    notifyListeners();
  }

  void toggleTheme() {
    final next = isDark ? ThemeMode.light : ThemeMode.dark;
    safeDebugPrint('ThemeService: Toggling theme to: $next');
    _apply(next);
  }

  void setThemeMode(ThemeMode mode) {
    safeDebugPrint('ThemeService: Setting theme mode to: $mode');
    _apply(mode);
  }

  void _apply(ThemeMode mode) {
    if (_themeMode == mode) return;
    _themeMode = mode;
    _settingsBox.put('themeMode', mode.name);
    notifyListeners();
  }

  ThemeMode _themeModeFromString(String value) {
    switch (value) {
      case 'dark':
        return ThemeMode.dark;
      case 'system':
        return ThemeMode.system;
      default:
        return ThemeMode.light;
    }
  }
}
