import 'dart:async';
import 'dart:convert';
import 'package:hive/hive.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../models/security/user_model.dart';
import '../../models/security/permission_model.dart';
import '../../models/security/branch_model.dart';
import '../sync_service.dart';
import '../../repositories/base_repository.dart';
import 'password_hasher.dart';
import 'secure_storage_helper.dart';
import '../../constants/app_strings.dart';
import '../../utils/app_utils.dart';
import '../../injection.dart';

part 'auth_session.dart';
part 'auth_device_lock.dart';
part 'auth_user_sync.dart';

class AuthService {
  static UserModel? _currentUser;
  static String? _currentBranchId;
  static BranchModel? _currentBranch;
  static String? _currentDeviceId;
  static bool _initialized = false;

  static Timer? _loginThrottleTimer;
  static Timer? _registerThrottleTimer;
  static int _loginAttemptCount = 0;
  static int _registerAttemptCount = 0;
  static const int _maxAttempts = 5;
  static const Duration _throttleWindow = Duration(minutes: 1);

  static UserModel? get currentUser => _currentUser;
  static String? get currentBranchId => _currentBranchId;
  static BranchModel? get currentBranch => _currentBranch;
  static String? get currentDeviceId => _currentDeviceId;
  static bool get isInitialized => _initialized;

  static Future<String?> _getDeviceId() async {
    final box = await Hive.openBox('auth');
    var deviceId = box.get('device_id') as String?;
    if (deviceId == null || deviceId.isEmpty) {
      deviceId = const Uuid().v4();
      await box.put('device_id', deviceId);
    }
    return deviceId;
  }

  static bool _isLoginThrottled() {
    if (_loginThrottleTimer?.isActive ?? false) {
      _loginAttemptCount++;
      if (_loginAttemptCount >= _maxAttempts) {
        return true;
      }
    }
    return false;
  }

  static bool _isRegisterThrottled() {
    if (_registerThrottleTimer?.isActive ?? false) {
      _registerAttemptCount++;
      if (_registerAttemptCount >= _maxAttempts) {
        return true;
      }
    }
    return false;
  }

  static void _startLoginThrottle() {
    _loginAttemptCount = 0;
    _loginThrottleTimer?.cancel();
    _loginThrottleTimer = Timer(_throttleWindow, () {
      _loginThrottleTimer = null;
      _loginAttemptCount = 0;
    });
  }

  static void _startRegisterThrottle() {
    _registerAttemptCount = 0;
    _registerThrottleTimer?.cancel();
    _registerThrottleTimer = Timer(_throttleWindow, () {
      _registerThrottleTimer = null;
      _registerAttemptCount = 0;
    });
  }

  static Future<bool> _isOnline() async {
    return SyncService.isOnline;
  }

  static Future<void> init() => AuthSession.init();

  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    if (_isLoginThrottled()) {
      return {
        'success': false,
        'message': AppStrings.tooManyAttempts,
      };
    }

    if (!await AuthService._isOnline()) {
      _startLoginThrottle();
      return {
        'success': false,
        'message': AppStrings.loginRequiresInternet,
      };
    }

    try {
      final result = await AuthSession.login(email: email, password: password);
      if (result['success'] == true) {
        _startLoginThrottle();
      } else {
        _startLoginThrottle();
      }
      return result;
    } catch (e) {
      _startLoginThrottle();
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    required UserRole role,
    String? assignedBranchId,
  }) async {
    if (_isRegisterThrottled()) {
      return {
        'success': false,
        'message': AppStrings.tooManyAttempts,
      };
    }

    if (!await AuthService._isOnline()) {
      _startRegisterThrottle();
      return {
        'success': false,
        'message': AppStrings.registerRequiresInternet,
      };
    }

    try {
      final result = await AuthSession.register(
        name: name,
        email: email,
        password: password,
        role: role,
        assignedBranchId: assignedBranchId,
      );
      if (result['success'] == true) {
        _startRegisterThrottle();
      } else {
        _startRegisterThrottle();
      }
      return result;
    } catch (e) {
      _startRegisterThrottle();
      rethrow;
    }
  }

  static Future<void> logout() => AuthSession.logout();

  static Future<Map<String, dynamic>> changePassword({
    required String currentPassword,
    required String newPassword,
  }) =>
      AuthSession.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );

  static Future<void> selectBranch(String branchId) =>
      AuthSession.selectBranch(branchId);

  static void refreshCurrentBranch() {
    if (_currentBranchId == null || _currentBranchId!.isEmpty) return;
    try {
      final box = Hive.box('branches');
      final branch = box.get(_currentBranchId);
      if (branch is BranchModel) {
        _currentBranch = branch;
      }
    } catch (_) {}
  }

  static Future<List<BranchModel>> getAllBranches() =>
      AuthSession.getAllBranches();

  static Future<Map<String, dynamic>> getDashboardStats() =>
      AuthSession.getDashboardStats();

  static Future<Map<String, dynamic>> resendConfirmation(String email) =>
      AuthSession.resendConfirmation(email);

  static bool hasPermission(String permissionKey) =>
      AuthSession.hasPermission(permissionKey);

  // ─── Device Lock (الواجهة العامة) ───

  static Future<Map<String, dynamic>> forceReleaseLock() =>
      AuthDeviceLock.forceReleaseLock();

  static Future<String?> fetchLockedDevice(String userId) =>
      AuthDeviceLock.fetchLockedDevice(userId);
}
