import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../models/tasks/task_models.dart';
import '../auth/auth_service.dart';
import 'package:get_it/get_it.dart';

/// TaskService - خدمة مُنفذة كـ singleton عبر get_it
/// خدمة المهام — خدمة عادية مُدارة عبر GetIt.
class TaskService {
  static final TaskService _instance = TaskService._internal();
  factory TaskService() => _instance;
  TaskService._internal();

  static TaskService get to => GetIt.instance<TaskService>();

  late Box<TaskModel> _taskBox;
  late Box<NoteModel> _noteBox;
  late Box<ReminderModel> _reminderBox;
  late Box<MessageModel> _messageBox;

  Future<void> init() async {
    _taskBox = Hive.box<TaskModel>('tasks');
    _noteBox = Hive.box<NoteModel>('notes');
    _reminderBox = Hive.box<ReminderModel>('reminders');
    _messageBox = Hive.box<MessageModel>('messages');
  }

  String get _branchId => AuthService.currentBranchId ?? '';

  // ─── Tasks ───
  List<TaskModel> getTasks({
    String? status,
    String? priority,
    String? assignedTo,
  }) {
    var tasks = _taskBox.values.where((t) => t.branchId == _branchId).toList();
    if (status != null) tasks = tasks.where((t) => t.status == status).toList();
    if (priority != null) {
      tasks = tasks.where((t) => t.priority == priority).toList();
    }
    if (assignedTo != null) {
      tasks = tasks.where((t) => t.assignedTo == assignedTo).toList();
    }
    tasks.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return tasks;
  }

  Future<TaskModel> createTask({
    required String title,
    String? description,
    String priority = 'medium',
    String? assignedTo,
    String? assignedName,
    DateTime? dueDate,
  }) async {
    final task = TaskModel(
      id: const Uuid().v4(),
      branchId: _branchId,
      title: title,
      description: description,
      priority: priority,
      assignedTo: assignedTo,
      assignedName: assignedName,
      dueDate: dueDate,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    await _taskBox.put(task.id, task);
    return task;
  }

  Future<void> updateTask(
    String id, {
    String? title,
    String? description,
    String? priority,
    String? status,
    String? assignedTo,
    String? assignedName,
    DateTime? dueDate,
    DateTime? completedAt,
  }) async {
    final task = _taskBox.get(id);
    if (task == null) return;
    if (title != null) task.title = title;
    if (description != null) task.description = description;
    if (priority != null) task.priority = priority;
    if (status != null) task.status = status;
    if (assignedTo != null) task.assignedTo = assignedTo;
    if (assignedName != null) task.assignedName = assignedName;
    if (dueDate != null) task.dueDate = dueDate;
    task.updatedAt = DateTime.now();
    if (status == 'completed') task.completedAt = DateTime.now();
    task.completedAt = completedAt;
    await task.save();
  }

  Future<void> deleteTask(String id) async => _taskBox.delete(id);
  Future<void> completeTask(String id) async =>
      updateTask(id, status: 'completed');
  Future<void> reopenTask(String id) async =>
      updateTask(id, status: 'pending', completedAt: null);

  // ─── Notes ───
  List<NoteModel> getNotes() {
    final notes = _noteBox.values
        .where((n) => n.branchId == _branchId)
        .toList();
    notes.sort((a, b) {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return b.createdAt.compareTo(a.createdAt);
    });
    return notes;
  }

  Future<NoteModel> createNote({
    required String title,
    required String content,
    bool pinned = false,
    String? color,
  }) async {
    final note = NoteModel(
      id: const Uuid().v4(),
      branchId: _branchId,
      title: title,
      content: content,
      pinned: pinned,
      color: color,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    await _noteBox.put(note.id, note);
    return note;
  }

  Future<void> updateNote(
    String id, {
    String? title,
    String? content,
    bool? pinned,
    String? color,
  }) async {
    final note = _noteBox.get(id);
    if (note == null) return;
    if (title != null) note.title = title;
    if (content != null) note.content = content;
    if (pinned != null) note.pinned = pinned;
    if (color != null) note.color = color;
    note.updatedAt = DateTime.now();
    await note.save();
  }

  Future<void> deleteNote(String id) async => _noteBox.delete(id);
  Future<void> togglePinNote(String id) async {
    final note = _noteBox.get(id);
    if (note == null) return;
    note.pinned = !note.pinned;
    await note.save();
  }

  // ─── Reminders ───
  List<ReminderModel> getReminders({bool? dismissed}) {
    var reminders = _reminderBox.values
        .where((r) => r.branchId == _branchId)
        .toList();
    if (dismissed != null) {
      reminders = reminders.where((r) => r.dismissed == dismissed).toList();
    }
    reminders.sort((a, b) => a.remindAt.compareTo(b.remindAt));
    return reminders;
  }

  Future<ReminderModel> createReminder({
    required String title,
    required String message,
    required DateTime remindAt,
    String repeat = 'none',
  }) async {
    final reminder = ReminderModel(
      id: const Uuid().v4(),
      branchId: _branchId,
      title: title,
      message: message,
      remindAt: remindAt,
      repeat: repeat,
      createdAt: DateTime.now(),
    );
    await _reminderBox.put(reminder.id, reminder);
    return reminder;
  }

  Future<void> dismissReminder(String id) async {
    final reminder = _reminderBox.get(id);
    if (reminder == null) return;
    reminder.dismissed = true;
    await reminder.save();
  }

  Future<void> deleteReminder(String id) async => _reminderBox.delete(id);

  // ─── Messages ───
  List<MessageModel> getMessages({String? userId}) {
    var messages = _messageBox.values
        .where((m) => m.branchId == _branchId)
        .toList();
    if (userId != null) {
      messages = messages
          .where((m) => m.toUserId == userId || m.fromUserId == userId)
          .toList();
    }
    messages.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return messages;
  }

  Future<MessageModel> sendMessage({
    required String toUserId,
    required String toName,
    required String subject,
    required String body,
    String priority = 'normal',
  }) async {
    final user = AuthService.currentUser;
    final msg = MessageModel(
      id: const Uuid().v4(),
      branchId: _branchId,
      fromUserId: user?.id ?? '',
      fromName: user?.name ?? '',
      toUserId: toUserId,
      toName: toName,
      subject: subject,
      body: body,
      priority: priority,
      createdAt: DateTime.now(),
    );
    await _messageBox.put(msg.id, msg);
    return msg;
  }

  Future<void> markMessageRead(String id) async {
    final msg = _messageBox.get(id);
    if (msg == null) return;
    msg.readAt = DateTime.now();
    await msg.save();
  }

  Future<void> deleteMessage(String id) async => _messageBox.delete(id);

  int get unreadCount => _messageBox.values
      .where((m) => m.readAt == null && m.branchId == _branchId)
      .length;
}
