import 'dart:async';

import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../models/customer/customer_ledger_model.dart';
import '../models/supplier/supplier_ledger_model.dart';
import '../utils/app_utils.dart';
import 'sync_service.dart';
import 'sync_box_extension.dart';

class LedgerService {
  static const _uuid = Uuid();

  // Customer Ledger Box
  static Box<dynamic> get _customerLedgerBox {
    if (!Hive.isBoxOpen('customer_ledgers')) {
      throw Exception('Customer ledger box not open');
    }
    return Hive.box('customer_ledgers');
  }

  // Supplier Ledger Box
  static Box<dynamic> get _supplierLedgerBox {
    if (!Hive.isBoxOpen('supplier_ledgers')) {
      throw Exception('Supplier ledger box not open');
    }
    return Hive.box('supplier_ledgers');
  }

  // ==================== Customer Ledger Methods ====================
  static Future<void> insertCustomerEntry(CustomerLedgerModel entry) async {
    await _customerLedgerBox.putSynced(entry.id, entry, table: 'customer_ledgers', branchId: entry.branchId);
  }

  static Future<void> updateCustomerEntry(CustomerLedgerModel entry) async {
    await _customerLedgerBox.putSynced(entry.id, entry, table: 'customer_ledgers', type: SyncOperationType.update, branchId: entry.branchId);
  }

  static Future<void> deleteCustomerEntry(String id) async {
    await _customerLedgerBox.delete(id);
    // نحتاج الـ data عشان الـ queue يحتوي الـ id للحذف؛ نبعته كـ delete operation
    unawaited(_queueOp(SyncOperationType.delete, 'customer_ledgers', {'id': id, 'is_deleted': true}, ''));
  }

  static List<CustomerLedgerModel> getCustomerEntries(
    String customerId,
    String branchId,
  ) {
    return _customerLedgerBox.values
        .whereType<CustomerLedgerModel>()
        .where(
          (e) =>
              e.customerId == customerId &&
              e.branchId == branchId &&
              !e.isDeleted,
        )
        .toList()
      ..sort((a, b) => b.entryDate.compareTo(a.entryDate));
  }

  static Future<double> getCustomerBalance(
    String customerId,
    String branchId,
  ) async {
    final entries = getCustomerEntries(customerId, branchId);
    return entries.fold<double>(0.0, (sum, e) => sum + e.debit - e.credit);
  }

  static Future<double> getSupplierBalance(
    String supplierId,
    String branchId,
  ) async {
    final entries = getSupplierEntries(supplierId, branchId);
    return entries.fold<double>(0.0, (sum, e) => sum + e.debit - e.credit);
  }

  // ==================== Supplier Ledger Methods ====================
  static Future<void> insertSupplierEntry(SupplierLedgerModel entry) async {
    await _supplierLedgerBox.putSynced(entry.id, entry, table: 'supplier_ledgers', branchId: entry.branchId);
  }

  static Future<void> updateSupplierEntry(SupplierLedgerModel entry) async {
    await _supplierLedgerBox.putSynced(entry.id, entry, table: 'supplier_ledgers', type: SyncOperationType.update, branchId: entry.branchId);
  }

  static Future<void> deleteSupplierEntry(String id) async {
    await _supplierLedgerBox.delete(id);
    unawaited(_queueOp(SyncOperationType.delete, 'supplier_ledgers', {'id': id, 'is_deleted': true}, ''));
  }

  static List<SupplierLedgerModel> getSupplierEntries(
    String supplierId,
    String branchId,
  ) {
    return _supplierLedgerBox.values
        .whereType<SupplierLedgerModel>()
        .where(
          (e) =>
              e.supplierId == supplierId &&
              e.branchId == branchId &&
              !e.isDeleted,
        )
        .toList()
      ..sort((a, b) => b.entryDate.compareTo(a.entryDate));
  }

  // ==================== Combined Party Ledger ====================
  static List<Map<String, dynamic>> getCombinedLedger(
    String partyId, {
    String branchId = '',
  }) {
    final customerEntries = getCustomerEntries(partyId, branchId);
    final supplierEntries = getSupplierEntries(partyId, branchId);

    final combined = <Map<String, dynamic>>[];

    for (final e in customerEntries) {
      combined.add({
        'id': e.id,
        'date': e.entryDate,
        'type': 'customer',
        'entryType': e.type.name,
        'debit': e.debit,
        'credit': e.credit,
        'balanceAfter': e.balanceAfter,
        'referenceNumber': e.referenceNumber,
        'notes': e.notes,
        'createdBy': e.createdBy,
        'runningBalance': 0.0, // Will be calculated below
      });
    }

    for (final e in supplierEntries) {
      combined.add({
        'id': e.id,
        'date': e.entryDate,
        'type': 'supplier',
        'entryType': e.type.name,
        'debit': e.debit,
        'credit': e.credit,
        'balanceAfter': e.balanceAfter,
        'referenceNumber': e.referenceNumber,
        'notes': e.notes,
        'createdBy': e.createdBy,
        'runningBalance': 0.0, // Will be calculated below
      });
    }

    // Sort by date descending
    combined.sort(
      (a, b) => (b['date'] as DateTime).compareTo(a['date'] as DateTime),
    );

    // Calculate running balance
    double runningBalance = 0.0;
    for (final entry in combined) {
      final debit = entry['debit'] as double;
      final credit = entry['credit'] as double;
      runningBalance += debit - credit;
      entry['runningBalance'] = runningBalance;
    }

    return combined;
  }

  static double getCombinedBalance(String partyId, {String branchId = ''}) {
    final customerBalance = _customerLedgerBox.values
        .where(
          (e) =>
              e.customerId == partyId && e.branchId == branchId && !e.isDeleted,
        )
        .fold<double>(0.0, (sum, e) => sum + e.debit - e.credit);

    final supplierBalance = _supplierLedgerBox.values
        .where(
          (e) =>
              e.supplierId == partyId && e.branchId == branchId && !e.isDeleted,
        )
        .fold<double>(0.0, (sum, e) => sum + e.debit - e.credit);

    return customerBalance - supplierBalance;
  }

  static Map<String, double> getTransactionSummary(
    String partyId, {
    String branchId = '',
  }) {
    final customerEntries = getCustomerEntries(partyId, branchId);
    final supplierEntries = getSupplierEntries(partyId, branchId);

    double totalSales = 0;
    double totalSalesReturns = 0;
    double totalPurchases = 0;
    double totalPurchaseReturns = 0;
    double totalReceipts = 0;
    double totalPayments = 0;
    double totalAdditions = 0;
    double totalDiscounts = 0;
    double totalCheckReceipts = 0;
    double totalCheckPayments = 0;

    for (final e in customerEntries) {
      switch (e.type) {
        case CustomerLedgerEntryType.saleInvoice:
          totalSales += e.debit;
          break;
        case CustomerLedgerEntryType.saleReturn:
          totalSalesReturns += e.credit;
          break;
        case CustomerLedgerEntryType.customerPayment:
          totalReceipts += e.credit;
          break;
        case CustomerLedgerEntryType.additionNotice:
          totalAdditions += e.debit;
          break;
        case CustomerLedgerEntryType.discountNotice:
          totalDiscounts += e.credit;
          break;
        case CustomerLedgerEntryType.checkReceipt:
          totalCheckReceipts += e.credit;
          break;
        case CustomerLedgerEntryType.checkPayment:
          totalCheckPayments += e.debit;
          break;
        default:
          break;
      }
    }

    for (final e in supplierEntries) {
      switch (e.type) {
        case SupplierLedgerEntryType.purchaseInvoice:
          totalPurchases += e.debit;
          break;
        case SupplierLedgerEntryType.supplierPayment:
          totalPayments += e.credit;
          break;
        case SupplierLedgerEntryType.purchaseVoid:
          totalPurchaseReturns += e.credit;
          break;
        case SupplierLedgerEntryType.additionNotice:
          totalAdditions += e.debit;
          break;
        case SupplierLedgerEntryType.discountNotice:
          totalDiscounts += e.credit;
          break;
        case SupplierLedgerEntryType.checkReceipt:
          totalCheckReceipts += e.debit;
          break;
        case SupplierLedgerEntryType.checkPayment:
          totalCheckPayments += e.credit;
          break;
        default:
          break;
      }
    }

    return {
      'totalSales': totalSales,
      'totalSalesReturns': totalSalesReturns,
      'totalPurchases': totalPurchases,
      'totalPurchaseReturns': totalPurchaseReturns,
      'totalReceipts': totalReceipts,
      'totalPayments': totalPayments,
      'totalAdditions': totalAdditions,
      'totalDiscounts': totalDiscounts,
      'totalCheckReceipts': totalCheckReceipts,
      'totalCheckPayments': totalCheckPayments,
    };
  }

  // ==================== Record Entry Helpers ====================
  static String generateId() => _uuid.v4();

  // ==================== Sync Queue Helper ====================
  static Future<void> _queueOp(SyncOperationType type, String table, Map<String, dynamic> data, String branchId) async {
    try {
      await SyncService.queueOperation(type: type, table: table, data: data, branchId: branchId);
    } catch (e) {
      safeDebugPrint('LedgerService: queue $table failed: $e');
    }
  }
}
