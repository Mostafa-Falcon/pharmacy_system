import 'dart:async';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../models/inventory/promotion_model.dart';

class PromotionService {
  static const _boxName = 'promotions';
  static final _uuid = const Uuid();

  static Future<Box> get _box async => Hive.isBoxOpen(_boxName)
      ? Hive.box(_boxName)
      : await Hive.openBox(_boxName);

  static Future<List<PromotionModel>> getAll({String? branchId}) async {
    final box = await _box;
    final items = box.values.whereType<PromotionModel>().toList();
    if (branchId != null) {
      return items.where((p) => p.branchId == branchId).toList();
    }
    return items;
  }

  static Future<List<PromotionModel>> getActive({String? branchId}) async {
    final all = await getAll(branchId: branchId);
    return all.where((p) => p.isCurrentlyActive).toList();
  }

  static Future<PromotionModel?> getById(String id) async {
    final box = await _box;
    return box.get(id) as PromotionModel?;
  }

  static Future<PromotionModel> create(PromotionModel promotion) async {
    final box = await _box;
    final newPromotion = promotion.copyWith(
      id: _uuid.v4(),
      lastModified: DateTime.now(),
    );
    await box.put(newPromotion.id, newPromotion);
    return newPromotion;
  }

  static Future<PromotionModel> update(PromotionModel promotion) async {
    final box = await _box;
    final updated = promotion.copyWith(lastModified: DateTime.now());
    await box.put(updated.id, updated);
    return updated;
  }

  static Future<void> delete(String id) async {
    final box = await _box;
    await box.delete(id);
  }

  static Future<void> toggleActive(String id, bool isActive) async {
    final promotion = await getById(id);
    if (promotion != null) {
      await update(promotion.copyWith(isActive: isActive));
    }
  }

  static Future<List<PromotionModel>> getForMedicine(String medicineId, String? category, String? customerGroupId, {String? branchId}) async {
    final active = await getActive(branchId: branchId);
    return active.where((p) => p.appliesToMedicine(medicineId, category, customerGroupId)).toList();
  }

  static Future<PromotionModel?> getBestForMedicine(String medicineId, String? category, String? customerGroupId, {String? branchId}) async {
    final applicable = await getForMedicine(medicineId, category, customerGroupId, branchId: branchId);
    if (applicable.isEmpty) return null;
    applicable.sort((a, b) {
      final aDiscount = a.isPercentage ? a.value : (a.value / 100);
      final bDiscount = b.isPercentage ? b.value : (b.value / 100);
      return bDiscount.compareTo(aDiscount);
    });
    return applicable.first;
  }
}
