import 'dart:async';
import 'package:collection/collection.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../models/inventory/opening_stock_model.dart';

class OpeningStockService {
  static const _boxName = 'opening_stock';
  static final _uuid = const Uuid();

  static Future<Box> get _box async => Hive.isBoxOpen(_boxName)
      ? Hive.box(_boxName)
      : await Hive.openBox(_boxName);

  static Future<List<OpeningStockModel>> getAll({String? branchId}) async {
    final box = await _box;
    final items = box.values.whereType<OpeningStockModel>().toList();
    if (branchId != null) {
      return items.where((o) => o.branchId == branchId).toList();
    }
    return items;
  }

  static Future<OpeningStockModel?> getByMedicine(String medicineId, String branchId) async {
    final all = await getAll(branchId: branchId);
    return all.firstWhereOrNull((o) => o.medicineId == medicineId);
  }

  static Future<OpeningStockModel> record({
    required String medicineId,
    required String medicineName,
    required int quantity,
    required double buyPrice,
    required String branchId,
    required String recordedBy,
  }) async {
    final box = await _box;
    final existing = await getByMedicine(medicineId, branchId);
    if (existing != null) {
      final updated = existing.copyWith(
        quantity: quantity,
        buyPrice: buyPrice,
        lastModified: DateTime.now(),
      );
      await box.put(updated.id, updated);
      return updated;
    }

    final opening = OpeningStockModel(
      id: _uuid.v4(),
      medicineId: medicineId,
      medicineName: medicineName,
      quantity: quantity,
      buyPrice: buyPrice,
      branchId: branchId,
      recordedBy: recordedBy,
    );
    await box.put(opening.id, opening);
    return opening;
  }

  static Future<void> delete(String id) async {
    final box = await _box;
    await box.delete(id);
  }
}
