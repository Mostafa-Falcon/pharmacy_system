import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:get_it/get_it.dart';
import '../../models/inventory/stocktaking_period_model.dart';
import '../../models/inventory/stocktaking_model.dart';
import '../auth/auth_service.dart';
import '../sync_service.dart';
import 'stock_mutation_service.dart';

class StocktakingService {
  static final StocktakingService _instance = StocktakingService._internal();
  factory StocktakingService() => _instance;
  StocktakingService._internal();

  static StocktakingService get to => GetIt.instance<StocktakingService>();

  late Box<StocktakingPeriodModel> _periodBox;
  late Box<StocktakingCountModel> _countBox;

  Future<void> init() async {
    _periodBox = Hive.box<StocktakingPeriodModel>('stocktaking_periods');
    _countBox = Hive.box<StocktakingCountModel>('stocktaking_counts');
  }

  String get _branchId => AuthService.currentBranchId ?? '';
  String get _userId => AuthService.currentUser?.id ?? '';

  // ─── Periods ───
  List<StocktakingPeriodModel> getPeriods() {
    final periods = _periodBox.values
        .where((p) => p.branchId == _branchId && !p.isDeleted)
        .toList();
    periods.sort((a, b) => b.startedAt.compareTo(a.startedAt));
    return periods;
  }

  List<StocktakingPeriodModel> getPeriodsPage(int page, int pageSize) {
    final all = getPeriods();
    final start = (page - 1) * pageSize;
    if (start >= all.length) return [];
    return all.sublist(start, (start + pageSize).clamp(0, all.length));
  }

  StocktakingPeriodModel? getPeriod(String id) => _periodBox.get(id);

  Future<StocktakingPeriodModel> createPeriod({
    required String name,
    String? notes,
  }) async {
    final period = StocktakingPeriodModel(
      id: const Uuid().v4(),
      branchId: _branchId,
      name: name,
      status: 'open',
      startedAt: DateTime.now(),
      createdBy: _userId,
      notes: notes,
    );
    await _periodBox.put(period.id, period);
    await SyncService.queueOperation(
      type: SyncOperationType.create,
      table: 'stocktaking_periods',
      data: period.toJson(),
      branchId: _branchId,
    );
    return period;
  }

  Future<void> updatePeriod(
    String id, {
    String? name,
    String? status,
    String? notes,
  }) async {
    final period = _periodBox.get(id);
    if (period == null) return;
    if (name != null) period.name = name;
    if (status != null) period.status = status;
    if (notes != null) period.notes = notes;
    period.lastModified = DateTime.now();
    await period.save();
    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: 'stocktaking_periods',
      data: period.toJson(),
      branchId: _branchId,
    );
  }

  Future<void> deletePeriod(String id) async {
    final period = _periodBox.get(id);
    if (period == null) return;
    period.isDeleted = true;
    period.lastModified = DateTime.now();
    await period.save();
    await SyncService.queueOperation(
      type: SyncOperationType.delete,
      table: 'stocktaking_periods',
      data: period.toJson(),
      branchId: _branchId,
    );
  }

  // ─── Close Period (auto-adjust inventory) ───
  Future<void> closePeriod(String periodId, {String? notes}) async {
    final period = _periodBox.get(periodId);
    if (period == null) throw Exception('Period not found');
    if (period.isClosed) throw Exception('Period is already closed');
    if (period.isCancelled) throw Exception('Cannot close a cancelled period');

    final counts = getCounts(periodId);
    double totalDiff = 0;

    for (final count in counts) {
      totalDiff += count.differenceValue;

      if (count.difference != 0) {
        // تطبيق الفرق على المخزون الفعلي عبر StockMutationService
        // (القفل + طابور المزامنة) بدل التعديل المباشر، عشان التغيير
        // يتدفع لـ Supabase ويتزامن مع باقي الفروع.
        await StockMutationService.adjustStock(
          medicineId: count.itemId,
          delta: count.difference,
          branchId: period.branchId,
        );
      }
    }

    period.status = 'closed';
    period.closedAt = DateTime.now();
    period.totalDifference = totalDiff;
    if (notes != null) period.notes = notes;
    period.lastModified = DateTime.now();
    await period.save();

    // إضافة للـ sync queue للمزامنة
    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: 'stocktaking_periods',
      data: period.toJson(),
      branchId: _branchId,
    );
  }

  Future<void> cancelPeriod(String periodId) async {
    final period = _periodBox.get(periodId);
    if (period == null) throw Exception('Period not found');
    if (period.isClosed) throw Exception('Cannot cancel a closed period');

    period.status = 'cancelled';
    period.closedAt = DateTime.now();
    period.lastModified = DateTime.now();
    await period.save();

    // إضافة للـ sync queue للمزامنة
    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: 'stocktaking_periods',
      data: period.toJson(),
      branchId: _branchId,
    );
  }

  // ─── Counts ───
  List<StocktakingCountModel> getCounts(String periodId) {
    final counts = _countBox.values
        .where((c) => c.periodId == periodId)
        .toList();
    counts.sort((a, b) => b.countedAt.compareTo(a.countedAt));
    return counts;
  }

  StocktakingCountModel? getCount(String id) => _countBox.get(id);

  Future<StocktakingCountModel> recordCount({
    required String periodId,
    required String itemId,
    required String itemName,
    String? sku,
    String unit = 'وحدة',
    required int systemQuantity,
    required int actualQuantity,
    double buyPrice = 0,
    String? notes,
  }) async {
    final count = StocktakingCountModel(
      id: const Uuid().v4(),
      periodId: periodId,
      itemId: itemId,
      itemName: itemName,
      sku: sku,
      unit: unit,
      systemQuantity: systemQuantity,
      actualQuantity: actualQuantity,
      buyPrice: buyPrice,
      notes: notes,
      createdBy: _userId,
    );
    await _countBox.put(count.id, count);

    // Update period counters
    final period = _periodBox.get(periodId);
    if (period != null) {
      period.countedItems = getCounts(periodId).length;
      period.totalDifference += count.differenceValue;
      if (period.isOpen) period.status = 'inProgress';
      period.lastModified = DateTime.now();
      await period.save();
    }

    return count;
  }

  Future<void> updateCount(
    String id, {
    int? actualQuantity,
    String? notes,
  }) async {
    final count = _countBox.get(id);
    if (count == null) return;

    final oldDiff = count.differenceValue;
    if (actualQuantity != null) {
      count.actualQuantity = actualQuantity;
      count.difference = actualQuantity - count.systemQuantity;
      count.differenceValue = count.difference * count.buyPrice;
    }
    if (notes != null) count.notes = notes;
    count.updatedAt = DateTime.now();
    await count.save();

    // Adjust period total
    final period = _periodBox.get(count.periodId);
    if (period != null) {
      period.totalDifference =
          period.totalDifference - oldDiff + count.differenceValue;
      period.lastModified = DateTime.now();
      await period.save();
    }
  }

  Future<void> deleteCount(String id) async {
    final count = _countBox.get(id);
    if (count == null) return;
    await _countBox.delete(id);

    // Recalculate period
    final period = _periodBox.get(count.periodId);
    if (period != null) {
      period.countedItems = getCounts(count.periodId).length;
      period.totalDifference -= count.differenceValue;
      period.lastModified = DateTime.now();
      await period.save();
    }
  }

  Future<void> deleteCountAndRestore(String id) async {
    final count = _countBox.get(id);
    if (count == null) return;

    // Restore medicine stock
    if (count.difference != 0) {
      await StockMutationService.adjustStock(
        medicineId: count.itemId,
        delta: -count.difference,
        branchId: _branchId,
      );
    }

    await deleteCount(id);
  }

  // ─── Sync with old StocktakingModel ───
  Future<void> migrateFromOldModel(StocktakingModel old) async {
    final period = StocktakingPeriodModel(
      id: old.id,
      branchId: old.branchId,
      name: 'جرد ${old.startDate.toString().substring(0, 10)}',
      status: old.status == StocktakingStatus.confirmed ? 'closed' : 'open',
      startedAt: old.startDate,
      closedAt: old.endDate,
      createdBy: old.createdBy,
    );
    await _periodBox.put(period.id, period);
  }
}
