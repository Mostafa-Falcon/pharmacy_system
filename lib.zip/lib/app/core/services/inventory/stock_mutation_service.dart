import 'dart:async';
import 'package:hive/hive.dart';
import '../../models/inventory/medicine_model.dart';
import '../sync_service.dart';

/// Serializes stock mutations per medicine to prevent race conditions.
/// Uses a simple FIFO queue + in-flight flag per medicine ID.
class StockMutationService {
  static final Map<String, bool> _inFlight = {};
  static final Map<String, List<Function()>> _queues = {};

  static Future<T> _withLock<T>(
    String medicineId,
    Future<T> Function() action,
  ) async {
    if (_inFlight[medicineId] != true) {
      _inFlight[medicineId] = true;
      try {
        return await action();
      } finally {
        _inFlight[medicineId] = false;
        _processQueue(medicineId);
      }
    } else {
      final completer = Completer<T>();
      _queues.putIfAbsent(medicineId, () => []).add(() {
        action().then(completer.complete).catchError(completer.completeError);
      });
      return completer.future;
    }
  }

  static void _processQueue(String medicineId) {
    final queue = _queues[medicineId];
    if (queue == null || queue.isEmpty) return;
    final next = queue.removeAt(0);
    if (queue.isEmpty) _queues.remove(medicineId);
    _inFlight[medicineId] = true;
    next().whenComplete(() {
      _inFlight[medicineId] = false;
      _processQueue(medicineId);
    });
  }

  /// تعديل كمية الدواء (للبيع والشراء والمرتجعات)
  /// الحل الصحيح: حفظ الكمية في Hive مباشرةً باستخدام copyWith
  static Future<void> adjustStock({
    required String medicineId,
    required int delta,
    required String branchId,
  }) async {
    await _withLock(medicineId, () async {
      final box = Hive.box('medicines');
      final medicine = box.get(medicineId);
      if (medicine is! MedicineModel) return;

      final newQty = medicine.quantity + delta;
      if (newQty < 0 && !medicine.allowNegativeStock) {
        throw StateError('Insufficient stock for $medicineId');
      }
      final clamped = newQty.clamp(0, 1 << 30);

      final updatedMedicine = medicine.copyWith(
        quantity: clamped,
        lastModified: DateTime.now(),
      );

      await box.put(medicineId, updatedMedicine);

      // إخطار المنظومة بتحديث البيانات لتحديث الـ UI لحظياً
      SyncService.onTableUpdated?.call('medicines', branchId);

      _queueStockUpdate(updatedMedicine, branchId);
    });
  }

  /// حفظ كمية الدواء مباشد
  static Future<void> setStock({
    required String medicineId,
    required int quantity,
    required String branchId,
  }) async {
    await _withLock(medicineId, () async {
      final box = Hive.box('medicines');
      final medicine = box.get(medicineId);
      if (medicine is! MedicineModel) return;

      final newQty = quantity.clamp(0, 1 << 30);

      // حفظ النسخة المحدثة في Hive
      final updatedMedicine = medicine.copyWith(
        quantity: newQty,
        lastModified: DateTime.now(),
      );

      await box.put(medicineId, updatedMedicine);

      // إخطار المنظومة بتحديث البيانات لتحديث الـ UI لحظياً
      SyncService.onTableUpdated?.call('medicines', branchId);

      // إرسال للمزامنة
      _queueStockUpdate(updatedMedicine, branchId);
    });
  }

  /// إرسال التحديث للمزامنة عبر نظام الـ queue الموحّد في SyncService.
  /// ده بيضمن: dedupe بالـ id (نفس الدواء يتحدّث مرة واحدة مش تراكم)،
  /// retry تلقائي مع backoff، ودمج في batch upsert وقت الدفع — بلا تأخير.
  static Future<void> _queueStockUpdate(MedicineModel medicine, String branchId) async {
    final data = Map<String, dynamic>.from(medicine.toJson());
    data['last_modified'] = DateTime.now().toIso8601String();

    await SyncService.update(
      boxName: 'medicines',
      entity: medicine,
      branchId: branchId,
      toJson: data,
    );
  }
}
