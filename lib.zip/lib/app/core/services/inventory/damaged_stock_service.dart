import 'dart:async';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../models/inventory/damaged_stock_model.dart';
import '../../models/inventory/medicine_model.dart';

class DamagedStockService {
  static const _boxName = 'damaged_stock';
  static final _uuid = const Uuid();

  static Future<Box> get _box async => Hive.isBoxOpen(_boxName)
      ? Hive.box(_boxName)
      : await Hive.openBox(_boxName);

  static Future<List<DamagedStockModel>> getAll({String? branchId}) async {
    final box = await _box;
    final items = box.values.whereType<DamagedStockModel>().toList();
    if (branchId != null) {
      return items.where((d) => d.branchId == branchId).toList();
    }
    return items;
  }

  static Future<List<DamagedStockModel>> getByMedicine(String medicineId) async {
    final all = await getAll();
    return all.where((d) => d.medicineId == medicineId).toList();
  }

  static Future<DamagedStockModel> record({
    required String medicineId,
    required String medicineName,
    required int quantity,
    required String reason,
    String? notes,
    required String branchId,
    required String recordedBy,
  }) async {
    final box = await _box;
    final damaged = DamagedStockModel(
      id: _uuid.v4(),
      medicineId: medicineId,
      medicineName: medicineName,
      quantity: quantity,
      reason: reason,
      notes: notes,
      branchId: branchId,
      recordedBy: recordedBy,
    );
    await box.put(damaged.id, damaged);

    final medBox = Hive.box('medicines');
    final medicine = medBox.get(medicineId);
    if (medicine is MedicineModel) {
      final newQty = (medicine.quantity - quantity).clamp(0, double.infinity).toInt();
      await medicine.save();
      await medBox.put(medicineId, medicine.copyWith(quantity: newQty));
    }

    return damaged;
  }

  static Future<void> delete(String id) async {
    final box = await _box;
    await box.delete(id);
  }
}
