import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:get_it/get_it.dart';
import '../../models/inventory/item_batch_model.dart';
import '../../utils/app_utils.dart';
import '../auth/auth_service.dart';
import '../sync_box_extension.dart';

class BatchService {
  static final BatchService _instance = BatchService._internal();
  factory BatchService() => _instance;
  BatchService._internal();

  static BatchService get to => GetIt.instance<BatchService>();

  late Box<ItemBatchModel> _batchBox;

  Future<void> init() async {
    _batchBox = Hive.box<ItemBatchModel>('medicine_batches');
    await _autoExpiryCheck();
  }

  List<ItemBatchModel> getBatches(String medicineId) {
    return _batchBox.values
        .where((b) => b.medicineId == medicineId && !b.isDeleted)
        .toList()
      ..sort((a, b) {
        if (a.expiryDate == null && b.expiryDate == null) return 0;
        if (a.expiryDate == null) return 1;
        if (b.expiryDate == null) return -1;
        return a.expiryDate!.compareTo(b.expiryDate!);
      });
  }

  List<ItemBatchModel> getActiveBatches(String medicineId) {
    return getBatches(medicineId).where((b) => b.isActive).toList();
  }

  int getTotalQuantity(String medicineId) {
    return getActiveBatches(medicineId)
        .fold(0, (sum, b) => sum + b.availableQuantity);
  }

  int getDamagedQuantity(String medicineId) {
    return getActiveBatches(medicineId)
        .fold(0, (sum, b) => sum + b.damagedQuantity);
  }

  int getExpiredQuantity(String medicineId) {
    return getBatches(medicineId)
        .where((b) => b.isActive && b.isExpired)
        .fold(0, (sum, b) => sum + b.remainingQuantity);
  }

  ItemBatchModel? getNearestExpiry(String medicineId) {
    final active = getActiveBatches(medicineId)
        .where((b) => b.expiryDate != null && b.remainingQuantity > 0)
        .toList();
    if (active.isEmpty) return null;
    active.sort((a, b) => a.expiryDate!.compareTo(b.expiryDate!));
    return active.first;
  }

  Future<ItemBatchModel> addBatch({
    required String medicineId,
    String? batchNumber,
    DateTime? expiryDate,
    int quantity = 0,
    double? purchasePrice,
  }) async {
    final batch = ItemBatchModel(
      id: const Uuid().v4(),
      medicineId: medicineId,
      batchNumber: batchNumber,
      expiryDate: expiryDate,
      quantity: quantity,
      purchasePrice: purchasePrice,
    );
    await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
    return batch;
  }

  Future<void> updateBatch(ItemBatchModel batch) async {
    await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
  }

  Future<void> deleteBatch(String batchId) async {
    await _batchBox.delete(batchId);
  }

  Future<ItemBatchModel?> findById(String id) async {
    return _batchBox.get(id);
  }

  List<ItemBatchAllocation> fefoPick({
    required String medicineId,
    required int quantity,
  }) {
    final batches = getActiveBatches(medicineId)
        .where((b) => b.availableQuantity > 0)
        .toList();
    batches.sort((a, b) {
      if (a.expiryDate == null && b.expiryDate == null) return 0;
      if (a.expiryDate == null) return 1;
      if (b.expiryDate == null) return -1;
      return a.expiryDate!.compareTo(b.expiryDate!);
    });

    final picked = <ItemBatchAllocation>[];
    int remaining = quantity;

    for (final batch in batches) {
      if (remaining <= 0) break;
      final take = remaining < batch.availableQuantity
          ? remaining
          : batch.availableQuantity;
      picked.add(ItemBatchAllocation(batch: batch, quantity: take));
      remaining -= take;
    }

    return picked;
  }

  Future<void> consumeFromBatches({
    required String medicineId,
    required int quantity,
  }) async {
    final allocations = fefoPick(medicineId: medicineId, quantity: quantity);
    for (final alloc in allocations) {
      alloc.batch.quantity -= alloc.quantity;
      await _batchBox.putSynced(alloc.batch.id, alloc.batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
    }
  }

  Future<void> addToBatch({
    required String batchId,
    required int quantity,
  }) async {
    final batch = await findById(batchId);
    if (batch == null) return;
    batch.quantity += quantity;
    await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
  }

  Future<void> markBatchAsDamaged({
    required String batchId,
    required int damagedQty,
  }) async {
    final batch = await findById(batchId);
    if (batch == null) return;
    if (damagedQty > batch.remainingQuantity) {
      throw StateError('الكمية التالفة أكبر من الكمية المتبقية في التشغيلة');
    }
    batch.damagedQuantity += damagedQty;
    await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
  }

  Future<void> markExpiredBatches(String medicineId) async {
    final batches = getBatches(medicineId).where((b) => b.isExpired).toList();
    for (final batch in batches) {
      batch.damagedQuantity = batch.remainingQuantity;
      await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
    }
  }

  Future<ExpiryTrackingResult> runExpiryTracking() async {
    int checked = 0;
    int withExpired = 0;
    int marked = 0;

    final medicineIds = _batchBox.values
        .map((b) => b.medicineId)
        .toSet();

    for (final medId in medicineIds) {
      final expired = getBatches(medId).where((b) => b.isExpired && b.isActive).toList();
      if (expired.isEmpty) continue;
      checked++;
      withExpired++;
      for (final batch in expired) {
        final remaining = batch.remainingQuantity;
        if (remaining > 0) {
          batch.damagedQuantity += remaining;
          await _batchBox.putSynced(batch.id, batch, table: 'batches', branchId: AuthService.currentBranchId ?? '');
          marked++;
        }
      }
    }

    return ExpiryTrackingResult(
      itemsChecked: checked,
      itemsWithExpiredBatches: withExpired,
      batchesMarkedAsDamaged: marked,
    );
  }

  Future<void> _autoExpiryCheck() async {
    final result = await runExpiryTracking();
    if (result.hasChanges) {
      safeDebugPrint('[BatchService] Expiry tracking: ${result.batchesMarkedAsDamaged} batches auto-marked');
    }
  }
}

class ItemBatchAllocation {
  final ItemBatchModel batch;
  final int quantity;

  const ItemBatchAllocation({required this.batch, required this.quantity});
}

class ExpiryTrackingResult {
  final int itemsChecked;
  final int itemsWithExpiredBatches;
  final int batchesMarkedAsDamaged;

  const ExpiryTrackingResult({
    required this.itemsChecked,
    required this.itemsWithExpiredBatches,
    required this.batchesMarkedAsDamaged,
  });

  bool get hasChanges => batchesMarkedAsDamaged > 0;
}
