import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'auth/auth_service.dart';
import '../utils/app_utils.dart';

class StorageService {
  StorageService._();

  static const String _bucketName = 'medicine-images';

  static StorageFileApi get _storage =>
      Supabase.instance.client.storage.from(_bucketName);

  static Future<String?> uploadMedicineImage({
    File? file,
    Uint8List? bytes,
    String? extension,
    String? medicineId,
  }) async {
    try {
      final ext = extension ?? (file != null ? file.path.split('.').last : 'jpg');
      final id = medicineId ?? const Uuid().v4();
      final branchId = AuthService.currentBranchId ?? 'default';
      final path = '$branchId/${id}_${DateTime.now().millisecondsSinceEpoch}.$ext';

      if (kIsWeb && bytes != null) {
        await _storage.uploadBinary(path, bytes);
      } else if (file != null) {
        await _storage.upload(path, file);
      } else if (bytes != null) {
        await _storage.uploadBinary(path, bytes);
      } else {
        return null;
      }

      return _storage.getPublicUrl(path);
    } catch (e) {
      safeDebugPrint('StorageService.uploadMedicineImage error: $e');
      return null;
    }
  }

  static Future<bool> deleteImage(String url) async {
    try {
      final uri = Uri.parse(url);
      final segments = uri.pathSegments;
      final bucketIndex = segments.indexOf(_bucketName);
      if (bucketIndex == -1 || bucketIndex + 1 >= segments.length) return false;
      final path = segments.sublist(bucketIndex + 1).join('/');
      await _storage.remove([path]);
      return true;
    } catch (e) {
      safeDebugPrint('StorageService.deleteImage error: $e');
      return false;
    }
  }

  static Future<void> ensureBucket() async {
    try {
      final buckets = await Supabase.instance.client.storage.listBuckets();
      final exists = buckets.any((b) => b.name == _bucketName);
      if (!exists) {
        await Supabase.instance.client.storage.createBucket(_bucketName);
      }
    } catch (e) {
      safeDebugPrint('StorageService.ensureBucket error: $e');
    }
  }

  static bool isRemoteUrl(String? url) =>
      url != null && (url.startsWith('http://') || url.startsWith('https://'));
}
