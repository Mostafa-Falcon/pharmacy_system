import 'package:hive/hive.dart';
import 'sync_service.dart';
import '../utils/app_utils.dart';

extension BoxSyncExtension on Box {
  Future<void> putSynced(dynamic key, dynamic value, {
    required String table,
    required String branchId,
    SyncOperationType type = SyncOperationType.create,
  }) async {
    await put(key, value);
    try {
      final json = _toJson(value);
      if (json != null) {
        await SyncService.queueOperation(
          type: type,
          table: table,
          data: json,
          branchId: branchId,
        );
      }
    } catch (e) {
      safeDebugPrint('SyncBox: failed to queue $table/$key: $e');
    }
  }

  Map<String, dynamic>? _toJson(dynamic value) {
    if (value is Map<String, dynamic>) return Map<String, dynamic>.from(value);
    final dynamic obj = value;
    try {
      final json = obj.toJson();
      if (json is Map<String, dynamic>) return json;
    } catch (_) {}
    return null;
  }
}
