import 'package:hive/hive.dart';
import 'package:get_it/get_it.dart';
import '../../models/security/branch_model.dart';

/// [BranchService] - الخدمة الأساسية لإدارة وجلب الفروع المتاحة في النظام
/// مُصممة كـ Singleton ومتوافقة مع GetIt لتسهيل عملية حقن الاعتماديات.
class BranchService {
  static final BranchService _instance = BranchService._internal();
  factory BranchService() => _instance;
  BranchService._internal();

  /// الحصول على النسخة المشتركة من الخدمة عبر GetIt
  static BranchService get to => GetIt.instance<BranchService>();

  /// جلب كافة الفروع المخزنة محلياً في صندوق Hive
  Future<List<BranchModel>> getBranches() async {
    final box = Hive.box('branches');
    return box.values.whereType<BranchModel>().toList();
  }
}
