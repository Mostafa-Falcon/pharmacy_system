import 'package:hive/hive.dart';
import '../../models/security/permission_model.dart';
import '../../utils/app_utils.dart';
import '../auth/auth_service.dart';
import '../sync_box_extension.dart';
import '../sync_service.dart';

class PermissionService {
  static const List<String> defaultOwnerPermissions = [
    'dashboard', 'pos', 'inventory', 'medicines', 'categories', 'stock',
    'customers', 'suppliers', 'reports', 'settings',
    'admin_panel', 'employees', 'branches', 'permissions',
    'create_invoice', 'cancel_invoice', 'refund', 'adjust_stock',
    'delete_medicine', 'manage_users', 'manage_branches',
    'view_reports', 'export_data', 'manage_permissions',
  ];

  static const List<String> defaultEmployeePermissions = [
    'dashboard', 'pos', 'customers',
    'create_invoice', 'refund',
  ];

  static Future<void> grantPermission(String userId, String permissionKey) async {
    try {
      final box = Hive.box('permissions');

      PermissionModel? existing;
      try {
        existing = box.values
            .whereType<PermissionModel>()
            .firstWhere((p) => p.userId == userId && p.permissionKey == permissionKey);
      } catch (_) {
        existing = null;
      }

      if (existing != null) {
        existing.isAllowed = true;
        await box.putSynced(existing.id, existing, table: 'permissions', branchId: AuthService.currentBranchId ?? '', type: SyncOperationType.update);
      } else {
        final permission = PermissionModel(
          id: '${userId}_$permissionKey',
          userId: userId,
          permissionKey: permissionKey,
          isAllowed: true,
          createdAt: DateTime.now(),
        );
        await box.putSynced(permission.id, permission, table: 'permissions', branchId: AuthService.currentBranchId ?? '');
      }
    } catch (e, s) {
      safeDebugPrint('PermissionService.grantPermission failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> revokePermission(String userId, String permissionKey) async {
    try {
      final box = Hive.box('permissions');

      PermissionModel? existing;
      try {
        existing = box.values
            .whereType<PermissionModel>()
            .firstWhere((p) => p.userId == userId && p.permissionKey == permissionKey);
      } catch (_) {
        existing = null;
      }

      if (existing != null) {
        existing.isAllowed = false;
        await box.putSynced(existing.id, existing, table: 'permissions', branchId: AuthService.currentBranchId ?? '', type: SyncOperationType.update);
      }
    } catch (e, s) {
      safeDebugPrint('PermissionService.revokePermission failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> setPermissions(String userId, List<String> permissions) async {
    try {
      final box = Hive.box('permissions');
      final now = DateTime.now();

      final existing = box.values.whereType<PermissionModel>().where((p) => p.userId == userId).toList();
      for (final p in existing) {
        await box.delete(p.id);
      }

      final Map<String, dynamic> batchData = {};
      for (final perm in permissions) {
        final permission = PermissionModel(
          id: '${userId}_$perm',
          userId: userId,
          permissionKey: perm,
          isAllowed: true,
          createdAt: now,
        );

        batchData[permission.id] = permission;
      }

      for (final entry in batchData.entries) {
        await box.putSynced(entry.key, entry.value, table: 'permissions', branchId: AuthService.currentBranchId ?? '');
      }
    } catch (e, s) {
      safeDebugPrint('PermissionService.setPermissions failed: $e\n$s');
      rethrow;
    }
  }

  static List<String> getPermissionsForUser(String userId) {
    try {
      final box = Hive.box('permissions');
      return box.values
          .whereType<PermissionModel>()
          .where((p) => p.userId == userId && p.isAllowed)
          .map((p) => p.permissionKey)
          .toList();
    } catch (e, s) {
      safeDebugPrint('PermissionService.getPermissionsForUser failed: $e\n$s');
      return [];
    }
  }

  static bool hasPermission(String permissionKey) {
    try {
      final user = AuthService.currentUser;
      if (user == null) return false;
      if (user.isOwner) return true;

      final permissions = getPermissionsForUser(user.id);
      return permissions.contains(permissionKey);
    } catch (e, s) {
      safeDebugPrint('PermissionService.hasPermission failed: $e\n$s');
      return false;
    }
  }

  static bool hasPageAccess(String page) {
    return hasPermission(page);
  }

  static bool hasActionPermission(String action) {
    return hasPermission(action);
  }
}
