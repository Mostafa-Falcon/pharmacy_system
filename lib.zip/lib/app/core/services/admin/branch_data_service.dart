import 'package:hive/hive.dart';
import '../../models/inventory/medicine_model.dart';
import '../../models/sales/sale_model.dart';
import '../../models/sales/purchase_model.dart';
import '../../models/inventory/inventory_model.dart';
import '../../models/sales/return_model.dart';
import '../../models/customer/customer_model.dart';
import '../auth/auth_service.dart';
import '../sync_service.dart';
import '../customer/customer_ledger_service.dart';
import '../inventory/stock_mutation_service.dart';
import '../inventory/batch_service.dart';
import '../../repositories/medicines_repository.dart';
import '../../repositories/sales_repository.dart';
import '../../repositories/sales_return_repository.dart';
import '../../repositories/customers_repository.dart';
import '../../repositories/purchases_repository.dart';
import '../../utils/app_utils.dart';
import '../../../modules/archive/services/archive_service.dart';
import '../../injection.dart';

/// الخدمة الرئيسية للوصول للداتا حسب الفرع
/// مُحسنة لاستخدام الـ Repositories الموحدة عبر حاوي GetIt
class BranchDataService {
  // ─── Repositories Getters from GetIt ────────────────────────────────
  static MedicinesRepository get _medicinesRepo => sl<MedicinesRepository>();
  static CustomersRepository get _customersRepo => sl<CustomersRepository>();
  static SalesRepository get _salesRepo => sl<SalesRepository>();
  static PurchasesRepository get _purchasesRepo => sl<PurchasesRepository>();
  static SalesReturnRepository get _salesReturnRepo => sl<SalesReturnRepository>();

  // ─── Current Branch ───────────────────────────────────────────────

  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  // ─── Medicines - مُحسنة لاستخدام الـ Repository ──────────────────────────

  static List<MedicineModel> getMedicines({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    return _medicinesRepo.getMedicines(branchId: bid);
  }

  static MedicineModel? getMedicine(String id) {
    return _medicinesRepo.getById(id);
  }

  static Future<void> addMedicine(MedicineModel medicine) async {
    await _medicinesRepo.create(medicine, branchId: medicine.branchId);
  }

  static Future<void> batchAddMedicines(List<MedicineModel> medicines, {bool skipSync = false}) async {
    if (medicines.isEmpty) return;
    await _medicinesRepo.batchCreate(medicines, branchId: medicines.first.branchId, skipSync: skipSync);
  }

  static Future<void> updateMedicine(MedicineModel medicine) async {
    await _medicinesRepo.update(medicine, branchId: medicine.branchId);
  }

  static Future<void> batchUpdateMedicines(List<MedicineModel> medicines, {bool skipSync = false}) async {
    if (medicines.isEmpty) return;
    await _medicinesRepo.batchUpdate(medicines, branchId: medicines.first.branchId, skipSync: skipSync);
  }

  static Future<void> deleteMedicine(MedicineModel medicine) async {
    await _medicinesRepo.delete(medicine, branchId: medicine.branchId);
  }

  // ─── Sales - مُحسنة لاستخدام الـ Repository ─────────────────────────────

  static List<SaleModel> getSales({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    return _salesRepo.getSales(branchId: bid);
  }

  static SaleModel? getSale(String id) {
    return _salesRepo.getById(id);
  }

  static Future<void> addSale(SaleModel sale) async {
    await _salesRepo.create(sale, branchId: sale.branchId);
  }

  static Future<void> updateSale(SaleModel sale) async {
    await _salesRepo.update(sale, branchId: sale.branchId);
  }

  /// إلغاء فاتورة بيع - يرجع المخزون ويسجل الإلغاء في الكشف الحسابي
  static Future<void> voidSale(String saleId, {String? branchId}) async {
    final bid = branchId ?? _currentBranchId;
    final sale = getSale(saleId);
    if (sale == null) throw StateError('الفاتورة غير موجودة');

    // إرجاع المخزون
    for (final item in sale.items) {
      await StockMutationService.adjustStock(
        medicineId: item.medicineId,
        delta: item.quantity,
        branchId: bid,
      );

      // إرجاع الكمية للتشغيلات (Batches) عند الإلغاء
      try {
        await BatchService.to.addBatch(
          medicineId: item.medicineId,
          batchNumber: 'VOID-${saleId.substring(0, 8)}',
          quantity: item.quantity,
          purchasePrice: item.costPrice,
        );
      } catch (e) {
        safeDebugPrint('BranchDataService.voidSale: addBatch failed for ${item.medicineId}: $e');
      }
    }

    // تسجيل الإلغاء في الكشف الحسابي — نعكس المديونية المستحقة فعلياً
    // (credit = كامل المبلغ، mixed = المبلغ ناقص المدفوع، نقدي/بطاقة = صفر)
    // بدل عكس كامل المبلغ، عشان متعكسش مديونية أكتر من الحقيقي.
    final dueAmount = sale.dueAmount;
    if (sale.customerId != null && dueAmount > 0.0001) {
      await CustomerLedgerService.recordSaleVoid(
        customerId: sale.customerId!,
        branchId: bid,
        saleId: saleId,
        invoiceNumber: saleId,
        dueAmount: double.parse(dueAmount.toStringAsFixed(2)),
        createdBy: sale.createdBy,
      );
    }

    await ArchiveService.record(
      entityType: 'sale',
      entityId: sale.id,
      entityName: 'فاتورة #${sale.id.substring(0, 8)}',
      entityData: sale.toJson(),
      branchId: bid,
    );

    // تعليم الفاتورة كمحذوفة
    final updated = sale.copyWith(
      isDeleted: true,
      lastModified: DateTime.now(),
    );
    await _salesRepo.update(updated, branchId: bid);
  }

  // ─── Purchases - مُحسنة لاستخدام الـ Repository ───────────────────────────

  static List<PurchaseModel> getPurchases({String? branchId}) {
    return _purchasesRepo.getPurchases(
      branchId: branchId ?? _currentBranchId,
    );
  }

  static PurchaseModel? getPurchase(String id) {
    return _purchasesRepo.getById(id);
  }

  static Future<void> addPurchase(PurchaseModel purchase) async {
    await _purchasesRepo.create(purchase, branchId: purchase.branchId);
  }

  static Future<void> updatePurchase(PurchaseModel purchase) async {
    await _purchasesRepo.update(purchase, branchId: purchase.branchId);
  }

  static Future<void> voidPurchase(
    String purchaseId, {
    String? branchId,
  }) async {
    await _purchasesRepo.voidPurchase(
      purchaseId,
      branchId: branchId ?? _currentBranchId,
    );
  }

  // ─── Inventory ────────────────────────────────────────────────────

  static List<InventoryItemModel> getInventory({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    return SyncService.getLocalData<InventoryItemModel>(
      boxName: 'inventory',
      branchId: bid,
    );
  }

  static InventoryItemModel? getInventoryItem(String id) {
    final box = Hive.box('inventory');
    final item = box.get(id);
    if (item is InventoryItemModel) return item;
    return null;
  }

  static Future<void> addInventory(InventoryItemModel item) async {
    item.lastModified = DateTime.now();
    await SyncService.create(
      boxName: 'inventory',
      entity: item,
      branchId: item.branchId,
      toJson: item.toJson(),
    );
  }

  static Future<void> updateInventory(InventoryItemModel item) async {
    item.lastModified = DateTime.now();
    await SyncService.update(
      boxName: 'inventory',
      entity: item,
      branchId: item.branchId,
      toJson: item.toJson(),
    );
  }

  // ─── Returns - مُحسنة لاستخدام الـ Repository ───────────────────────────

  static List<ReturnModel> getReturns({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    return _salesReturnRepo.getSalesReturns(branchId: bid);
  }

  static Future<void> addReturn(ReturnModel returnModel) async {
    await _salesReturnRepo.create(
      returnModel,
      branchId: returnModel.branchId,
    );
  }

  // ─── Customers - مُحسنة لاستخدام الـ Repository ─────────────────────────

  static List<CustomerModel> getCustomers({String? branchId}) {
    // العملاء عامة ولا يوجد branchId مطلوب
    return _customersRepo.getCustomers();
  }

  static CustomerModel? getCustomer(String id) {
    return _customersRepo.getById(id);
  }

  // ─── Branches ─────────────────────────────────────────────────────

  static List<dynamic> getAllBranches() {
    return SyncService.getAllLocalData<dynamic>(boxName: 'branches');
  }

  // ─── Stats (for dashboard) ────────────────────────────────────────

  static Map<String, dynamic> getDashboardStats({String? branchId}) {
    final medicines = getMedicines(branchId: branchId);
    final sales = getSales(branchId: branchId);
    final purchases = getPurchases(branchId: branchId);

    final now = DateTime.now();
    final totalMedicines = medicines.length;
    final lowStockCount = medicines
        .where((m) => m.quantity <= m.minStock)
        .length;

    final totalSalesToday = sales
        .where(
          (s) =>
              s.createdAt.day == now.day &&
              s.createdAt.month == now.month &&
              s.createdAt.year == now.year,
        )
        .fold(0.0, (sum, s) => sum + s.finalAmount);

    final totalPurchasesThisMonth = purchases
        .where(
          (p) => p.createdAt.month == now.month && p.createdAt.year == now.year,
        )
        .fold(0.0, (sum, p) => sum + p.finalAmount);

    return {
      'total_medicines': totalMedicines,
      'low_stock_count': lowStockCount,
      'total_sales_today': totalSalesToday,
      'total_purchases_month': totalPurchasesThisMonth,
    };
  }
}
