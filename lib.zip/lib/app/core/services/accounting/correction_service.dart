import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../models/base/correction_model.dart';
import '../auth/auth_service.dart';
import '../sync_box_extension.dart';

class CorrectionService {
  static final _uuid = const Uuid();
  static Box get _box => Hive.box('corrections');

  static Future<void> record({
    required CorrectionReferenceType referenceType,
    required String referenceId,
    required CorrectionAction action,
    String? details,
  }) async {
    final entry = CorrectionEntry(
      id: _uuid.v4(),
      referenceType: referenceType,
      referenceId: referenceId,
      action: action,
      userId: AuthService.currentUser?.id ?? 'unknown',
      userDisplayName: AuthService.currentUser?.name ?? 'غير معروف',
      timestamp: DateTime.now(),
      details: details,
    );
    await _box.putSynced(entry.id, entry.toJson(), table: 'corrections', branchId: AuthService.currentBranchId ?? '');
  }

  static List<CorrectionEntry> getChain({
    required CorrectionReferenceType referenceType,
    required String referenceId,
  }) {
    final all = _box.values.whereType<Map<dynamic, dynamic>>().map((m) {
      return CorrectionEntry.fromJson(Map<String, dynamic>.from(m));
    }).toList();

    return all
        .where((e) => e.referenceType == referenceType && e.referenceId == referenceId)
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  static List<CorrectionEntry> getByReferenceId(String referenceId) {
    final all = _box.values.whereType<Map<dynamic, dynamic>>().map((m) {
      return CorrectionEntry.fromJson(Map<String, dynamic>.from(m));
    }).toList();

    return all
        .where((e) => e.referenceId == referenceId)
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  static List<CorrectionEntry> getAll({int? limit}) {
    final all = _box.values.whereType<Map<dynamic, dynamic>>().map((m) {
      return CorrectionEntry.fromJson(Map<String, dynamic>.from(m));
    }).toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

    return limit != null ? all.take(limit).toList() : all;
  }
}
