import 'package:hive/hive.dart';
import '../models/base/lookup_model.dart';
import '../utils/app_utils.dart';
import 'auth/auth_service.dart';

class LookupService {
  static Box get _box => Hive.box('lookups');

  static String get _branchId => AuthService.currentBranchId ?? '';

  static Iterable<LookupModel> _allFromBox() {
    try {
      return _box.values.whereType<LookupModel>();
    } catch (e, s) {
      safeDebugPrint('LookupService._allFromBox failed: $e\n$s');
      return [];
    }
  }

  static List<LookupModel> getAll({LookupType? type}) {
    try {
      final list = _allFromBox().where((l) => !l.isDeleted && l.branchId == _branchId);
      if (type == null) return list.toList();
      return list.where((l) => l.type == type.name).toList();
    } catch (e, s) {
      safeDebugPrint('LookupService.getAll failed: $e\n$s');
      return [];
    }
  }

  static List<LookupModel> getItemTypes() => getAll(type: LookupType.itemType);

  static List<LookupModel> getGroups() => getAll(type: LookupType.group);

  static LookupModel? getById(String id) {
    try {
      final item = _box.get(id);
      if (item is LookupModel && !item.isDeleted) {
        return item;
      }
      return null;
    } catch (e, s) {
      safeDebugPrint('LookupService.getById failed: $e\n$s');
      return null;
    }
  }

  static String? getNameById(String? id) {
    if (id == null || id.isEmpty) return null;
    return getById(id)?.name;
  }

  static Future<void> add(LookupModel lookup) async {
    try {
      lookup.lastModified = DateTime.now();
      await _box.put(lookup.id, lookup);
    } catch (e, s) {
      safeDebugPrint('LookupService.add failed: $e\n$s');
      rethrow;
    }
  }

  static Future<LookupModel> addByName({
    required String name,
    required LookupType type,
  }) async {
    try {
      final lookup = LookupModel.create(
        name: name,
        lookupType: type,
        branchId: _branchId,
      );
      lookup.lastModified = DateTime.now();
      await _box.put(lookup.id, lookup);
      return lookup;
    } catch (e, s) {
      safeDebugPrint('LookupService.addByName failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> update(LookupModel lookup) async {
    try {
      lookup.lastModified = DateTime.now();
      await _box.put(lookup.id, lookup);
    } catch (e, s) {
      safeDebugPrint('LookupService.update failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> remove(String id) async {
    try {
      final existing = getById(id);
      if (existing == null) return;

      final updated = existing.copyWith(isDeleted: true);
      updated.lastModified = DateTime.now();
      await _box.put(id, updated);
    } catch (e, s) {
      safeDebugPrint('LookupService.remove failed: $e\n$s');
      rethrow;
    }
  }

  static List<LookupModel> search(String query, {required LookupType type}) {
    try {
      final q = query.trim().toLowerCase();
      if (q.isEmpty) return getAll(type: type);
      return getAll(type: type).where((l) => l.name.toLowerCase().contains(q)).toList();
    } catch (e, s) {
      safeDebugPrint('LookupService.search failed: $e\n$s');
      return [];
    }
  }

  static bool nameExists(String name, {required LookupType type}) {
    try {
      return getAll(type: type).any(
            (l) => l.name.trim().toLowerCase() == name.trim().toLowerCase(),
      );
    } catch (e, s) {
      safeDebugPrint('LookupService.nameExists failed: $e\n$s');
      return false;
    }
  }
}
