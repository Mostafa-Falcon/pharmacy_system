import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'sync_pull_service.dart';
import 'sync_push_service.dart';
import 'sync_dead_letter_service.dart';
import 'sync_compaction_service.dart';
import '../../utils/app_utils.dart';

/// المحرك الأساسي لإدارة عملية المزامنة الحية المنسقة (Sync Engine Coordinator)
class SyncEngine {
  static final SyncEngine instance = SyncEngine._internal();
  SyncEngine._internal();

  late final SyncPullService pullService;
  late final SyncPushService pushService;
  late final SyncDeadLetterService deadLetterService;
  late final SyncCompactionService compactionService;

  final StreamController<bool> _connectivityController = StreamController<bool>.broadcast();
  bool _isOnline = true;
  bool _isSyncing = false;

  bool get isOnline => _isOnline;
  bool get isSyncing => _isSyncing;
  Stream<bool> get connectivityStream => _connectivityController.stream;

  void initialize() {
    final supabase = Supabase.instance.client;
    pullService = SyncPullService(supabase);
    pushService = SyncPushService(supabase);
    deadLetterService = SyncDeadLetterService();
    compactionService = SyncCompactionService();

    _initConnectivityListener();
  }

  void _initConnectivityListener() {
    Connectivity().onConnectivityChanged.listen((result) {
      final isConnected = result != ConnectivityResult.none;
      _isOnline = isConnected;
      _connectivityController.add(isConnected);
      if (isConnected) {
        syncAll();
      }
    });
  }

  Future<void> syncAll() async {
    if (_isSyncing || !_isOnline) return;
    _isSyncing = true;
    try {
      safeDebugPrint('SyncEngine: Starting full synchronization cycle...');
      await pushService.processPushQueue(
        syncBoxName: 'sync_queue',
        onFailedItem: (item) => deadLetterService.handleFailedItem(item),
      );
      safeDebugPrint('SyncEngine: Full synchronization completed successfully.');
    } catch (e, s) {
      safeDebugPrint('SyncEngine: Synchronization cycle failed: $e\n$s');
    } finally {
      _isSyncing = false;
    }
  }
}
