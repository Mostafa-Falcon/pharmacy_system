import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hive/hive.dart';
import '../../models/base/sync_queue_item.dart';
import '../../utils/app_utils.dart';

/// خدمة مسئوليتها رفع التغييرات المحلية المنتظرة إلى السيرفر (Push Engine)
class SyncPushService {
  final SupabaseClient _supabase;

  SyncPushService(this._supabase);

  /// رفع طابور التغييرات المنتظرة بالترتيب الزمني
  Future<int> processPushQueue({
    required String syncBoxName,
    required Future<bool> Function(SyncQueueItem item) onFailedItem,
  }) async {
    if (!Hive.isBoxOpen(syncBoxName)) {
      await Hive.openBox<SyncQueueItem>(syncBoxName);
    }
    final box = Hive.box<SyncQueueItem>(syncBoxName);
    final items = box.values.toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    if (items.isEmpty) return 0;

    int successCount = 0;
    for (final item in items) {
      try {
        final success = await _pushSingleItem(item);
        if (success) {
          await box.delete(item.id);
          successCount++;
        } else {
          final shouldKeep = await onFailedItem(item);
          if (!shouldKeep) {
            await box.delete(item.id);
          }
        }
      } catch (e, s) {
        safeDebugPrint('SyncPushService: Error pushing item ${item.id}: $e\n$s');
        final shouldKeep = await onFailedItem(item);
        if (!shouldKeep) {
          await box.delete(item.id);
        }
      }
    }
    return successCount;
  }

  Future<bool> _pushSingleItem(SyncQueueItem item) async {
    final payload = Map<String, dynamic>.from(item.data);
    final tableName = item.table;
    final op = item.operation;

    switch (op) {
      case 'create':
      case 'update':
        await _supabase.from(tableName).upsert(payload);
        return true;
      case 'delete':
        final idVal = payload['id'] ?? item.id;
        await _supabase.from(tableName).delete().eq('id', idVal);
        return true;
      default:
        safeDebugPrint('SyncPushService: Unknown operation type "$op"');
        return false;
    }
  }
}
