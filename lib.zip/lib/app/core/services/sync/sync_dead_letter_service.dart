import 'package:hive/hive.dart';
import '../../models/base/sync_queue_item.dart';
import '../../utils/app_utils.dart';

/// خدمة مسئوليتها احتواء ركن العمليات الفاشلة (Dead Letter Queue) ومنع الضياع
class SyncDeadLetterService {
  static const String deadLetterBoxName = 'dead_letter_queue';
  static const int maxRetryCount = 5;

  Future<void> init() async {
    if (!Hive.isBoxOpen(deadLetterBoxName)) {
      await Hive.openBox<SyncQueueItem>(deadLetterBoxName);
    }
  }

  /// ركن عنصر فاشل في الـ Dead Letter Queue
  Future<bool> handleFailedItem(SyncQueueItem item) async {
    await init();
    final box = Hive.box<SyncQueueItem>(deadLetterBoxName);

    final updatedRetryCount = item.retryCount + 1;
    if (updatedRetryCount > maxRetryCount) {
      safeDebugPrint('SyncDeadLetterService: Exceeded max retries for item ${item.id}. Moving to permanent dead letter.');
      await box.put(item.id, item.copyWith(retryCount: updatedRetryCount, lastError: 'failed_permanently'));
      return false; // لا تتركه في الطابور الأصلي
    }

    safeDebugPrint('SyncDeadLetterService: Queuing item ${item.id} for retry ($updatedRetryCount/$maxRetryCount)');
    await box.put(item.id, item.copyWith(retryCount: updatedRetryCount));
    return false;
  }

  /// الحصول على كافة العناصر المعلقة في الـ Dead Letter Queue
  List<SyncQueueItem> getDeadLetterItems() {
    if (!Hive.isBoxOpen(deadLetterBoxName)) return [];
    return Hive.box<SyncQueueItem>(deadLetterBoxName).values.toList();
  }
}
