import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:hive/hive.dart';
import '../../utils/app_utils.dart';

/// خدمة مسئوليتها الوحيدة سحب التغييرات الحديثة من السيرفر (Delta Pull Engine)
class SyncPullService {
  final SupabaseClient _supabase;

  SyncPullService(this._supabase);

  /// سحب جدول معين وتحديد أحدث البيانات اعتماداً على watermark
  Future<int> pullTable<T>({
    required String tableName,
    required String boxName,
    required T Function(Map<String, dynamic> json) fromJson,
    required String Function(T item) getId,
    DateTime? lastSyncedAt,
  }) async {
    try {
      var query = _supabase.from(tableName).select();
      if (lastSyncedAt != null) {
        query = query.gt('updated_at', lastSyncedAt.toIso8601String());
      }

      final List<dynamic> response = await query;
      if (response.isEmpty) return 0;

      final box = Hive.isBoxOpen(boxName) ? Hive.box(boxName) : await Hive.openBox(boxName);

      int updatedCount = 0;
      for (final rawItem in response) {
        final Map<String, dynamic> json = Map<String, dynamic>.from(rawItem as Map);
        final item = fromJson(json);
        final id = getId(item);
        await box.put(id, item);
        updatedCount++;
      }

      safeDebugPrint('SyncPullService: Succeeded pulling $updatedCount records for table $tableName');
      return updatedCount;
    } catch (e, s) {
      safeDebugPrint('SyncPullService: Error pulling table $tableName: $e\n$s');
      rethrow;
    }
  }
}
