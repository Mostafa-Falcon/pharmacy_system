import 'package:hive/hive.dart';
import '../../utils/app_utils.dart';

/// خدمة مسئوليتها تنظيف وضغط قاعدة البيانات المحلية (Compaction Service)
class SyncCompactionService {
  /// ضغط صندوق محدد لتفريغ المساحات غير المستغلة
  Future<void> compactBox(String boxName) async {
    try {
      if (Hive.isBoxOpen(boxName)) {
        final box = Hive.box(boxName);
        await box.compact();
        safeDebugPrint('SyncCompactionService: Successfully compacted box "$boxName"');
      }
    } catch (e) {
      safeDebugPrint('SyncCompactionService: Error compacting box "$boxName": $e');
    }
  }

  /// ضغط كافة الصناديق النشطة دورياً
  Future<void> compactAllBoxes(List<String> boxNames) async {
    for (final boxName in boxNames) {
      await compactBox(boxName);
    }
  }
}
