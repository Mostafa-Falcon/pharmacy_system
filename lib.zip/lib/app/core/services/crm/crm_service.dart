
import '../../models/crm/crm_model.dart';
import '../sync_service.dart';

class CrmService {
  static const String leadsBox = 'crm_leads';
  static const String followUpsBox = 'crm_followups';

  /// الحصول على العملاء المحتملين حسب الفرع
  static List<CrmLeadModel> getLeads(String branchId) {
    return SyncService.getLocalData<CrmLeadModel>(
      boxName: leadsBox,
      branchId: branchId,
    ).where((e) => !e.isDeleted).toList();
  }

  /// إضافة عميل محتمل
  static Future<void> addLead(CrmLeadModel lead) async {
    lead.lastModified = DateTime.now();
    await SyncService.create(
      boxName: leadsBox,
      entity: lead,
      branchId: lead.branchId,
      toJson: lead.toJson(),
    );
  }

  /// تحديث حالة العميل المحتمل
  static Future<void> updateLead(CrmLeadModel lead) async {
    lead.lastModified = DateTime.now();
    await SyncService.update(
      boxName: leadsBox,
      entity: lead,
      branchId: lead.branchId,
      toJson: lead.toJson(),
    );
  }

  /// حساب الإحصائيات
  static Map<String, int> getStats(String branchId) {
    final leads = SyncService.getLocalData<CrmLeadModel>(
      boxName: leadsBox,
      branchId: branchId,
    ).where((e) => !e.isDeleted).toList();

    return {
      'total': leads.length,
      'new': leads.where((l) => l.status == CrmLeadStatus.newLead).length,
      'contacted': leads
          .where((l) => l.status == CrmLeadStatus.contacted)
          .length,
      'interested': leads
          .where((l) => l.status == CrmLeadStatus.interested)
          .length,
      'converted': leads
          .where((l) => l.status == CrmLeadStatus.converted)
          .length,
    };
  }
}
