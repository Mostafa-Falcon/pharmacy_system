import 'package:hive/hive.dart';

class ReceiptNumberService {
  static Box<dynamic> get _box => Hive.box('receipt_counters');

  static String nextForBranch(String branchId) {
    final key = 'sales:$branchId';
    final current = (_box.get(key) as int?) ?? 0;
    final next = current + 1;
    _box.put(key, next);
    return '#${next.toString().padLeft(6, '0')}';
  }
}
