import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../models/supplier/supplier_model.dart';
import '../../services/sync_service.dart';
import '../../services/auth/auth_service.dart';
import '../../utils/app_utils.dart';
import '../../../modules/archive/services/archive_service.dart';

class SupplierService {
  static Box get _box => Hive.box('suppliers');
  static const _uuid = Uuid();

  static Future<void> init() async {
    await Hive.openBox('settings');
    await Hive.openBox('suppliers');
  }

  static List<SupplierModel> getAll({bool activeOnly = true}) {
    final items = _box.values.whereType<SupplierModel>().toList();
    if (activeOnly) {
      return items.where((s) => s.isActive).toList();
    }
    return items;
  }

  static List<SupplierModel> getByType(SupplierType type, {bool activeOnly = true}) {
    return getAll(activeOnly: activeOnly).where((s) => s.type == type).toList();
  }

  static SupplierModel? getById(String? id) {
    if (id == null) return null;
    final item = _box.get(id);
    if (item is SupplierModel) return item;
    return null;
  }

  static String? getNameById(String? id) {
    return getById(id)?.name;
  }

  static Future<SupplierModel> add({
    required String name,
    required SupplierType type,
    SupplierPartyType partyType = SupplierPartyType.company,
    String? phone,
    String? address,
    String? companyName,
    String? email,
    String? taxId,
    double creditLimit = 0,
    double discountPercent = 0,
    int paymentTermDays = 0,
    String? notes,
  }) async {
    try {
      final supplier = SupplierModel(
        id: _uuid.v4(),
        name: name,
        type: type,
        partyType: partyType,
        phone: phone,
        address: address,
        companyName: companyName,
        email: email,
        taxId: taxId,
        creditLimit: creditLimit,
        discountPercent: discountPercent,
        paymentTermDays: paymentTermDays,
        notes: notes,
      );
      supplier.lastModified = DateTime.now();
      await SyncService.create(
        boxName: 'suppliers',
        entity: supplier,
        branchId: AuthService.currentBranchId ?? '',
        toJson: supplier.toJson(),
      );
      return supplier;
    } catch (e, s) {
      safeDebugPrint('SupplierService.add failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> update(SupplierModel supplier) async {
    try {
      supplier.lastModified = DateTime.now();
      await SyncService.update(
        boxName: 'suppliers',
        entity: supplier,
        branchId: AuthService.currentBranchId ?? '',
        toJson: supplier.toJson(),
      );
    } catch (e, s) {
      safeDebugPrint('SupplierService.update failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> deactivate(String id) async {
    try {
      final supplier = getById(id);
      if (supplier != null) {
        await update(supplier.copyWith(isActive: false));
      }
    } catch (e, s) {
      safeDebugPrint('SupplierService.deactivate failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> activate(String id) async {
    try {
      final supplier = getById(id);
      if (supplier != null) {
        await update(supplier.copyWith(isActive: true));
      }
    } catch (e, s) {
      safeDebugPrint('SupplierService.activate failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> delete(String id) async {
    try {
      final supplier = getById(id);
      if (supplier != null) {
        await ArchiveService.record(
          entityType: 'supplier',
          entityId: supplier.id,
          entityName: supplier.name,
          entityData: supplier.toJson(),
          branchId: AuthService.currentBranchId ?? '',
        );

        await SyncService.softDelete(
          boxName: 'suppliers',
          key: id,
          branchId: AuthService.currentBranchId ?? '',
          currentData: supplier.toJson(),
        );
      }
    } catch (e, s) {
      safeDebugPrint('SupplierService.delete failed: $e\n$s');
      rethrow;
    }
  }

  static bool nameExists(String name, {String? excludeId}) {
    return _box.values.whereType<SupplierModel>().any((s) =>
    s.name.toLowerCase() == name.toLowerCase().trim() &&
        s.id != excludeId
    );
  }
}
