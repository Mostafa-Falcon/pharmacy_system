import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../models/sales/cashier_shift_model.dart';
import '../../models/sales/sale_model.dart';
import '../../models/sales/return_model.dart';
import '../auth/auth_service.dart';
import '../../utils/app_utils.dart';
import '../sync_box_extension.dart';

class CashierShiftService {
  static Box<dynamic> get _box => Hive.box('cashier_shifts');
  static Box<dynamic> get _salesBox => Hive.box('sales');
  static const _uuid = Uuid();

  static List<CashierShiftModel> getAll({String? branchId}) {
    final bid = branchId ?? AuthService.currentBranchId ?? '';
    return _box.values
        .whereType<CashierShiftModel>()
        .where((s) => s.branchId == bid && !s.isDeleted)
        .toList()
      ..sort((a, b) => b.openedAt.compareTo(a.openedAt));
  }

  static CashierShiftModel? findOpenShift({
    String? cashierId,
    String? deviceId,
    String? branchId,
  }) {
    final bid = branchId ?? AuthService.currentBranchId ?? '';
    final cid = cashierId ?? AuthService.currentUser?.id ?? '';
    try {
      return _box.values.whereType<CashierShiftModel>().firstWhere(
        (s) =>
            s.branchId == bid &&
            s.cashierId == cid &&
            s.deviceId == (deviceId ?? '') &&
            s.status == CashierShiftStatus.open &&
            !s.isDeleted,
      );
    } catch (_) {
      return null;
    }
  }

  static int _nextShiftNumber(String branchId) {
    final existing = getAll(branchId: branchId);
    if (existing.isEmpty) return 1;
    return existing.map((s) => s.shiftNumber).reduce((a, b) => a > b ? a : b) +
        1;
  }

  static Future<CashierShiftModel> openShift({
    double openingCash = 0,
    String? branchId,
  }) async {
    final bid = branchId ?? AuthService.currentBranchId ?? '';
    final cashier = AuthService.currentUser;
    if (cashier == null) throw StateError('لم يتم تسجيل الدخول');

    final existing = findOpenShift(cashierId: cashier.id, branchId: bid);
    if (existing != null) {
      throw StateError('وردية مفتوحة موجودة');
    }

    final shift = CashierShiftModel(
      id: _uuid.v4(),
      branchId: bid,
      shiftNumber: _nextShiftNumber(bid),
      cashierId: cashier.id,
      cashierName: cashier.name,
      deviceId: AuthService.currentDeviceId ?? '',
      openedAt: DateTime.now(),
      openingCash: openingCash,
    );
    await _box.putSynced(shift.id, shift, table: 'cashier_shifts', branchId: bid);
    return shift;
  }

  static Future<CashierShiftModel> closeShift({
    required String shiftId,
    required double countedCash,
    String? notes,
  }) async {
    final shift = _box.get(shiftId);
    if (shift == null) throw StateError('الوردية غير موجودة');
    if (shift.status == CashierShiftStatus.closed) {
      throw StateError('الوردية مغلقة بالفعل');
    }

    final expectedCash = _calculateExpectedCash(shift);
    final difference = countedCash - expectedCash;

    final updated = shift.copyWith(
      status: CashierShiftStatus.closed,
      closedAt: DateTime.now(),
      expectedCash: expectedCash,
      countedCash: countedCash,
      difference: double.parse(difference.toStringAsFixed(2)),
      notes: notes,
    );
    await _box.putSynced(shift.id, updated, table: 'cashier_shifts', branchId: shift.branchId);
    return updated;
  }

  static double _calculateExpectedCash(CashierShiftModel shift) {
    final bid = shift.branchId;
    double cashSales = 0;
    try {
      cashSales = _salesBox.values
          .whereType<SaleModel>()
          .where(
            (s) =>
                s.branchId == bid &&
                !s.isDeleted &&
                s.createdAt.isAfter(shift.openedAt) &&
                (shift.closedAt == null ||
                    s.createdAt.isBefore(shift.closedAt!)) &&
                (s.paymentMethod == 'cash' || s.paymentMethod == 'mixed'),
          )
          .fold(0.0, (sum, s) => sum + s.finalAmount);
    } catch (e, s) {
      safeDebugPrint('CashierShiftService._calculateExpectedCash failed: $e\n$s');
    }
    return double.parse((shift.openingCash + cashSales).toStringAsFixed(2));
  }

  static Map<String, dynamic> getShiftSummary(String shiftId) {
    final shift = _box.get(shiftId);
    if (shift == null) return {};
    final sales = _salesBox.values
        .whereType<SaleModel>()
        .where(
          (s) =>
              s.branchId == shift.branchId &&
              !s.isDeleted &&
              s.createdAt.isAfter(shift.openedAt) &&
              (shift.closedAt == null || s.createdAt.isBefore(shift.closedAt!)),
        )
        .toList();

    return {
      'shift': shift,
      'sales_count': sales.length,
      'cash_sales': sales
          .where((s) => s.paymentMethod == 'cash' || s.paymentMethod == 'mixed')
          .fold(0.0, (sum, s) => sum + s.finalAmount),
      'card_sales': sales
          .where((s) => s.paymentMethod == 'card')
          .fold(0.0, (sum, s) => sum + s.finalAmount),
      'credit_sales': sales
          .where((s) => s.paymentMethod == 'credit')
          .fold(0.0, (sum, s) => sum + s.finalAmount),
      'total_sales': sales.fold(0.0, (sum, s) => sum + s.finalAmount),
    };
  }

  static List<SaleModel> getShiftInvoices(String shiftId) {
    final shift = _box.get(shiftId) as CashierShiftModel?;
    if (shift == null) return [];
    return _salesBox.values
        .whereType<SaleModel>()
        .where(
          (s) =>
              s.branchId == shift.branchId &&
              !s.isDeleted &&
              s.createdAt.isAfter(shift.openedAt) &&
              (shift.closedAt == null || s.createdAt.isBefore(shift.closedAt!)),
        )
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static List<dynamic> getShiftTransactions(String shiftId) {
    final shift = _box.get(shiftId) as CashierShiftModel?;
    if (shift == null) return [];

    final sales = _salesBox.values
        .whereType<SaleModel>()
        .where(
          (s) =>
              s.branchId == shift.branchId &&
              !s.isDeleted &&
              s.createdAt.isAfter(shift.openedAt) &&
              (shift.closedAt == null || s.createdAt.isBefore(shift.closedAt!)),
        )
        .toList();

    final returns = Hive.box('returns')
        .values
        .whereType<ReturnModel>()
        .where(
          (r) =>
              r.branchId == shift.branchId &&
              !r.isDeleted &&
              r.saleId != null &&
              r.createdAt.isAfter(shift.openedAt) &&
              (shift.closedAt == null || r.createdAt.isBefore(shift.closedAt!)),
        )
        .toList();

    final all = <dynamic>[...sales, ...returns];
    all.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return all;
  }
}
