import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../models/sales/quote_model.dart';
import '../auth/auth_service.dart';
import '../sync_box_extension.dart';

class QuoteService {
  static Box<dynamic> get _box => Hive.box('quotes');
  static const _uuid = Uuid();

  static List<QuoteModel> getAll({String? branchId}) {
    final bid = branchId ?? AuthService.currentBranchId ?? '';
    return _box.values
        .whereType<QuoteModel>()
        .where((q) => q.branchId == bid && !q.isDeleted)
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static QuoteModel? getById(String id) {
    final q = _box.get(id);
    return (q != null && !q.isDeleted) ? q : null;
  }

  static int _nextNumber(String branchId) {
    final existing = getAll(branchId: branchId);
    if (existing.isEmpty) return 1;
    return existing.map((q) => q.number).reduce((a, b) => a > b ? a : b) + 1;
  }

  static Future<QuoteModel> create({
    required String customerName,
    String? notes,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    double discount = 0,
    required double total,
    String? branchId,
  }) async {
    final bid = branchId ?? AuthService.currentBranchId ?? '';
    final quote = QuoteModel(
      id: _uuid.v4(),
      branchId: bid,
      number: _nextNumber(bid),
      customerName: customerName,
      notes: notes,
      items: items,
      subtotal: subtotal,
      discount: discount,
      total: total,
      createdAt: DateTime.now(),
    );
    await _box.putSynced(quote.id, quote, table: 'quotes', branchId: bid);
    return quote;
  }

  static Future<QuoteModel> updateStatus(String id, QuoteStatus status) async {
    final quote = _box.get(id);
    if (quote == null) throw Exception('عرض السعر غير موجود');
    final updated = quote.copyWith(status: status);
    await _box.putSynced(id, updated, table: 'quotes', branchId: quote.branchId);
    return updated;
  }

  static Future<void> softDelete(String id) async {
    final quote = _box.get(id);
    if (quote == null) return;
    final updated = quote.copyWith(isDeleted: true);
    await _box.putSynced(id, updated, table: 'quotes', branchId: quote.branchId);
  }
}
