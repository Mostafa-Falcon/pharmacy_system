import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:excel/excel.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:hive/hive.dart';

import '../models/inventory/medicine_model.dart';
import '../models/inventory/medicine_unit_model.dart';
import '../models/base/lookup_model.dart';
import 'auth/auth_service.dart';
import 'admin/branch_data_service.dart';
import 'lookup_service.dart';
import 'sync_service.dart';
import 'sync_box_extension.dart';
import '../utils/app_utils.dart';
import '../models/customer/customer_model.dart';
import '../models/supplier/supplier_model.dart';
import '../services/customer/customer_service.dart';
import '../services/supplier/supplier_service.dart';
import '../../modules/inventory/models/import_step_info.dart';
import '../models/sales/sale_model.dart';
import '../../modules/accounting/models/expense_model.dart';

class ExcelImportService {
  static String? _cell(List<dynamic> row, int i) {
    if (i >= row.length) return null;
    final c = row[i];
    if (c == null) return null;

    dynamic v;
    if (c is Data) {
      v = c.value;
    } else {
      v = c;
    }
    if (v == null) return null;

    if (v is TextCellValue) {
      final str = v.value.toString().trim();
      return str.isEmpty ? null : str;
    }
    if (v is IntCellValue) {
      return v.value.toString();
    }
    if (v is DoubleCellValue) {
      final d = v.value;
      if (d.isInfinite || d.isNaN) return null;
      if (d == d.toInt()) return d.toInt().toString();
      return d.toString();
    }
    if (v is DateCellValue) {
      return '${v.year}-${v.month.toString().padLeft(2, '0')}-${v.day.toString().padLeft(2, '0')}';
    }
    if (v is double) {
      if (v.isInfinite || v.isNaN) return null;
      if (v == v.toInt()) return v.toInt().toString();
      return v.toString();
    }
    final str = v.toString().trim();
    if (str.isEmpty) return null;
    return str;
  }

  static String _normalizeBarcode(String? barcode) {
    if (barcode == null || barcode.isEmpty) return '';
    final trimmed = barcode.trim();
    if (trimmed.isEmpty) return '';
    final parsed = double.tryParse(trimmed);
    if (parsed != null && parsed == parsed.toInt()) {
      return parsed.toInt().toString();
    }
    return trimmed;
  }

  static double _parseMoney(String? text) {
    if (text == null || text.isEmpty) return 0;
    final cleaned = text.replaceAll(RegExp(r'[^\d\.\-]'), '');
    return double.tryParse(cleaned) ?? 0;
  }

  static DateTime? _parseDate(String? text) {
    if (text == null || text.isEmpty) return null;
    final cleaned = text.trim();
    try {
      return DateTime.parse(cleaned);
    } catch (_) {
      return null;
    }
  }

  static _CustomerImportColumns _resolveCustomerColumnIndexes(List<dynamic> headerRow) {
    final names = headerRow.map((c) {
      if (c is Data) return (c.value?.toString() ?? '').toLowerCase();
      return c?.toString().toLowerCase() ?? '';
    }).toList();

    int idx(List<String> keys) {
      for (final k in keys) {
        final i = names.indexWhere((n) => n.contains(k));
        if (i >= 0) return i;
      }
      return -1;
    }

    return _CustomerImportColumns(
      name: idx(['اسم', 'name', 'العميل']),
      contactId: idx(['رقم', 'contact id', 'customer id', 'id']),
      phone: idx(['هاتف', 'phone', 'تليفون', 'موبايل', 'جوال']),
      email: idx(['بريد', 'email', 'إيميل']),
      address: idx(['عنوان', 'address']),
      company: idx(['شركة', 'company']),
      taxId: idx(['ضريبي', 'tax', 'tax_id']),
      creditLimit: idx(['ائتمان', 'credit limit', 'limit']),
      discount: idx(['خصم', 'discount']),
      kind: idx(['نوع', 'kind', 'type', 'النوع']),
    );
  }

  static List<List<dynamic>> decodeExcelRows(Uint8List bytes) {
    if (bytes.isEmpty) {
      throw Exception('الملف المرفق فارغ.');
    }

    // 1. Try decoding with excel package after sanitizing ZIP entries (removing BOM from XMLs if present)
    try {
      final sanitizedBytes = _sanitizeZipBytes(bytes);
      final excel = Excel.decodeBytes(sanitizedBytes);
      for (final table in excel.tables.values) {
        if (table.rows.isNotEmpty) {
          return table.rows;
        }
      }
    } catch (e) {
      safeDebugPrint('Excel.decodeBytes (sanitized) failed: $e');
    }

    // 2. Try raw excel.decodeBytes(bytes) directly
    try {
      final excel = Excel.decodeBytes(bytes);
      for (final table in excel.tables.values) {
        if (table.rows.isNotEmpty) {
          return table.rows;
        }
      }
    } catch (e) {
      safeDebugPrint('Excel.decodeBytes (raw) failed: $e');
    }

    // 3. Fallback: Direct ZipDecoder parsing for XLSX
    try {
      if (bytes.length >= 4 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
        final archive = ZipDecoder().decodeBytes(bytes, verify: false);
        final rows = _parseXlsxArchiveDirect(archive);
        if (rows.isNotEmpty) return rows;
      }
    } catch (e) {
      safeDebugPrint('Direct ZipDecoder fallback failed: $e');
    }

    // 4. Text-based fallbacks (HTML Table, XML Spreadsheet 2003, CSV / TSV)
    final text = _decodeBytesToString(bytes);
    if (text != null && text.trim().isNotEmpty) {
      if (text.contains('<table') || text.contains('<tr')) {
        final htmlRows = _parseHtmlTable(text);
        if (htmlRows.isNotEmpty) return htmlRows;
      }

      if (text.contains('<Workbook') || text.contains('<Table')) {
        final xmlRows = _parseXmlSpreadsheet2003(text);
        if (xmlRows.isNotEmpty) return xmlRows;
      }

      final csvRows = _parseCsvText(text);
      if (csvRows.isNotEmpty) return csvRows;
    }

    throw Exception('فشل في قراءة ملف Excel. يرجى التأكد من اختيار ملف Excel (.xlsx) سليم وغير تالف.');
  }

  static Uint8List _sanitizeZipBytes(Uint8List bytes) {
    if (bytes.length < 4 || bytes[0] != 0x50 || bytes[1] != 0x4B) {
      return bytes;
    }
    try {
      final archive = ZipDecoder().decodeBytes(bytes, verify: false);
      final newArchive = Archive();
      bool modified = false;

      for (final file in archive.files) {
        if (file.isFile) {
          dynamic content = file.content;
          List<int>? fileBytes;
          if (content is List<int>) {
            fileBytes = content;
          } else if (content != null) {
            try {
              fileBytes = (content as dynamic).getBytes() as List<int>?;
            } catch (_) {}
          }

          if (file.name.endsWith('.xml') && fileBytes != null && fileBytes.length >= 3) {
            if (fileBytes[0] == 0xEF && fileBytes[1] == 0xBB && fileBytes[2] == 0xBF) {
              fileBytes = fileBytes.sublist(3);
              modified = true;
            }
          }
          newArchive.addFile(ArchiveFile(file.name, fileBytes?.length ?? file.size, fileBytes ?? content));
        }
      }

      if (modified) {
        final encoder = ZipEncoder();
        final encoded = encoder.encode(newArchive);
        if (encoded != null) {
          return Uint8List.fromList(encoded);
        }
      }
    } catch (_) {}
    return bytes;
  }

  static List<List<dynamic>> _parseXlsxArchiveDirect(Archive archive) {
    final sharedStrings = <String>[];
    final ssFile = archive.files.firstWhereOrNull((f) => f.name.endsWith('sharedStrings.xml'));
    if (ssFile != null) {
      final ssXml = _fileToString(ssFile);
      if (ssXml != null) {
        final tMatches = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true).allMatches(ssXml);
        for (final m in tMatches) {
          var val = m.group(1) ?? '';
          val = val.replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&apos;', "'");
          sharedStrings.add(val);
        }
      }
    }

    final sheetFile = archive.files.firstWhereOrNull((f) => f.name.contains('worksheets/sheet')) ??
        archive.files.firstWhereOrNull((f) => f.name.contains('sheet1.xml'));
    if (sheetFile == null) return [];

    final sheetXml = _fileToString(sheetFile);
    if (sheetXml == null || sheetXml.isEmpty) return [];

    final rows = <List<dynamic>>[];
    final rowMatches = RegExp(r'<row[^>]*>(.*?)</row>', dotAll: true).allMatches(sheetXml);

    for (final rm in rowMatches) {
      final rowContent = rm.group(1) ?? '';
      final cMatches = RegExp(r'<c\s+([^>]*?)>(.*?)</c>', dotAll: true).allMatches(rowContent);
      final row = <dynamic>[];

      for (final cm in cMatches) {
        final attrs = cm.group(1) ?? '';
        final cellInner = cm.group(2) ?? '';

        final isShared = attrs.contains('t="s"');
        final isInlineStr = attrs.contains('t="inlineStr"') || attrs.contains('t="str"');

        String? val;
        if (isInlineStr) {
          final tMatch = RegExp(r'<t[^>]*>(.*?)</t>', dotAll: true).firstMatch(cellInner);
          val = tMatch?.group(1);
        } else {
          final vMatch = RegExp(r'<v[^>]*>(.*?)</v>', dotAll: true).firstMatch(cellInner);
          final rawV = vMatch?.group(1);
          if (rawV != null) {
            if (isShared) {
              final idx = int.tryParse(rawV);
              if (idx != null && idx >= 0 && idx < sharedStrings.length) {
                val = sharedStrings[idx];
              }
            } else {
              val = rawV;
            }
          }
        }
        if (val != null) {
          val = val.replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&apos;', "'");
        }
        row.add(val);
      }
      if (row.any((element) => element != null && element.toString().trim().isNotEmpty)) {
        rows.add(row);
      }
    }

    return rows;
  }

  static String? _fileToString(ArchiveFile file) {
    try {
      List<int>? content;
      if (file.content is List<int>) {
        content = file.content as List<int>;
      } else if (file.content != null) {
        content = (file.content as dynamic).getBytes() as List<int>?;
      }
      if (content == null || content.isEmpty) return null;
      if (content.length >= 3 && content[0] == 0xEF && content[1] == 0xBB && content[2] == 0xBF) {
        content = content.sublist(3);
      }
      return utf8.decode(content, allowMalformed: true);
    } catch (_) {
      return null;
    }
  }

  static List<List<dynamic>> _parseHtmlTable(String html) {
    final rows = <List<dynamic>>[];
    final trMatches = RegExp(r'<tr[^>]*>(.*?)</tr>', caseSensitive: false, dotAll: true).allMatches(html);
    for (final tr in trMatches) {
      final trInner = tr.group(1) ?? '';
      final tdMatches = RegExp(r'<(?:td|th)[^>]*>(.*?)</(?:td|th)>', caseSensitive: false, dotAll: true).allMatches(trInner);
      final row = <dynamic>[];
      for (final td in tdMatches) {
        var cell = td.group(1) ?? '';
        cell = cell.replaceAll(RegExp(r'<[^>]*>'), '');
        cell = cell.replaceAll('&nbsp;', ' ').replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').trim();
        row.add(cell.isEmpty ? null : cell);
      }
      if (row.any((e) => e != null)) {
        rows.add(row);
      }
    }
    return rows;
  }

  static List<List<dynamic>> _parseXmlSpreadsheet2003(String xml) {
    final rows = <List<dynamic>>[];
    final rowMatches = RegExp(r'<Row[^>]*>(.*?)</Row>', caseSensitive: false, dotAll: true).allMatches(xml);
    for (final rm in rowMatches) {
      final rowInner = rm.group(1) ?? '';
      final cellMatches = RegExp(r'<Cell[^>]*>(.*?)</Cell>', caseSensitive: false, dotAll: true).allMatches(rowInner);
      final row = <dynamic>[];
      for (final cm in cellMatches) {
        final cellInner = cm.group(1) ?? '';
        final dataMatch = RegExp(r'<Data[^>]*>(.*?)</Data>', caseSensitive: false, dotAll: true).firstMatch(cellInner);
        var val = dataMatch?.group(1) ?? '';
        val = val.replaceAll(RegExp(r'<[^>]*>'), '').trim();
        val = val.replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"');
        row.add(val.isEmpty ? null : val);
      }
      if (row.any((e) => e != null)) {
        rows.add(row);
      }
    }
    return rows;
  }

  static List<List<dynamic>> _parseCsvText(String text) {
    final rows = <List<dynamic>>[];
    final lines = text.split(RegExp(r'\r?\n'));
    if (lines.isEmpty) return rows;

    final firstLine = lines.firstWhere((l) => l.trim().isNotEmpty, orElse: () => '');
    if (firstLine.isEmpty) return rows;

    String sep = ',';
    if (firstLine.contains('\t')) {
      sep = '\t';
    } else if (firstLine.contains(';')) {
      sep = ';';
    }

    for (final line in lines) {
      if (line.trim().isEmpty) continue;
      final parts = line.split(sep).map((p) {
        var cleaned = p.trim();
        if (cleaned.startsWith('"') && cleaned.endsWith('"') && cleaned.length >= 2) {
          cleaned = cleaned.substring(1, cleaned.length - 1).replaceAll('""', '"');
        }
        return cleaned.isEmpty ? null : cleaned;
      }).toList();
      rows.add(parts);
    }
    return rows;
  }

  static String? _decodeBytesToString(Uint8List bytes) {
    try {
      var data = bytes;
      if (data.length >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF) {
        data = bytes.sublist(3);
      }
      return utf8.decode(data, allowMalformed: true);
    } catch (_) {
      return null;
    }
  }

  static Future<int> importFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final currentBranchId = AuthService.currentBranchId;
    if (currentBranchId == null || currentBranchId.isEmpty) {
      throw Exception('لم يتم العثور على معرف الفرع الحالي. يرجى تسجيل الدخول أولاً.');
    }
    final branchId = currentBranchId;

    onStep?.call(const ImportStepInfo(step: 'reading'));

    if (SyncService.isOnline) {
      try {
        await SyncService.syncAll().timeout(const Duration(seconds: 2));
      } catch (_) {}
    }

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) {
        throw Exception('مسار الملف غير مدعوم على الويب. استخدم اختيار الملف من المتصفح.');
      }
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.isEmpty) throw Exception('لا توجد بيانات في ملف Excel.');

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final now = DateTime.now();
    final medicines = <MedicineModel>[];
    final seenKeys = <String>{};
    var fileDuplicates = 0;
    final totalDataRows = (rows.length - 1).clamp(1, rows.length);
    var parsedRows = 0;

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final nameVal = _cell(row, 0);
      if (nameVal == null || nameVal.isEmpty) continue;
      final name = nameVal.trim();
      final brand = _cell(row, 1);
      final unitName = _cell(row, 2) ?? 'علبة';
      final categoryName = _cell(row, 3);
      final rawBarcode = _cell(row, 5);
      final skuCleaned = rawBarcode != null ? _normalizeBarcode(rawBarcode) : null;
      final barcodes = skuCleaned != null && skuCleaned.isNotEmpty ? [skuCleaned] : <String>[];
      final dedupKey = (skuCleaned != null && skuCleaned.isNotEmpty) ? 'barcode:$skuCleaned' : 'name:$name';
      if (seenKeys.contains(dedupKey)) { fileDuplicates++; continue; }
      seenKeys.add(dedupKey);
      final alertQty = double.tryParse(_cell(row, 8) ?? '')?.toInt() ?? 0;
      final parsedBuy17 = double.tryParse(_cell(row, 17) ?? '');
      final parsedBuy18 = double.tryParse(_cell(row, 18) ?? '');
      final sellPrice = double.tryParse(_cell(row, 20) ?? '') ?? 0.0;
      final buyPrice = parsedBuy18 ?? parsedBuy17 ?? (sellPrice > 0 ? sellPrice : 0.0);
      final expiresVal = double.tryParse(_cell(row, 9) ?? '');
      final expiryUnit = _cell(row, 10)?.toLowerCase();
      DateTime? expiryDate;
      bool expiryTrackingEnabled = false;
      if (expiresVal != null && expiresVal > 0) {
        expiryTrackingEnabled = true;
        expiryDate = DateTime.now().add(Duration(days: (expiryUnit == 'days' ? expiresVal : expiresVal * 30).toInt()));
      }
      final qty = double.tryParse(_cell(row, 21) ?? '')?.toInt() ?? 0;
      final rack = _cell(row, 26) ?? '';
      final rowLoc = _cell(row, 27) ?? '';
      final pos = _cell(row, 28) ?? '';
      String? location;
      if (rack.isNotEmpty || rowLoc.isNotEmpty || pos.isNotEmpty) {
        location = [if (rack.isNotEmpty) 'رف $rack', if (rowLoc.isNotEmpty) 'صف $rowLoc', if (pos.isNotEmpty) 'خانة $pos'].join(' - ');
      }
      final imageUrl = _cell(row, 29) ?? 'https://cashcl.com/img/default.png';
      final id = 'med_${const Uuid().v4()}';
      String? itemTypeId;
      if (categoryName != null && categoryName.isNotEmpty) {
        final existingTypes = LookupService.getItemTypes();
        final LookupModel? matchedType = existingTypes.firstWhereOrNull((t) => t.name.trim().toLowerCase() == categoryName.trim().toLowerCase());
        if (matchedType != null) {
          itemTypeId = matchedType.id;
        } else {
          final newType = await LookupService.addByName(name: categoryName, type: LookupType.itemType);
          itemTypeId = newType.id;
        }
      }
      final mainUnit = MedicineUnitModel(id: '${id}_unit_main', name: unitName, level: 1, conversionFactor: 1.0, buyPrice: buyPrice, sellPrice: sellPrice, quantity: qty, barcode: skuCleaned);
      medicines.add(MedicineModel(id: id, name: name, category: categoryName, barcodes: barcodes, buyPrice: buyPrice, sellPrice: sellPrice, quantity: qty, minStock: alertQty, expiryDate: expiryDate, expiryTrackingEnabled: expiryTrackingEnabled, manufacturer: brand, branchId: branchId, imageUrl: imageUrl, location: location, itemTypeId: itemTypeId, units: [mainUnit], alertEnabled: alertQty > 0, pricesIncludeTax: true, createdAt: now));
      parsedRows++;
      if (parsedRows % 200 == 0 || parsedRows == totalDataRows) {
        onProgress?.call((parsedRows / totalDataRows) * 0.45);
        await Future.microtask(() {});
      }
    }

    if (medicines.isEmpty) return 0;

    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSkipped: fileDuplicates));
    final existing = BranchDataService.getMedicines(branchId: branchId);
    final existingByKey = <String, MedicineModel>{};
    for (final m in existing) {
      if (m.barcodes.isNotEmpty) {
        for (final b in m.barcodes) {
          final nb = _normalizeBarcode(b);
          if (nb.isNotEmpty) existingByKey['barcode:$nb'] = m;
        }
      }
      existingByKey['name:${m.name.trim()}'] = m;
    }

    final toAdd = <MedicineModel>[];
    final toUpdate = <MedicineModel>[];
    for (final med in medicines) {
      final normalizedBarcode = med.barcodes.isNotEmpty ? _normalizeBarcode(med.barcodes.first) : null;
      final dedupKey = (normalizedBarcode != null && normalizedBarcode.isNotEmpty) ? 'barcode:$normalizedBarcode' : 'name:${med.name.trim()}';
      final match = existingByKey[dedupKey];
      if (match != null) {
        toUpdate.add(match.copyWith(name: med.name, nameEn: med.nameEn, category: med.category, barcodes: med.barcodes, buyPrice: med.buyPrice, sellPrice: med.sellPrice, quantity: med.quantity, minStock: med.minStock, expiryDate: med.expiryDate, expiryTrackingEnabled: med.expiryTrackingEnabled, manufacturer: med.manufacturer, imageUrl: med.imageUrl, location: med.location, itemTypeId: med.itemTypeId, units: med.units, alertEnabled: med.alertEnabled, pricesIncludeTax: med.pricesIncludeTax, lastModified: DateTime.now()));
      } else {
        toAdd.add(med);
      }
    }

    onProgress?.call(0.5);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: 0, itemsUpdated: 0, itemsSkipped: fileDuplicates));
    if (toAdd.isNotEmpty) await BranchDataService.batchAddMedicines(toAdd, skipSync: true);
    onProgress?.call(0.8);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: toAdd.length, itemsUpdated: 0, itemsSkipped: fileDuplicates));
    if (toUpdate.isNotEmpty) await BranchDataService.batchUpdateMedicines(toUpdate, skipSync: true);
    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: toAdd.length, itemsUpdated: toUpdate.length, itemsSkipped: fileDuplicates));

    if (SyncService.isOnline) {
      try {
        final supabaseRows = <Map<String, dynamic>>[];
        for (final med in medicines) {
          supabaseRows.add({'id': med.id, 'name': med.name, 'scientific_name': med.nameEn, 'category': med.category, 'barcode': med.barcodes.isNotEmpty ? med.barcodes.first : null, 'buy_price': med.buyPrice, 'sell_price': med.sellPrice, 'quantity': med.quantity, 'min_stock': med.minStock, 'expiry_date': med.expiryDate?.toIso8601String().split('T').first, 'manufacturer': med.manufacturer, 'branch_id': med.branchId, 'sync_version': med.syncVersion, 'last_modified': med.lastModified.toIso8601String(), 'is_deleted': med.isDeleted});
        }
        await Supabase.instance.client.from('medicines').upsert(supabaseRows);
        try { await SyncService.syncAll().timeout(const Duration(seconds: 2)); } catch (_) {}
      } catch (e) {
        safeDebugPrint('ExcelImport: sync failed: $e');
      }
    }

    return medicines.length;
  }

  static Future<int> importCustomersFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final branchId = AuthService.currentBranchId;
    if (branchId == null || branchId.isEmpty) throw Exception('لم يتم العثور على معرف الفرع الحالي.');

    onStep?.call(const ImportStepInfo(step: 'reading'));

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) throw Exception('مسار الملف غير مدعوم على الويب.');
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.isEmpty) return 0;

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final seen = <String>{};
    var imported = 0;
    final totalRows = rows.length - 1;
    var processed = 0;

    final headerRow = rows.first;
    final col = _resolveCustomerColumnIndexes(headerRow);

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;

      final name = _cell(row, col.name);
      if (name == null || name.isEmpty) continue;

      final contactId = _cell(row, col.contactId);
      final phone = _cell(row, col.phone);
      final email = _cell(row, col.email);
      final address = _cell(row, col.address);
      final company = _cell(row, col.company);
      final taxId = contactId;
      final creditLimit = _parseMoney(_cell(row, col.creditLimit));
      final discount = _parseMoney(_cell(row, col.discount));
      final kindRaw = (_cell(row, col.kind) ?? '').toLowerCase();
      final kind = kindRaw.contains('نقدي') || kindRaw.contains('cash') ? CustomerKind.cash : CustomerKind.regular;
      final key = phone != null && phone.isNotEmpty ? 'phone:$phone' : 'name:$name';
      if (seen.contains(key)) { processed++; continue; }
      seen.add(key);
      await CustomerService.add(name: name, kind: kind, phone: phone, email: email, address: address, companyName: company, taxId: taxId, creditLimit: creditLimit, discountPercent: discount);
      imported++;
      processed++;
      if (processed % 50 == 0 || processed == totalRows) {
        onProgress?.call((processed / totalRows) * 0.9);
        await Future.microtask(() {});
      }
    }

    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'done', itemsFound: processed, itemsSaved: imported, itemsSkipped: processed - imported));
    return imported;
  }

  static Future<int> importSuppliersFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final branchId = AuthService.currentBranchId;
    if (branchId == null || branchId.isEmpty) throw Exception('لم يتم العثور على معرف الفرع الحالي.');

    onStep?.call(const ImportStepInfo(step: 'reading'));

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) throw Exception('مسار الملف غير مدعوم على الويب.');
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.length < 2) return 0;

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final seen = <String>{};
    var imported = 0;
    final totalRows = rows.length - 1;
    var processed = 0;

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final contactId = _cell(row, 1);
      final name = _cell(row, 3);
      if (name == null || name.isEmpty) continue;
      final phone = _cell(row, 8);
      final email = _cell(row, 2);
      final address = _cell(row, 7);
      final company = _cell(row, 2);
      final taxId = contactId;
      final notes = _cell(row, 7);
      final key = phone != null && phone.isNotEmpty ? 'phone:$phone' : 'name:$name';
      if (seen.contains(key)) { processed++; continue; }
      seen.add(key);
      await SupplierService.add(name: name, type: SupplierType.supplier, partyType: SupplierPartyType.company, phone: phone, email: email, address: address, companyName: company, taxId: taxId, notes: notes);
      imported++;
      processed++;
      if (processed % 50 == 0 || processed == totalRows) {
        onProgress?.call((processed / totalRows) * 0.9);
        await Future.microtask(() {});
      }
    }

    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'done', itemsFound: processed, itemsSaved: imported, itemsSkipped: processed - imported));
    return imported;
  }

  static Future<int> importExpensesFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final branchId = AuthService.currentBranchId;
    if (branchId == null || branchId.isEmpty) throw Exception('لم يتم العثور على معرف الفرع الحالي.');

    onStep?.call(const ImportStepInfo(step: 'reading'));

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) throw Exception('مسار الملف غير مدعوم على الويب.');
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.length < 2) return 0;

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final box = Hive.box('expenses');
    final existingNumbers = box.values.map((e) => (e is Map && e['expense_number'] != null) ? (e['expense_number'] as int) : 0).toList();
    final maxNumber = existingNumbers.isEmpty ? 0 : existingNumbers.reduce((a, b) => a > b ? a : b);
    var nextNumber = maxNumber + 1;

    final seen = <String>{};
    var imported = 0;
    var skipped = 0;
    final totalRows = rows.length - 1;
    var processed = 0;

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final dateStr = _cell(row, 1);
      final refNumber = _cell(row, 2);
      final category = _cell(row, 3);
      final paymentStatus = _cell(row, 5);
      final amountStr = _cell(row, 6);
      final supplierOrCustomer = _cell(row, 9);
      final reason = _cell(row, 10);
      final addedBy = _cell(row, 11);

      if (category == null || category.isEmpty) { processed++; skipped++; continue; }
      if (amountStr == null || amountStr.isEmpty) { processed++; skipped++; continue; }

      final expenseDate = _parseDate(dateStr) ?? DateTime.now();
      final amount = _parseMoney(amountStr);
      if (amount <= 0) { processed++; skipped++; continue; }

      final dedupKey = '${refNumber ?? ''}:$category:$amount:${expenseDate.millisecondsSinceEpoch}';
      if (seen.contains(dedupKey)) { processed++; skipped++; continue; }
      seen.add(dedupKey);

      final expense = ExpenseModel(
        id: 'exp_${const Uuid().v4()}',
        branchId: branchId,
        expenseNumber: nextNumber++,
        expenseDate: expenseDate,
        category: category.trim(),
        description: reason?.trim().isNotEmpty == true ? reason!.trim() : category.trim(),
        amount: amount,
        paymentMethod: (paymentStatus ?? 'مدفوع').contains('نقدي') || (paymentStatus ?? '').contains('cash') ? 'cash' : 'cash',
        createdById: 'excel_import',
        createdByName: addedBy?.trim().isNotEmpty == true ? addedBy!.trim() : 'استيراد Excel',
        notes: supplierOrCustomer?.trim().isNotEmpty == true ? supplierOrCustomer!.trim() : null,
        createdAt: expenseDate,
        updatedAt: DateTime.now(),
      );

      await box.putSynced(expense.id, expense.toJson(), table: 'expenses', branchId: branchId);
      imported++;
      processed++;
      if (processed % 50 == 0 || processed == totalRows) {
        onProgress?.call((processed / totalRows) * 0.9);
        await Future.microtask(() {});
      }
    }

    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'done', itemsFound: processed, itemsSaved: imported, itemsSkipped: skipped));
    return imported;
  }

  static Future<int> importSalesFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final branchId = AuthService.currentBranchId;
    if (branchId == null || branchId.isEmpty) throw Exception('لم يتم العثور على معرف الفرع الحالي.');

    onStep?.call(const ImportStepInfo(step: 'reading'));

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) throw Exception('مسار الملف غير مدعوم على الويب.');
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.length < 2) return 0;

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final box = Hive.box('sales');
    final Map<String, SaleModel> salesMap = {};

    final totalRows = rows.length - 1;
    var processed = 0;
    var skipped = 0;

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final productName = _cell(row, 0);
      if (productName == null || productName.isEmpty) { processed++; skipped++; continue; }

      final barcode = _normalizeBarcode(_cell(row, 1));
      final customerName = _cell(row, 2);
      final contactId = _cell(row, 3);
      final invoiceNumber = _cell(row, 4);
      final dateStr = _cell(row, 5);
      final qtyStr = _cell(row, 6);
      final unitPriceStr = _cell(row, 7);
      final discountStr = _cell(row, 8);
      final taxStr = _cell(row, 9);
      final totalStr = _cell(row, 11);
      final paymentMethodRaw = _cell(row, 12) ?? 'نقدا';

      final quantity = double.tryParse(qtyStr?.replaceAll(RegExp(r'[^\d\.]'), '') ?? '')?.toInt() ?? 1;
      final unitPrice = _parseMoney(unitPriceStr);
      final discount = _parseMoney(discountStr);
      final tax = _parseMoney(taxStr);
      final total = _parseMoney(totalStr);
      final saleDate = _parseDate(dateStr) ?? DateTime.now();

      String paymentMethod = 'cash';
      if (paymentMethodRaw.contains('آجل') || paymentMethodRaw.contains('credit')) {
        paymentMethod = 'credit';
      } else if (paymentMethodRaw.contains('بطاقة') || paymentMethodRaw.contains('card')) {
        paymentMethod = 'card';
      } else if (paymentMethodRaw.contains('مختلط') || paymentMethodRaw.contains('mixed')) {
        paymentMethod = 'mixed';
      }

      final medicineId = barcode.isNotEmpty ? barcode : 'unknown_$i';
      final saleId = invoiceNumber != null && invoiceNumber.isNotEmpty ? 'sale_import_$invoiceNumber' : 'sale_import_${const Uuid().v4()}';

      if (!salesMap.containsKey(saleId)) {
        salesMap[saleId] = SaleModel(
          id: saleId,
          branchId: branchId,
          customerId: contactId,
          customerName: customerName,
          items: [],
          totalAmount: 0,
          discount: 0,
          finalAmount: 0,
          taxAmount: 0,
          paymentMethod: paymentMethod,
          notes: 'استيراد من Excel',
          createdBy: 'excel_import',
          createdAt: saleDate,
          syncVersion: 1,
          lastModified: DateTime.now(),
          isDeleted: false,
        );
      }

      final sale = salesMap[saleId]!;
      final itemTotal = (unitPrice * quantity) - discount;
      sale.items.add(SaleItemModel(medicineId: medicineId, medicineName: productName, quantity: quantity, unitPrice: unitPrice, totalPrice: itemTotal > 0 ? itemTotal : total, costPrice: 0));
      sale.totalAmount += itemTotal;
      sale.finalAmount += total > 0 ? total : itemTotal;
      sale.taxAmount = (sale.taxAmount ?? 0) + tax;
      if (customerName != null && sale.customerName == null) sale.customerName = customerName;

      processed++;
      if (processed % 50 == 0 || processed == totalRows) {
        onProgress?.call((processed / totalRows) * 0.9);
        await Future.microtask(() {});
      }
    }

    for (final sale in salesMap.values) {
      if (sale.items.isEmpty) { skipped++; continue; }
      sale.finalAmount = sale.finalAmount > 0 ? sale.finalAmount : sale.totalAmount;
      await box.putSynced(sale.id, sale.toJson(), table: 'sales', branchId: branchId);
    }

    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'done', itemsFound: processed, itemsSaved: salesMap.length, itemsSkipped: skipped));
    return salesMap.length;
  }

  static Future<int> importProductsFromExcel(String? filePath, {Uint8List? fileBytes, Function(double)? onProgress, Function(ImportStepInfo)? onStep}) async {
    final currentBranchId = AuthService.currentBranchId;
    if (currentBranchId == null || currentBranchId.isEmpty) {
      throw Exception('لم يتم العثور على معرف الفرع الحالي. يرجى تسجيل الدخول أولاً.');
    }
    final branchId = currentBranchId;

    onStep?.call(const ImportStepInfo(step: 'reading'));

    if (SyncService.isOnline) {
      try { await SyncService.syncAll().timeout(const Duration(seconds: 2)); } catch (_) {}
    }

    final Uint8List bytes;
    if (fileBytes != null) {
      bytes = fileBytes;
    } else if (filePath != null) {
      if (kIsWeb) throw Exception('مسار الملف غير مدعوم على الويب.');
      bytes = await File(filePath).readAsBytes();
    } else {
      throw Exception('يجب توفير مسار الملف أو محتواه.');
    }

    final rows = decodeExcelRows(bytes);
    if (rows.isEmpty) throw Exception('لا توجد بيانات في ملف Excel.');

    onStep?.call(const ImportStepInfo(step: 'parsing'));

    final now = DateTime.now();
    final medicines = <MedicineModel>[];
    final seenKeys = <String>{};
    var fileDuplicates = 0;
    final totalDataRows = (rows.length - 1).clamp(1, rows.length);
    var parsedRows = 0;

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isEmpty) continue;
      final nameVal = _cell(row, 0);
      if (nameVal == null || nameVal.isEmpty) continue;
      final name = nameVal.trim();
      final brand = _cell(row, 1);
      final unitName = _cell(row, 2) ?? 'علبة';
      final categoryName = _cell(row, 3);
      final rawBarcode = _cell(row, 5);
      final skuCleaned = rawBarcode != null ? _normalizeBarcode(rawBarcode) : null;
      final barcodes = skuCleaned != null && skuCleaned.isNotEmpty ? [skuCleaned] : <String>[];
      final dedupKey = (skuCleaned != null && skuCleaned.isNotEmpty) ? 'barcode:$skuCleaned' : 'name:$name';
      if (seenKeys.contains(dedupKey)) { fileDuplicates++; continue; }
      seenKeys.add(dedupKey);
      final alertQty = double.tryParse(_cell(row, 8) ?? '')?.toInt() ?? 0;
      final parsedBuy17 = double.tryParse(_cell(row, 17) ?? '');
      final parsedBuy18 = double.tryParse(_cell(row, 18) ?? '');
      final sellPrice = double.tryParse(_cell(row, 20) ?? '') ?? 0.0;
      final buyPrice = parsedBuy18 ?? parsedBuy17 ?? (sellPrice > 0 ? sellPrice : 0.0);
      final expiresVal = double.tryParse(_cell(row, 9) ?? '');
      final expiryUnit = _cell(row, 10)?.toLowerCase();
      DateTime? expiryDate;
      bool expiryTrackingEnabled = false;
      if (expiresVal != null && expiresVal > 0) {
        expiryTrackingEnabled = true;
        expiryDate = DateTime.now().add(Duration(days: (expiryUnit == 'days' ? expiresVal : expiresVal * 30).toInt()));
      }
      final qty = double.tryParse(_cell(row, 21) ?? '')?.toInt() ?? 0;
      final rack = _cell(row, 26) ?? '';
      final rowLoc = _cell(row, 27) ?? '';
      final pos = _cell(row, 28) ?? '';
      String? location;
      if (rack.isNotEmpty || rowLoc.isNotEmpty || pos.isNotEmpty) {
        location = [if (rack.isNotEmpty) 'رف $rack', if (rowLoc.isNotEmpty) 'صف $rowLoc', if (pos.isNotEmpty) 'خانة $pos'].join(' - ');
      }
      final imageUrl = _cell(row, 29);
      final id = 'med_${const Uuid().v4()}';
      String? itemTypeId;
      if (categoryName != null && categoryName.isNotEmpty) {
        final existingTypes = LookupService.getItemTypes();
        final LookupModel? matchedType = existingTypes.firstWhereOrNull((t) => t.name.trim().toLowerCase() == categoryName.trim().toLowerCase());
        if (matchedType != null) {
          itemTypeId = matchedType.id;
        } else {
          final newType = await LookupService.addByName(name: categoryName, type: LookupType.itemType);
          itemTypeId = newType.id;
        }
      }
      final mainUnit = MedicineUnitModel(id: '${id}_unit_main', name: unitName, level: 1, conversionFactor: 1.0, buyPrice: buyPrice, sellPrice: sellPrice, quantity: qty, barcode: skuCleaned);
      medicines.add(MedicineModel(id: id, name: name, category: categoryName, barcodes: barcodes, buyPrice: buyPrice, sellPrice: sellPrice, quantity: qty, minStock: alertQty, expiryDate: expiryDate, expiryTrackingEnabled: expiryTrackingEnabled, manufacturer: brand, branchId: branchId, imageUrl: imageUrl, location: location, itemTypeId: itemTypeId, units: [mainUnit], alertEnabled: alertQty > 0, pricesIncludeTax: true, createdAt: now));
      parsedRows++;
      if (parsedRows % 200 == 0 || parsedRows == totalDataRows) {
        onProgress?.call((parsedRows / totalDataRows) * 0.45);
        await Future.microtask(() {});
      }
    }

    if (medicines.isEmpty) return 0;

    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSkipped: fileDuplicates));
    final existing = BranchDataService.getMedicines(branchId: branchId);
    final existingByKey = <String, MedicineModel>{};
    for (final m in existing) {
      if (m.barcodes.isNotEmpty) {
        for (final b in m.barcodes) {
          final nb = _normalizeBarcode(b);
          if (nb.isNotEmpty) existingByKey['barcode:$nb'] = m;
        }
      }
      existingByKey['name:${m.name.trim()}'] = m;
    }

    final toAdd = <MedicineModel>[];
    final toUpdate = <MedicineModel>[];
    for (final med in medicines) {
      final normalizedBarcode = med.barcodes.isNotEmpty ? _normalizeBarcode(med.barcodes.first) : null;
      final dedupKey = (normalizedBarcode != null && normalizedBarcode.isNotEmpty) ? 'barcode:$normalizedBarcode' : 'name:${med.name.trim()}';
      final match = existingByKey[dedupKey];
      if (match != null) {
        toUpdate.add(match.copyWith(name: med.name, nameEn: med.nameEn, category: med.category, barcodes: med.barcodes, buyPrice: med.buyPrice, sellPrice: med.sellPrice, quantity: med.quantity, minStock: med.minStock, expiryDate: med.expiryDate, expiryTrackingEnabled: med.expiryTrackingEnabled, manufacturer: med.manufacturer, imageUrl: med.imageUrl, location: med.location, itemTypeId: med.itemTypeId, units: med.units, alertEnabled: med.alertEnabled, pricesIncludeTax: med.pricesIncludeTax, lastModified: DateTime.now()));
      } else {
        toAdd.add(med);
      }
    }

    onProgress?.call(0.5);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: 0, itemsUpdated: 0, itemsSkipped: fileDuplicates));
    if (toAdd.isNotEmpty) await BranchDataService.batchAddMedicines(toAdd, skipSync: true);
    onProgress?.call(0.8);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: toAdd.length, itemsUpdated: 0, itemsSkipped: fileDuplicates));
    if (toUpdate.isNotEmpty) await BranchDataService.batchUpdateMedicines(toUpdate, skipSync: true);
    onProgress?.call(1.0);
    onStep?.call(ImportStepInfo(step: 'saving', itemsFound: medicines.length, itemsSaved: toAdd.length, itemsUpdated: toUpdate.length, itemsSkipped: fileDuplicates));

    if (SyncService.isOnline) {
      try {
        final supabaseRows = <Map<String, dynamic>>[];
        for (final med in medicines) {
          supabaseRows.add({'id': med.id, 'name': med.name, 'scientific_name': med.nameEn, 'category': med.category, 'barcode': med.barcodes.isNotEmpty ? med.barcodes.first : null, 'buy_price': med.buyPrice, 'sell_price': med.sellPrice, 'quantity': med.quantity, 'min_stock': med.minStock, 'expiry_date': med.expiryDate?.toIso8601String().split('T').first, 'manufacturer': med.manufacturer, 'branch_id': med.branchId, 'sync_version': med.syncVersion, 'last_modified': med.lastModified.toIso8601String(), 'is_deleted': med.isDeleted});
        }
        await Supabase.instance.client.from('medicines').upsert(supabaseRows);
        try { await SyncService.syncAll().timeout(const Duration(seconds: 2)); } catch (_) {}
      } catch (e) {
        safeDebugPrint('ExcelImport: sync failed: $e');
      }
    }

    return medicines.length;
  }
}

class _CustomerImportColumns {
  final int name;
  final int contactId;
  final int phone;
  final int email;
  final int address;
  final int company;
  final int taxId;
  final int creditLimit;
  final int discount;
  final int kind;

  const _CustomerImportColumns({
    this.name = -1,
    this.contactId = -1,
    this.phone = -1,
    this.email = -1,
    this.address = -1,
    this.company = -1,
    this.taxId = -1,
    this.creditLimit = -1,
    this.discount = -1,
    this.kind = -1,
  });
}
