import 'package:hive/hive.dart';
import 'package:just_audio/just_audio.dart';
import '../utils/app_utils.dart';

enum SoundEffect {
  scanSuccess,
  cashDrawer,
  error,
  itemAdded,
  click,
  saleComplete,
  saleError,
  purchaseComplete,
  returnComplete,
  syncComplete,
  notification,
}

class SoundService {
  SoundService._();
  static final SoundService instance = SoundService._();

  final Map<SoundEffect, AudioPlayer> _players = {};
  bool _enabled = true;
  double _volume = 0.7;

  // تأمين استدعاء الـ Box ليتماشى مع التعديلات الموحدة اللي عملناها
  Box? get _settings =>
      Hive.isBoxOpen('settings') ? Hive.box('settings') : null;

  bool get enabled => _enabled;
  set enabled(bool value) {
    _enabled = value;
    _savePrefs();
  }

  double get volume => _volume;
  set volume(double value) {
    _volume = value.clamp(0.0, 1.0);
    _applyVolumeToAll();
    _savePrefs();
  }

  static const _soundPaths = {
    SoundEffect.scanSuccess: 'assets/sounds/scan_success.wav',
    SoundEffect.cashDrawer: 'assets/sounds/cash_drawer.wav',
    SoundEffect.error: 'assets/sounds/error.wav',
    SoundEffect.itemAdded: 'assets/sounds/item_added.wav',
    SoundEffect.click: 'assets/sounds/click.wav',
    SoundEffect.saleComplete: 'assets/sounds/cash_drawer.wav',
    SoundEffect.saleError: 'assets/sounds/error.wav',
    SoundEffect.purchaseComplete: 'assets/sounds/item_added.wav',
    SoundEffect.returnComplete: 'assets/sounds/item_added.wav',
    SoundEffect.syncComplete: 'assets/sounds/scan_success.wav',
    SoundEffect.notification: 'assets/sounds/scan_success.wav',
  };

  Future<void> initialize() async {
    _loadPrefs();

    // تفريغ اللاعبين القدامى أولاً قبل إعادة البناء لمنع الـ Memory Leak
    await dispose();

    for (final effect in SoundEffect.values) {
      final player = AudioPlayer();
      try {
        await player.setAsset(_soundPaths[effect]!);
        await player.setVolume(_volume);
        _players[effect] = player;
      } catch (_) {
        await player.dispose();
      }
    }
  }

  Future<void> play(SoundEffect effect) async {
    if (!_enabled) return;

    final player = _players[effect];
    if (player == null) return;

    try {
      // إيقاف أي صوت شغال حالياً لنفس الـ Player وعمل Reset فوري عشان يلقط الضربات السريعة ورا بعض
      if (player.playing) {
        await player.stop();
      }
      await player.setVolume(_volume);
      await player.seek(Duration.zero);
      // عدم انتظار الـ play بالـ await حتى لا يتجمد الـ UI Thread أثناء قراءة ملف الصوت
      player.play(); // الـ play غير متزامن بالفعل، لا نحتاج unawaited
    } catch (e, s) {
      safeDebugPrint('SoundService._load failed: $e\n$s');
    }
  }

  void _applyVolumeToAll() {
    for (final player in _players.values) {
      try {
        player.setVolume(_volume);
      } catch (e, s) {
        safeDebugPrint('SoundService._applyVolumeToAll failed: $e\n$s');
      }
    }
  }

  void _loadPrefs() {
    final box = _settings;
    if (box == null) return;
    _enabled = box.get('sound_enabled', defaultValue: true);
    _volume = (box.get('sound_volume', defaultValue: 0.7) as num).toDouble();
  }

  void _savePrefs() {
    final box = _settings;
    if (box == null) return;
    box.put('sound_enabled', _enabled);
    box.put('sound_volume', _volume);
  }

  Future<void> dispose() async {
    for (final player in _players.values) {
      try {
        await player.dispose();
      } catch (e, s) {
        safeDebugPrint('SoundService.dispose player failed: $e\n$s');
      }
    }
    _players.clear();
  }
}
