import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/sync_config.dart';
import '../models/base/sync_queue_item.dart';
import '../models/inventory/medicine_model.dart';
import '../models/sales/sale_model.dart';
import '../models/sales/purchase_model.dart';
import '../utils/app_utils.dart';
import '../models/inventory/inventory_model.dart';
import '../models/sales/return_model.dart';
import '../models/security/branch_model.dart';
import '../models/security/user_model.dart';
import '../models/security/permission_model.dart';
import '../models/customer/customer_model.dart';
import '../models/supplier/supplier_model.dart';
import '../models/customer/customer_supplier_model.dart';
import '../models/customer/customer_ledger_model.dart';
import '../models/supplier/supplier_ledger_model.dart';
import '../models/sales/cashier_shift_model.dart';
import '../models/sales/quote_model.dart';
import '../models/customer/customer_group_model.dart';
import '../models/archive/archive_record_model.dart';
import '../models/inventory/stocktaking_period_model.dart';

enum SyncOperationType { create, update, delete }

/// حالة عامة للمزامنة — بتتبثّر لحظيًا عشان كل الـ UI يتبع الحدث نفسه.
class SyncStatus {
  final bool isOnline;
  final bool isSyncing;
  final DateTime? lastSyncTime;
  final String? lastSyncError;

  const SyncStatus({
    required this.isOnline,
    required this.isSyncing,
    this.lastSyncTime,
    this.lastSyncError,
  });

  SyncStatus copyWith({
    bool? isOnline,
    bool? isSyncing,
    DateTime? lastSyncTime,
    String? lastSyncError,
  }) => SyncStatus(
    isOnline: isOnline ?? this.isOnline,
    isSyncing: isSyncing ?? this.isSyncing,
    lastSyncTime: lastSyncTime ?? this.lastSyncTime,
    lastSyncError: lastSyncError ?? this.lastSyncError,
  );
}

class SyncProgress {
  final SyncOperationType operation;
  final String table;
  final bool isPending;
  final bool? isSuccess;
  final String? error;

  SyncProgress({
    required this.operation,
    required this.table,
    this.isPending = false,
    this.isSuccess,
    this.error,
  });
}

class SyncService {
  static SupabaseClient get _client => Supabase.instance.client;
  static final Connectivity _connectivity = Connectivity();

  static bool _isSyncing = false;
  static bool _isOnline = true;
  static DateTime? _lastSyncTime;
  static String? _lastSyncError;
  static bool _listenerStarted = false;
  static Timer? _periodicSyncTimer;
  static StreamSubscription<ConnectivityResult>? _connectivitySubscription;
  static final Map<String, List<String>> _branchIndex = {};
  static final Set<String> _dirtyIndexes = {};

  /// كولباك يتم استدعاؤه عند تحديث البيانات (سواء سحب من السيرفر أو تعديل محلي)
  /// لربط الـ Repositories بالـ Streams بدون عمل Circular Dependency.
  static void Function(String table, String branchId)? onTableUpdated;

  // حجم صفحة السحب يطابق الحد الأقصى لـ Supabase (1000 صف/طلب) لتقليل الجولات
  // مع الأعداد الكبيرة، واللوب بيكمّل تلقائياً لحد ما يرجّع أقل من الحجم.
  static const int _pullPageSize = SyncConfig.pullPageSize;

  // ─── ذكاء المزامنة (تخفيف الحمل ومنع التهنيج) ───
  // فاصل الزحف الدوري: 60 ثانية (كان 30) لتقليل الضغط على الشبكة والمنظومة.
  static const Duration _periodicInterval = SyncConfig.periodicInterval;
  // أدنى فاصل بين عمليتي سحب متتاليتين حتى لو تم استدعاء syncAll عدة مرات.
  static const Duration _minPullGap = SyncConfig.minPullGap;
  static DateTime _lastPullAt = DateTime.fromMillisecondsSinceEpoch(0);
  // صندوق لتخزين "علامة المياه" لكل جدول (آخر وقت سحب ناجح) عشان السحب يكون تزايدي.
  static const String _metaBoxName = SyncConfig.metaBoxName;

  // الجداول اللي فيها عمود is_deleted فعلياً في Supabase.
  // جدول inventory مفيهوش is_deleted (مش بيتم soft-delete)، فبنفلتر عليه بس
  // للجداول اللي تدعمه عشان نتجنب خطأ 400 (عمود مش موجود).
  static const Set<String> _tablesWithIsDeleted = {
    'medicines',
    'sales',
    'purchases',
    'returns',
    'branches',
    'users',
    'permissions',
    'customers',
    'suppliers',
    'customer_ledgers',
    'supplier_ledgers',
    'cashier_shifts',
    'quotes',
    'customer_suppliers',
    'customer_groups',
    'archive_records',
    'stocktaking_periods',
    'stocktaking_counts',
  };

  static final StreamController<bool> _onlineController =
      StreamController<bool>.broadcast();
  static final StreamController<SyncProgress> _progressController =
      StreamController<SyncProgress>.broadcast();
  static final StreamController<SyncStatus> _statusController =
      StreamController<SyncStatus>.broadcast();

  static Stream<bool> get onlineStream => _onlineController.stream;
  static Stream<SyncProgress> get progressStream => _progressController.stream;
  static Stream<SyncStatus> get statusStream => _statusController.stream;
  static bool get isOnline => _isOnline;
  static bool get isSyncing => _isSyncing;
  static DateTime? get lastSyncTime => _lastSyncTime;
  static String? get lastSyncError => _lastSyncError;

  /// يبثّ حالة المزامنة الكاملة لحظيًا لكل مشترك (navbar، صفحة التفاصيل...).
  static void _emitStatus() {
    if (_statusController.isClosed) return;
    _statusController.add(
      SyncStatus(
        isOnline: _isOnline,
        isSyncing: _isSyncing,
        lastSyncTime: _lastSyncTime,
        lastSyncError: _lastSyncError,
      ),
    );
  }

  /// يبثّ تقدّم عملية واحدة، مع dedupe للأحداث المتطابقة في نفس اللحظة
  /// عشان نفس السجل ما يظهرش مرتين في الـ UI (منع التكرار).
  static final Set<String> _recentProgressKeys = {};
  static void _emitProgress(SyncProgress progress) {
    if (_progressController.isClosed) return;
    final key =
        '${progress.operation.name}_${progress.table}_${progress.isPending}_${progress.isSuccess}';
    if (_recentProgressKeys.contains(key)) return;
    _recentProgressKeys.add(key);
    // تنضيف بسيط للـ set عشان ما يكبرش بلا هدف
    if (_recentProgressKeys.length > 200) _recentProgressKeys.clear();
    _progressController.add(progress);
  }

  // ─── Branch Index ────────────────────────────────────────────────

  static void _invalidateBranchIndex(String boxName) {
    _dirtyIndexes.add(boxName);
  }

  // ─── Initialization ───────────────────────────────────────────────

  static Future<void> initialize() async {
    final result = await _connectivity.checkConnectivity();
    final hasNetwork = result != ConnectivityResult.none;
    if (hasNetwork) {
      await _checkSupabaseReachable();
    } else {
      _isOnline = false;
    }
    _emitStatus();

    // ─── جديد: محاولة إنعاش الأخطاء السابقة عند البدء ───
    if (_isOnline) {
      _retryDeadLettersOnce();
    }

    if (!_listenerStarted) {
      _listenerStarted = true;
      _connectivitySubscription = _connectivity.onConnectivityChanged.listen((
        result,
      ) async {
        final wasOffline = !_isOnline;
        final hasNetwork = result != ConnectivityResult.none;
        if (hasNetwork) {
          await _checkSupabaseReachable();
        } else {
          _isOnline = false;
          _onlineController.add(false);
          _emitStatus();
        }

        if (wasOffline && _isOnline) {
          _retryDeadLettersOnce(); // إنعاش عند عودة النت
          syncAll();
        }
      });
    }

    _periodicSyncTimer?.cancel();
    _periodicSyncTimer = Timer.periodic(_periodicInterval, (_) async {
      if (!_isSyncing) {
        if (!_isOnline) {
          await _checkSupabaseReachable();
        }
        if (_isOnline) {
          syncAll();
          _compactPeriodically(); // تنظيف دوري لقاعدة البيانات
        }
      }
    });
  }

  // ─── محرك الإنعاش التلقائي ───
  static bool _didRetryDeadLetters = false;
  static Future<void> _retryDeadLettersOnce() async {
    if (_didRetryDeadLetters || !_isOnline) return;
    _didRetryDeadLetters = true;
    final items = await getDeadLetterItems();
    if (items.isEmpty) return;

    safeDebugPrint('Sync: Auto-retrying ${items.length} dead letter items...');
    for (final item in items) {
      await retryDeadLetterItem(item.id);
    }
  }

  // ─── محرك تنظيف البيانات (Compaction) ───
  static DateTime _lastCompactAt = DateTime.fromMillisecondsSinceEpoch(0);
  static Future<void> _compactPeriodically() async {
    final now = DateTime.now();
    // التنظيف يتم مرة واحدة كل 24 ساعة لتوفير الموارد
    if (now.difference(_lastCompactAt).inHours < 24) return;
    _lastCompactAt = now;

    safeDebugPrint('Sync: Starting local database compaction...');
    final boxesToClean = [
      'medicines',
      'sales',
      'purchases',
      'returns',
      'customers',
      'suppliers',
      'customer_ledgers',
      'supplier_ledgers',
    ];

    for (final boxName in boxesToClean) {
      try {
        final box = Hive.box(boxName);
        final keysToRemove = <dynamic>[];
        final thirtyDaysAgo = now.subtract(const Duration(days: 30));

        for (final entry in box.toMap().entries) {
          final entity = entry.value;
          if (_isDeleted(entity)) {
            final lm = _getLastModified(entity);
            if (lm.isBefore(thirtyDaysAgo)) {
              keysToRemove.add(entry.key);
            }
          }
        }

        if (keysToRemove.isNotEmpty) {
          await box.deleteAll(keysToRemove);
          safeDebugPrint(
            'Sync: Compacted $boxName, removed ${keysToRemove.length} old deleted records.',
          );
        }
      } catch (e) {
        safeDebugPrint('Sync: Compaction failed for $boxName: $e');
      }
    }
  }

  /// تتأكد هل السيرفر حقيقيًا شغال (مش مجرد نت جهاز)
  static Future<bool> _checkSupabaseReachable() async {
    try {
      // أي ريكويست خفيف عشان نشوف لو السيرفر بيرد أصلاً
      await _client.from('_health').select().limit(1).maybeSingle();
      _isOnline = true;
      return true;
    } catch (e) {
      final msg = e.toString().toLowerCase();
      // 404/42P01 = جدول مش موجود (عادي، ده معناه أن السيرفر شغال)
      if (msg.contains('404') ||
          msg.contains('42p01') ||
          msg.contains('does not exist') ||
          msg.contains('relation')) {
        _isOnline = true;
        return true;
      }
      // أي خطأ تاني = السيرفر مش شغال بجد
      _isOnline = false;
      _onlineController.add(false);
      _emitStatus();
      return false;
    }
  }

  /// تحدّث حالة الاتصال بناءً على فشل حقيقي في طلب Supabase
  static void _markOfflineIfServerError(Object e) {
    final msg = e.toString().toLowerCase();
    final isServerError =
        msg.contains('socketerror') ||
        msg.contains('sockettimeout') ||
        msg.contains('connection refused') ||
        msg.contains('connectionreset') ||
        msg.contains('handshake') ||
        msg.contains('timeout') ||
        msg.contains('dns') ||
        msg.contains('500') ||
        msg.contains('502') ||
        msg.contains('503');
    if (isServerError && _isOnline) {
      _isOnline = false;
      _onlineController.add(false);
      _emitStatus();
    }
  }

  static void dispose() {
    _periodicSyncTimer?.cancel();
    _connectivitySubscription?.cancel();
    if (!_onlineController.isClosed) _onlineController.close();
    if (!_progressController.isClosed) _progressController.close();
    if (!_statusController.isClosed) _statusController.close();
  }

  // ─── Write Operations ───────────────────────────────────────────────

  static Future<void> create<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> toJson,
  }) async {
    final box = Hive.box(boxName);
    await box.put(
      entity.key ?? DateTime.now().millisecondsSinceEpoch.toString(),
      entity,
    );

    _invalidateBranchIndex(boxName);
    onTableUpdated?.call(boxName, branchId);

    await queueOperation(
      type: SyncOperationType.create,
      table: boxName,
      data: toJson,
      branchId: branchId,
    );
  }

  static Future<void> update<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> toJson,
  }) async {
    final box = Hive.box(boxName);
    // الحل النهائي: الكي قد يكون null، نستخدم id من البيانات أو timestamp
    final key =
        entity.key ??
        toJson['id'] as String? ??
        DateTime.now().millisecondsSinceEpoch.toString();
    await box.put(key, entity);

    _invalidateBranchIndex(boxName);
    onTableUpdated?.call(boxName, branchId);

    await queueOperation(
      type: SyncOperationType.update,
      table: boxName,
      data: toJson,
      branchId: branchId,
    );
  }

  static Future<void> softDelete({
    required String boxName,
    required dynamic key,
    required String branchId,
    required Map<String, dynamic> currentData,
  }) async {
    final box = Hive.box(boxName);
    await box.delete(key);

    _invalidateBranchIndex(boxName);
    onTableUpdated?.call(boxName, branchId);

    currentData['is_deleted'] = true;
    await queueOperation(
      type: SyncOperationType.delete,
      table: boxName,
      data: currentData,
      branchId: branchId,
    );
  }

  // ─── Queue Management ─────────────────────────────────────────────

  static Future<void> queueOperation({
    required SyncOperationType type,
    required String table,
    required Map<String, dynamic> data,
    required String branchId,
  }) async {
    final box = Hive.box('sync_queue');
    // نستخدم id السجل كـ queue item id (مش timestamp) عشان:
    // - نفس السجل ما يتكررش في الـ queue (create+update بنفس الـ id = عنصر واحد محدّث).
    // - لو نفس السجل اتعدّل مرتين قبل ما يتدفع، آخر تعديل هو اللي يندفع (no duplication).
    final recordId =
        (data['id'] as String?) ??
        '${DateTime.now().millisecondsSinceEpoch}_${type.name}_$table';
    final id = '${type.name}_${table}_$recordId';

    final item = SyncQueueItem(
      id: id,
      operation: type.name,
      table: table,
      data: data,
      createdAt: DateTime.now(),
      retryCount: 0,
      branchId: branchId,
    );

    await box.put(id, item);
    _emitProgress(SyncProgress(operation: type, table: table, isPending: true));

    if (_isOnline) {
      syncAll();
    }
  }

  // ─── Sync Engine ──────────────────────────────────────────────────

  static Future<void> pushAll() async {
    if (_isSyncing || !_isOnline) return;
    _isSyncing = true;
    _lastSyncError = null;
    _emitStatus();
    try {
      await _drainQueue();
    } catch (e) {
      _lastSyncError = e.toString();
    } finally {
      _lastSyncTime = DateTime.now();
      _isSyncing = false;
      _emitStatus();
    }
  }

  // ─── متغيّرات التحكّم في التدفّق (Flow Control) ───────────────────────
  // علم واحد فقط يحكم دورة المزامنة الكاملة (push ثم pull). لا يُرفع أبداً
  // أثناء push نشط، وهذا يمنع الـ race condition اللي كان بيحصل لما
  // queueOperation يستدعي syncAll أثناء تنفيذ دورة سابقة.
  static final List<Completer<void>> _waiters = [];

  /// يطلق دورة مزامنة كاملة: (1) دفع الـ queue ثم (2) سحب تزايدي.
  /// آمن للاستدعاء المتزامن: لو فيه دورة شغّالة بترجّع فوراً بعد ما تخلص
  /// (عبر الـ _waiters) من غير ما تبدأ دورة تانية متداخلة.
  static Future<void> syncAll() async {
    if (!_isOnline) return;
    if (_isSyncing) {
      // دورة شغّالة: نستنى لحد ما تخلص بدل ما نتداخل معاها.
      final waiter = Completer<void>();
      _waiters.add(waiter);
      return waiter.future;
    }

    // منع السحب المتكرر في وقت قصير جداً (ذكاء تخفيف الحمل):
    // لو السحب الأخير كان قبل أقل من _minPullGap نأجله شوية بدل ما نضغط المنظومة.
    final now = DateTime.now();
    if (now.difference(_lastPullAt) < _minPullGap) {
      return;
    }

    _isSyncing = true;
    _lastSyncError = null;
    _emitStatus();

    try {
      await _drainQueue();
      await _pullAllInternal();
      _lastSyncTime = DateTime.now();
    } catch (e) {
      safeDebugPrint('Sync: cycle failed: $e');
      _lastSyncError = e.toString();
    } finally {
      _isSyncing = false;
      _emitStatus();
      _releaseWaiters();
    }
  }

  static void _releaseWaiters() {
    if (_waiters.isEmpty) return;
    final waiters = List<Completer<void>>.from(_waiters);
    _waiters.clear();
    for (final w in waiters) {
      if (!w.isCompleted) w.complete();
    }
  }

  static Future<void> _drainQueue() async {
    Box<dynamic> box;
    try {
      box = Hive.box('sync_queue');
    } catch (_) {
      box = await Hive.openBox('sync_queue');
    }
    if (box.isEmpty) return;

    final pending = box.values.whereType<SyncQueueItem>().toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    // تجميع العمليات حسب الجدول عشان ندفع كل جدول بطلب upsert واحد
    // (BATCH UPSERT) بدل طلب لكل سجل — ده بيشيل التأخير تماماً حتى مع
    // آلاف العمليات المعلّقة.
    final Map<String, List<SyncQueueItem>> byTable = {};

    for (final item in pending) {
      if (!_isOnline) break;
      byTable.putIfAbsent(item.table, () => []).add(item);
    }

    for (final entry in byTable.entries) {
      final table = entry.key;
      final items = entry.value;
      try {
        await _pushTableBatch(table, items);
        // نجح الدفع: نمسح كل العناصر من الـ queue
        for (final item in items) {
          await box.delete(item.id);
          _emitProgress(
            SyncProgress(
              operation: SyncOperationType.values.firstWhere(
                (e) => e.name == item.operation,
              ),
              table: table,
              isPending: false,
              isSuccess: true,
            ),
          );
        }
      } catch (e) {
        _markOfflineIfServerError(e);
        // فشل الدفعة: نحدّث retryCount لكل عنصر ونعيده للـ queue
        // (أو ننقله للـ dead-letter لو تجاوز الحد الأقصى).
        for (final item in items) {
          item.retryCount++;
          item.lastError = e.toString();
          if (item.retryCount >= SyncConfig.maxRetryCount) {
            await _moveToDeadLetter(item);
            await box.delete(item.id);
          } else {
            await box.put(item.id, item);
          }
          _emitProgress(
            SyncProgress(
              operation: SyncOperationType.values.firstWhere(
                (e) => e.name == item.operation,
              ),
              table: table,
              isPending: false,
              isSuccess: false,
              error: e.toString(),
            ),
          );
        }
        break; // نوقف باقي الجداول عند أول خطأ شبكي عشان نحافظ على الترتيب
      }
    }
  }

  /// يدفع دفعة واحدة لجدول: upsert للإنشاء/التحديث + update is_deleted للحذف.
  /// طلبان كحد أقصى لكل جدول (بدل طلب لكل سجل) → أداء احترافي بلا تأخير.
  static Future<void> _pushTableBatch(
    String table,
    List<SyncQueueItem> items,
  ) async {
    final upserts = <Map<String, dynamic>>[];
    final deletes = <SyncQueueItem>[];

    for (final item in items) {
      final data = Map<String, dynamic>.from(item.data);
      if (!data.containsKey('last_modified')) {
        data['last_modified'] = DateTime.now().toIso8601String();
      }
      if (item.operation == 'delete') {
        deletes.add(item);
      } else {
        upserts.add(data);
      }
    }

    // upsert جماعي (طلب واحد لكل الجدول)
    if (upserts.isNotEmpty) {
      await _client.from(table).upsert(upserts);
    }

    // الحذف الناعم/الصعب جماعي — على دفعات (batch size 50) عشان URL ما يطولش
    if (deletes.isNotEmpty) {
      final ids = deletes.map((d) => d.data['id']).whereType<String>().toList();
      if (ids.isNotEmpty) {
        const int deleteBatchSize = 50;
        for (int i = 0; i < ids.length; i += deleteBatchSize) {
          final batch = ids.sublist(
            i,
            (i + deleteBatchSize).clamp(0, ids.length),
          );
          if (_tablesWithIsDeleted.contains(table)) {
            await _client
                .from(table)
                .update({
                  'is_deleted': true,
                  'last_modified': DateTime.now().toIso8601String(),
                })
                .filter('id', 'in', batch);
          } else {
            await _client
                .from(table)
                .delete()
                .filter('id', 'in', batch);
          }
        }
      }
    }
  }

  static Future<void> _moveToDeadLetter(SyncQueueItem item) async {
    final deadBox = await Hive.openBox('sync_dead_letter');
    // نستخدم copyWith عشان نتجنب HiveError: The same instance...
    // لأن الـ HiveObject مينفعش يكون مربوط بصندوقين (queue و dead_letter) في نفس الوقت.
    await deadBox.put(item.id, item.copyWith());
  }

  // ─── Pull Operations ──────────────────────────────────────────────

  /// واجهة عامة للسحب (تُستدعى من أزرار يدوية في واجهة المزامنة).
  /// بترجع فوراً لو فيه دورة شغّالة عشان ما يتداخلش مع syncAll.
  static Future<void> pullAll() async {
    if (!_isOnline || _isSyncing) return;
    _isSyncing = true;
    _lastSyncError = null;
    _emitStatus();
    try {
      await _pullAllInternal();
    } finally {
      _isSyncing = false;
      _emitStatus();
    }
  }

  static Future<void> _pullAllInternal() async {
    _lastPullAt = DateTime.now();
    final tables = [
      {'table': 'medicines', 'box': 'medicines', 'fn': MedicineModel.fromJson},
      {'table': 'sales', 'box': 'sales', 'fn': SaleModel.fromJson},
      {'table': 'purchases', 'box': 'purchases', 'fn': PurchaseModel.fromJson},
      {
        'table': 'cashier_shifts',
        'box': 'cashier_shifts',
        'fn': CashierShiftModel.fromJson,
      },
      {'table': 'quotes', 'box': 'quotes', 'fn': QuoteModel.fromJson},
      {
        'table': 'inventory',
        'box': 'inventory',
        'fn': InventoryItemModel.fromJson,
      },
      {'table': 'returns', 'box': 'returns', 'fn': ReturnModel.fromJson},
      {'table': 'branches', 'box': 'branches', 'fn': BranchModel.fromJson},
      {'table': 'users', 'box': 'users', 'fn': UserModel.fromJson},
      {
        'table': 'permissions',
        'box': 'permissions',
        'fn': PermissionModel.fromJson,
      },
      {'table': 'customers', 'box': 'customers', 'fn': CustomerModel.fromJson},
      {'table': 'suppliers', 'box': 'suppliers', 'fn': SupplierModel.fromJson},
      {
        'table': 'customer_suppliers',
        'box': 'customer_suppliers',
        'fn': CustomerSupplierModel.fromJson,
      },
      {
        'table': 'customer_groups',
        'box': 'customer_groups',
        'fn': CustomerGroupModel.fromJson,
      },
      {
        'table': 'customer_ledgers',
        'box': 'customer_ledgers',
        'fn': CustomerLedgerModel.fromJson,
      },
      {
        'table': 'supplier_ledgers',
        'box': 'supplier_ledgers',
        'fn': SupplierLedgerModel.fromJson,
      },
      {
        'table': 'archive_records',
        'box': 'archive_records',
        'fn': ArchiveRecordModel.fromJson,
      },
      {
        'table': 'stocktaking_periods',
        'box': 'stocktaking_periods',
        'fn': StocktakingPeriodModel.fromJson,
      },
      {
        'table': 'stocktaking_counts',
        'box': 'stocktaking_counts',
        'fn': StocktakingCountModel.fromJson,
      },
    ];

    for (final t in tables) {
      try {
        await _pullTable(
          table: t['table'] as String,
          boxName: t['box'] as String,
          fromJson: t['fn'] as dynamic,
        );
      } catch (e) {
        safeDebugPrint('Pull Error [${t['table']}]: $e');
      }
      await Future.delayed(Duration(milliseconds: SyncConfig.pullTableDelayMs));
    }

    _lastSyncTime = DateTime.now();
  }

  static Future<void> _pullTable<T>({
    required String table,
    required String boxName,
    required T Function(Map<String, dynamic>) fromJson,
  }) async {
    // حل جذري للويب: نستخدم Box مباشرة مع تحديد النوع لضمان عدم حدوث تعارض
    // إذا كان الصندوق قد فُتح بنوع محدد في hive_init.
    final localBox = Hive.box<T>(boxName);

    // السحب التزايدي: نسحب بس الصفوف اللي اتعدلت بعد آخر سحب ناجح (watermark).
    final meta = Hive.isBoxOpen(_metaBoxName)
        ? Hive.box(_metaBoxName)
        : await Hive.openBox(_metaBoxName);
    final sinceKey = 'since_$table';
    final sinceVal = meta.get(sinceKey) as String?;
    final DateTime? since = sinceVal != null
        ? DateTime.tryParse(sinceVal)
        : null;

    final Map<dynamic, dynamic> batchData = {};
    int offset = 0;
    bool hasMore = true;

    // ─── ذكاء علامة المياه (Watermark): تعتمد على توقيت السيرفر الفعلي ───
    DateTime newestRemoteAtServer =
        since ?? DateTime.fromMillisecondsSinceEpoch(0);

    while (hasMore) {
      final dynamic remoteRecords;
      try {
        var filter = _client.from(table).select();
        if (_tablesWithIsDeleted.contains(table)) {
          filter = filter.eq('is_deleted', false);
        }
        if (since != null) {
          // استخدام gte (أكبر من أو يساوي) لضمان عدم فقدان أي حركة في نفس الثانية.
          // الـ dedupe بالـ id في batchData يمنع تكرار معالجة نفس السجل.
          filter = filter.gte('last_modified', since.toIso8601String());
        }

        final paged = filter
            .order('last_modified', ascending: true)
            .range(offset, offset + _pullPageSize - 1);
        remoteRecords = await paged;
      } catch (e) {
        final msg = e.toString();
        _markOfflineIfServerError(e);
        final isMissing =
            msg.contains('PGRST205') ||
            msg.contains('42703') ||
            msg.contains('404') ||
            msg.contains('does not exist') ||
            msg.toLowerCase().contains('not found');
        if (isMissing) {
          return;
        }
        rethrow;
      }

      if (remoteRecords == null || remoteRecords.isEmpty) {
        hasMore = false;
        break;
      }

      final List<dynamic> decoded = await compute(
        _deserializeRecords,
        _DeserializePayload(remoteRecords, table),
      );

      for (final entity in decoded) {
        final remoteId = entity.id?.toString() ?? '';
        batchData[remoteId] = entity;

        // تتبع أحدث توقيت سيرفر وصلنا له في هذه الدفعة
        final lm = _getLastModified(entity);
        if (lm.isAfter(newestRemoteAtServer)) {
          newestRemoteAtServer = lm;
        }
      }

      if (remoteRecords.length < _pullPageSize) {
        hasMore = false;
      }
      offset += _pullPageSize;
    }

    if (batchData.isNotEmpty) {
      // ─── درع النزاعات (Conflict Shield): منع مسح البيانات المحلية الأحدث ───
      final Map<dynamic, dynamic> merged = {};
      for (final entry in batchData.entries) {
        final remoteEntity = entry.value;
        final localEntity = localBox.get(entry.key);

        if (localEntity != null) {
          final localLm = _getLastModified(localEntity);
          final remoteLm = _getLastModified(remoteEntity);

          // إذا كان التعديل المحلي أحدث (مثلاً تم أوفلاين ولم يُرفع بعد)،
          // لا نقوم بالكتابة فوقه ببيانات السيرفر الأقدم.
          if (localLm.isAfter(remoteLm)) {
            continue;
          }
        }
        merged[entry.key] = remoteEntity;
      }

      if (merged.isNotEmpty) {
        await localBox.putAll(Map<dynamic, T>.from(merged));
        _invalidateBranchIndex(boxName);

        final branches = merged.values
            .map((e) => _getBranchId(e))
            .whereType<String>()
            .toSet();
        for (final bid in branches) {
          onTableUpdated?.call(table, bid);
        }
        safeDebugPrint(
          'Pull [$table]: ${merged.length} records merged safely.',
        );
      }
    }

    // ─── تحديث علامة المياه لتبدأ من حيث انتهى السيرفر (+1ms أمان) ───
    if (newestRemoteAtServer.isAfter(
      since ?? DateTime.fromMillisecondsSinceEpoch(0),
    )) {
      final nextWatermark = newestRemoteAtServer.add(
        const Duration(milliseconds: 1),
      );
      await meta.put(sinceKey, nextWatermark.toUtc().toIso8601String());
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────

  static DateTime _getLastModified(dynamic entity) {
    if (entity is MedicineModel) return entity.lastModified;
    if (entity is SaleModel) return entity.lastModified;
    if (entity is PurchaseModel) return entity.lastModified;
    if (entity is InventoryItemModel) return entity.lastModified;
    if (entity is ReturnModel) return entity.lastModified;
    if (entity is BranchModel) return entity.lastModified;
    if (entity is UserModel) return entity.lastModified;
    if (entity is PermissionModel) return entity.lastModified;
    if (entity is CustomerModel) return entity.lastModified;
    if (entity is SupplierModel) return entity.lastModified;
    if (entity is CustomerSupplierModel) return entity.lastModified;
    if (entity is CustomerLedgerModel) return entity.lastModified;
    if (entity is SupplierLedgerModel) return entity.lastModified;
    if (entity is CashierShiftModel) return entity.lastModified;
    if (entity is QuoteModel) return entity.lastModified;
    if (entity is CustomerGroupModel) return entity.lastModified;
    if (entity is ArchiveRecordModel) return entity.lastModified;
    if (entity is StocktakingPeriodModel) return entity.lastModified;
    if (entity is StocktakingCountModel) return entity.lastModified;
    return DateTime.now();
  }

  // ─── Query Helpers ──────────────────────────────────────────────

  static List<T> getLocalData<T>({
    required String boxName,
    required String branchId,
    bool includeDeleted = false,
  }) {
    final box = Hive.box(boxName);
    if (box.isEmpty) return <T>[];

    final indexKey = '$boxName:$branchId';
    if (!includeDeleted &&
        _branchIndex.containsKey(indexKey) &&
        !_dirtyIndexes.contains(boxName)) {
      final ids = _branchIndex[indexKey]!;
      final result = <T>[];
      for (final id in ids) {
        final entity = box.get(id);
        if (entity is T) result.add(entity);
      }
      return result;
    }

    final result = box.values
        .where((entity) {
          if (entity is! HiveObject) return false;
          if (_getBranchId(entity) != branchId) return false;
          if (!includeDeleted && _isDeleted(entity)) return false;
          return entity is T;
        })
        .cast<T>()
        .toList();

    if (!includeDeleted) {
      final ids = <String>[];
      for (final e in result.whereType<HiveObject>()) {
        final k = e.key;
        if (k != null) ids.add(k);
      }
      _branchIndex[indexKey] = ids;
      _dirtyIndexes.remove(boxName);
    }

    return result;
  }

  static List<T> getAllLocalData<T>({required String boxName}) {
    return Hive.box(boxName).values.whereType<T>().toList();
  }

  static String? _getBranchId(dynamic entity) {
    if (entity is MedicineModel) return entity.branchId;
    if (entity is SaleModel) return entity.branchId;
    if (entity is PurchaseModel) return entity.branchId;
    if (entity is InventoryItemModel) return entity.branchId;
    if (entity is ReturnModel) return entity.branchId;
    if (entity is CustomerLedgerModel) return entity.branchId;
    if (entity is SupplierLedgerModel) return entity.branchId;
    if (entity is CashierShiftModel) return entity.branchId;
    if (entity is QuoteModel) return entity.branchId;
    return null;
  }

  static bool _isDeleted(dynamic entity) {
    if (entity is MedicineModel) return entity.isDeleted;
    if (entity is SaleModel) return entity.isDeleted;
    if (entity is PurchaseModel) return entity.isDeleted;
    if (entity is ReturnModel) return entity.isDeleted;
    if (entity is CustomerLedgerModel) return entity.isDeleted;
    if (entity is SupplierLedgerModel) return entity.isDeleted;
    if (entity is PermissionModel) return entity.isDeleted;
    if (entity is CashierShiftModel) return entity.isDeleted;
    if (entity is QuoteModel) return entity.isDeleted;
    if (entity is BranchModel) return entity.isDeleted;
    if (entity is UserModel) return entity.isDeleted;
    if (entity is CustomerModel) return entity.isDeleted;
    if (entity is SupplierModel) return entity.isDeleted;
    if (entity is CustomerSupplierModel) return entity.isDeleted;
    if (entity is CustomerGroupModel) return entity.isDeleted;
    return false;
  }

  static int get pendingOperationsCount => Hive.box('sync_queue').length;

  static List<SyncQueueItem> getPendingItems() {
    final box = Hive.box('sync_queue');
    return box.values.whereType<SyncQueueItem>().toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  }

  static Future<void> removePendingItem(String id) async {
    final box = Hive.box('sync_queue');
    await box.delete(id);
    _emitProgress(
      SyncProgress(
        operation: SyncOperationType.delete,
        table: 'sync_queue',
        isPending: false,
      ),
    );
  }

  static Future<void> clearQueue() async =>
      await Hive.box('sync_queue').clear();

  // ─── Dead Letter Queue ─────────────────────────────────────────────
  static Future<int> get deadLetterCount async {
    final box = await Hive.openBox('sync_dead_letter');
    return box.length;
  }

  static Future<List<SyncQueueItem>> getDeadLetterItems() async {
    final box = await Hive.openBox('sync_dead_letter');
    return box.values.whereType<SyncQueueItem>().toList();
  }

  static Future<void> retryDeadLetterItem(String id) async {
    final deadBox = await Hive.openBox('sync_dead_letter');
    final item = deadBox.get(id) as SyncQueueItem?;
    if (item == null) return;

    final newItem = item.copyWith(retryCount: 0, lastError: null);

    final queueBox = await Hive.openBox('sync_queue');
    await queueBox.put(id, newItem);
    await deadBox.delete(id);

    if (_isOnline && !_isSyncing) {
      syncAll();
    }
  }

  static Future<void> clearDeadLetter() async {
    final box = await Hive.openBox('sync_dead_letter');
    await box.clear();
  }
}

// حمولة نمرّرها لـ Isolate المنفصل عشان يحوّل الخرائط لنماذج من غير ما يحجب الـ UI.
// لازم تكون بيانات قابلة للتمرور (plain data) — بنمرّر اسم الجدول مش دالة.
class _DeserializePayload {
  final List<dynamic> records;
  final String table;

  _DeserializePayload(this.records, this.table);
}

// ─── دوال الـ Isolate (top-level عشان compute) ───────────────────────────
// يحوّل قائمة الخرائط لنماذج (fromJson) على خيط منفصل بدون حجب الـ UI.
// الدالة لازم تكون top-level وتاخد بيانات قابلة للتمرور فقط (مينفعش نمرّر Function)،
// لذلك بنمرّر اسم الجدول ونختار الـ fromJson الصح جوه الـ Isolate.
List<dynamic> _deserializeRecords(_DeserializePayload payload) {
  final records = payload.records.cast<Map<Object?, Object?>>();
  switch (payload.table) {
    case 'medicines':
      return records.map((r) => MedicineModel.fromJson(_asMap(r))).toList();
    case 'sales':
      return records.map((r) => SaleModel.fromJson(_asMap(r))).toList();
    case 'purchases':
      return records.map((r) => PurchaseModel.fromJson(_asMap(r))).toList();
    case 'cashier_shifts':
      return records.map((r) => CashierShiftModel.fromJson(_asMap(r))).toList();
    case 'quotes':
      return records.map((r) => QuoteModel.fromJson(_asMap(r))).toList();
    case 'inventory':
      return records
          .map((r) => InventoryItemModel.fromJson(_asMap(r)))
          .toList();
    case 'returns':
      return records.map((r) => ReturnModel.fromJson(_asMap(r))).toList();
    case 'branches':
      return records.map((r) => BranchModel.fromJson(_asMap(r))).toList();
    case 'users':
      return records.map((r) => UserModel.fromJson(_asMap(r))).toList();
    case 'permissions':
      return records.map((r) => PermissionModel.fromJson(_asMap(r))).toList();
    case 'customers':
      return records.map((r) => CustomerModel.fromJson(_asMap(r))).toList();
    case 'suppliers':
      return records.map((r) => SupplierModel.fromJson(_asMap(r))).toList();
    case 'customer_suppliers':
      return records
          .map((r) => CustomerSupplierModel.fromJson(_asMap(r)))
          .toList();
    case 'customer_groups':
      return records
          .map((r) => CustomerGroupModel.fromJson(_asMap(r)))
          .toList();
    case 'customer_ledgers':
      return records
          .map((r) => CustomerLedgerModel.fromJson(_asMap(r)))
          .toList();
    case 'supplier_ledgers':
      return records
          .map((r) => SupplierLedgerModel.fromJson(_asMap(r)))
          .toList();
    case 'archive_records':
      return records
          .map((r) => ArchiveRecordModel.fromJson(_asMap(r)))
          .toList();
    case 'stocktaking_periods':
      return records
          .map((r) => StocktakingPeriodModel.fromJson(_asMap(r)))
          .toList();
    case 'stocktaking_counts':
      return records
          .map((r) => StocktakingCountModel.fromJson(_asMap(r)))
          .toList();
    default:
      return const [];
  }
}

Map<String, dynamic> _asMap(Map<Object?, Object?> m) =>
    m.map((k, v) => MapEntry(k.toString(), v));
