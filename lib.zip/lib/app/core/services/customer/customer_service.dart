import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../models/customer/customer_model.dart';
import '../../services/sync_service.dart';
import '../../services/auth/auth_service.dart';
import '../../utils/app_utils.dart';

class CustomerService {
  static Box get _box => Hive.box('customers');
  static const _uuid = Uuid();

  static Future<void> init() async {
  }

  static List<CustomerModel> getAll({bool activeOnly = true, bool includeDeleted = false}) {
    var items = _box.values.whereType<CustomerModel>().toList();
    if (!includeDeleted) {
      items = items.where((c) => !c.isDeleted).toList();
    }
    if (activeOnly) {
      items = items.where((c) => c.isActive).toList();
    }
    return items;
  }

  static CustomerModel? getById(String? id) {
    if (id == null) return null;
    final item = _box.get(id);
    if (item is CustomerModel) return item;
    return null;
  }

  static String? getNameById(String? id) {
    return getById(id)?.name;
  }

  static Future<CustomerModel> add({
    required String name,
    CustomerKind kind = CustomerKind.regular,
    String? phone,
    String? address,
    String? companyName,
    String? email,
    String? taxId,
    double creditLimit = 0,
    double discountPercent = 0,
    int paymentTermDays = 0,
    String? notes,
  }) async {
    try {
      final customer = CustomerModel(
        id: _uuid.v4(),
        name: name,
        kind: kind,
        phone: phone,
        address: address,
        companyName: companyName,
        email: email,
        taxId: taxId,
        creditLimit: creditLimit,
        discountPercent: discountPercent,
        paymentTermDays: paymentTermDays,
        notes: notes,
      );
      customer.lastModified = DateTime.now();
      await SyncService.create(
        boxName: 'customers',
        entity: customer,
        branchId: AuthService.currentBranchId ?? '',
        toJson: customer.toJson(),
      );
      return customer;
    } catch (e, s) {
      safeDebugPrint('CustomerService.add failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> update(CustomerModel customer) async {
    try {
      customer.lastModified = DateTime.now();
      await SyncService.update(
        boxName: 'customers',
        entity: customer,
        branchId: AuthService.currentBranchId ?? '',
        toJson: customer.toJson(),
      );
    } catch (e, s) {
      safeDebugPrint('CustomerService.update failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> deactivate(String id) async {
    try {
      final customer = getById(id);
      if (customer != null) {
        await update(customer.copyWith(isActive: false));
      }
    } catch (e, s) {
      safeDebugPrint('CustomerService.deactivate failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> activate(String id) async {
    try {
      final customer = getById(id);
      if (customer != null) {
        await update(customer.copyWith(isActive: true));
      }
    } catch (e, s) {
      safeDebugPrint('CustomerService.activate failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> delete(String id) async {
    try {
      final customer = getById(id);
      if (customer != null) {
        await SyncService.softDelete(
          boxName: 'customers',
          key: id,
          branchId: AuthService.currentBranchId ?? '',
          currentData: customer.toJson(),
        );
      }
    } catch (e, s) {
      safeDebugPrint('CustomerService.delete failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> hardDelete(String id) async {
    try {
      await _box.delete(id);
    } catch (e, s) {
      safeDebugPrint('CustomerService.hardDelete failed: $e\n$s');
      rethrow;
    }
  }

  static bool nameExists(String name, {String? excludeId}) {
    return _box.values.whereType<CustomerModel>().any((c) =>
        c.name.toLowerCase() == name.toLowerCase().trim() &&
        c.id != excludeId
    );
  }

  static List<CustomerModel> search(String query) {
    if (query.isEmpty) return getAll();
    final q = query.toLowerCase();
    return getAll().where((c) =>
        c.name.toLowerCase().contains(q) ||
        (c.phone?.contains(q) ?? false) ||
        (c.companyName?.toLowerCase().contains(q) ?? false)
    ).toList();
  }
}
