import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../models/customer/customer_group_model.dart';
import '../../utils/app_utils.dart';
import '../../services/auth/auth_service.dart';
import '../../services/sync_box_extension.dart';
import '../../../modules/archive/services/archive_service.dart';

class CustomerGroupService {
  static Box get _box => Hive.box('customer_groups');
  static const _uuid = Uuid();

  static Future<void> init() async {
  }

  static List<CustomerGroupModel> getAll({bool activeOnly = true, bool includeDeleted = false}) {
    try {
      var items = _box.values.whereType<CustomerGroupModel>().toList();
      if (!includeDeleted) {
        items = items.where((g) => !g.isDeleted).toList();
      }
      if (activeOnly) {
        items = items.where((g) => g.isActive).toList();
      }
      return items;
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.getAll failed: $e\n$s');
      return [];
    }
  }

  static CustomerGroupModel? getById(String? id) {
    try {
      if (id == null) return null;
      final item = _box.get(id);
      if (item is CustomerGroupModel) return item;
      return null;
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.getById failed: $e\n$s');
      return null;
    }
  }

  static Future<CustomerGroupModel> add({
    required String name,
    double discountPercent = 0,
    String? priceGroupId,
    String? description,
  }) async {
    try {
      final group = CustomerGroupModel(
        id: _uuid.v4(),
        name: name,
        discountPercent: discountPercent,
        priceGroupId: priceGroupId,
        description: description,
      );
      group.lastModified = DateTime.now();
      await _box.putSynced(group.id, group, table: 'customer_groups', branchId: AuthService.currentBranchId ?? '');
      return group;
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.add failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> update(CustomerGroupModel group) async {
    try {
      group.lastModified = DateTime.now();
      await _box.putSynced(group.id, group, table: 'customer_groups', branchId: AuthService.currentBranchId ?? '');
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.update failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> deactivate(String id) async {
    try {
      final group = getById(id);
      if (group != null) {
        group.isActive = false;
        group.lastModified = DateTime.now();
        await _box.putSynced(id, group, table: 'customer_groups', branchId: AuthService.currentBranchId ?? '');
      }
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.deactivate failed: $e\n$s');
      rethrow;
    }
  }

  static Future<void> delete(String id) async {
    try {
      final group = getById(id);
      if (group != null) {
        await ArchiveService.record(
          entityType: 'customer_group',
          entityId: group.id,
          entityName: group.name,
          entityData: group.toJson(),
          branchId: AuthService.currentBranchId ?? '',
        );

        await _box.putSynced(id, group.copyWith(isDeleted: true), table: 'customer_groups', branchId: AuthService.currentBranchId ?? '');
      }
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.delete failed: $e\n$s');
      rethrow;
    }
  }

  static bool nameExists(String name, {String? excludeId}) {
    try {
      return _box.values.whereType<CustomerGroupModel>().any((g) =>
          g.name.toLowerCase() == name.toLowerCase().trim() &&
          g.id != excludeId
      );
    } catch (e, s) {
      safeDebugPrint('CustomerGroupService.nameExists failed: $e\n$s');
      return false;
    }
  }
}
