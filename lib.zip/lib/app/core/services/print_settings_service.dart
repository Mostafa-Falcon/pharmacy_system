import 'package:hive/hive.dart';

class PrintSettingsService {
  PrintSettingsService._();
  static Box? _box;

  static Box get _settingsBox {
    _box ??= Hive.box('settings');
    return _box!;
  }

  static bool get isPrintEnabled {
    try {
      return _settingsBox.get('print_enabled', defaultValue: true) as bool;
    } catch (_) {
      return true;
    }
  }

  static set isPrintEnabled(bool value) {
    _settingsBox.put('print_enabled', value);
  }

  static void toggle() {
    isPrintEnabled = !isPrintEnabled;
  }
}
