// reports_strings.dart — التقارير (مبيعات، مشتريات، أرباح، مخزون، ضرائب، نشاط، جهات اتصال)

class ReportsStrings {
  ReportsStrings._();

  static const String reportsTitle = 'التقارير';
  static const String reportsExtra = 'التقارير الإضافية';
  static const String reportsSales = 'تقرير المبيعات';
  static const String reportsPurchases = 'تقرير المشتريات';
  static const String reportsProfit = 'تقرير الأرباح';
  static const String reportsInventory = 'تقرير المخزون';
  static const String reportsStocktake = 'الجرد المخزني';
  static const String reportsPopularItems = 'الأصناف الشائعة';
  static const String reportsItemMovement = 'حركة الأصناف';
  static const String reportsTaxSummary = 'ملخص الضريبة';
  static const String reportsEmployeeActivity = 'نشاطات الموظفين';
  static const String reportsCustomRange = 'نطاق مخصص';
  static const String reportsThisWeek = 'هذا الأسبوع';
  static const String reportsThisYear = 'هذا العام';
  static const String reportsCustom = 'مخصص';
  static const String reportsOperationalExpenses = 'المصروفات التشغيلية';
  static const String reportsJournalIntegrity = 'سلامة دفتر اليومية';
  static const String reportsDailyBalance = 'رصيد اليوم';
  static const String reportsInventoryValue = 'قيمة المخزون بسعر الشراء والبيع';
  static const String reportsInventoryMovement = 'إجمالي الداخل والخارج من المخزون';
  static const String reportsBestSelling = 'الأصناف الأكثر مبيعاً';
  static const String reportsItemTransactionMovements = 'حركة صنف ناتجة عن البيع والشراء والمرتجعات';
  static const String reportsTaxDetails = 'تفاصيل ضرائب المبيعات والمشتريات';
  static const String reportsEmployeeActivityLog = 'سجل مبسط لحركات الموظفين';

  // ─── Reports: Tax Summary ───
  static const String taxSummaryEmpty = 'لا توجد ضرائب مسجلة';
  static const String taxSummarySalesTax = 'ضريبة المبيعات';
  static const String taxSummaryPurchaseTax = 'ضريبة المشتريات';
  static const String taxSummaryExpenseTax = 'ضريبة النفقات';
  static const String taxSummaryNet = 'الصافي الضريبي';
  static const String taxColumnDate = 'التاريخ';
  static const String taxColumnType = 'النوع';
  static const String taxColumnRef = 'المرجع';
  static const String taxColumnParty = 'الطرف';
  static const String taxColumnMethod = 'طريقة الدفع';
  static const String taxColumnBase = 'الأساس';

  // ─── Reports: Activity ───
  static const String activityEmpty = 'لا توجد أنشطة موظفين';
  static const String activityCount = 'عدد الأنشطة';
  static const String activityShifts = 'مناوبات الكاشير';
  static const String activityUsers = 'المستخدمين';
  static const String activityEmployee = 'موظف';

  // ─── Reports: Inventory ───
  static const String invReportEmpty = 'لا توجد أصناف مخزنية';
  static const String invReportPotentialProfit = 'الربح المحتمل';
  static const String invReportTotalUnits = 'إجمالي الوحدات';
  static const String invReportBuyPrice = 'سعر الشراء';
  static const String invReportSellPrice = 'سعر البيع';
  static const String invReportBuyValue = 'قيمة الشراء';
  static const String invReportSellValue = 'قيمة البيع';
  static const String invReportProfit = 'الربح';
  static const String invReportBuyLabel = 'شراء';
  static const String invReportSellLabel = 'بيع';

  // ─── Reports: Contacts ───
  static const String contactReportTitle = 'تقرير جهات الاتصال';
  static const String contactFilterAll = 'الكل';
  static const String contactFilterCustomers = 'العملاء';
  static const String contactFilterSuppliers = 'الموردين';
  static const String contactFilterDebtors = 'المدينون';

  // ─── Reports: Advanced Ledger ───
  static const String advancedLedgerReportTitle = 'تقرير كشوف الحسابات المتقدم';
  static const String customerType = 'عميل';
  static const String customerSupplierType = 'عميل/مورد';
  static const String exportSuccess = 'تم تصدير التقرير بنجاح';
  static const String exportFailedFormat = 'فشل في التصدير: %s';
  static const String fromDateLabel = 'من';
  static const String toDateLabel = 'إلى';
  static const String sortLabel = 'ترتيب';
  static const String sortByBalance = 'ترتيب بالرصيد';
  static const String sortByName = 'ترتيب بالاسم';
  static const String sortByDate = 'ترتيب بالتاريخ';
  static const String openingBalanceLabel = 'الرصيد الافتتاحي';
  static const String prepaidLabel = 'المدفوع مقدمًا';
  static const String addedDateLabel = 'تاريخ الإضافة';
  static const String unpaidPurchasesLabel = 'المشتريات غير المدفوعة';
  static const String purchaseReturnsLabel = 'مرتجع المشتريات';
  static const String finalDueLabel = 'المستحق النهائي';
}
