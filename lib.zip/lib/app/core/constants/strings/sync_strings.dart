// sync_strings.dart — المزامنة السحابية وحالة الجداول والاتصال

class SyncStrings {
  SyncStrings._();

  static const String syncStatusTitle = 'تفاصيل المزامنة والسحابة';
  static const String syncStatusSubtitle = 'مراقبة حالة اتصال الفروع ومزامنة البيانات اللحظية';
  static const String loadingSyncStatus = 'جاري تحميل حالة المزامنة...';
  static const String syncDataProgress = 'مزامنة البيانات';
  static const String syncDataSubtitle = 'يتم الآن رفع العمليات المعلقة وتحديث الجداول';
  static const String tablesStatus = 'حالة الجداول';
  static const String pendingQueueFormat = 'طابور العمليات (%s)';
  static const String tablesStatusFormat = 'حالة جداول البيانات (%s)';
  static const String tablePrefix = 'جدول: ';
  static const String localRecordsFormat = '%s سجل محلي';
  static const String errorDetailsPrefix = 'تفاصيل الخطأ: ';
  static const String syncErrorPrefix = 'حدث خطأ أثناء مزامنة جدول %s:';
  static const String unknownError = 'خطأ غير معروف';
  static const String syncErrorTip = 'نصيحة: تأكد من وجود العمود المذكور في قاعدة البيانات السحابية أو قم بإعادة محاولة المزامنة.';
  
  // Status Labels
  static const String statusPending = 'بالطابور';
  static const String statusSynced = 'مزامن';
  static const String statusError = 'خطأ';
  static const String statusIdle = 'هادئ';

  // Table Names
  static const String tableMedicines = 'الأدوية';
  static const String tableSales = 'المبيعات';
  static const String tablePurchases = 'المشتريات';
  static const String tableShifts = 'ورديات الكاشير';
  static const String tableQuotes = 'عروض الأسعار';
  static const String tableInventory = 'المخزون';
  static const String tableReturns = 'المرتجعات';
  static const String tableBranches = 'الفروع';
  static const String tableUsers = 'الموظفين';
  static const String tablePermissions = 'الصلاحيات';
  static const String tableCustomers = 'العملاء';
  static const String tableSuppliers = 'الموردين';
  static const String tableCustomerSuppliers = 'عملاء/موردين';
  static const String tableCustomerLedgers = 'دفاتر العملاء';
  static const String tableSupplierLedgers = 'دفاتر الموردين';
}
