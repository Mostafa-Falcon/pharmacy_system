// sales_strings.dart — المبيعات، نقطة البيع (POS)، السلة، تقرير الوردية

class SalesStrings {
  SalesStrings._();

  // ─── Sales ───
  static const String salesTitle = 'كل المبيعات';
  static const String salesSubtitle =
      'متابعة وإدارة كافة عمليات البيع والتحصيلات وحالات الشحن.';
  static const String allSales = 'كل المبيعات';
  static const String shippingStatus = 'حالة الشحن';
  static const String paymentStatus = 'حالة الدفع';
  static const String shippingPending = 'في الانتظار';
  static const String paymentPaid = 'مدفوع';
  static const String paymentPartial = 'جزئي';
  static const String paymentUnpaid = 'غير مدفوع';
  static const String addedBy = 'أضيفت بواسطة';
  static const String contactNumber = 'رقم الاتصال';
  static const String paidAmount = 'مدفوعات المبيعات';
  static const String dueAmount = 'بلغ مستحق';
  static const String viewColumns = 'رؤية العمود';
  static const String inspect = 'فحص';
  static const String invoicePayments = 'دفعات الفاتورة';
  static const String invoiceViewLink = 'رابط عرض الفاتورة';
  static const String createReturn = 'إنشاء مرتجع';
  static const String editShipping = 'تعديل الشحن والتوصيل';
  static const String deliveryNote = 'إشعار التسليم';
  static const String convertToCredit = 'تحويل لآجل';
  static const String newSale = 'فاتورة بيع جديدة';
  static const String posTitle = 'نقطة البيع (الكاشير)';
  static const String invoiceNumberLabel = 'رقم الفاتورة';
  static const String customerNameLabel = 'اسم العميل';
  static const String paymentMethodLabel = 'طريقة الدفع';
  static const String finalTotal = 'الإجمالي النهائي';
  static const String totalInvoices = 'إجمالي الفواتير';
  static const String todaySales = 'مبيعات اليوم';
  static const String thisMonthSales = 'مبيعات الشهر';
  static const String creditSales = 'البيع الآجل';
  static const String quickFilter = 'تصفية سريعة:';
  static const String emptySalesTitle = 'سجل المبيعات فارغ';
  static const String emptySalesSubtitle =
      'سوف تظهر فواتير المبيعات هنا بمجرد إتمام عمليات البيع.';
  static const String noMatchingResults = 'لا توجد نتائج مطابقة لبحثك';
  static const String cashCustomer = 'عميل نقدي (عام)';
  static const String totalValue = 'القيمة الإجمالية';
  static const String dateTime = 'التاريخ والوقت';
  static const String viewDetails = 'عرض التفاصيل';
  static const String voidInvoice = 'إلغاء الفاتورة';
  static const String voidInvoiceTitle = 'إلغاء فاتورة بيع';
  static const String voidInvoiceConfirmPrefix =
      'هل أنت متأكد من إلغاء الفاتورة #';
  static const String voidInvoiceWarning =
      'سيتم استرجاع المخزون وتعديل القيود المالية.';
  static const String yesVoidNow = 'نعم، إلغاء الآن';

  // ─── POS Toolbar ───
  static const String posAddExpenses = 'إضافة المصاريف';
  static const String posItemInquiry = 'الاستعلام عن الأصناف';
  static const String posQuickItems = 'الأصناف السريعة';
  static const String posSuspendedSales = 'المبيعات المعلقة';
  static const String posRecentTransactions = 'آخر الحركات';
  static const String posCustomerPayment = 'تحصيل من عميل';
  static const String posLoadFromCustomer = 'تحميل من عميل';
  static const String posSupplierPayment = 'دفعة لمورد';
  static const String posSalesReturn = 'مرتجع المبيعات';
  static const String posCalculator = 'آلة حاسبة';
  static const String posHideProducts = 'إخفاء المنتجات';
  static const String posShowProducts = 'عرض المنتجات';
  static const String posExitFullScreen = 'خروج من الشاشة الكاملة';
  static const String posFullScreen = 'شاشة كاملة';
  static const String posSessionDetails = 'تفاصيل الجلسة';
  static const String posCloseShift = 'إنهاء الجلسة';

  // ─── POS Cart ───
  static const String cartTitle = 'السلة';
  static const String cartProduct = 'المنتج';
  static const String cartQuantity = 'الكمية';
  static const String cartPrice = 'السعر';
  static const String cartTotal = 'الإجمالي';
  static const String cartDiscount = 'الخصم';
  static const String cartItemsCount = 'البنود';
  static const String cartPaymentCash = 'نقداً';
  static const String cartPaymentCard = 'بطاقة';
  static const String cartPaymentCredit = 'آجل';
  static const String cartPaymentMixed = 'مختلط';
  static const String cartSuspend = 'تعليق';
  static const String cartPurchaseOrder = 'أمر شراء';
  static const String cartSalesOrder = 'أمر بيع';
  static const String cartPay = 'دفع';
  static const String cartVoid = 'إلغاء';
  static const String cartEditItem = 'تعديل';
  static const String cartDiscountPercent = 'نسبة';
  static const String cartDiscountFixed = 'قيمة مقطوعة';
  static const String cartSearchProduct = 'البحث عن منتج';
  static const String cartAddCustomer = 'إضافة عميل جديد';

  // ─── POS Cart Table ───
  static const String cartTableProduct = 'الصنف';
  static const String cartTableUnit = 'الوحدة';
  static const String cartEmptyTitle = 'السلة فارغة، ابدأ بإضافة المنتجات';

  // ─── POS Cart Panel (نصوص الواجهة الموحّدة) ───
  static const String cartEmptyHint = 'أضف أصناف من القائمة على اليسار';
  static const String discountOnInvoice = 'خصم على الفاتورة';
  static const String quickValuesLabel = 'قيم سريعة:';
  static const String taxOnInvoice = 'ضريبة على الفاتورة';
  static const String paymentMethodLabelCart = 'طريقة الدفع';
  static const String editUnitPrice = 'تعديل سعر الوحدة';

  // ─── POS Dialogs ───
  static const String noMatchingSearchResults = 'لا توجد نتائج بحث مطابقة';
  static const String addToCart = 'إضافة للسلة';
  static const String addExpensesFromCashier = 'إضافة مصاريف من الخزينة';
  static const String recordExpense = 'تسجيل المصروف';
  static const String invalidExpenseInput = 'يرجى إدخال وصف ومبلغ صحيح';
  static const String topRequestedItems = 'الأصناف الأكثر طلباً';
  static const String noItemsAvailable = 'لا توجد أصناف متوفرة حالياً';
  static const String noPendingSales = 'لا توجد مبيعات معلقة';
  static const String resumeSale = 'استئناف';
  static const String selectCustomerFirst = 'يرجى اختيار عميل أولاً من القائمة';
  static const String selectSupplierFirst = 'يرجى اختيار مورد أولاً من القائمة';
  static const String customerPaymentTitle = 'دفعة من عميل';
  static const String supplierPaymentTitle = 'دفعة لمورد';
  static const String recordPayment = 'تسجيل الدفعة';
  static const String additionalDiscount = 'خصم إضافي على الفاتورة';
  static const String cashDiscountValue = 'قيمة الخصم النقدي';
  static const String cancelDiscount = 'إلغاء الخصم';
  static const String applyDiscount = 'تطبيق الخصم';
  static const String recentOperations = 'آخر العمليات المسجلة';
  static const String salesInvoices = 'الفواتير';
  static const String priceQuotes = 'عروض الأسعار';
  static const String drafts = 'المسودات';
  static const String noSalesInvoices = 'لا توجد فواتير مبيعات مسجلة';
  static const String cashCustomerLabel = 'زبون نقدي';
  static const String noPriceQuotes = 'لا توجد عروض أسعار';
  static const String confirmDeleteQuote = 'هل أنت متأكد من حذف عرض السعر هذا؟';
  static const String noDraftsPending = 'لا توجد مسودات معلقة';
  static const String untitledDraft = 'مسودة بدون عنوان';
  static const String confirmDelete = 'تأكيد الحذف';
  static const String permanentDelete = 'حذف نهائي';

  // ─── Price Quotes (عروض الأسعار) ───
  static const String createQuoteTitle = 'إنشاء عرض سعر جديد';
  static const String quoteCustomerLabel = 'اسم العميل الموجه إليه العرض *';
  static const String quoteCustomerHint = 'مثلاً: شركة النور أو أحمد محمد';
  static const String quoteNotesLabel = 'ملاحظات إضافية';
  static const String quoteNotesHint = 'تظهر في أسفل العرض...';
  static const String quoteItemsSection = 'أصناف عرض السعر';
  static const String itemNameOrService = 'اسم الصنف / الخدمة';
  static const String quantityLabel = 'الكمية';
  static const String unitPriceLabel = 'سعر الوحدة';
  static const String totalLabel = 'الإجمالي';
  static const String addNewItemLine = 'إضافة سطر جديد للأصناف';
  static const String subtotalBeforeDiscount = 'المجموع قبل الخصم:';
  static const String discountValueLabel = 'قيمة الخصم:';
  static const String finalNetTotal = 'الصافي النهائي:';
  static const String saveAndIssueQuote = 'حفظ واصدار عرض السعر';
  static const String enterCustomerNameWarning = 'يرجى إدخال اسم العميل';
  static const String addAtLeastOneItemWarning = 'أضف صنف واحد صالح على الأقل';
  static const String deleteLineTooltip = 'حذف السطر';
  static const String itemOrSearchHint = 'اسم الصنف أو بحث...';
  static const String priceStockFormat = 'السعر: %s | المخزون: %s';

  // ─── Quote Status Labels ───
  static const String statusDraft = 'مسودة';
  static const String statusSent = 'مرسل';
  static const String statusAccepted = 'مقبول';
  static const String statusRejected = 'مرفوض';
  static const String quotesTitle = 'عروض الأسعار';
  static const String errorLoadingQuotes = 'خطأ في تحميل عروض الأسعار';
  static const String createQuoteAction = 'إنشاء عرض سعر';
  static const String quoteNumberTitleFormat = 'عرض سعر #%s — %s';
  static const String deleteQuoteTitle = 'حذف عرض السعر';
  static const String deleteQuoteConfirmFormat =
      'هل أنت متأكد من حذف عرض السعر رقم #%s؟';
  static const String packing = 'التغليف';
  static const String printInvoice = 'طباعة الفاتورة';
  static const String paymentInfo = 'معلومات الدفع:';
  static const String itemsTitle = 'الأصناف:';
  static const String saleDetailsTitle =
      'تفاصيل المبيعات ( الفاتورة رقم : %s )';
  static const String amountPaid = 'المبلغ المدفوع';
  static const String method = 'طريقة الدفع';

  // ─── POS Layout & Messages ───
  static const String stockLimitExceeded =
      'الكمية المطلوبة تتجاوز المخزون المتاح';
  static const String barcodeOrNameSearch = 'بحث بالباركود / الاسم...';
  static const String startTypingOrScan = 'ابدأ الكتابة أو امسح الباركود';
  static const String quickNavTooltip = 'التنقل السريع';
  static const String homeAction = 'الرئيسية';
  static const String hideCatalog = 'إخفاء الكتالوج';
  static const String showCatalog = 'عرض الكتالوج';
  static const String shiftInfoFormat = 'الوردية #%s — %s';
  static const String shiftIsClosed = 'الوردية مغلقة';
  static const String closeShiftTitle = 'غلق الوردية';
  static const String cashSalesLabel = 'المبيعات النقدية';
  static const String expectedCashLabel = 'النقدية المتوقعة';
  static const String actualCashLabel = 'النقدية الفعلية';
  static const String optionalNotesLabel = 'ملاحظات (اختياري)';
  static const String defaultSellPriceGroup = 'سعر البيع الافتراضي';
  static const String regularPriceLabel = 'السعر العادي (جمهور)';
  static const String wholesalePriceLabel = 'سعر الجملة المعتمد';
  static const String semiWholesalePriceLabel = 'سعر نصف الجملة';
  static const String fastCashCustomer = 'زبون نقدي (سريع)';
  static const String balanceFormat = 'الرصيد: %s';

  // ─── Sales Returns ───
  static const String salesReturnsTitle = 'مرتجعات المبيعات';
  static const String createReturnAction = 'إنشاء مرتجع';
  static const String searchReturnHintSales = 'بحث عن مرتجع أو فاتورة...';
  static const String totalReturnsLabel = 'إجمالي المرتجعات';
  static const String totalReturnedAmountsSales = 'إجمالي المبالغ المرتجعة';
  static const String returnNumberPrefix = 'مرتجع #';
  static const String createSalesReturnTitle = 'إنشاء مرتجع بيع';
  static const String selectOriginalInvoiceHint =
      'اختر الفاتورة الأصلية لإنشاء المرتجع';
  static const String selectInvoiceHint = 'اختر الفاتورة';
  static const String invoiceNumberDateFormat = 'فاتورة #%s - %s';
  static const String returnReasonLabel = 'سبب المرتجع';
  static const String reasonWrongItemSales = 'صنف خاطئ';
  static const String reasonCustomerReturn = 'مرتجع عميل';
  static const String confirmReturnAction = 'تأكيد المرتجع';
  static const String selectAtLeastOneItemError =
      'يرجى اختيار صنف واحد على الأقل';

  // ─── Open Shift ───
  static const String startNewShift = 'بدء وردية جديدة';
  static const String enterInitialCashHint =
      'يرجى إدخال الرصيد النقدي المتوفر في الدرج الآن';
  static const String openShiftAction = 'فتح وردية';
  static const String enterOpeningBalanceHint = 'أدخل الرصيد الافتتاحي';
  static const String shiftOpenedSuccess = 'تم فتح الوردية بنجاح';
  static const String shiftOpenFailedFormat = 'فشل فتح الوردية: %s';

  // ─── Cashier Register (سجل الكاشير) ───
  static const String cashierShiftsTitle = 'سجل الكاشير';
  static const String startNewSession = 'جلسة جديدة';
  static const String openCashier = 'فتح الكاشير';
  static const String openingDate = 'تاريخ الفتح';
  static const String openingCash = 'النقدية الافتتاحية';
  static const String closingDate = 'تاريخ الإغلاق';
  static const String closingCash = 'النقدية الختامية';
  static const String invoiceCount = 'عدد الفواتير';
  static const String totalReturns = 'إجمالي المرتجعات';
  static const String netAmount = 'الصافي';
  static const String saleType = 'بيع';
  static const String returnType = 'مرجع';

  // ─── Shift Report ───
  static const String shiftReportTitle = 'تقرير الوردية';
  static const String shiftCashSales = 'المبيعات النقدية';
  static const String shiftCardSales = 'مبيعات البطاقة';
  static const String shiftTotalSales = 'إجمالي المبيعات';
  static const String shiftExpenses = 'المصروفات';
  static const String shiftExpectedCash = 'المبلغ المتوقع';
  static const String shiftCountedCash = 'المبلغ الموجود';
  static const String shiftDifference = 'الفارق';
  static const String shiftClosed = 'الوردية مغلقة';
  static const String shiftOpened = 'الوردية مفتوحة';
  static const String shiftNoOpen = 'لا توجد وردية مفتوحة';
  static const String shiftOpenTitle = 'إدارة الورديات';
  static const String shiftViewDetails = 'عرض التفاصيل';

  static const String allReturns = 'كل المرتجعات';
  static const String cardSalesLabelShifts = 'مبيعات الشبكة';
  static const String creditSalesLabelShifts = 'مبيعات الآجل';
  static const String openLabel = 'مفتوحة';
  static const String closedLabel = 'مغلقة';
  static const String openingLabelShifts = 'الافتتاحي';
  static const String actualAmountPrefix = 'الفعلي';
  static const String noShiftsYet = 'لا توجد ورديات سابقة';
  static const String itemNameLabel = 'اسم الصنف';

  static const String searchSalesInvoicesHint =
      'بحث برقم الفاتورة، اسم العميل، أو صنف محدد...';
  static const String itemsLabelSales = 'الأصناف';
  static const String invoiceLabelSales = 'فاتورة';

  // ─── Promotions ───
  static const String promotionsTitle = 'العروض والترقيات';
  static const String createPromotion = 'إنشاء عرض جديد';
  static const String promotionNameLabel = 'اسم العرض';
  static const String promotionTypeLabel = 'نوع العرض';
  static const String promotionValueLabel = 'قيمة الخصم';
  static const String promotionStartDate = 'تاريخ البدء';
  static const String promotionEndDate = 'تاريخ الانتهاء';
  static const String promotionActiveLabel = 'نشط';
  static const String promotionInactiveLabel = 'غير نشط';
  static const String noPromotions = 'لا توجد عروض نشطة';
  static const String promotionDeleted = 'تم حذف العرض';
  static const String promotionCreated = 'تم إنشاء العرض';
  static const String promotionUpdated = 'تم تحديث العرض';
  static const String discountTypeLabel = 'نوع الخصم';
  static const String percentageLabel = 'نسبة';
  static const String fixedAmountLabel = 'قيمة ثابتة';
  static const String applyPromotion = 'تطبيق العرض';
  static const String removePromotion = 'إزالة العرض';
  static const String promotionApplied = 'تم تطبيق العرض';

  // ─── Damaged Stock ───
  static const String damagedStockTitle = 'الأصناف التالفة';
  static const String recordDamage = 'تسجيل تالف';
  static const String damageReasonLabel = 'سبب التلف';
  static const String damageQuantityLabel = 'الكمية التالفة';
  static const String damageNotesLabel = 'ملاحظات';
  static const String noDamagedStock = 'لا توجد أصناف تالفة مسجلة';
  static const String damageRecorded = 'تم تسجيل التلف';
  static const String damageDeleted = 'تم حذف سجل التالف';

  // ─── Opening Stock ───
  static const String openingStockTitle = 'الرصيد الافتتاحي';
  static const String recordOpeningStock = 'تسجيل رصيد افتتاحي';
  static const String openingQuantityLabel = 'الكمية الافتتاحية';
  static const String openingBuyPriceLabel = 'سعر الشراء';
  static const String noOpeningStock = 'لا توجد أرصدة افتتاحية مسجلة';
  static const String openingRecorded = 'تم تسجيل الرصيد الافتتاحي';
  static const String openingDeleted = 'تم حذف الرصيد الافتتاحي';
}
