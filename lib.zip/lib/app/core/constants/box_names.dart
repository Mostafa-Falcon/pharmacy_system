/// ثوابت أسماء صناديق Hive المستخدمة في المنظومة.
///
/// استخدم دائماً هذه الثوابت بدل الـ magic strings المتفرقة.
/// يضمن ذلك:
/// - تجنّب الأخطاء المطبعية (typos).
/// - إمكانية تغيير اسم صندوق من مكان واحد فقط.
/// - سهولة الاستيراد في أي ملف.
abstract final class BoxNames {
  BoxNames._();

  // ─── Security ────────────────────────────────────────────────────────
  static const String users       = 'users';
  static const String branches    = 'branches';
  static const String permissions = 'permissions';

  // ─── Inventory ────────────────────────────────────────────────────────
  static const String medicines    = 'medicines';
  static const String inventory    = 'inventory';
  static const String itemBatches  = 'item_batches';
  static const String stocktakings = 'stocktakings';
  static const String stocktakingPeriods = 'stocktaking_periods';
  static const String lookups      = 'lookups';
  static const String medicineUnits = 'medicine_units';

  // ─── Sales ────────────────────────────────────────────────────────────
  static const String sales         = 'sales';
  static const String purchases     = 'purchases';
  static const String returns       = 'returns';
  static const String cashierShifts = 'cashier_shifts';
  static const String quotes        = 'quotes';
  static const String suspendedSales = 'suspended_sales';

  // ─── Contacts ─────────────────────────────────────────────────────────
  static const String customers        = 'customers';
  static const String customerGroups   = 'customer_groups';
  static const String customerSuppliers = 'customer_suppliers';
  static const String suppliers        = 'suppliers';

  // ─── Ledgers ──────────────────────────────────────────────────────────
  static const String customerLedgers = 'customer_ledgers';
  static const String supplierLedgers = 'supplier_ledgers';

  // ─── CRM ──────────────────────────────────────────────────────────────
  static const String crmLeads      = 'crm_leads';
  static const String crmFollowUps  = 'crm_follow_ups';

  // ─── Archive & Tasks ──────────────────────────────────────────────────
  static const String archiveRecords = 'archive_records';
  static const String pharmacyTasks  = 'pharmacy_tasks';

  // ─── Admin ────────────────────────────────────────────────────────────
  static const String settings = 'settings';

  // ─── Sync ─────────────────────────────────────────────────────────────
  static const String syncQueue      = 'sync_queue';
  static const String syncDeadLetter = 'sync_dead_letter';
  static const String syncMeta       = '_sync_meta';
}
