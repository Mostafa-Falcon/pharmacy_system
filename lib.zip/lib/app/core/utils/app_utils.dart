import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum ScreenTier { mobile, tablet, desktop }

ScreenTier screenTier(BuildContext context) {
  final w = MediaQuery.of(context).size.width;
  if (w >= 992) return ScreenTier.desktop;
  if (w >= 768) return ScreenTier.tablet;
  return ScreenTier.mobile;
}

void safeDebugPrint(Object? object) {
  if (!kReleaseMode) debugPrint(object?.toString());
}
