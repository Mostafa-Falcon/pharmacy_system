import 'package:hive/hive.dart';

class PageableHiveBox<T> {
  final Box _box;
  final T Function(Map<String, dynamic>) fromJson;

  PageableHiveBox(this._box, this.fromJson);

  int get totalCount => _box.length;

  List<T> getAll() {
    return _box.values
        .map((e) => fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  List<T> getPage(int page, int pageSize) {
    final start = page * pageSize;
    final values = _box.values
        .skip(start)
        .take(pageSize)
        .map((e) => fromJson(Map<String, dynamic>.from(e)))
        .toList();
    return values;
  }

  List<String> getAllKeys() {
    return _box.keys.cast<String>().toList();
  }

  List<String> getPageKeys(int page, int pageSize) {
    final start = page * pageSize;
    return _box.keys.cast<String>().toList().skip(start).take(pageSize).toList();
  }

  List<T> getByKeys(List<String> keys) {
    return keys
        .map((k) => _box.get(k))
        .where((e) => e != null)
        .map((e) => fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  T? getById(String id) {
    final data = _box.get(id);
    if (data == null) return null;
    return fromJson(Map<String, dynamic>.from(data));
  }
}
