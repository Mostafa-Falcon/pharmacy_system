import 'package:toastification/toastification.dart';

import '../theme/app_colors.dart';
import '../constants/app_strings.dart';
import '../../../app/core/widgets/reusables/index.dart';

/// Helper Ù…ÙˆØ­Ù‘Ø¯ Ù„ÙƒÙ„ Ø§Ù„Ù€ Snackbars ÙÙŠ Ø§Ù„ØªØ·Ø¨ÙŠÙ‚.
/// ÙŠÙ‚ÙˆÙ… Ø¨Ø§Ù„Ø§Ø¹ØªÙ…Ø§Ø¯ Ø¹Ù„Ù‰ [ReusableSnackbar] Ù„ØªÙˆØ­ÙŠØ¯ Ø§Ù„ØªØµÙ…ÙŠÙ… ÙˆØ§Ù„Ù…ÙƒÙˆÙ†Ø§Øª Ø§Ù„Ù…Ø´ØªØ±ÙƒØ© ÙˆØªÙØ§Ø¯ÙŠ ØªÙƒØ±Ø§Ø± Ø§Ù„Ø£ÙƒÙˆØ§Ø¯.
class AppSnackbar {
  AppSnackbar._();

  static void _clear() {
    toastification.dismissAll();
  }

  static void success(String message, {String title = AppStrings.done}) {
    _clear();
    ReusableSnackbar.show(
      title,
      message,
      primaryColor: AppColors.success,
      type: ToastificationType.success,
    );
  }

  static void error(String message, {String title = AppStrings.error}) {
    _clear();
    ReusableSnackbar.show(
      title,
      message,
      primaryColor: AppColors.error,
      type: ToastificationType.error,
    );
  }

  static void warning(String message, {String title = AppStrings.warning}) {
    _clear();
    ReusableSnackbar.show(
      title,
      message,
      primaryColor: AppColors.warning,
      type: ToastificationType.warning,
    );
  }

  static void info(String message, {String title = AppStrings.information}) {
    _clear();
    ReusableSnackbar.show(
      title,
      message,
      primaryColor: AppColors.info,
      type: ToastificationType.info,
    );
  }
}
