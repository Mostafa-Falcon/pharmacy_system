import 'package:equatable/equatable.dart';

sealed class AsyncState<T> extends Equatable {
  const AsyncState();

  bool get isInitial => this is Initial<T>;
  bool get isLoading => this is Loading<T>;
  bool get isSuccess => this is Success<T>;
  bool get isFailure => this is Failure<T>;

  T? get dataOrNull => switch (this) {
        Success<T>(:final data) => data,
        Failure<T>(:final data) => data,
        _ => null,
      };

  String? get errorOrNull => switch (this) {
        Failure<T>(:final error) => error,
        _ => null,
      };

  @override
  List<Object?> get props => [];
}

final class Initial<T> extends AsyncState<T> {
  const Initial();
}

final class Loading<T> extends AsyncState<T> {
  final String? message;
  const Loading([this.message]);

  @override
  List<Object?> get props => [message];
}

final class Success<T> extends AsyncState<T> {
  final T data;
  const Success(this.data);

  @override
  List<Object?> get props => [data];
}

final class Failure<T> extends AsyncState<T> {
  final String error;
  final T? data;
  const Failure(this.error, [this.data]);

  @override
  List<Object?> get props => [error, data];
}
