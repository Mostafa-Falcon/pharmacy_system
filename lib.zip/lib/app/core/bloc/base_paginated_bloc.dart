import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'base_state.dart';

abstract class PaginatedEvent extends Equatable {
  const PaginatedEvent();

  @override
  List<Object?> get props => [];
}

class LoadItems extends PaginatedEvent {
  const LoadItems();
}

class SearchItems extends PaginatedEvent {
  final String query;
  const SearchItems(this.query);

  @override
  List<Object?> get props => [query];
}

class SortItems extends PaginatedEvent {
  final String column;
  const SortItems(this.column);

  @override
  List<Object?> get props => [column];
}

class GoToPage extends PaginatedEvent {
  final int page;
  const GoToPage(this.page);

  @override
  List<Object?> get props => [page];
}

class ChangePageSize extends PaginatedEvent {
  final int size;
  const ChangePageSize(this.size);

  @override
  List<Object?> get props => [size];
}

class NextPage extends PaginatedEvent {
  const NextPage();
}

class PreviousPage extends PaginatedEvent {
  const PreviousPage();
}

class ToggleSelectItem extends PaginatedEvent {
  final String id;
  const ToggleSelectItem(this.id);

  @override
  List<Object?> get props => [id];
}

class ToggleSelectAll extends PaginatedEvent {
  final bool? selected;
  const ToggleSelectAll([this.selected]);
}

class ClearSelection extends PaginatedEvent {
  const ClearSelection();
}

class PaginatedState<T> extends Equatable {
  final AsyncState<List<T>> dataState;
  final int page;
  final int pageSize;
  final int totalItems;
  final String sortColumn;
  final bool sortAscending;
  final String searchQuery;
  final Set<String> selectedIds;

  const PaginatedState({
    this.dataState = const Initial(),
    this.page = 0,
    this.pageSize = 50,
    this.totalItems = 0,
    this.sortColumn = '',
    this.sortAscending = true,
    this.searchQuery = '',
    this.selectedIds = const {},
  });

  List<T>? get items => dataState.dataOrNull;
  bool get isInitial => dataState.isInitial;
  bool get isLoading => dataState.isLoading;
  bool get isFailure => dataState.isFailure;
  String? get error => dataState.errorOrNull;
  int get totalPages => totalItems == 0 ? 1 : (totalItems / pageSize).ceil();
  bool get hasSelection => selectedIds.isNotEmpty;
  bool get isAllSelected => items != null && items!.isNotEmpty && selectedIds.length == items!.length;
  bool get hasPreviousPage => page > 0;
  bool get hasNextPage => page < totalPages - 1;

  List<T> currentPageItems(List<T> all) {
    final start = page * pageSize;
    if (start >= all.length) return [];
    final end = (start + pageSize).clamp(0, all.length);
    return all.sublist(start, end);
  }

  PaginatedState<T> copyWith({
    AsyncState<List<T>>? dataState,
    int? page,
    int? pageSize,
    int? totalItems,
    String? sortColumn,
    bool? sortAscending,
    String? searchQuery,
    Set<String>? selectedIds,
  }) {
    return PaginatedState<T>(
      dataState: dataState ?? this.dataState,
      page: page ?? this.page,
      pageSize: pageSize ?? this.pageSize,
      totalItems: totalItems ?? this.totalItems,
      sortColumn: sortColumn ?? this.sortColumn,
      sortAscending: sortAscending ?? this.sortAscending,
      searchQuery: searchQuery ?? this.searchQuery,
      selectedIds: selectedIds ?? this.selectedIds,
    );
  }

  @override
  List<Object?> get props => [
        dataState,
        page,
        pageSize,
        totalItems,
        sortColumn,
        sortAscending,
        searchQuery,
        selectedIds,
      ];
}

abstract class BasePaginatedBloc<T> extends Bloc<PaginatedEvent, PaginatedState<T>> {
  BasePaginatedBloc() : super(PaginatedState<T>()) {
    on<LoadItems>(_onLoad);
    on<SearchItems>(_onSearch);
    on<SortItems>(_onSort);
    on<GoToPage>(_onGoToPage);
    on<ChangePageSize>(_onChangePageSize);
    on<NextPage>(_onNextPage);
    on<PreviousPage>(_onPreviousPage);
    on<ToggleSelectItem>(_onToggleSelect);
    on<ToggleSelectAll>(_onToggleSelectAll);
    on<ClearSelection>(_onClearSelection);
  }

  Future<List<T>> fetchItems(PaginatedState<T> state);
  String itemId(T item);
  List<T> sortItems(List<T> items, String column, bool ascending);
  bool matchesSearch(T item, String query);

  Future<void> _onLoad(LoadItems event, Emitter<PaginatedState<T>> emit) async {
    emit(state.copyWith(dataState: const Loading()));
    try {
      final items = await fetchItems(state);
      emit(state.copyWith(
        dataState: Success(items),
        totalItems: items.length,
      ));
    } catch (e) {
      emit(state.copyWith(
        dataState: Failure(e.toString(), state.items),
      ));
    }
  }

  Future<void> _onSearch(SearchItems event, Emitter<PaginatedState<T>> emit) async {
    emit(state.copyWith(
      searchQuery: event.query,
      page: 0,
      selectedIds: const {},
    ));
    add(const LoadItems());
  }

  Future<void> _onSort(SortItems event, Emitter<PaginatedState<T>> emit) async {
    final ascending = state.sortColumn == event.column ? !state.sortAscending : true;
    emit(state.copyWith(
      sortColumn: event.column,
      sortAscending: ascending,
    ));
    add(const LoadItems());
  }

  void _onGoToPage(GoToPage event, Emitter<PaginatedState<T>> emit) {
    final page = event.page.clamp(0, state.totalPages - 1);
    emit(state.copyWith(page: page));
  }

  void _onChangePageSize(ChangePageSize event, Emitter<PaginatedState<T>> emit) {
    emit(state.copyWith(pageSize: event.size, page: 0));
  }

  void _onNextPage(NextPage event, Emitter<PaginatedState<T>> emit) {
    if (state.hasNextPage) {
      emit(state.copyWith(page: state.page + 1));
    }
  }

  void _onPreviousPage(PreviousPage event, Emitter<PaginatedState<T>> emit) {
    if (state.hasPreviousPage) {
      emit(state.copyWith(page: state.page - 1));
    }
  }

  void _onToggleSelect(ToggleSelectItem event, Emitter<PaginatedState<T>> emit) {
    final ids = Set<String>.from(state.selectedIds);
    if (ids.contains(event.id)) {
      ids.remove(event.id);
    } else {
      ids.add(event.id);
    }
    emit(state.copyWith(selectedIds: ids));
  }

  void _onToggleSelectAll(ToggleSelectAll event, Emitter<PaginatedState<T>> emit) {
    final items = state.items;
    if (items == null || items.isEmpty) return;

    if (event.selected == false || (event.selected == null && state.isAllSelected)) {
      emit(state.copyWith(selectedIds: const {}));
      return;
    }

    emit(state.copyWith(
      selectedIds: items.map((e) => itemId(e)).toSet(),
    ));
  }

  void _onClearSelection(ClearSelection event, Emitter<PaginatedState<T>> emit) {
    emit(state.copyWith(selectedIds: const {}));
  }
}
