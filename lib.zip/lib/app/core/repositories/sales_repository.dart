import 'package:hive/hive.dart';
import '../models/sales/sale_model.dart';
import '../services/inventory/stock_mutation_service.dart';
import 'base_repository.dart';

/// Repository للمبيعات - فصل عقد البيانات عن المنطق
/// مُحسنة للكفاءة العالية مع الكاش والـ Streams
class SalesRepository {
  const SalesRepository();
  static const String _boxName = 'sales';

  // ─── Query Methods ─────────────────────────────────────────────────

  /// الحصول على المبيعات مع الفلترة والبحث
  List<SaleModel> getSales({
    required String branchId,
    String? searchQuery,
    String? filter,
    bool includeDeleted = false,
  }) {
    var items = BaseRepository.getAllByBranch<SaleModel>(
      boxName: _boxName,
      branchId: branchId,
      includeDeleted: includeDeleted,
    );

    // فلترة البحث
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.trim().toLowerCase();
      items = items.where((s) => _matchesSearch(s, q)).toList();
    }

    // الفلاتر الزمنية
    final now = DateTime.now();
    if (filter == 'today') {
      items = items
          .where(
            (s) =>
                s.createdAt.day == now.day &&
                s.createdAt.month == now.month &&
                s.createdAt.year == now.year,
          )
          .toList();
    } else if (filter == 'this_month') {
      items = items
          .where(
            (s) =>
                s.createdAt.month == now.month && s.createdAt.year == now.year,
          )
          .toList();
    } else if (filter == 'credit') {
      items = items.where((s) => s.paymentMethod == 'credit').toList();
    }

    // ترتيب حسب التاريخ (الأحدث أولاً)
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return items;
  }

  /// مراقبة التغييرات في المبيعات
  Stream<List<SaleModel>> watchSales(String branchId) {
    return BaseRepository.watchBranch<SaleModel>(_boxName, branchId);
  }

  bool _matchesSearch(SaleModel sale, String query) {
    return sale.id.toLowerCase().contains(query) ||
        (sale.customerName?.toLowerCase().contains(query) ?? false) ||
        sale.items.any((i) => i.medicineName.toLowerCase().contains(query));
  }

  /// الحصول على فاتورة بالمعرف
  SaleModel? getById(String id) {
    final box = Hive.box(_boxName);
    final item = box.get(id);
    if (item is SaleModel) return item;
    return null;
  }

  /// الحصول على فاتورة بالمعرف (غير متزامن)
  Future<SaleModel?> getByIdAsync(String id) {
    return BaseRepository.getById<SaleModel>(_boxName, id);
  }

  // ─── CRUD Operations ─────────────────────────────────────────────────

  /// إضافة فاتورة جديدة
  Future<void> create(SaleModel sale, {required String branchId}) async {
    sale.lastModified = DateTime.now();
    await BaseRepository.create(
      boxName: _boxName,
      entity: sale,
      branchId: branchId,
      toJson: (s) => s.toJson(),
    );
  }

  /// تحديث فاتورة موجودة
  Future<void> update(SaleModel sale, {required String branchId}) async {
    sale.lastModified = DateTime.now();
    await BaseRepository.update(
      boxName: _boxName,
      entity: sale,
      branchId: branchId,
      toJson: (s) => s.toJson(),
    );
  }

  /// إلغاء فاتورة البيع - الإصلاح الجوهري: إرجاع المخزون تلقائيًا
  Future<void> voidSale(
    String saleId, {
    required String branchId,
  }) async {
    final sale = getById(saleId);
    if (sale == null) throw Exception('الفاتورة غير موجودة');

    // إرجاع المخزون
    for (final item in sale.items) {
      await StockMutationService.adjustStock(
        medicineId: item.medicineId,
        delta: item.quantity,
        branchId: branchId,
      );
    }

    // تعليم الفاتورة كمحذوفة
    final updated = sale.copyWith(
      isDeleted: true,
      lastModified: DateTime.now(),
    );

    await update(updated, branchId: branchId);
  }

  // ─── Statistics ───────────────────────────────────────────────────

  /// حساب الإحصائيات
  Map<String, dynamic> calculateStats(List<SaleModel> sales) {
    final now = DateTime.now();

    return {
      'totalCount': sales.length,
      'totalAmount': sales.fold(0.0, (sum, s) => sum + s.finalAmount),
      'todayTotal': sales
          .where(
            (s) =>
                s.createdAt.day == now.day &&
                s.createdAt.month == now.month &&
                s.createdAt.year == now.year,
          )
          .fold(0.0, (sum, s) => sum + s.finalAmount),
      'monthTotal': sales
          .where(
            (s) =>
                s.createdAt.month == now.month && s.createdAt.year == now.year,
          )
          .fold(0.0, (sum, s) => sum + s.finalAmount),
      'creditTotal': sales
          .where((s) => s.paymentMethod == 'credit')
          .fold(0.0, (sum, s) => sum + s.finalAmount),
    };
  }
}
