import 'package:hive/hive.dart';
import '../models/customer/customer_model.dart';
import '../services/sync_service.dart';
import '../../modules/archive/services/archive_service.dart';

/// Repository للعملاء - فصل عقد البيانات عن المنطق
/// مُحسنة للكفاءة العالية (العملاء عامة بدون branchId)
class CustomersRepository {
  const CustomersRepository();
  static const String _boxName = 'customers';

  // ─── Query Methods ─────────────────────────────────────────────────

  /// الحصول على العملاء مع الفلترة والبحث
  /// ملاحظة: العملاء عامة ولا يوجد branchId لديهم
  List<CustomerModel> getCustomers({
    String? searchQuery,
    bool includeInactive = true,
    bool includeDeleted = false,
  }) {
    var items = SyncService.getAllLocalData<CustomerModel>(boxName: _boxName);

    if (!includeDeleted) {
      items = items.where((c) => !c.isDeleted).toList();
    }

    // فلترة البحث
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.trim().toLowerCase();
      items = items.where((c) => _matchesSearch(c, q)).toList();
    }

    // فلترة غير النشطين
    if (!includeInactive) {
      items = items.where((c) => c.isActive).toList();
    }

    // ترتيب حسب الاسم
    items.sort((a, b) => a.name.compareTo(b.name));

    return items;
  }

  /// مراقبة التغييرات في العملاء
  Stream<List<CustomerModel>> watchCustomers() {
    return Hive.box(_boxName).watch().map((_) => getCustomers());
  }

  bool _matchesSearch(CustomerModel customer, String query) {
    return customer.name.toLowerCase().contains(query) ||
        (customer.phone?.contains(query) ?? false) ||
        (customer.companyName?.toLowerCase().contains(query) ?? false);
  }

  /// الحصول على عميل بالمعرف
  CustomerModel? getById(String id) {
    final box = Hive.box(_boxName);
    final item = box.get(id);
    if (item is CustomerModel) return item;
    return null;
  }

  /// الحصول على عميل بالمعرف (غير متزامن)
  Future<CustomerModel?> getByIdAsync(String id) async {
    try {
      return Hive.box(_boxName).get(id) as CustomerModel?;
    } catch (_) {
      return null;
    }
  }

  // ─── CRUD Operations ─────────────────────────────────────────────────

  /// إضافة عميل جديد
  Future<void> create(CustomerModel customer) async {
    customer.lastModified = DateTime.now();
    final box = Hive.box(_boxName);
    await box.put(customer.id, customer);

    await SyncService.queueOperation(
      type: SyncOperationType.create,
      table: _boxName,
      data: customer.toJson(),
      branchId: '',
    );
  }

  /// تحديث عميل موجود
  Future<void> update(CustomerModel customer) async {
    customer.lastModified = DateTime.now();
    final box = Hive.box(_boxName);
    await box.put(customer.id, customer);

    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: _boxName,
      data: customer.toJson(),
      branchId: '',
    );
  }

  /// حذف عميل (soft delete)
  Future<void> delete(CustomerModel customer) async {
    await ArchiveService.record(
      entityType: 'customer',
      entityId: customer.id,
      entityName: customer.name,
      entityData: customer.toJson(),
      branchId: '',
    );

    final box = Hive.box(_boxName);
    customer.lastModified = DateTime.now();
    customer.isDeleted = true;
    await box.put(customer.id, customer);

    final data = customer.toJson();
    data['is_deleted'] = true;
    await SyncService.queueOperation(
      type: SyncOperationType.delete,
      table: _boxName,
      data: data,
      branchId: '',
    );
  }

  // ─── Statistics ───────────────────────────────────────────────────

  /// الحصول على إحصائيات العملاء
  Map<String, int> getCustomersStats() {
    final customers = SyncService.getAllLocalData<CustomerModel>(
      boxName: _boxName,
    );

    return {
      'total': customers.length,
      'active': customers.where((c) => c.isActive).length,
      'inactive': customers.where((c) => !c.isActive).length,
      'credit': customers.where((c) => c.kind == CustomerKind.regular).length,
      'cash': customers.where((c) => c.kind == CustomerKind.cash).length,
    };
  }

  /// الحصول على الفئات (أنواع العملاء الفريدة)
  List<CustomerKind> getCustomerKinds() {
    final customers = SyncService.getAllLocalData<CustomerModel>(
      boxName: _boxName,
    );
    return customers.map((c) => c.kind).toSet().toList();
  }
}
