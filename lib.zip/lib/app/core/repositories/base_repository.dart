import 'dart:async';
import 'package:hive/hive.dart';
import '../services/sync_service.dart';

/// Base Repository - فئة أساسية لجميع الـ Repositories
/// توفر عمليات CRUD الأساسية مع دعم الكاش والـ Streams للكفاءة العالية
abstract class BaseRepository {
  /// تهيئة المستودع وربطه بنظام المزامنة للاستماع للتحديثات الحية
  static void init() {
    SyncService.onTableUpdated = notifyBranchUpdate;
  }

  // ─── Caching ───────────────────────────────────────────────────────
  static final Map<String, List<dynamic>> _cache = {};
  static final Map<String, DateTime> _cacheTimestamp = {};
  static const Duration _cacheTTL = Duration(seconds: 5);

  // ─── Streams for reactive updates ───────────────────────────────────
  static final Map<String, StreamController<List<dynamic>>> _controllers = {};

  /// مراقبة التغييرات في البيانات لفرع معين
  static Stream<List<T>> watchBranch<T>(String boxName, String branchId) {
    final key = '$boxName:$branchId';
    if (!_controllers.containsKey(key)) {
      _controllers[key] = StreamController<List<dynamic>>.broadcast();
    }
    return _controllers[key]!.stream.cast<List<T>>();
  }

  /// إبلاغ المشتركين بالتغييرات
  static void notifyBranchUpdate(String boxName, String branchId) {
    // إبطال الكاش فوراً لضمان تحميل البيانات الجديدة
    invalidateCache(branchId, specificBox: boxName);

    final key = '$boxName:$branchId';
    final controller = _controllers[key];
    if (controller != null && !controller.isClosed) {
      controller.add(getAllByBranchSync(boxName, branchId));
    }
  }

  // ─── Cache Management ───────────────────────────────────────────────

  /// الحصول على البيانات مع دعم الكاش
  static List<T> getAllByBranch<T>({
    required String boxName,
    required String branchId,
    bool includeDeleted = false,
  }) {
    final cacheKey = '$boxName:$branchId';
    final cached = _cache[cacheKey];
    final timestamp = _cacheTimestamp[cacheKey];

    if (cached != null && timestamp != null) {
      final age = DateTime.now().difference(timestamp);
      if (age < _cacheTTL) {
        return cached.cast<T>();
      }
    }

    final result = SyncService.getLocalData<T>(
      boxName: boxName,
      branchId: branchId,
      includeDeleted: includeDeleted,
    );

    _cache[cacheKey] = result;
    _cacheTimestamp[cacheKey] = DateTime.now();

    return result;
  }

  /// الحصول على البيانات بشكل متزامن (للـ Streams)
  static List<T> getAllByBranchSync<T>(String boxName, String branchId) {
    return getAllByBranch<T>(boxName: boxName, branchId: branchId);
  }

  /// إبطال الكاش للفرع
  static void invalidateCache(String branchId, {String? specificBox}) {
    if (specificBox != null) {
      _cache.remove('$specificBox:$branchId');
      _cacheTimestamp.remove('$specificBox:$branchId');
    } else {
      final keysToRemove = _cache.keys
          .where((k) => k.endsWith(':$branchId'))
          .toList();
      for (final key in keysToRemove) {
        _cache.remove(key);
        _cacheTimestamp.remove(key);
      }
    }
  }

  // ─── Generic CRUD Operations ───────────────────────────────────────

  static Future<T?> getById<T extends HiveObject>(
    String boxName,
    String id,
  ) async {
    try {
      return Hive.box(boxName).get(id) as T?;
    } catch (_) {
      return null;
    }
  }

  static Future<void> _persistAndSync<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required SyncOperationType operation,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
    bool awaitSync = true,
  }) async {
    final key = entity.key?.toString() ?? keyFromEntity?.call(entity) ?? _getId(entity);
    final box = Hive.box(boxName);

    if (operation == SyncOperationType.delete) {
      await box.delete(key);
    } else {
      await box.put(key, entity);
    }

    invalidateCache(branchId, specificBox: boxName);

    final jsonData = toJson(entity);
    if (operation == SyncOperationType.delete) {
      jsonData['is_deleted'] = true;
    }

    final queueFn = SyncService.queueOperation(
      type: operation,
      table: boxName,
      data: jsonData,
      branchId: branchId,
    );

    if (awaitSync) {
      await queueFn;
    } else {
      unawaited(queueFn);
    }

    notifyBranchUpdate(boxName, branchId);
  }

  static Future<void> create<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
  }) async {
    await _persistAndSync(
      boxName: boxName,
      entity: entity,
      branchId: branchId,
      operation: SyncOperationType.create,
      toJson: toJson,
      keyFromEntity: keyFromEntity,
      awaitSync: true,
    );
  }

  static Future<void> update<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
  }) async {
    await _persistAndSync(
      boxName: boxName,
      entity: entity,
      branchId: branchId,
      operation: SyncOperationType.update,
      toJson: toJson,
      keyFromEntity: keyFromEntity,
      awaitSync: true,
    );
  }

  static Future<void> delete<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
  }) async {
    await _persistAndSync(
      boxName: boxName,
      entity: entity,
      branchId: branchId,
      operation: SyncOperationType.delete,
      toJson: toJson,
      keyFromEntity: keyFromEntity,
      awaitSync: true,
    );
  }

  // ─── Fast Operations (بدون انتظار المزامنة) ─────────────────────────

  static Future<void> createFast<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
  }) async {
    await _persistAndSync(
      boxName: boxName,
      entity: entity,
      branchId: branchId,
      operation: SyncOperationType.create,
      toJson: toJson,
      keyFromEntity: keyFromEntity,
      awaitSync: false,
    );
  }

  static Future<void> updateFast<T extends HiveObject>({
    required String boxName,
    required T entity,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
  }) async {
    await _persistAndSync(
      boxName: boxName,
      entity: entity,
      branchId: branchId,
      operation: SyncOperationType.update,
      toJson: toJson,
      keyFromEntity: keyFromEntity,
      awaitSync: false,
    );
  }

  // ─── Batch Operations ───────────────────────────────────────────────

  static Future<void> batchCreate<T extends HiveObject>({
    required String boxName,
    required List<T> entities,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
    bool skipSync = false,
  }) async {
    final box = Hive.box(boxName);
    final Map<String, T> batchData = {};

    for (final entity in entities) {
      final key = entity.key?.toString() ?? keyFromEntity?.call(entity) ?? _getId(entity);
      batchData[key] = entity;
    }

    await box.putAll(batchData);
    invalidateCache(branchId, specificBox: boxName);

    if (!skipSync) {
      for (final entity in entities) {
        unawaited(
          SyncService.queueOperation(
            type: SyncOperationType.create,
            table: boxName,
            data: toJson(entity),
            branchId: branchId,
          ),
        );
      }
    }

    notifyBranchUpdate(boxName, branchId);
  }

  static Future<void> batchUpdate<T extends HiveObject>({
    required String boxName,
    required List<T> entities,
    required String branchId,
    required Map<String, dynamic> Function(T) toJson,
    String Function(T)? keyFromEntity,
    bool skipSync = false,
  }) async {
    final box = Hive.box(boxName);
    final Map<String, T> batchData = {};

    for (final entity in entities) {
      final key = entity.key?.toString() ?? keyFromEntity?.call(entity) ?? _getId(entity);
      batchData[key] = entity;
    }

    await box.putAll(batchData);
    invalidateCache(branchId, specificBox: boxName);

    if (!skipSync) {
      for (final entity in entities) {
        unawaited(
          SyncService.queueOperation(
            type: SyncOperationType.update,
            table: boxName,
            data: toJson(entity),
            branchId: branchId,
          ),
        );
      }
    }

    notifyBranchUpdate(boxName, branchId);
  }

  // ─── Helper Methods ───────────────────────────────────────────────

  static int _batchCounter = 0;

  static String _getId<T extends HiveObject>(T entity) {
    return entity.key?.toString() ??
        '${DateTime.now().millisecondsSinceEpoch}_${_batchCounter++}';
  }

  /// يغلق كل الـ StreamControllers المفتوحة عشان ما يحصلش تسرب للذاكرة
  /// (memory leak) مع مرور الوقت — كل فرع/جدول بيعمل controller جديد.
  /// يُستدعى عند خروج المستخدم أو تدمير المنظومة.
  static void dispose() {
    for (final controller in _controllers.values) {
      if (!controller.isClosed) controller.close();
    }
    _controllers.clear();
    _cache.clear();
    _cacheTimestamp.clear();
  }
}
