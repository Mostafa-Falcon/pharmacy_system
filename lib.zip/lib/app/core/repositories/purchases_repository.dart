import 'package:hive/hive.dart';
import '../models/sales/purchase_model.dart';
import '../services/inventory/stock_mutation_service.dart';
import '../services/supplier/supplier_ledger_service.dart';
import 'base_repository.dart';
import '../../modules/archive/services/archive_service.dart';

/// Repository للمشتريات - فصل عقد البيانات عن المنطق
/// مُحسنة للكفاءة العالية مع الكاش والـ Streams
class PurchasesRepository {
  const PurchasesRepository();
  static const String _boxName = 'purchases';

  // ─── Query Methods ─────────────────────────────────────────────────

  /// الحصول على المشتريات مع الفلترة والبحث
  List<PurchaseModel> getPurchases({
    required String branchId,
    String? searchQuery,
    String? filter,
    bool includeDeleted = false,
  }) {
    var items = BaseRepository.getAllByBranch<PurchaseModel>(
      boxName: _boxName,
      branchId: branchId,
      includeDeleted: includeDeleted,
    );

    // فلترة البحث
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.trim().toLowerCase();
      items = items.where((p) => _matchesSearch(p, q)).toList();
    }

    // الفلاتر الزمنية
    final now = DateTime.now();
    if (filter == 'today') {
      items = items
          .where(
            (p) =>
                p.createdAt.day == now.day &&
                p.createdAt.month == now.month &&
                p.createdAt.year == now.year,
          )
          .toList();
    } else if (filter == 'this_month') {
      items = items
          .where(
            (p) =>
                p.createdAt.month == now.month && p.createdAt.year == now.year,
          )
          .toList();
    } else if (filter == 'completed') {
      items = items.where((p) => p.status == 'completed').toList();
    }

    // ترتيب حسب التاريخ (الأحدث أولاً)
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return items;
  }

  /// مراقبة التغييرات في المشتريات
  Stream<List<PurchaseModel>> watchPurchases(String branchId) {
    return BaseRepository.watchBranch<PurchaseModel>(_boxName, branchId);
  }

  bool _matchesSearch(PurchaseModel purchase, String query) {
    return purchase.id.toLowerCase().contains(query) ||
        purchase.supplierName.toLowerCase().contains(query) ||
        (purchase.supplierPhone?.contains(query) ?? false) ||
        purchase.items.any((i) => i.medicineName.toLowerCase().contains(query));
  }

  /// الحصول على فاتورة بالمعرف
  PurchaseModel? getById(String id) {
    final box = Hive.box(_boxName);
    final item = box.get(id);
    if (item is PurchaseModel) return item;
    return null;
  }

  /// الحصول على فاتورة بالمعرف (غير متزامن)
  Future<PurchaseModel?> getByIdAsync(String id) {
    return BaseRepository.getById<PurchaseModel>(_boxName, id);
  }

  // ─── CRUD Operations ─────────────────────────────────────────────────

  /// إضافة فاتورة مشتريات جديدة
  Future<void> create(
    PurchaseModel purchase, {
    required String branchId,
  }) async {
    purchase.lastModified = DateTime.now();
    await BaseRepository.create(
      boxName: _boxName,
      entity: purchase,
      branchId: branchId,
      toJson: (p) => p.toJson(),
    );
  }

  /// تحديث فاتورة موجودة
  Future<void> update(
    PurchaseModel purchase, {
    required String branchId,
  }) async {
    purchase.lastModified = DateTime.now();
    await BaseRepository.update(
      boxName: _boxName,
      entity: purchase,
      branchId: branchId,
      toJson: (p) => p.toJson(),
    );
  }

  /// إلغاء فاتورة مشتريات - يرجع المخزون إذا كانت الحالة received
  /// ويعكس ديون المورد (المبلغ المتبقي المستحق) في الكشف الحسابي.
  Future<void> voidPurchase(
    String purchaseId, {
    required String branchId,
  }) async {
    final purchase = getById(purchaseId);
    if (purchase == null) throw Exception('الفاتورة غير موجودة');

    if (purchase.status == 'received') {
      // إرجاع المخزون إذا كانت الحالة received
      for (final item in purchase.items) {
        await StockMutationService.adjustStock(
          medicineId: item.medicineId,
          delta: -item.quantity,
          branchId: branchId,
        );
      }
    }

    // عكس ديون المورد المستحقة (المبلغ المتبقي بعد السداد)
    final dueAmount = purchase.remainingAmount;
    if (purchase.supplierId != null && dueAmount > 0.0001) {
      await SupplierLedgerService.recordPurchaseVoid(
        supplierId: purchase.supplierId!,
        branchId: branchId,
        purchaseId: purchaseId,
        invoiceNumber: purchaseId,
        dueAmount: double.parse(dueAmount.toStringAsFixed(2)),
        createdBy: purchase.createdBy,
      );
    }

    await ArchiveService.record(
      entityType: 'purchase',
      entityId: purchase.id,
      entityName: 'فاتورة #${purchase.id.substring(0, 8)}',
      entityData: purchase.toJson(),
      branchId: branchId,
    );

    // تعليم الفاتورة كمحذوفة
    purchase.lastModified = DateTime.now();
    purchase.isDeleted = true;

    await update(purchase, branchId: branchId);
  }

  // ─── Statistics ───────────────────────────────────────────────────

  /// حساب الإحصائيات
  Map<String, dynamic> calculateStats(List<PurchaseModel> purchases) {
    final now = DateTime.now();

    return {
      'totalCount': purchases.length,
      'totalAmount': purchases.fold(0.0, (sum, p) => sum + p.finalAmount),
      'todayCount': purchases
          .where(
            (p) =>
                p.createdAt.day == now.day &&
                p.createdAt.month == now.month &&
                p.createdAt.year == now.year,
          )
          .length,
      'todayAmount': purchases
          .where(
            (p) =>
                p.createdAt.day == now.day &&
                p.createdAt.month == now.month &&
                p.createdAt.year == now.year,
          )
          .fold(0.0, (sum, p) => sum + p.finalAmount),
      'monthCount': purchases
          .where(
            (p) =>
                p.createdAt.month == now.month && p.createdAt.year == now.year,
          )
          .length,
      'monthAmount': purchases
          .where(
            (p) =>
                p.createdAt.month == now.month && p.createdAt.year == now.year,
          )
          .fold(0.0, (sum, p) => sum + p.finalAmount),
    };
  }

  /// الحصول على الموردين الفريدين
  List<String> getSuppliers(String branchId) {
    final purchases = BaseRepository.getAllByBranch<PurchaseModel>(
      boxName: _boxName,
      branchId: branchId,
    );

    return purchases.map((p) => p.supplierName).toSet().toList()..sort();
  }
}
