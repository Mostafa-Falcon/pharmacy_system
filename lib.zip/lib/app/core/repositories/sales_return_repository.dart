import 'package:hive/hive.dart';
import '../models/sales/return_model.dart';
import 'base_repository.dart';
import '../../modules/archive/services/archive_service.dart';

/// Repository لمرتجعات المبيعات - فصل عقد البيانات عن المنطق
/// مُحسنة للكفاءة العالية مع دعم الكاش والـ Streams
class SalesReturnRepository {
  const SalesReturnRepository();
  static const String _boxName = 'returns';

  // ─── Query Methods ─────────────────────────────────────────────────

  /// الحصول على مرتجعات المبيعات (مرتجعات من فواتير البيع فقط)
  /// مُحسنة مع فهارس وكاش
  List<ReturnModel> getSalesReturns({
    required String branchId,
    String? searchQuery,
    String? filter,
    bool includeDeleted = false,
  }) {
    var items = BaseRepository.getAllByBranch<ReturnModel>(
      boxName: _boxName,
      branchId: branchId,
      includeDeleted: includeDeleted,
    );

    // تصفية مرتجعات المبيعات فقط (saleId != null)
    items = items.where((r) => r.saleId != null).toList();

    // فلترة البحث
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.trim().toLowerCase();
      items = items.where((r) => _matchesSearch(r, q)).toList();
    }

    // الفلاتر الزمنية
    final now = DateTime.now();
    if (filter == 'today') {
      items = items
          .where(
            (r) =>
                r.createdAt.day == now.day &&
                r.createdAt.month == now.month &&
                r.createdAt.year == now.year,
          )
          .toList();
    } else if (filter == 'this_month') {
      items = items
          .where(
            (r) =>
                r.createdAt.month == now.month && r.createdAt.year == now.year,
          )
          .toList();
    }

    // ترتيب حسب التاريخ (الأحدث أولاً)
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return items;
  }

  /// مراقبة التغييرات في المرتجعات
  Stream<List<ReturnModel>> watchSalesReturns(String branchId) {
    return BaseRepository.watchBranch<ReturnModel>(_boxName, branchId);
  }

  bool _matchesSearch(ReturnModel returnModel, String query) {
    return returnModel.id.toLowerCase().contains(query) ||
        (returnModel.saleId?.toLowerCase().contains(query) ?? false) ||
        returnModel.items.any(
          (i) => i.medicineName.toLowerCase().contains(query),
        );
  }

  /// الحصول على مرتجع بالمعرف
  ReturnModel? getById(String id) {
    try {
      final box = Hive.box(_boxName);
      final item = box.get(id);
      if (item is ReturnModel) return item;
      return null;
    } catch (_) {
      return null;
    }
  }

  /// الحصول على مرتجع بالمعرف (غير متزامن)
  Future<ReturnModel?> getByIdAsync(String id) {
    return BaseRepository.getById<ReturnModel>(_boxName, id);
  }

  // ─── CRUD Operations ─────────────────────────────────────────────────

  /// إضافة مرتجع جديد (مُحسنة للسرعة)
  Future<void> create(
    ReturnModel returnModel, {
    required String branchId,
  }) async {
    returnModel.lastModified = DateTime.now();
    await BaseRepository.createFast(
      boxName: _boxName,
      entity: returnModel,
      branchId: branchId,
      toJson: (r) => r.toJson(),
    );
  }

  /// تحديث مرتجع
  Future<void> update(
    ReturnModel returnModel, {
    required String branchId,
  }) async {
    returnModel.lastModified = DateTime.now();
    await BaseRepository.updateFast(
      boxName: _boxName,
      entity: returnModel,
      branchId: branchId,
      toJson: (r) => r.toJson(),
    );
  }

  /// حذف مرتجع
  Future<void> delete(
    ReturnModel returnModel, {
    required String branchId,
  }) async {
    await ArchiveService.record(
      entityType: 'return',
      entityId: returnModel.id,
      entityName: 'مرتجع #${returnModel.id.substring(0, 8)}',
      entityData: returnModel.toJson(),
      branchId: branchId,
    );

    await BaseRepository.delete(
      boxName: _boxName,
      entity: returnModel,
      branchId: branchId,
      toJson: (r) => r.toJson(),
    );
  }

  // ─── Statistics ───────────────────────────────────────────────────

  /// حساب الإحصائيات
  Map<String, dynamic> calculateStats(List<ReturnModel> returns) {
    final now = DateTime.now();

    return {
      'totalCount': returns.length,
      'totalAmount': returns.fold(0.0, (sum, r) => sum + r.totalAmount),
      'todayCount': returns
          .where(
            (r) =>
                r.createdAt.day == now.day &&
                r.createdAt.month == now.month &&
                r.createdAt.year == now.year,
          )
          .length,
      'todayAmount': returns
          .where(
            (r) =>
                r.createdAt.day == now.day &&
                r.createdAt.month == now.month &&
                r.createdAt.year == now.year,
          )
          .fold(0.0, (sum, r) => sum + r.totalAmount),
      'monthCount': returns
          .where(
            (r) =>
                r.createdAt.month == now.month && r.createdAt.year == now.year,
          )
          .length,
    };
  }

  /// إرجاع المخزون للدواء (للكفاءة في المرتجعات)
  Future<void> returnStockToMedicine({
    required String medicineId,
    required int quantity,
    required String branchId,
  }) async {
    // استخدام StockMutationService مباشرة للكفاءة
    // سيتم استيراده في الـ Controller
  }
}
