import 'dart:async';
import 'package:hive/hive.dart';
import '../models/inventory/medicine_model.dart';
import '../services/inventory/stock_mutation_service.dart';
import '../services/sync_service.dart';
import 'base_repository.dart';
import '../../modules/archive/services/archive_service.dart';

/// Repository للأدوية - فصل عقد البيانات عن المنطق
/// مُحسنة للكفاءة العالية مع الكاش والـ Streams
class MedicinesRepository {
  const MedicinesRepository();
  static const String _boxName = 'medicines';

  // ─── Query Methods ─────────────────────────────────────────────────

  /// الحصول على الأدوية مع الفلترة والبحث (مُحسنة للأداء)
  List<MedicineModel> getMedicines({
    required String branchId,
    String? searchQuery,
    String? category,
    bool includeDeleted = false,
  }) {
    var items = BaseRepository.getAllByBranch<MedicineModel>(
      boxName: _boxName,
      branchId: branchId,
      includeDeleted: includeDeleted,
    );

    // فلترة البحث
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.trim().toLowerCase();
      items = items.where((m) => _matchesSearch(m, q)).toList();
    }

    // فلترة الفئة
    if (category != null) {
      items = items.where((m) => m.category == category).toList();
    }

    // ترتيب حسب الصلاحية (FIFO)
    items.sort((a, b) {
      if (a.expiryDate == null && b.expiryDate == null) return 0;
      if (a.expiryDate == null) return 1;
      if (b.expiryDate == null) return -1;
      return a.expiryDate!.compareTo(b.expiryDate!);
    });

    return items;
  }

  /// مراقبة التغييرات في الأدوية
  Stream<List<MedicineModel>> watchMedicines(String branchId) {
    return BaseRepository.watchBranch<MedicineModel>(_boxName, branchId);
  }

  bool _matchesSearch(MedicineModel medicine, String query) {
    return medicine.name.toLowerCase().contains(query) ||
        (medicine.nameEn?.toLowerCase().contains(query) ?? false) ||
        medicine.barcodes.any((b) => b.toLowerCase().contains(query));
  }

  /// الحصول على عنصر بالمعرف
  MedicineModel? getById(String id) {
    final box = Hive.box(_boxName);
    final item = box.get(id);
    if (item is MedicineModel) return item;
    return null;
  }

  /// الحصول على عنصر بالمعرف (غير متزامن)
  Future<MedicineModel?> getByIdAsync(String id) {
    return BaseRepository.getById<MedicineModel>(_boxName, id);
  }

  // ─── CRUD Operations ─────────────────────────────────────────────────

  /// إضافة دواء جديد (مُحسنة للسرعة)
  Future<void> create(
    MedicineModel medicine, {
    required String branchId,
  }) async {
    medicine.lastModified = DateTime.now();
    await BaseRepository.createFast(
      boxName: _boxName,
      entity: medicine,
      branchId: branchId,
      toJson: (m) => m.toJson(),
      keyFromEntity: (m) => m.id,
    );
  }

  /// تحديث دواء موجود
  Future<void> update(
    MedicineModel medicine, {
    required String branchId,
  }) async {
    medicine.lastModified = DateTime.now();
    await BaseRepository.update(
      boxName: _boxName,
      entity: medicine,
      branchId: branchId,
      toJson: (m) => m.toJson(),
      keyFromEntity: (m) => m.id,
    );
  }

  /// حذف دواء (soft delete) — يحتفظ بالدواء في Hive بـ isDeleted=true
  /// بدل مسحه من Hive أولاً والتسبب في مشكلة رجوعه بعد الـ pull لو sync فشلت
  Future<void> delete(
    MedicineModel medicine, {
    required String branchId,
  }) async {
    await ArchiveService.record(
      entityType: 'medicine',
      entityId: medicine.id,
      entityName: medicine.name,
      entityData: medicine.toJson(),
      branchId: branchId,
    );

    final updated = medicine.copyWith(
      isDeleted: true,
      lastModified: DateTime.now(),
    );
    final box = Hive.box(_boxName);
    await box.put(medicine.id, updated);
    BaseRepository.invalidateCache(branchId, specificBox: _boxName);

    final jsonData = updated.toJson();
    await SyncService.queueOperation(
      type: SyncOperationType.delete,
      table: _boxName,
      data: jsonData,
      branchId: branchId,
    );

    BaseRepository.notifyBranchUpdate(_boxName, branchId);
  }

  // ─── Stock Management ───────────────────────────────────────────────

  /// تحديث كمية الدواء مباشرة
  Future<void> updateQuantity({
    required String medicineId,
    required int delta,
    required String branchId,
  }) async {
    final medicine = getById(medicineId);
    if (medicine == null) return;

    final updated = medicine.copyWith(
      quantity: medicine.quantity + delta,
      lastModified: DateTime.now(),
    );

    await update(updated, branchId: branchId);

    // تحديث خلاصة المخزون
    StockMutationService.adjustStock(
      medicineId: medicineId,
      delta: delta,
      branchId: branchId,
    );
  }

  /// تحديث كمية متعددة دواء (عملية مجمعة للكفاءة)
  Future<void> batchUpdateQuantities({
    required List<String> medicineIds,
    required List<int> deltas,
    required String branchId,
  }) async {
    if (medicineIds.length != deltas.length) return;

    final box = Hive.box(_boxName);
    final Map<String, MedicineModel> batchData = {};

    for (int i = 0; i < medicineIds.length; i++) {
      final medicine = getById(medicineIds[i]);
      if (medicine != null) {
        final updated = medicine.copyWith(
          quantity: medicine.quantity + deltas[i],
          lastModified: DateTime.now(),
        );
        batchData[medicineIds[i]] = updated;
      }
    }

    await box.putAll(batchData);
    BaseRepository.invalidateCache(branchId, specificBox: _boxName);
    BaseRepository.notifyBranchUpdate(_boxName, branchId);
  }

  // ─── Statistics ───────────────────────────────────────────────────

  /// الحصول على إحصائيات المخزون
  Map<String, int> getStockStats(String branchId) {
    final medicines = BaseRepository.getAllByBranch<MedicineModel>(
      boxName: _boxName,
      branchId: branchId,
    );
    final now = DateTime.now();

    return {
      'total': medicines.length,
      'lowStock': medicines.where((m) => m.quantity <= m.minStock).length,
      'outOfStock': medicines.where((m) => m.quantity <= 0).length,
      'expiring': medicines
          .where(
            (m) =>
                m.expiryDate != null &&
                m.expiryDate!.isAfter(now) &&
                m.expiryDate!.difference(now).inDays <= 90,
          )
          .length,
      'expired': medicines
          .where((m) => m.expiryDate != null && m.expiryDate!.isBefore(now))
          .length,
    };
  }

  /// الحصول على الفئات الفريدة
  List<String> getCategories(String branchId) {
    final items = BaseRepository.getAllByBranch<MedicineModel>(
      boxName: _boxName,
      branchId: branchId,
    );

    return items.map((m) => m.category).whereType<String>().toSet().toList()
      ..sort();
  }

  /// إضافة قائمة أدوية جديدة دفعة واحدة (عملية مجمعة للكفاءة)
  Future<void> batchCreate(List<MedicineModel> medicines, {required String branchId, bool skipSync = false}) async {
    await BaseRepository.batchCreate<MedicineModel>(
      boxName: _boxName,
      entities: medicines,
      branchId: branchId,
      toJson: (m) => m.toJson(),
      keyFromEntity: (m) => m.id,
      skipSync: skipSync,
    );
  }

  /// تحديث قائمة أدوية موجودة دفعة واحدة (عملية مجمعة للكفاءة)
  Future<void> batchUpdate(List<MedicineModel> medicines, {required String branchId, bool skipSync = false}) async {
    await BaseRepository.batchUpdate<MedicineModel>(
      boxName: _boxName,
      entities: medicines,
      branchId: branchId,
      toJson: (m) => m.toJson(),
      keyFromEntity: (m) => m.id,
      skipSync: skipSync,
    );
  }
}
