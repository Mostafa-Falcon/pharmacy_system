import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../bloc/auth_bloc.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/widgets/index.dart';
import '../../../routes/app_routes.dart';
import 'widgets/signup_form.dart';
import 'widgets/signup_promo_panel.dart';

class SignupView extends StatelessWidget {
  const SignupView({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isWeb = size.width >= 900;

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        switch (state.status) {
          case AuthStatus.authenticated:
            final user = state.user;
            if (user != null && user.isOwner) {
              context.go(Routes.ADMIN_DASHBOARD);
            } else {
              context.go(Routes.EMPLOYEE_DASHBOARD);
            }
            break;
          case AuthStatus.error:
            if (state.error != null) {
              AppSnackbar.error(state.error!);
              // نمسح الخطأ بعد عرضه عشان ما يتكررش الـ snackbar عند أي إعادة بناء.
              context.read<AuthBloc>().add(const AuthErrorDisplayed());
            }
            break;
          default:
            break;
        }
      },
      child: AppScaffold(
        showBackButton: false,
        body: Row(
          children: [
            // القسم التعريفي (يظهر فقط على الشاشات الكبيرة)
            if (isWeb)
              const Expanded(
                flex: 10,
                child: SignupPromoPanel(),
              ),

            // قسم فورم إنشاء الحساب
            const Expanded(
              flex: 8,
              child: SignupForm(),
            ),
          ],
        ),
      ),
    );
  }
}

