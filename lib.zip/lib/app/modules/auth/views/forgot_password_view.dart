import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../bloc/auth_bloc.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/index.dart';
import 'widgets/forgot_password_form.dart';

class ForgotPasswordView extends StatelessWidget {
  const ForgotPasswordView({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isWeb = size.width >= 800;
    final isDark = AppColors.isDark(context);

    return PopScope(
      canPop: true,
      child: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state.status == AuthStatus.error && state.error != null) {
            AppSnackbar.error(state.error!);
          }
        },
        child: AppScaffold(
          showBackButton: !isWeb, // إخفاء زر الهيدر العادي على الويب
          body: Stack(
            children: [
              // خلفية مع التوهج الفخم في حالة الويب
              if (isWeb)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: isDark
                            ? [
                                AppColors.surfaceTintDark,
                                AppColors.surfaceTintDarkAlt,
                                AppColors.surfaceTintDarkDeep
                              ]
                            : [
                                AppColors.surfaceTintDarkNavy,
                                AppColors.primary,
                                AppColors.info
                              ],
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          top: -100,
                          right: -50,
                          child: Container(
                            width: 350,
                            height: 350,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white
                                  .withValues(alpha: isDark ? 0.02 : 0.05),
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: -80,
                          left: -80,
                          child: Container(
                            width: 350,
                            height: 350,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black
                                  .withValues(alpha: isDark ? 0.2 : 0.08),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // المحتوى الأساسي الممركز
              Center(
                child: SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  padding: const EdgeInsets.all(24),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: isWeb ? 520 : 380.w,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                            sigmaX: isWeb ? 15 : 0, sigmaY: isWeb ? 15 : 0),
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: isWeb ? 40 : 16.w,
                            vertical: isWeb ? 48 : 24.h,
                          ),
                          decoration: BoxDecoration(
                            color: isWeb
                                ? (isDark
                                    ? AppColors.surfaceTintDarkAlt
                                        .withValues(alpha: 0.5)
                                    : Colors.white.withValues(alpha: 0.75))
                                : theme.scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(isWeb ? 24 : 0),
                            border: isWeb
                                ? Border.all(
                                    color: isDark
                                        ? Colors.white.withValues(alpha: 0.08)
                                        : Colors.black.withValues(alpha: 0.05),
                                    width: 1.5,
                                  )
                                : null,
                            boxShadow: isWeb
                                ? [
                                    BoxShadow(
                                      color: Colors.black.withValues(
                                          alpha: isDark ? 0.25 : 0.08),
                                      blurRadius: 40,
                                      offset: const Offset(0, 16),
                                    ),
                                  ]
                                : null,
                          ),
                          child: const ForgotPasswordForm(),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


