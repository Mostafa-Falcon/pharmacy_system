import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import '../../bloc/auth_bloc.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/index.dart';
import '../../../../routes/app_routes.dart';

class ForgotPasswordForm extends StatefulWidget {
  const ForgotPasswordForm({super.key});

  @override
  State<ForgotPasswordForm> createState() => _ForgotPasswordFormState();
}

class _ForgotPasswordFormState extends State<ForgotPasswordForm> {
  final _emailController = TextEditingController();
  final _emailFocus = FocusNode();

  @override
  void dispose() {
    _emailController.dispose();
    _emailFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isWeb = size.width >= 800;

    return BlocBuilder<AuthBloc, AuthState>(
      buildWhen: (prev, current) =>
          prev.isResetSent != current.isResetSent ||
          prev.status != current.status ||
          prev.emailError != current.emailError,
      builder: (context, state) {
        if (state.isResetSent) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.success.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle_outline_rounded,
                  size: 64,
                  color: AppColors.success,
                ),
              ),
              const SizedBox(height: 24),
              ReusableText(
                AppStrings.resetSentTitle,
                style: TextStyle(
                  fontSize: isWeb ? 20 : 18.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimaryOf(context),
                ),
              ),
              const SizedBox(height: 12),
              ReusableText(
                AppStrings.resetSentSubtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: isWeb ? 14.5 : 13.sp,
                  color: AppColors.textSecondaryOf(context),
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 32),
              ReusableButton(
                text: AppStrings.backToLogin,
                width: double.infinity,
                onPressed: () => context.go(Routes.LOGIN),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () =>
                    context.read<AuthBloc>().add(const ClearAuthErrors()),
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(0, 36),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: ReusableText(
                  AppStrings.resendLink,
                  style: TextStyle(
                    fontSize: isWeb ? 13.5 : 12.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
              ),
            ],
          );
        }

        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.lock_reset_rounded,
                  size: 56,
                  color: AppColors.primary,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ReusableText(
              AppStrings.resetPasswordTitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: isWeb ? 24 : 20.sp,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimaryOf(context),
              ),
            ),
            const SizedBox(height: 8),
            ReusableText(
              AppStrings.resetPasswordSubtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: isWeb ? 14 : 12.5.sp,
                color: AppColors.textSecondaryOf(context),
              ),
            ),
            const SizedBox(height: 32),
            ReusableInput(
              controller: _emailController,
              focusNode: _emailFocus,
              label: AppStrings.emailLabel,
              hint: AppStrings.emailHintGeneric,
              keyboardType: TextInputType.emailAddress,
              prefixIcon: const Icon(Icons.email_outlined),
              error: state.emailError,
              textInputAction: TextInputAction.done,
              onChanged: (_) => context.read<AuthBloc>().add(const ClearAuthErrors()),
            ),
            const SizedBox(height: 24),
            ReusableButton(
              text: AppStrings.resetPasswordButton,
              onPressed: state.status == AuthStatus.loading
                  ? null
                  : () {
                      context.read<AuthBloc>().add(
                            ResetPasswordRequested(
                                email: _emailController.text.trim()),
                          );
                    },
              isLoading: state.status == AuthStatus.loading,
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => context.go(Routes.LOGIN),
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
                minimumSize: const Size(0, 36),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: ReusableText(
                AppStrings.backToLogin,
                style: TextStyle(
                  fontSize: isWeb ? 13.5 : 12.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primary,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
