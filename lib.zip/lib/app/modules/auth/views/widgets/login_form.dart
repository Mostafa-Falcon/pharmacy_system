import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import '../../bloc/auth_bloc.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/index.dart';
import '../../../../routes/app_routes.dart';

class LoginForm extends StatefulWidget {
  const LoginForm({super.key});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _emailFocus = FocusNode();
  final _passwordFocus = FocusNode();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  void _login() {
    if (!_formKey.currentState!.validate()) return;
    context.read<AuthBloc>().add(
          LoginRequested(
            email: _emailController.text.trim(),
            password: _passwordController.text,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isWeb = size.width >= 900;

    final double paddingHorizontal = isWeb ? 64.0 : 24.w;
    final double titleFontSize = isWeb ? 30.0 : 24.sp;
    final double descFontSize = isWeb ? 14.5 : 13.0.sp;

    return Container(
      color: theme.scaffoldBackgroundColor,
      child: Center(
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal,
            vertical: 24,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: isWeb ? 420 : 380.w,
            ),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isWeb) ...[
                    Center(
                      child: Container(
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(
                            alpha: 0.1,
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.local_pharmacy_rounded,
                          size: 36.sp,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    SizedBox(height: 20.h),
                  ],
                  Center(
                    child: Column(
                      children: [
                        ReusableText(
                          AppStrings.welcomeBack,
                          style: TextStyle(
                            fontSize: titleFontSize,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimaryOf(context),
                            height: 1.2,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        ReusableText(
                          AppStrings.loginSubtitle,
                          style: TextStyle(
                            fontSize: descFontSize,
                            color: AppColors.textSecondaryOf(context),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: isWeb ? 40 : 32.h),

                  // البريد الإلكتروني
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.emailError != current.emailError,
                    builder: (context, state) => ReusableInput.email(
                      controller: _emailController,
                      focusNode: _emailFocus,
                      label: AppStrings.emailLabel,
                      hint: AppStrings.emailHint,
                      prefixIcon: const Icon(Icons.email_outlined),
                      error: state.emailError,
                      textDirection: TextDirection.ltr,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) => _passwordFocus.requestFocus(),
                    ),
                  ),
                  SizedBox(height: isWeb ? 16 : 16.h),

                  // كلمة المرور
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.passwordError != current.passwordError ||
                        prev.isPasswordVisible != current.isPasswordVisible,
                    builder: (context, state) => ReusableInput(
                      controller: _passwordController,
                      focusNode: _passwordFocus,
                      label: AppStrings.passwordLabel,
                      isPassword: true,
                      showObscureToggle: true,
                      showClearButton: false,
                      prefixIcon: const Icon(Icons.lock_outlined),
                      obscureText: !state.isPasswordVisible,
                      onSuffixTap: () => context.read<AuthBloc>().add(
                            const TogglePasswordVisibility(),
                          ),
                      error: state.passwordError,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _login(),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // رابط نسيت كلمة المرور محاذى لليسار بشكل شيك
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () => context.go(Routes.FORGOT_PASSWORD),
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: ReusableText(
                        AppStrings.forgotPassword,
                        style: TextStyle(
                          fontSize: isWeb ? 13 : 12.sp,
                          fontWeight: FontWeight.w600,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: isWeb ? 32 : 28.h),

                  // رسالة الخطأ المستمرة (بدل Snackbar اللي بيختفي)
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) => prev.error != current.error,
                    builder: (context, state) {
                      if (state.error == null) return const SizedBox.shrink();
                      final isEmailConfirm = state.error!.contains('تأكيد');
                      return Container(
                        width: double.infinity,
                        margin: EdgeInsets.only(bottom: 12.h),
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(color: Theme.of(context).colorScheme.error.withValues(alpha: 0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.error_outline, color: Theme.of(context).colorScheme.error, size: 18),
                                SizedBox(width: 8.w),
                                Expanded(
                                  child: ReusableText(
                                    state.error!,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Theme.of(context).colorScheme.error,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if (isEmailConfirm && state.emailAttempt != null) ...[
                              SizedBox(height: 10.h),
                              TextButton(
                                onPressed: () => context.read<AuthBloc>().add(
                                  ResendConfirmationRequested(email: state.emailAttempt!),
                                ),
                                child: ReusableText(
                                  AppStrings.emailConfirmationResend,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Theme.of(context).colorScheme.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      );
                    },
                  ),

                  // زر الدخول
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) => prev.status != current.status,
                    builder: (context, state) => ReusableButton(
                      text: AppStrings.loginButton,
                      width: double.infinity,
                      height: 54.h,
                      isLoading: state.status == AuthStatus.loading,
                      onPressed: state.status == AuthStatus.loading ? null : _login,
                    ),
                  ),
                  SizedBox(height: isWeb ? 28 : 24.h),

                  // التوجيه لإنشاء حساب جديد
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ReusableText(
                        AppStrings.noAccount,
                        style: TextStyle(
                          color: AppColors.textMutedOf(context),
                          fontSize: isWeb ? 13.5 : 12.sp,
                        ),
                      ),
                      const SizedBox(width: 4),
                      TextButton(
                        onPressed: () => context.go(Routes.SIGNUP),
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: ReusableText(
                          AppStrings.signupLink,
                          style: TextStyle(
                            fontSize: isWeb ? 13.5 : 12.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
