import 'package:flutter/material.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/index.dart';

class LoginPromoPanel extends StatelessWidget {
  const LoginPromoPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = AppColors.isDark(context);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: isDark
              ? [
                  AppColors.surfaceTintDark,
                  AppColors.surfaceTintDarkAlt,
                ]
              : [
                  AppColors.brandBlueDeep, // أزرق ملكي ثابت
                  AppColors.primary, // الأزرق الأساسي
                ],
        ),
      ),
      child: Stack(
        children: [
          // أشكال جمالية هادئة بدلاً من الدوائر الشفافة جداً
          Positioned(
            top: -50,
            right: -50,
            child: CircleAvatar(
              radius: 150,
              backgroundColor: Colors.white.withValues(alpha: 0.04),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(40.0),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 500),
                padding: const EdgeInsets.symmetric(
                  vertical: 64,
                  horizontal: 40,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(
                    alpha: isDark ? 0.05 : 0.08,
                  ),
                  borderRadius: BorderRadius.circular(32),
                  border: Border.all(
                    color: Colors.white.withValues(
                      alpha: 0.15,
                    ),
                    width: 1.5,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(
                          alpha: 0.12,
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withValues(
                            alpha: 0.2,
                          ),
                        ),
                      ),
                      child: const Icon(
                        Icons.local_pharmacy_rounded,
                        size: 64,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 32),
                    ReusableText(
                      AppStrings.pharmacySystem,
                      style: const TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 0.5,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    ReusableText(
                      AppStrings.pharmacySystemDesc,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white.withValues(
                          alpha: 0.95,
                        ),
                        height: 1.7,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 3,
                    ),
                    const SizedBox(height: 48),
                    Image.asset(
                      'assets/images/pharmacy-hero.png',
                      height: 220,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => Container(
                        height: 180,
                        width: 180,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.04),
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Icon(
                          Icons.analytics_outlined,
                          size: 80,
                          color: Colors.white.withValues(alpha: 0.15),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
