import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import '../../bloc/auth_bloc.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/index.dart';
import '../../../../routes/app_routes.dart';

class SignupForm extends StatefulWidget {
  const SignupForm({super.key});

  @override
  State<SignupForm> createState() => _SignupFormState();
}

class _SignupFormState extends State<SignupForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _nameFocus = FocusNode();
  final _emailFocus = FocusNode();
  final _passwordFocus = FocusNode();
  final _confirmPasswordFocus = FocusNode();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _nameFocus.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    _confirmPasswordFocus.dispose();
    super.dispose();
  }

  void _register() {
    if (!_formKey.currentState!.validate()) return;
    context.read<AuthBloc>().add(
          RegisterRequested(
            name: _nameController.text.trim(),
            email: _emailController.text.trim(),
            password: _passwordController.text,
            confirmPassword: _confirmPasswordController.text,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isWeb = size.width >= 900;

    final double paddingHorizontal = isWeb ? 64.0 : 24.w;
    final double titleFontSize = isWeb ? 30.0 : 24.sp;
    final double descFontSize = isWeb ? 14.5 : 13.0.sp;

    return Container(
      color: theme.scaffoldBackgroundColor,
      child: Center(
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal,
            vertical: 24,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: isWeb ? 420 : 380.w,
            ),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isWeb) ...[
                    Center(
                      child: Container(
                        padding: EdgeInsets.all(12.w),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(
                            alpha: 0.1,
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.local_pharmacy_rounded,
                          size: 36.sp,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    SizedBox(height: 20.h),
                  ],
                  ReusableText(
                    AppStrings.signupTitle,
                    style: TextStyle(
                      fontSize: titleFontSize,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimaryOf(context),
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ReusableText(
                    AppStrings.signupSubtitle,
                    style: TextStyle(
                      fontSize: descFontSize,
                      color: AppColors.textSecondaryOf(context),
                    ),
                  ),
                  SizedBox(height: isWeb ? 28 : 24.h),

                  // الاسم الكامل
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.nameError != current.nameError,
                    builder: (context, state) => ReusableInput.text(
                      controller: _nameController,
                      focusNode: _nameFocus,
                      label: AppStrings.fullNameLabel,
                      hint: AppStrings.nameHint,
                      prefixIcon: const Icon(Icons.person_outlined),
                      error: state.nameError,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) => _emailFocus.requestFocus(),
                      onChanged: (_) => context.read<AuthBloc>().add(const ClearAuthErrors()),
                    ),
                  ),
                  SizedBox(height: isWeb ? 16 : 16.h),

                  // البريد الإلكتروني
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.emailError != current.emailError,
                    builder: (context, state) => ReusableInput.email(
                      controller: _emailController,
                      focusNode: _emailFocus,
                      label: AppStrings.emailLabel,
                      hint: AppStrings.emailHint,
                      prefixIcon: const Icon(Icons.email_outlined),
                      error: state.emailError,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) => _passwordFocus.requestFocus(),
                      onChanged: (_) => context.read<AuthBloc>().add(const ClearAuthErrors()),
                    ),
                  ),
                  SizedBox(height: isWeb ? 16 : 16.h),

                  // كلمة المرور
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.passwordError != current.passwordError ||
                        prev.isPasswordVisible != current.isPasswordVisible,
                    builder: (context, state) => ReusableInput(
                      controller: _passwordController,
                      focusNode: _passwordFocus,
                      label: AppStrings.passwordLabel,
                      isPassword: true,
                      showObscureToggle: true,
                      showClearButton: false,
                      prefixIcon: const Icon(Icons.lock_outlined),
                      obscureText: !state.isPasswordVisible,
                      onSuffixTap: () => context.read<AuthBloc>().add(
                            const TogglePasswordVisibility(),
                          ),
                      error: state.passwordError,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) =>
                          _confirmPasswordFocus.requestFocus(),
                      onChanged: (_) => context.read<AuthBloc>().add(const ClearAuthErrors()),
                    ),
                  ),
                  SizedBox(height: isWeb ? 16 : 16.h),

                  // تأكيد كلمة المرور
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) =>
                        prev.confirmPasswordError !=
                        current.confirmPasswordError,
                    builder: (context, state) => ReusableInput(
                      controller: _confirmPasswordController,
                      focusNode: _confirmPasswordFocus,
                      label: AppStrings.confirmPasswordLabel,
                      isPassword: true,
                      showObscureToggle: true,
                      showClearButton: false,
                      prefixIcon: const Icon(
                        Icons.lock_clock_outlined,
                      ),
                      obscureText: !state.isPasswordVisible,
                      onSuffixTap: () => context.read<AuthBloc>().add(
                            const TogglePasswordVisibility(),
                          ),
                      error: state.confirmPasswordError,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _register(),
                      onChanged: (_) => context.read<AuthBloc>().add(const ClearAuthErrors()),
                    ),
                  ),
                  SizedBox(height: isWeb ? 28 : 24.h),

                  // زر إنشاء الحساب
                  BlocBuilder<AuthBloc, AuthState>(
                    buildWhen: (prev, current) => prev.status != current.status,
                    builder: (context, state) => ReusableButton(
                      text: AppStrings.signupButton,
                      width: double.infinity,
                      isLoading: state.status == AuthStatus.loading,
                      onPressed:
                          state.status == AuthStatus.loading ? null : _register,
                    ),
                  ),
                  SizedBox(height: isWeb ? 24 : 20.h),

                  // التوجيه لتسجيل الدخول
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ReusableText(
                        AppStrings.alreadyHaveAccount,
                        style: TextStyle(
                          color: AppColors.textMutedOf(context),
                          fontSize: isWeb ? 13.5 : 12.sp,
                        ),
                      ),
                      const SizedBox(width: 4),
                      TextButton(
                        onPressed: () => context.go(Routes.LOGIN),
                        style: TextButton.styleFrom(
                          padding: EdgeInsets.zero,
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: ReusableText(
                          AppStrings.loginNow,
                          style: TextStyle(
                            fontSize: isWeb ? 13.5 : 12.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
