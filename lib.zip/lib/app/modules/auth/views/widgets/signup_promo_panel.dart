import 'dart:ui';
import 'package:flutter/material.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/index.dart';

class SignupPromoPanel extends StatelessWidget {
  const SignupPromoPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = AppColors.isDark(context);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: isDark
              ? [
                  AppColors.surfaceTintDark,
                  AppColors.surfaceTintDarkAlt,
                  AppColors.surfaceTintDarkDeep,
                ]
              : [
                  AppColors.surfaceTintDarkNavy,
                  AppColors.primary,
                  AppColors.info,
                ],
        ),
      ),
      child: Stack(
        children: [
          // دوائر توهج جمالية
          Positioned(
            top: -100,
            right: -50,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(
                  alpha: isDark ? 0.02 : 0.05,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            left: -80,
            child: Container(
              width: 350,
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withValues(
                  alpha: isDark ? 0.2 : 0.08,
                ),
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(40.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                  child: Container(
                    width: 480,
                    padding: const EdgeInsets.symmetric(
                      vertical: 48,
                      horizontal: 36,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(
                        alpha: isDark ? 0.03 : 0.06,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: Colors.white.withValues(
                          alpha: isDark ? 0.08 : 0.12,
                        ),
                        width: 1.5,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(
                              alpha: 0.1,
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(
                                alpha: 0.15,
                              ),
                            ),
                          ),
                          child: const Icon(
                            Icons.local_pharmacy_rounded,
                            size: 54,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 28),
                        ReusableText(
                          AppStrings.pharmacySystem,
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ReusableText(
                          AppStrings.pharmacySystemDesc,
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white.withValues(
                              alpha: 0.75,
                            ),
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 3,
                        ),
                        const SizedBox(height: 36),
                        Image.asset(
                          'assets/images/pharmacy-hero.png',
                          height: 200,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                            height: 160,
                            width: 160,
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.04),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(
                              Icons.analytics_outlined,
                              size: 72,
                              color: Colors.white.withValues(alpha: 0.15),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
