import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../bloc/monitoring_dashboard_bloc.dart';
import '../bloc/monitoring_dashboard_state.dart';
import '../widgets/monitoring_chart_card.dart';
import '../widgets/monitoring_stat_card.dart';
import '../widgets/monitoring_table_card.dart';
import '../../../../app/core/widgets/reusables/index.dart';

class DashboardView extends StatelessWidget {
  // UTF-8 Force Refresh
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MonitoringDashboardBloc, MonitoringDashboardState>(
      builder: (context, state) {
        if (state.loading) {
          return const LoadingIndicator();
        }

        return LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 950;
            final isMid = constraints.maxWidth >= 650;
            final hp = isWide ? AppSpacing.xl.w : (isMid ? AppSpacing.lg.w : AppSpacing.md.w);

            return CustomScrollView(
              physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
              slivers: [
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: _buildWelcomeHeader(context, state),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: _buildStatCards(context, state, isWide, isMid, hp),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: _buildCharts(context, state),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: _buildDebtTables(context, state),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: MonitoringTableCard(
                      title: AppStrings.lowStockAlertTitle,
                      icon: Icons.inventory_2_outlined,
        iconColor: AppColors.chartRed,
        columns: const [
          TableColumnDef(key: 'item', label: AppStrings.item),
                        TableColumnDef(key: 'stock', label: AppStrings.currentStock),
                        TableColumnDef(key: 'minStock', label: AppStrings.minStock),
                      ],
                      rows: state.lowStockRows,
                    ),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 0),
                  sliver: SliverToBoxAdapter(
                    child: MonitoringTableCard(
                      title: AppStrings.recentOrdersTitle,
                      icon: Icons.shopping_cart_outlined,
        iconColor: AppColors.chartBlue,
        columns: const [
          TableColumnDef(key: 'date', label: AppStrings.date),
          TableColumnDef(key: 'orderNumber', label: AppStrings.orderNumber),
                        TableColumnDef(key: 'customer', label: AppStrings.customer),
                        TableColumnDef(key: 'total', label: AppStrings.total),
                        TableColumnDef(key: 'status', label: AppStrings.status),
                      ],
                      rows: state.orderRows,
                    ),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsetsDirectional.fromSTEB(hp, 16.h, hp, 32.h),
                  sliver: SliverToBoxAdapter(
                    child: MonitoringTableCard(
                      title: AppStrings.pendingShipmentsTitle,
                      icon: Icons.local_shipping_outlined,
        iconColor: AppColors.chartAmber,
        columns: const [
          TableColumnDef(key: 'date', label: AppStrings.date),
          TableColumnDef(key: 'invoice', label: AppStrings.invoice),
                        TableColumnDef(key: 'customer', label: AppStrings.customer),
                        TableColumnDef(key: 'status', label: AppStrings.status),
                      ],
                      rows: state.pendingShipmentRows,
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildWelcomeHeader(BuildContext context, MonitoringDashboardState state) {
    return Container(
      padding: EdgeInsets.all(AppSpacing.lg.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.chartTeal, AppColors.chartTealDark],
        ),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        boxShadow: [
          BoxShadow(
            color: AppColors.chartTeal.withValues(alpha: 0.25),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ReusableText(
            '${AppStrings.welcomeUserPrefix}${state.userName} 👋',
            style: TextStyle(
              fontSize: 22.sp,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 6.h),
          ReusableText(
            AppStrings.dashboardSubtitle,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              color: Colors.white.withValues(alpha: 0.75),
            ),
          ),
          SizedBox(height: 16.h),
          Row(
            children: [
              _chip(context, Icons.verified_user_rounded, AppStrings.activeAccount, AppColors.chartGreen),
              SizedBox(width: 8.w),
              _chip(context, Icons.store_rounded, state.branchName, AppColors.info),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(BuildContext context, IconData icon, String label, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppRadius.pill.r),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14.sp, color: Colors.white),
          SizedBox(width: 6.w),
          ReusableText(
            label,
            style: TextStyle(fontSize: 10.5.sp, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCards(BuildContext context, MonitoringDashboardState state, bool isWide, bool isMid, double hp) {
    final cards = [
      MonitoringStatCard(
        title: AppStrings.totalSales,
        value: _fmt(state.totalSales),
        icon: Icons.shopping_cart_rounded,
        tone: StatCardTone.sky,
      ),
      MonitoringStatCard(
        title: AppStrings.netIncome,
        value: _fmt(state.netIncome),
        icon: Icons.account_balance_wallet_rounded,
        tone: StatCardTone.green,
      ),
      MonitoringStatCard(
        title: AppStrings.salesDue,
        value: _fmt(state.salesDue),
        icon: Icons.receipt_long_rounded,
        tone: StatCardTone.amber,
      ),
      MonitoringStatCard(
        title: AppStrings.salesReturns,
        value: _fmt(state.salesReturnsTotal),
        icon: Icons.refresh_rounded,
        tone: StatCardTone.red,
      ),
      MonitoringStatCard(
        title: AppStrings.totalPurchases,
        value: _fmt(state.totalPurchases),
        icon: Icons.inventory_rounded,
        tone: StatCardTone.sky,
      ),
      MonitoringStatCard(
        title: AppStrings.purchasesDue,
        value: _fmt(state.purchasesDue),
        icon: Icons.warning_amber_rounded,
        tone: StatCardTone.amber,
      ),
      MonitoringStatCard(
        title: AppStrings.purchaseReturns,
        value: _fmt(state.purchaseReturnsTotal),
        icon: Icons.undo_rounded,
        tone: StatCardTone.red,
      ),
      MonitoringStatCard(
        title: AppStrings.totalExpenses,
        value: _fmt(state.expenses),
        icon: Icons.money_off_rounded,
        tone: StatCardTone.red,
      ),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isWide ? 4 : (isMid ? 2 : 1),
        crossAxisSpacing: 16.w,
        mainAxisSpacing: 16.h,
        mainAxisExtent: 90.h,
      ),
      itemCount: cards.length,
      itemBuilder: (context, i) => cards[i],
    );
  }

  Widget _buildCharts(BuildContext context, MonitoringDashboardState state) {
    final isWide = MediaQuery.of(context).size.width >= 950;
    
    final content = [
      MonitoringChartCard(
        title: AppStrings.salesMovement30Days,
        icon: Icons.show_chart_rounded,
        data: state.last30DaysSales,
        lineColor: AppColors.chartBlue,
      ),
      MonitoringChartCard(
        title: AppStrings.annualPerformance,
        icon: Icons.trending_up_rounded,
        data: state.fiscalYearSales,
        lineColor: AppColors.chartGreen,
      ),
    ];

    if (isWide) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: content.map((c) => Expanded(child: Padding(padding: EdgeInsetsDirectional.only(end: 16.w), child: c))).toList(),
      );
    }

    return Column(
      children: content.map((c) => Padding(padding: EdgeInsets.only(bottom: 16.h), child: c)).toList(),
    );
  }

  Widget _buildDebtTables(BuildContext context, MonitoringDashboardState state) {
    final isWide = MediaQuery.of(context).size.width >= 950;
    
    final content = [
      MonitoringTableCard(
        title: AppStrings.customerDebts,
        icon: Icons.people_outline_rounded,
        iconColor: AppColors.chartAmber,
        columns: const [
          TableColumnDef(key: 'name', label: AppStrings.customer),
          TableColumnDef(key: 'debt', label: AppStrings.salesDue),
        ],
        rows: state.customerDebtRows,
      ),
      MonitoringTableCard(
        title: AppStrings.supplierDebts,
        icon: Icons.business_outlined,
        iconColor: AppColors.chartAmber,
        columns: const [
          TableColumnDef(key: 'name', label: AppStrings.supplier),
          TableColumnDef(key: 'debt', label: AppStrings.salesDue),
        ],
        rows: state.supplierDebtRows,
      ),
    ];

    if (isWide) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: content.map((c) => Expanded(child: Padding(padding: EdgeInsetsDirectional.only(end: 16.w), child: c))).toList(),
      );
    }

    return Column(
      children: content.map((c) => Padding(padding: EdgeInsets.only(bottom: 16.h), child: c)).toList(),
    );
  }

  String _fmt(double val) {
    return '${val.toStringAsFixed(2)} ج.م';
  }
}
