import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/constants/app_strings.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../../app/core/widgets/reusables/index.dart';

class HomeWelcomeBanner extends StatelessWidget {
  final String userName;
  final String branchName;

  const HomeWelcomeBanner({
    super.key,
    required this.userName,
    required this.branchName,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return LayoutBuilder(
      builder: (context, constraints) {
        final isCompact = constraints.maxWidth < 760;

        return Container(
          padding: EdgeInsets.symmetric(
            horizontal: isCompact ? AppSpacing.lg : AppSpacing.xxl,
            vertical: isCompact ? AppSpacing.lgH : AppSpacing.xlH,
          ),
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(AppRadius.xl.r),
            border: Border.all(
              color: scheme.outlineVariant.withValues(alpha: 0.55),
              width: 1.r,
            ),
            boxShadow: [
              BoxShadow(
                color: scheme.shadow.withValues(alpha: 0.05),
                blurRadius: 20.r,
                offset: Offset(0, 8.h),
              ),
            ],
          ),
          child: isCompact
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _Greeting(userName: userName),
                    SizedBox(height: AppSpacing.lgH),
                    _buildStatusChips(context, branchName),
                  ],
                )
              : Row(
                  children: [
                    Expanded(child: _Greeting(userName: userName)),
                    SizedBox(width: AppSpacing.xl),
                    _buildStatusChips(context, branchName),
                  ],
                ),
        );
      },
    );
  }

  Widget _buildStatusChips(BuildContext context, String branchName) {
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.smH,
      children: [
        _StatusChip(
          icon: Icons.verified_user_outlined,
          label: AppStrings.mainPageActiveUser,
          foregroundColor: AppColors.primary,
          backgroundColor: AppColors.primarySoftOf(context),
        ),
        _StatusChip(
          icon: Icons.business_outlined,
          label: branchName.isNotEmpty ? branchName : AppStrings.mainBranchLabel,
          foregroundColor: AppHomeColors.sales,
          backgroundColor: AppHomeColors.sales.withValues(alpha: 0.1),
        ),
      ],
    );
  }
}

class _Greeting extends StatelessWidget {
  final String userName;

  const _Greeting({required this.userName});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 62.w,
          height: 62.w,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: AlignmentDirectional.topEnd,
              end: AlignmentDirectional.bottomStart,
              colors: [AppColors.chartTeal, AppColors.chartTealDark],
            ),
            borderRadius: BorderRadius.circular(AppRadius.lg.r),
            boxShadow: [
              BoxShadow(
                color: AppColors.chartTeal.withValues(alpha: 0.22),
                blurRadius: 16.r,
                offset: Offset(0, 7.h),
              ),
            ],
          ),
          child: Icon(
            Icons.auto_awesome_rounded,
            color: Colors.white,
            size: 30.sp,
          ),
        ),
        SizedBox(width: AppSpacing.lg),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ReusableText(
                '${AppStrings.mainPageWelcomeUser}$userName',
                style: TextStyle(
                  fontSize: 22.sp,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimaryOf(context),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 6.h),
              ReusableText(
                AppStrings.mainPageSubtitleLong,
                style: TextStyle(
                  fontSize: 13.sp,
                  color: scheme.onSurfaceVariant,
                  fontWeight: FontWeight.w600,
                  height: 1.55,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StatusChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color foregroundColor;
  final Color backgroundColor;

  const _StatusChip({
    required this.icon,
    required this.label,
    required this.foregroundColor,
    required this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: 6.h,
      ),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(AppRadius.pill.r),
        border: Border.all(
          color: foregroundColor.withValues(alpha: 0.25),
          width: 1.r,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 19.sp, color: foregroundColor),
          SizedBox(width: AppSpacing.xs),
          ReusableText(
            label,
            style: TextStyle(
              fontSize: 13.sp,
              color: foregroundColor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
