import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../bloc/chart_data_point.dart';
import '../../../../app/core/widgets/reusables/index.dart';

class MonitoringChartCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<ChartDataPoint> data;
  final Color lineColor;

  const MonitoringChartCard({
    super.key,
    required this.title,
    required this.icon,
    required this.data,
    this.lineColor = AppColors.chartBlue,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.md.r),
        side: BorderSide(color: AppColors.borderOf(context).withValues(alpha: 0.5)),
      ),
      color: AppColors.surfaceOf(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(AppSpacing.md),
            child: Row(
              children: [
                Container(
                  width: 44.w,
                  height: 44.w,
                  decoration: BoxDecoration(
                    color: lineColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(AppRadius.md.r),
                  ),
                  child: Icon(icon, color: lineColor, size: 22.sp),
                ),
                SizedBox(width: AppSpacing.sm),
                ReusableText(
                  title,
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimaryOf(context),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: AppColors.borderOf(context).withValues(alpha: 0.5)),
          Padding(
            padding: EdgeInsets.fromLTRB(AppSpacing.sm, AppSpacing.md, AppSpacing.sm, AppSpacing.md),
            child: SizedBox(
              height: 260.h,
              child: data.isEmpty
                  ? Center(
                      child: ReusableText(
                        AppStrings.noData,
                        style: TextStyle(
                          fontSize: 13.sp,
                          color: AppColors.textMutedOf(context),
                        ),
                      ),
                    )
                  : LineChart(
                      LineChartData(
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: false,
                          horizontalInterval: _calcInterval(),
                          getDrawingHorizontalLine: (value) => FlLine(
                            color: AppColors.borderOf(context).withValues(alpha: 0.2),
                            strokeWidth: 1,
                          ),
                        ),
                        titlesData: FlTitlesData(
                          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 28.h,
                              getTitlesWidget: (value, meta) {
                                final idx = value.toInt();
                                if (idx < 0 || idx >= data.length) return const SizedBox();
                                if (data.length > 10 && idx % (data.length ~/ 5) != 0) {
                                  return const SizedBox();
                                }
                                return Padding(
                                  padding: EdgeInsets.only(top: 8.h),
                                  child: ReusableText(
                                    data[idx].label,
                                    style: TextStyle(
                                      fontSize: 9.sp,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textMutedOf(context),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 50.w,
                              getTitlesWidget: (value, meta) {
                                return Padding(
                                  padding: EdgeInsets.only(left: 4.w),
                                  child: ReusableText(
                                    '${value.toInt()}',
                                    style: TextStyle(
                                      fontSize: 9.sp,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textMutedOf(context),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        borderData: FlBorderData(show: false),
                        lineBarsData: [
                          LineChartBarData(
                            spots: data.asMap().entries.map((e) => FlSpot(e.key.toDouble(), e.value.value)).toList(),
                            isCurved: true,
                            preventCurveOverShooting: true,
                            color: lineColor,
                            barWidth: 3,
                            dotData: FlDotData(
                              show: data.length < 60,
                              getDotPainter: (spot, percent, barData, index) {
                                return FlDotCirclePainter(
                                  radius: 3.5,
                                  color: lineColor,
                                  strokeWidth: 2,
                                  strokeColor: Colors.white,
                                );
                              },
                            ),
                            belowBarData: BarAreaData(
                              show: true,
                              color: lineColor.withValues(alpha: 0.08),
                            ),
                          ),
                        ],
                        lineTouchData: LineTouchData(
                          touchTooltipData: LineTouchTooltipData(
                            getTooltipItems: (touchedSpots) {
                              return touchedSpots.map((spot) {
                                final idx = spot.spotIndex;
                                return LineTooltipItem(
                                  '${idx < data.length ? data[idx].label : ''}\n${spot.y.toStringAsFixed(2)}',
                                  TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12.sp,
                                  ),
                                );
                              }).toList();
                            },
                          ),
                        ),
                        minY: 0,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  double _calcInterval() {
    if (data.isEmpty) return 1000;
    final maxVal = data.map((e) => e.value).reduce((a, b) => a > b ? a : b);
    if (maxVal <= 0) return 1000;
    final raw = maxVal / 4;
    final magnitude = _pow10(raw);
    return (raw / magnitude).ceil() * magnitude;
  }

  double _pow10(double val) {
    if (val <= 0) return 1;
    var exp = 0;
    var v = val;
    while (v >= 10) { v /= 10; exp++; }
    while (v < 1) { v *= 10; exp--; }
    return _pow10Double(exp);
  }

  double _pow10Double(int exp) {
    double result = 1;
    for (var i = 0; i < exp.abs(); i++) {
      result *= (exp > 0 ? 10 : 0.1);
    }
    return result;
  }
}
