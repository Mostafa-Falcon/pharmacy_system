import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../../app/core/widgets/reusables/index.dart';

enum StatCardTone { sky, green, amber, red }

class MonitoringStatCard extends StatefulWidget {
  // UTF-8 Force Refresh
  final String title;
  final String value;
  final IconData icon;
  final StatCardTone tone;
  final bool loading;

  const MonitoringStatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.tone = StatCardTone.sky,
    this.loading = false,
  });

  @override
  State<MonitoringStatCard> createState() => _MonitoringStatCardState();
}

class _MonitoringStatCardState extends State<MonitoringStatCard> {
  bool _isHovered = false;

  LinearGradient _getGradient(StatCardTone tone) {
    switch (tone) {
      case StatCardTone.sky:
        return LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.info, AppColors.info.withValues(alpha: 0.85)],
        );
      case StatCardTone.green:
        return LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            AppColors.success,
            AppColors.success.withValues(alpha: 0.85),
          ],
        );
      case StatCardTone.amber:
        return LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            AppColors.warning,
            AppColors.warning.withValues(alpha: 0.85),
          ],
        );
      case StatCardTone.red:
        return LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.error, AppColors.error.withValues(alpha: 0.85)],
        );
    }
  }

  Color _toneColor() {
    switch (widget.tone) {
      case StatCardTone.sky:
        return AppColors.info;
      case StatCardTone.green:
        return AppColors.success;
      case StatCardTone.amber:
        return AppColors.warning;
      case StatCardTone.red:
        return AppColors.error;
    }
  }

  @override
  Widget build(BuildContext context) {
    final toneColor = _toneColor();

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        transform: Matrix4.translationValues(
          0.0,
          _isHovered ? -2.h : 0.0,
          0.0,
        ),
        decoration: BoxDecoration(
          gradient: _getGradient(widget.tone),
          borderRadius: BorderRadius.circular(AppRadius.md.r),
          border: Border.all(
            color: Colors.white.withValues(alpha: _isHovered ? 0.35 : 0.12),
            width: 1.r,
          ),
          boxShadow: [
            BoxShadow(
              color: toneColor.withValues(alpha: _isHovered ? 0.3 : 0.1),
              blurRadius: _isHovered ? 12.r : 6.r,
              offset: Offset(0, _isHovered ? 6.h : 3.h),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
          child: Row(
            children: [
              Container(
                width: 48.w,
                height: 48.w,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(AppRadius.sm.r),
                ),
                child: Icon(widget.icon, color: Colors.white, size: 24.sp),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ReusableText(
                      widget.title,
                      style: TextStyle(
                        fontSize: 11.5.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white.withValues(alpha: 0.85),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4.h),
                    if (widget.loading)
                      Container(
                        height: 20.h,
                        width: 70.w,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4.r),
                        ),
                      )
                    else
                      ReusableText(
                        widget.value,
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
