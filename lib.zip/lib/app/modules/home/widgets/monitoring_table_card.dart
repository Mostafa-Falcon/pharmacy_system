import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../../../../app/core/widgets/reusables/index.dart';

class MonitoringTableCard extends StatelessWidget {
  // UTF-8 Force Refresh
  final String title;
  final IconData icon;
  final Color iconColor;
  final List<Map<String, dynamic>> rows;
  final List<TableColumnDef> columns;

  const MonitoringTableCard({
    super.key,
    required this.title,
    required this.icon,
    required this.columns,
    required this.rows,
    this.iconColor = AppColors.chartAmber,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(AppSpacing.md.w),
            child: Row(
              children: [
                Container(
                  width: 40.w,
                  height: 40.w,
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(AppRadius.md.r),
                  ),
                  child: Icon(icon, color: iconColor, size: 20.sp),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: ReusableText(
                    title,
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimaryOf(context),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          if (rows.isEmpty)
            _buildEmptyState(context)
          else
            _buildTable(context),
          _buildPagination(context),
        ],
      ),
    );
  }

  Widget _buildTable(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(AppSpacing.md.w),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.2)),
          borderRadius: BorderRadius.circular(AppRadius.md.r),
        ),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            headingRowHeight: 44.h,
            dataRowMinHeight: 40.h,
            dataRowMaxHeight: 48.h,
            headingRowColor: WidgetStateProperty.all(AppColors.inputFillOf(context).withValues(alpha: 0.5)),
            columnSpacing: 24.w,
            columns: columns.map((col) {
              return DataColumn(
                label: ReusableText(
                  col.label,
                  style: TextStyle(
                    fontSize: 11.5.sp,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimaryOf(context),
                  ),
                ),
              );
            }).toList(),
            rows: rows.map((row) {
              return DataRow(
                cells: columns.map((col) {
                  final val = row[col.key] ?? '—';
                  return DataCell(
                    ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: 160.w),
                      child: ReusableText(
                        '$val',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textSecondaryOf(context),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  );
                }).toList(),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(AppSpacing.xxl.w),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_rounded, size: 40.sp, color: AppColors.textMutedOf(context).withValues(alpha: 0.3)),
            SizedBox(height: 12.h),
            const ReusableText(
              AppStrings.noData,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPagination(BuildContext context) {
    if (rows.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.fromLTRB(AppSpacing.md.w, 0, AppSpacing.md.w, AppSpacing.md.h),
      child: ReusableText(
        'عرض ${rows.length} سجل من إجمالي البيانات المتوفرة',
        variant: ReusableTextVariant.caption,
      ),
    );
  }
}

class TableColumnDef {
  final String key;
  final String label;
  const TableColumnDef({required this.key, required this.label});
}
