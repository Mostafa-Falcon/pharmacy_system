import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/bloc/base_paginated_bloc.dart';
import '../../../../core/models/customer/customer_group_model.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/constants/strings/customers_strings.dart';
import '../../../../core/extensions/string_ext.dart';
import '../../../../core/widgets/index.dart';
import '../bloc/customer_groups_bloc.dart';

class CustomerGroupsView extends StatelessWidget {
  const CustomerGroupsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const _CustomerGroupsBody();
  }
}

class _CustomerGroupsBody extends StatelessWidget {
  const _CustomerGroupsBody();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return HomeShell(
      title: 'مجموعات العملاء',
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.3),
        padding: EdgeInsets.all(AppSpacing.xl.w),
        child: BlocBuilder<CustomerGroupsBloc, PaginatedState<CustomerGroupModel>>(
          builder: (context, state) {
            if (state.isInitial || state.isLoading) {
              return const Center(child: LoadingIndicator());
            }
            if (state.isFailure) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ReusableText(state.error ?? 'خطأ في تحميل المجموعات'),
                    SizedBox(height: 16.h),
                    ReusableButton(
                      text: 'إعادة المحاولة',
                      onPressed: () => context.read<CustomerGroupsBloc>().add(const LoadItems()),
                    ),
                  ],
                ),
              );
            }
            final bloc = context.read<CustomerGroupsBloc>();
            final items = state.items ?? [];
            return Column(
              children: [
                _buildHeader(context, items.length),
                SizedBox(height: AppSpacing.lg.h),
                if (state.searchQuery.isNotEmpty || items.length > 5)
                  SearchField(
                    hint: 'بحث عن مجموعة...',
                    onChanged: (v) => bloc.add(SearchItems(v)),
                    onClear: () => bloc.add(const SearchItems('')),
                  ),
                if (state.searchQuery.isNotEmpty || items.length > 5)
                  SizedBox(height: AppSpacing.md.h),
                Expanded(
                  child: items.isEmpty
                      ? const EmptyState(
                          icon: Icons.group_work_outlined,
                          title: 'لا يوجد مجموعات',
                        )
                      : ListView.separated(
                          itemCount: items.length,
                          separatorBuilder: (_, _) => SizedBox(height: AppSpacing.sm.h),
                          itemBuilder: (_, i) => _groupTile(context, items[i]),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, int totalCount) {
    return Row(
      children: [
        ReusableButton(
          text: 'إضافة مجموعة',
          prefixIcon: Icons.add_rounded,
          onPressed: () => _showGroupDialog(context),
        ),
        const Spacer(),
        ReusableText(
          '$totalCount مجموعة',
          style: TextStyle(
            fontSize: 12.sp,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _groupTile(BuildContext context, CustomerGroupModel g) {
    final bloc = context.read<CustomerGroupsBloc>();
    final menuItems = <PopupMenuEntry<String>>[
      ReusableActionMenuItem(
        value: 'edit',
        icon: Icons.edit_outlined,
        label: AppStrings.edit,
      ),
      ReusableActionMenuItem(
        value: 'toggle',
        icon: g.isActive ? Icons.toggle_off_outlined : Icons.toggle_on_outlined,
        label: g.isActive ? CustomersStrings.deactivate : CustomersStrings.activate,
      ),
      ReusableActionMenuItem(
        value: 'delete',
        icon: Icons.delete_outline_rounded,
        label: AppStrings.delete,
        color: AppColors.error,
      ),
    ];

    return PartyListTile(
      avatarIcon: Icons.group_rounded,
      avatarColor: g.isActive ? AppColors.primary : AppColors.error,
      title: g.name,
      subtitle: g.description,
      tags: [
        Tag(
          label: 'خصم ${g.discountPercent.toStringAsFixed(0)}%${g.priceGroupId != null ? ' | مجموعة أسعار: ${g.priceGroupId}' : ''}',
          color: AppColors.info,
        ),
      ],
      menuItems: menuItems,
      onMenuSelected: (v) {
        switch (v) {
          case 'edit':
            _showGroupDialog(context, group: g);
          case 'toggle':
            bloc.add(ToggleActiveCustomerGroup(g.id));
          case 'delete':
            ConfirmDeleteDialog.show(
              context,
              title: 'حذف مجموعة',
              message: 'هل أنت متأكد من حذف المجموعة "${g.name}"؟',
              onConfirm: () => bloc.add(DeleteCustomerGroup(g.id)),
            );
        }
      },
      onTap: () => _showGroupDialog(context, group: g),
    );
  }

  void _showGroupDialog(BuildContext context, {CustomerGroupModel? group}) {
    final nameCtrl = TextEditingController(text: group?.name ?? '');
    final discountCtrl = TextEditingController(
      text: group?.discountPercent.toString() ?? '0',
    );
    final descCtrl = TextEditingController(text: group?.description ?? '');
    final isEditing = group != null;
    final bloc = context.read<CustomerGroupsBloc>();

    showDialog(
      context: context,
      builder: (context) => ReusableDialog(
        title: isEditing ? 'تعديل مجموعة' : 'إضافة مجموعة جديدة',
        children: [
          ReusableInput.text(
            controller: nameCtrl,
            label: 'الاسم *',
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableInput(
            controller: discountCtrl,
            label: 'نسبة الخصم %',
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableInput.text(
            controller: descCtrl,
            label: 'الوصف',
            maxLines: 2,
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: AppSpacing.md.h),
          DialogActions(
            confirmText: isEditing ? 'حفظ' : 'إضافة',
            onConfirm: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              if (isEditing) {
                bloc.add(UpdateCustomerGroup(
                  group.copyWith(
                    name: nameCtrl.text.trim(),
                    discountPercent: double.tryParse(discountCtrl.text) ?? 0,
                    description: descCtrl.text.trim().nullIfEmpty,
                  ),
                ));
              } else {
                bloc.add(AddCustomerGroup(
                  name: nameCtrl.text.trim(),
                  discountPercent: double.tryParse(discountCtrl.text) ?? 0,
                  description: descCtrl.text.trim().nullIfEmpty,
                ));
              }
              Navigator.pop(context);
            },
          ),
        ],
      ),
    ).whenComplete(() {
      nameCtrl.dispose();
      discountCtrl.dispose();
      descCtrl.dispose();
    });
  }
}
