import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/bloc/base_paginated_bloc.dart';
import '../../../../core/models/customer/customer_group_model.dart';
import '../../../../core/services/customer/customer_group_service.dart';
import '../../../../core/utils/app_snackbar.dart';

// ─── Custom Events ───

class AddCustomerGroup extends PaginatedEvent {
  final String name;
  final double discountPercent;
  final String? priceGroupId;
  final String? description;
  const AddCustomerGroup({
    required this.name,
    this.discountPercent = 0,
    this.priceGroupId,
    this.description,
  });
  @override
  List<Object?> get props => [name, discountPercent, priceGroupId, description];
}

class UpdateCustomerGroup extends PaginatedEvent {
  final CustomerGroupModel group;
  const UpdateCustomerGroup(this.group);
  @override
  List<Object?> get props => [group];
}

class DeleteCustomerGroup extends PaginatedEvent {
  final String id;
  const DeleteCustomerGroup(this.id);
  @override
  List<Object?> get props => [id];
}

class ToggleActiveCustomerGroup extends PaginatedEvent {
  final String id;
  const ToggleActiveCustomerGroup(this.id);
  @override
  List<Object?> get props => [id];
}

// ─── Bloc ───

class CustomerGroupsBloc extends BasePaginatedBloc<CustomerGroupModel> {
  CustomerGroupsBloc() {
    on<AddCustomerGroup>(_onAdd);
    on<UpdateCustomerGroup>(_onUpdate);
    on<DeleteCustomerGroup>(_onDelete);
    on<ToggleActiveCustomerGroup>(_onToggleActive);
    add(const LoadItems());
  }

  @override
  Future<List<CustomerGroupModel>> fetchItems(PaginatedState<CustomerGroupModel> state) async {
    var items = CustomerGroupService.getAll(activeOnly: false);
    if (state.searchQuery.isNotEmpty) {
      final q = state.searchQuery.toLowerCase();
      items = items.where((g) =>
        g.name.toLowerCase().contains(q) ||
        (g.description?.toLowerCase().contains(q) ?? false)
      ).toList();
    }
    return items;
  }

  @override
  String itemId(CustomerGroupModel item) => item.id;

  @override
  List<CustomerGroupModel> sortItems(List<CustomerGroupModel> items, String column, bool ascending) {
    final sorted = List<CustomerGroupModel>.from(items);
    sorted.sort((a, b) {
      int cmp;
      switch (column) {
        case 'name':
          cmp = a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case 'discount':
          cmp = a.discountPercent.compareTo(b.discountPercent);
        default:
          cmp = a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
      return ascending ? cmp : -cmp;
    });
    return sorted;
  }

  @override
  bool matchesSearch(CustomerGroupModel item, String query) {
    final q = query.toLowerCase();
    return item.name.toLowerCase().contains(q) ||
        (item.description?.toLowerCase().contains(q) ?? false);
  }

  Future<void> _onAdd(AddCustomerGroup event, Emitter<PaginatedState<CustomerGroupModel>> emit) async {
    try {
      await CustomerGroupService.add(
        name: event.name,
        discountPercent: event.discountPercent,
        priceGroupId: event.priceGroupId,
        description: event.description,
      );
      add(const LoadItems());
      AppSnackbar.success('تم إضافة المجموعة بنجاح');
    } catch (e) {
      AppSnackbar.error('فشل في إضافة المجوععة: $e');
    }
  }

  Future<void> _onUpdate(UpdateCustomerGroup event, Emitter<PaginatedState<CustomerGroupModel>> emit) async {
    try {
      await CustomerGroupService.update(event.group);
      add(const LoadItems());
      AppSnackbar.success('تم تحديث المجموعة');
    } catch (e) {
      AppSnackbar.error('فشل في تحديث المجموعة: $e');
    }
  }

  Future<void> _onDelete(DeleteCustomerGroup event, Emitter<PaginatedState<CustomerGroupModel>> emit) async {
    try {
      await CustomerGroupService.delete(event.id);
      add(const LoadItems());
      AppSnackbar.success('تم حذف المجموعة');
    } catch (e) {
      AppSnackbar.error('فشل في حذف المجموعة: $e');
    }
  }

  Future<void> _onToggleActive(ToggleActiveCustomerGroup event, Emitter<PaginatedState<CustomerGroupModel>> emit) async {
    final group = CustomerGroupService.getById(event.id);
    if (group != null) {
      if (group.isActive) {
        await CustomerGroupService.deactivate(event.id);
      } else {
        await CustomerGroupService.update(group.copyWith(isActive: true));
      }
      add(const LoadItems());
    }
  }
}
