import 'package:equatable/equatable.dart';
import '../../../../core/bloc/base_state.dart';
import '../../../../core/models/customer/customer_model.dart';
import '../../../../core/models/customer/customer_ledger_model.dart';

class CustomersState extends Equatable {
  final AsyncState<List<CustomerModel>> dataState;
  final List<CustomerModel> filteredCustomers;
  final List<CustomerModel> pagedCustomers;
  final CustomerModel? selectedCustomer;
  final List<CustomerLedgerModel> ledgerEntries;
  final Map<String, double> balances;
  final bool isLoadingLedger;
  final int currentPage;
  final int totalPages;
  final int currentPageSize;
  final String searchQuery;
  final String sortColumnId;
  final bool isSortAscending;
  final Set<String> selectedIds;

  const CustomersState({
    this.dataState = const Initial(),
    this.filteredCustomers = const [],
    this.pagedCustomers = const [],
    this.selectedCustomer,
    this.ledgerEntries = const [],
    this.balances = const {},
    this.isLoadingLedger = false,
    this.currentPage = 0,
    this.totalPages = 1,
    this.currentPageSize = 10,
    this.searchQuery = '',
    this.sortColumnId = 'name',
    this.isSortAscending = true,
    this.selectedIds = const {},
  });

  List<CustomerModel> get allCustomers => dataState.dataOrNull ?? [];
  int get activeCustomerCount => allCustomers.where((c) => c.isActive).length;
  double get totalBalance => balances.values.fold(0.0, (sum, v) => sum + v);

  CustomersState copyWith({
    AsyncState<List<CustomerModel>>? dataState,
    List<CustomerModel>? filteredCustomers,
    List<CustomerModel>? pagedCustomers,
    CustomerModel? selectedCustomer,
    bool clearSelected = false,
    List<CustomerLedgerModel>? ledgerEntries,
    Map<String, double>? balances,
    bool? isLoadingLedger,
    int? currentPage,
    int? totalPages,
    int? currentPageSize,
    String? searchQuery,
    String? sortColumnId,
    bool? isSortAscending,
    Set<String>? selectedIds,
  }) {
    return CustomersState(
      dataState: dataState ?? this.dataState,
      filteredCustomers: filteredCustomers ?? this.filteredCustomers,
      pagedCustomers: pagedCustomers ?? this.pagedCustomers,
      selectedCustomer: clearSelected ? null : (selectedCustomer ?? this.selectedCustomer),
      ledgerEntries: ledgerEntries ?? this.ledgerEntries,
      balances: balances ?? this.balances,
      isLoadingLedger: isLoadingLedger ?? this.isLoadingLedger,
      currentPage: currentPage ?? this.currentPage,
      totalPages: totalPages ?? this.totalPages,
      currentPageSize: currentPageSize ?? this.currentPageSize,
      searchQuery: searchQuery ?? this.searchQuery,
      sortColumnId: sortColumnId ?? this.sortColumnId,
      isSortAscending: isSortAscending ?? this.isSortAscending,
      selectedIds: selectedIds ?? this.selectedIds,
    );
  }

  @override
  List<Object?> get props => [
    dataState, filteredCustomers, pagedCustomers,
    selectedCustomer, ledgerEntries, balances, isLoadingLedger,
    currentPage, totalPages, currentPageSize, searchQuery, sortColumnId,
    isSortAscending, selectedIds,
  ];
}
