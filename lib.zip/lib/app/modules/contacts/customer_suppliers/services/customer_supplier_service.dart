import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../../../core/models/customer/customer_supplier_model.dart';
import '../../../../core/services/party_ledger_service.dart';
import '../../../../core/services/sync_service.dart';
import '../../../../core/services/auth/auth_service.dart';
import '../../../../modules/archive/services/archive_service.dart';

class CustomerSupplierService {
  static Box get _box => Hive.box('customer_suppliers');
  static const _uuid = Uuid();

  static Future<void> init() async {
  }

  static List<CustomerSupplierModel> getAll({bool activeOnly = true, bool includeDeleted = false}) {
    var items = _box.values.whereType<CustomerSupplierModel>().toList();
    if (!includeDeleted) {
      items = items.where((c) => !c.isDeleted).toList();
    }
    if (activeOnly) {
      items = items.where((c) => c.isActive).toList();
    }
    return items;
  }

  static CustomerSupplierModel? getById(String? id) {
    if (id == null) return null;
    final item = _box.get(id);
    if (item is CustomerSupplierModel) return item;
    return null;
  }

  static Future<CustomerSupplierModel> add({
    required String name,
    String? phone,
    String? address,
    String? email,
    String? companyName,
    String? taxId,
    String? notes,
    int customerKindIndex = 0,
    double creditLimit = 0,
    double discountPercent = 0,
    int paymentTermDays = 0,
    int supplierPartyTypeIndex = 0,
    double openingBalance = 0,
    String openingBalanceDirection = 'debit',
  }) async {
    final model = CustomerSupplierModel(
      id: _uuid.v4(),
      name: name,
      phone: phone,
      address: address,
      email: email,
      companyName: companyName,
      taxId: taxId,
      notes: notes,
      customerKindIndex: customerKindIndex,
      creditLimit: creditLimit,
      discountPercent: discountPercent,
      paymentTermDays: paymentTermDays,
      supplierPartyTypeIndex: supplierPartyTypeIndex,
    );
    await SyncService.create(
      boxName: 'customer_suppliers',
      entity: model,
      branchId: AuthService.currentBranchId ?? '',
      toJson: model.toJson(),
    );

    if (openingBalance > 0) {
      await PartyLedgerService.recordOpeningBalance(
        partyId: model.id,
        amount: openingBalance,
        createdBy: AuthService.currentUser?.id ?? 'system',
        direction: openingBalanceDirection,
        notes: notes,
      );
    }

    return model;
  }

  static Future<void> update(CustomerSupplierModel model) async {
    model.lastModified = DateTime.now();
    await SyncService.update(
      boxName: 'customer_suppliers',
      entity: model,
      branchId: AuthService.currentBranchId ?? '',
      toJson: model.toJson(),
    );
  }

  static Future<void> delete(String id) async {
    final model = getById(id);
    if (model != null) {
      await ArchiveService.record(
        entityType: 'customer_supplier',
        entityId: model.id,
        entityName: model.name,
        entityData: model.toJson(),
        branchId: AuthService.currentBranchId ?? '',
      );

      await SyncService.softDelete(
        boxName: 'customer_suppliers',
        key: id,
        branchId: AuthService.currentBranchId ?? '',
        currentData: model.toJson(),
      );
    }
  }
}
