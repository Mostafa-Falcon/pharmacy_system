import 'package:equatable/equatable.dart';
import '../../../../core/models/customer/customer_supplier_model.dart';

abstract class CustomerSuppliersEvent extends Equatable {
  const CustomerSuppliersEvent();

  @override
  List<Object?> get props => [];
}

class LoadCustomerSuppliers extends CustomerSuppliersEvent {
  const LoadCustomerSuppliers();
}

class SearchCustomerSuppliers extends CustomerSuppliersEvent {
  final String query;
  const SearchCustomerSuppliers(this.query);

  @override
  List<Object?> get props => [query];
}

class SetCustomerSuppliersFilter extends CustomerSuppliersEvent {
  final String filter;
  const SetCustomerSuppliersFilter(this.filter);

  @override
  List<Object?> get props => [filter];
}

class AddCustomerSupplier extends CustomerSuppliersEvent {
  final String name;
  final String? phone;
  final String? address;
  final String? email;
  final String? companyName;
  final String? taxId;
  final String? notes;
  final int customerKindIndex;
  final double creditLimit;
  final double discountPercent;
  final int paymentTermDays;
  final int supplierPartyTypeIndex;
  final double openingBalance;
  final String openingBalanceDirection;

  const AddCustomerSupplier({
    required this.name,
    this.phone,
    this.address,
    this.email,
    this.companyName,
    this.taxId,
    this.notes,
    this.customerKindIndex = 0,
    this.creditLimit = 0,
    this.discountPercent = 0,
    this.paymentTermDays = 0,
    this.supplierPartyTypeIndex = 0,
    this.openingBalance = 0,
    this.openingBalanceDirection = 'debit',
  });

  @override
  List<Object?> get props => [name, phone, address, email, companyName, taxId, notes, customerKindIndex, creditLimit, discountPercent, paymentTermDays, supplierPartyTypeIndex, openingBalance, openingBalanceDirection];
}

class UpdateCustomerSupplier extends CustomerSuppliersEvent {
  final CustomerSupplierModel supplier;
  const UpdateCustomerSupplier(this.supplier);

  @override
  List<Object?> get props => [supplier];
}

class DeleteCustomerSupplier extends CustomerSuppliersEvent {
  final String id;
  const DeleteCustomerSupplier(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectCustomerSupplier extends CustomerSuppliersEvent {
  final CustomerSupplierModel? supplier;
  const SelectCustomerSupplier(this.supplier);

  @override
  List<Object?> get props => [supplier];
}

class LoadSupplierLedger extends CustomerSuppliersEvent {
  final String partyId;
  const LoadSupplierLedger(this.partyId);

  @override
  List<Object?> get props => [partyId];
}

class RecordCashReceipt extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? notes;

  const RecordCashReceipt({required this.partyId, required this.amount, this.notes});

  @override
  List<Object?> get props => [partyId, amount, notes];
}

class RecordCashPayment extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? notes;

  const RecordCashPayment({required this.partyId, required this.amount, this.notes});

  @override
  List<Object?> get props => [partyId, amount, notes];
}

class RecordAdditionNotice extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? notes;
  final String ledgerTarget;

  const RecordAdditionNotice({required this.partyId, required this.amount, this.notes, this.ledgerTarget = 'customer'});

  @override
  List<Object?> get props => [partyId, amount, notes, ledgerTarget];
}

class RecordDiscountNotice extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? notes;
  final String ledgerTarget;

  const RecordDiscountNotice({required this.partyId, required this.amount, this.notes, this.ledgerTarget = 'customer'});

  @override
  List<Object?> get props => [partyId, amount, notes, ledgerTarget];
}

class RecordCheckReceipt extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? checkNumber;
  final String? bankName;
  final String? dueDate;
  final String? notes;

  const RecordCheckReceipt({required this.partyId, required this.amount, this.checkNumber, this.bankName, this.dueDate, this.notes});

  @override
  List<Object?> get props => [partyId, amount, checkNumber, bankName, dueDate, notes];
}

class RecordCheckPayment extends CustomerSuppliersEvent {
  final String partyId;
  final double amount;
  final String? checkNumber;
  final String? bankName;
  final String? dueDate;
  final String? notes;

  const RecordCheckPayment({required this.partyId, required this.amount, this.checkNumber, this.bankName, this.dueDate, this.notes});

  @override
  List<Object?> get props => [partyId, amount, checkNumber, bankName, dueDate, notes];
}

class ClearSupplierSelection extends CustomerSuppliersEvent {
  const ClearSupplierSelection();
}

class ExportSupplierLedger extends CustomerSuppliersEvent {
  final String format;
  const ExportSupplierLedger(this.format);

  @override
  List<Object?> get props => [format];
}
