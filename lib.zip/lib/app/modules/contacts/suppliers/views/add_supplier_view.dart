import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/navigation/app_navigator.dart';

import '../../../../core/models/supplier/supplier_model.dart';
import '../../../../core/theme/app_sizes.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../../app/core/widgets/reusables/index.dart';
import '../../../../core/widgets/shareds/home_shell.dart';
import '../bloc/suppliers_bloc.dart';
import '../bloc/suppliers_event.dart';

class AddSupplierView extends StatefulWidget {
  const AddSupplierView({super.key});

  @override
  State<AddSupplierView> createState() => _AddSupplierViewState();
}

class _AddSupplierViewState extends State<AddSupplierView> {
  final _formKey = GlobalKey<FormState>();
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final companyCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final taxCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final notesCtrl = TextEditingController();
  final creditLimitCtrl = TextEditingController(text: '0');
  final discountCtrl = TextEditingController(text: '0');
  final paymentDaysCtrl = TextEditingController(text: '0');
  final openingBalanceCtrl = TextEditingController();
  var type = SupplierType.supplier;
  var partyType = SupplierPartyType.company;
  var openingBalanceDirection = true;
  var isSaving = false;

  @override
  void dispose() {
    nameCtrl.dispose();
    phoneCtrl.dispose();
    companyCtrl.dispose();
    emailCtrl.dispose();
    taxCtrl.dispose();
    addressCtrl.dispose();
    notesCtrl.dispose();
    creditLimitCtrl.dispose();
    discountCtrl.dispose();
    paymentDaysCtrl.dispose();
    openingBalanceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return HomeShell(
      title: AppStrings.addNewSupplierTitle,
      child: SingleChildScrollView(
        padding: EdgeInsets.all(AppSpacing.xl.w),
        child: Form(
          key: _formKey,
          child: FormCard(
            maxWidth: 500,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ReusableInput(
                  label: AppStrings.nameLabelRequired,
                  hint: AppStrings.supplierNameHint,
                  controller: nameCtrl,
                  textDirection: TextDirection.rtl,
                  validator: (v) => v?.trim().isEmpty == true ? AppStrings.supplierNameRequired : null,
                ),
                SizedBox(height: AppSpacing.md.h),
                StatefulBuilder(
                  builder: (context, setLocalState) => ReusableDropdown<SupplierType>(
                    labelText: AppStrings.typeLabelDropdown,
                    hintText: AppStrings.selectTypeHint,
                    items: const [SupplierType.supplier, SupplierType.customerSupplier],
                    value: type,
                    itemAsString: (t) => t == SupplierType.supplier ? AppStrings.supplierType : AppStrings.customerSupplierType,
                    onChanged: (v) {
                      if (v != null) setLocalState(() => type = v);
                    },
                  ),
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.phoneLabelInput,
                  controller: phoneCtrl,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.rtl,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.companyLabelInput,
                  controller: companyCtrl,
                  textDirection: TextDirection.rtl,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.emailLabelInput,
                  controller: emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.taxIdLabelInput,
                  controller: taxCtrl,
                  textDirection: TextDirection.ltr,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.addressLabelInput,
                  controller: addressCtrl,
                  maxLines: 2,
                  textDirection: TextDirection.rtl,
                ),
                SizedBox(height: AppSpacing.md.h),
                StatefulBuilder(
                  builder: (context, setLocalState) => ReusableDropdown<SupplierPartyType>(
                    labelText: AppStrings.partyTypeLabel,
                    hintText: AppStrings.selectPartyTypeHint,
                    items: const [SupplierPartyType.company, SupplierPartyType.individual],
                    value: partyType,
                    itemAsString: (p) => p == SupplierPartyType.company ? AppStrings.enumPartyTypeCompany : AppStrings.enumPartyTypeIndividual,
                    onChanged: (v) {
                      if (v != null) setLocalState(() => partyType = v);
                    },
                  ),
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.creditLimitLabelInput,
                  controller: creditLimitCtrl,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.discountPercentLabelInput,
                  controller: discountCtrl,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.paymentTermDaysLabelInput,
                  controller: paymentDaysCtrl,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: AppSpacing.md.h),
                Row(
                  children: [
                    Expanded(
                      child: ReusableInput(
                        label: AppStrings.openingBalanceLabelInput,
                        controller: openingBalanceCtrl,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    SizedBox(width: AppSpacing.md.w),
                    Expanded(
                      child: StatefulBuilder(
                        builder: (context, setLocalState) => ReusableDropdown<bool>(
                          labelText: AppStrings.balanceDirectionLabel,
                          hintText: AppStrings.select,
                          items: const [true, false],
                          value: openingBalanceDirection,
                          itemAsString: (d) => d ? AppStrings.debitDirection : AppStrings.creditDirection,
                          onChanged: (v) {
                            if (v != null) setLocalState(() => openingBalanceDirection = v);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: AppSpacing.md.h),
                ReusableInput(
                  label: AppStrings.notesLabelInput,
                  controller: notesCtrl,
                  maxLines: 3,
                  textDirection: TextDirection.rtl,
                ),
                SizedBox(height: AppSpacing.lg.h),
                Row(
                  children: [
                    Expanded(
                      child: ReusableButton(
                        text: AppStrings.cancel,
                        type: ButtonType.outlined,
                        onPressed: () => AppNavigator.back(),
                      ),
                    ),
                    SizedBox(width: AppSpacing.md.w),
                    Expanded(
                      child: ReusableButton(
                        text: AppStrings.save,
                        isLoading: isSaving,
                        onPressed: _submit,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => isSaving = true);
    context.read<SuppliersBloc>().add(AddSupplier(
      name: nameCtrl.text.trim(),
      type: type,
      partyType: partyType,
      phone: phoneCtrl.text.trim().isEmpty ? null : phoneCtrl.text.trim(),
      address: addressCtrl.text.trim().isEmpty ? null : addressCtrl.text.trim(),
      companyName: companyCtrl.text.trim().isEmpty ? null : companyCtrl.text.trim(),
      email: emailCtrl.text.trim().isEmpty ? null : emailCtrl.text.trim(),
      taxId: taxCtrl.text.trim().isEmpty ? null : taxCtrl.text.trim(),
      creditLimit: double.tryParse(creditLimitCtrl.text) ?? 0,
      discountPercent: double.tryParse(discountCtrl.text) ?? 0,
      paymentTermDays: int.tryParse(paymentDaysCtrl.text) ?? 0,
      openingBalance: double.tryParse(openingBalanceCtrl.text) ?? 0,
      openingBalanceIsDebit: openingBalanceDirection,
      notes: notesCtrl.text.trim().isEmpty ? null : notesCtrl.text.trim(),
    ));
    AppNavigator.back();
  }
}

