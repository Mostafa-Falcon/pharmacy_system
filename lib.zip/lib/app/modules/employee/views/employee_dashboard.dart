import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/injection.dart';
import '../../../core/widgets/shareds/home_shell.dart';
import '../../home/bloc/monitoring_dashboard_bloc.dart';
import '../../home/views/dashboard_view.dart';
import '../bloc/employee_bloc.dart';

class EmployeeDashboardView extends StatelessWidget {
  const EmployeeDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: sl<EmployeeBloc>()),
        BlocProvider.value(value: sl<MonitoringDashboardBloc>()),
      ],
      child: const HomeShell(
        title: 'لوحة المتابعة',
        child: DashboardView(),
      ),
    );
  }
}
