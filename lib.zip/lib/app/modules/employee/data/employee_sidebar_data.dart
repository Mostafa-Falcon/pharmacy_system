import 'package:flutter/material.dart';
import '../../../core/widgets/shareds/sidebar.dart';
import '../../../core/services/auth/auth_service.dart';

List<SidebarGroup> getEmployeeSidebarGroups() {
  final user = AuthService.currentUser;
  if (user == null) return [];

  final groups = <SidebarGroup>[];

  // ─── الرئيسية ───
  final mainChildren = <SidebarItem>[
    SidebarItem(
      id: 'main_page',
      icon: Icons.home_rounded,
      label: 'الصفحة الرئيسية',
    ),
    SidebarItem(
      id: 'employee_dashboard',
      icon: Icons.analytics_rounded,
      label: 'لوحة المتابعة',
    ),
  ];

  // ─── العمليات ───
  final operationsChildren = <SidebarItem>[];

  if (AuthService.hasPermission('sales.view')) {
    operationsChildren.add(
      SidebarItem(
        id: 'sales',
        icon: Icons.point_of_sale_rounded,
        label: 'المبيعات',
        children: [
          SidebarItem(
            id: 'pos',
            icon: Icons.shopping_cart_rounded,
            label: 'نقطة البيع',
          ),
          SidebarItem(
            id: 'cashier_shifts',
            icon: Icons.access_time_rounded,
            label: 'ورديات الكاشير',
          ),
          SidebarItem(
            id: 'sales_invoice',
            icon: Icons.description_rounded,
            label: 'فواتير المبيعات',
          ),
          SidebarItem(
            id: 'sales_return',
            icon: Icons.currency_exchange_rounded,
            label: 'مرتجعات المبيعات',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('purchases.view')) {
    operationsChildren.add(
      SidebarItem(
        id: 'purchases',
        icon: Icons.inventory_2_rounded,
        label: 'المشتريات',
        children: [
          SidebarItem(
            id: 'purchase_order',
            icon: Icons.add_shopping_cart_rounded,
            label: 'فاتورة شراء جديدة',
          ),
          SidebarItem(
            id: 'purchase_return',
            icon: Icons.inventory_rounded,
            label: 'مرتجعات المشتريات',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('inventory.view')) {
    operationsChildren.add(
      SidebarItem(
        id: 'items',
        icon: Icons.medication_rounded,
        label: 'الأدوية',
        children: [
          SidebarItem(
            id: 'items_list',
            icon: Icons.list_alt_rounded,
            label: 'قائمة الأدوية',
          ),
          SidebarItem(
            id: 'inventory_health',
            icon: Icons.health_and_safety_outlined,
            label: 'حالة المخزون',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('contacts.view')) {
    operationsChildren.add(
      SidebarItem(
        id: 'contacts',
        icon: Icons.contacts_rounded,
        label: 'جهات الاتصال',
        children: [
          SidebarItem(
            id: 'customers',
            icon: Icons.group_outlined,
            label: 'العملاء',
          ),
          SidebarItem(
            id: 'suppliers',
            icon: Icons.business_outlined,
            label: 'الموردين',
          ),
          SidebarItem(
            id: 'customer_suppliers',
            icon: Icons.swap_horiz_rounded,
            label: 'عملاء/موردين',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('reports.view')) {
    operationsChildren.add(
      SidebarItem(
        id: 'reports',
        icon: Icons.analytics_rounded,
        label: 'التقارير',
        children: [
          SidebarItem(
            id: 'sales_report',
            icon: Icons.bar_chart_rounded,
            label: 'تقرير المبيعات',
          ),
        ],
      ),
    );
  }

  groups.add(SidebarGroup(label: 'الرئيسية', children: mainChildren));

  if (operationsChildren.isNotEmpty) {
    groups.add(SidebarGroup(label: 'العمليات', children: operationsChildren));
  }

  return groups;
}
