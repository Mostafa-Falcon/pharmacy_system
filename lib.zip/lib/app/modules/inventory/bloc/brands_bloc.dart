import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/bloc/base_paginated_bloc.dart';
import '../../../core/utils/app_snackbar.dart';
import '../models/medicine_brand_model.dart';
import '../services/brand_service.dart';

// ─── Custom Events ───

class AddBrand extends PaginatedEvent {
  final String name;
  final String? description;
  final String? logo;
  const AddBrand({required this.name, this.description, this.logo});
  @override
  List<Object?> get props => [name, description, logo];
}

class UpdateBrand extends PaginatedEvent {
  final MedicineBrandModel brand;
  const UpdateBrand(this.brand);
  @override
  List<Object?> get props => [brand];
}

class DeleteBrand extends PaginatedEvent {
  final String id;
  const DeleteBrand(this.id);
  @override
  List<Object?> get props => [id];
}

// ─── Bloc ───

class BrandsBloc extends BasePaginatedBloc<MedicineBrandModel> {
  BrandsBloc() {
    on<AddBrand>(_onAdd);
    on<UpdateBrand>(_onUpdate);
    on<DeleteBrand>(_onDelete);
    add(const LoadItems());
  }

  @override
  Future<List<MedicineBrandModel>> fetchItems(PaginatedState<MedicineBrandModel> state) async {
    var items = BrandService.getAll();
    if (state.searchQuery.isNotEmpty) {
      final q = state.searchQuery.toLowerCase();
      items = items.where((b) =>
        b.name.toLowerCase().contains(q) ||
        (b.description?.toLowerCase().contains(q) ?? false)
      ).toList();
    }
    return items;
  }

  @override
  String itemId(MedicineBrandModel item) => item.id;

  @override
  List<MedicineBrandModel> sortItems(List<MedicineBrandModel> items, String column, bool ascending) {
    final sorted = List<MedicineBrandModel>.from(items);
    sorted.sort((a, b) {
      int cmp;
      switch (column) {
        case 'name':
          cmp = a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case 'description':
          cmp = (a.description ?? '').toLowerCase().compareTo((b.description ?? '').toLowerCase());
        default:
          cmp = a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
      return ascending ? cmp : -cmp;
    });
    return sorted;
  }

  @override
  bool matchesSearch(MedicineBrandModel item, String query) {
    final q = query.toLowerCase();
    return item.name.toLowerCase().contains(q) ||
        (item.description?.toLowerCase().contains(q) ?? false);
  }

  Future<void> _onAdd(AddBrand event, Emitter<PaginatedState<MedicineBrandModel>> emit) async {
    if (BrandService.nameExists(event.name)) {
      AppSnackbar.error('اسم العلامة التجارية موجود مسبقاً');
      return;
    }
    await BrandService.add(
      name: event.name,
      description: event.description,
      logo: event.logo,
    );
    add(const LoadItems());
  }

  Future<void> _onUpdate(UpdateBrand event, Emitter<PaginatedState<MedicineBrandModel>> emit) async {
    if (BrandService.nameExists(event.brand.name, excludeId: event.brand.id)) {
      AppSnackbar.error('اسم العلامة التجارية موجود مسبقاً');
      return;
    }
    await BrandService.update(event.brand);
    add(const LoadItems());
  }

  Future<void> _onDelete(DeleteBrand event, Emitter<PaginatedState<MedicineBrandModel>> emit) async {
    await BrandService.delete(event.id);
    add(const LoadItems());
  }
}
