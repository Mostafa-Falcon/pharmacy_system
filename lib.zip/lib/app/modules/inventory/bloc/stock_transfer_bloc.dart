import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';

import '../../../core/models/security/branch_model.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/admin/branch_data_service.dart';
import '../../../core/services/inventory/stock_mutation_service.dart';
import '../../../core/utils/app_snackbar.dart';
import '../models/inventory_enums.dart';
import '../models/stock_transfer_model.dart';
import '../services/inventory_transaction_service.dart';
import '../services/stock_quantity_guard.dart';
import 'stock_transfer_event.dart';
import 'stock_transfer_state.dart';

export 'stock_transfer_event.dart';
export 'stock_transfer_state.dart';

class StockTransferBloc extends Bloc<StockTransferEvent, StockTransferState> {
  String get _branchId => AuthService.currentBranchId ?? '';
  String get _userId => AuthService.currentUser?.id ?? '';

  StockTransferBloc() : super(const StockTransferState()) {
    on<LoadStockTransfers>(_onLoad);
    on<SelectTransferTab>(_onSelectTab);
    on<SendTransfer>(_onSendTransfer);
    on<ReceiveTransfer>(_onReceiveTransfer);
    on<CancelTransfer>(_onCancelTransfer);
  }

  Future<void> _onLoad(LoadStockTransfers event, Emitter<StockTransferState> emit) async {
    emit(state.copyWith(status: StockTransferStatus.loading));
    try {
      final branches = _loadBranches();
      final transfers = _loadTransfers();
      emit(state.copyWith(
        status: StockTransferStatus.loaded,
        branches: branches,
        transfers: transfers,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: StockTransferStatus.error,
        error: e.toString(),
      ));
    }
  }

  void _onSelectTab(SelectTransferTab event, Emitter<StockTransferState> emit) {
    emit(state.copyWith(selectedTab: event.index));
  }

  List<BranchModel> _loadBranches() {
    final box = Hive.box('branches');
    return box.values
        .whereType<BranchModel>()
        .where((b) => b.id != _branchId && b.isActive)
        .toList();
  }

  List<StockTransferModel> _loadTransfers() {
    final box = Hive.box('stock_transfers');
    final all = box.values
        .whereType<String>()
        .map((json) {
          try {
            return StockTransferModel.fromJson(
              jsonDecode(json) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<StockTransferModel>()
        .where((t) => t.fromBranchId == _branchId || t.toBranchId == _branchId)
        .toList();
    all.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return all;
  }

  Future<void> _onSendTransfer(SendTransfer event, Emitter<StockTransferState> emit) async {
    emit(state.copyWith(isProcessing: true));
    try {
      final transfer = event.transfer;
      for (final item in transfer.items) {
        StockQuantityGuard.ensureSufficientStock(
          transfer.fromBranchId,
          item.medicineId,
          item.quantity.toDouble(),
          medicineName: item.medicineName,
        );
      }

      final updated = transfer.copyWith(
        status: TransferStatus.sent,
        updatedAt: DateTime.now(),
      );

      final box = Hive.box('stock_transfers');
      await box.put(updated.id, jsonEncode(updated.toJson()));

      for (final item in updated.items) {
        // خصم من فرع المصدر عبر StockMutationService (القفل + طابور المزامنة)
        // بدل التعديل المباشر، عشان التغيير يتدفع لـ Supabase ويتجنب السباق.
        final medicine = BranchDataService.getMedicine(item.medicineId);
        if (medicine != null && medicine.branchId == updated.fromBranchId) {
          await StockMutationService.adjustStock(
            medicineId: item.medicineId,
            delta: -item.quantity,
            branchId: updated.fromBranchId,
          );
        }
      }

      await InventoryTransactionService.to.transferStock(
        transfer: updated,
        actorId: _userId,
      );

      final transfers = _loadTransfers();
      emit(state.copyWith(transfers: transfers, isProcessing: false));
      AppSnackbar.success('تم إرسال التحويل رقم ${transfer.transferNumber}');
    } catch (e) {
      AppSnackbar.error('فشل إرسال التحويل: $e');
      emit(state.copyWith(isProcessing: false));
    }
  }

  Future<void> _onReceiveTransfer(ReceiveTransfer event, Emitter<StockTransferState> emit) async {
    emit(state.copyWith(isProcessing: true));
    try {
      final box = Hive.box('stock_transfers');
      final raw = box.get(event.id);
      if (raw == null) {
        AppSnackbar.error('التحويل غير موجود');
        emit(state.copyWith(isProcessing: false));
        return;
      }
      final transfer = StockTransferModel.fromJson(
        jsonDecode(raw as String) as Map<String, dynamic>,
      );

      if (transfer.status != TransferStatus.sent) {
        AppSnackbar.error('يمكن استلام التحويلات المرسلة فقط');
        emit(state.copyWith(isProcessing: false));
        return;
      }

      for (final item in transfer.items) {
        final medicines = BranchDataService.getMedicines(
          branchId: transfer.toBranchId,
        );
        final existing = medicines.cast<MedicineModel?>().firstWhere(
          (m) => m!.id == item.medicineId,
          orElse: () => null,
        );

        if (existing != null) {
          // إضافة لفرع الوجهة عبر StockMutationService (القفل + طابور المزامنة).
          await StockMutationService.adjustStock(
            medicineId: item.medicineId,
            delta: item.quantity,
            branchId: transfer.toBranchId,
          );
        }
      }

      final updated = transfer.copyWith(
        status: TransferStatus.received,
        receivedAt: DateTime.now(),
        receivedBy: _userId,
        updatedAt: DateTime.now(),
      );
      await box.put(updated.id, jsonEncode(updated.toJson()));

      final transfers = _loadTransfers();
      emit(state.copyWith(transfers: transfers, isProcessing: false));
      AppSnackbar.success('تم استلام التحويل رقم ${transfer.transferNumber}');
    } catch (e) {
      AppSnackbar.error('فشل استلام التحويل: $e');
      emit(state.copyWith(isProcessing: false));
    }
  }

  Future<void> _onCancelTransfer(CancelTransfer event, Emitter<StockTransferState> emit) async {
    emit(state.copyWith(isProcessing: true));
    try {
      final box = Hive.box('stock_transfers');
      final raw = box.get(event.id);
      if (raw == null) {
        emit(state.copyWith(isProcessing: false));
        return;
      }

      final transfer = StockTransferModel.fromJson(
        jsonDecode(raw as String) as Map<String, dynamic>,
      );

      if (transfer.status == TransferStatus.draft) {
        final updated = transfer.copyWith(
          status: TransferStatus.cancelled,
          updatedAt: DateTime.now(),
        );
        await box.put(updated.id, jsonEncode(updated.toJson()));
        final transfers = _loadTransfers();
        emit(state.copyWith(transfers: transfers, isProcessing: false));
        AppSnackbar.warning(
          'تم إلغاء التحويل رقم ${transfer.transferNumber}',
          title: 'تم',
        );
        return;
      }

      if (transfer.status == TransferStatus.sent) {
        for (final item in transfer.items) {
          final medicines = BranchDataService.getMedicines(
            branchId: transfer.fromBranchId,
          );
          final medicine = medicines.cast<MedicineModel?>().firstWhere(
            (m) => m!.id == item.medicineId,
            orElse: () => null,
          );

          if (medicine != null) {
            // استرجاع للمصدر عبر StockMutationService (القفل + طابور المزامنة).
            await StockMutationService.adjustStock(
              medicineId: item.medicineId,
              delta: item.quantity,
              branchId: transfer.fromBranchId,
            );
          }
        }

        final updated = transfer.copyWith(
          status: TransferStatus.cancelled,
          updatedAt: DateTime.now(),
        );
        await box.put(updated.id, jsonEncode(updated.toJson()));
        final transfers = _loadTransfers();
        emit(state.copyWith(transfers: transfers, isProcessing: false));
        AppSnackbar.warning(
          'تم إلغاء التحويل رقم ${transfer.transferNumber} وإرجاع المخزون',
          title: 'تم',
        );
      }
    } catch (e) {
      AppSnackbar.error('فشل إلغاء التحويل: $e');
      emit(state.copyWith(isProcessing: false));
    }
  }
}
