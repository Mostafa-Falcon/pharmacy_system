import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';

import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/admin/branch_data_service.dart';
import '../../../core/utils/app_snackbar.dart';
import 'items_archive_event.dart';
import 'items_archive_state.dart';

export 'items_archive_event.dart';
export 'items_archive_state.dart';

abstract final class _SearchNormalizer {
  static final _diacritics =
      RegExp(r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]');
  static final _ws = RegExp(r'\s+');

  static String normalize(String? v) {
    if (v == null || v.isEmpty) return '';
    return v
        .replaceAll('\u0640', '')
        .replaceAll(_diacritics, '')
        .replaceAll(RegExp(r'[أإآٱ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ؤ', 'و')
        .replaceAll('ئ', 'ي')
        .replaceAll('ة', 'ه')
        .toLowerCase()
        .trim()
        .replaceAll(_ws, ' ');
  }

  static String combine(Iterable<String?> vs) =>
      vs.map(normalize).where((v) => v.isNotEmpty).toSet().join(' ');
}

class ItemsArchiveBloc extends Bloc<ItemsArchiveEvent, ItemsArchiveState> {
  StreamSubscription<BoxEvent>? _subscription;
  List<MedicineModel> _source = [];

  String get _branchId => AuthService.currentBranchId ?? '';
  bool get canManage => AuthService.currentUser?.isOwner ?? false;

  ItemsArchiveBloc() : super(const ItemsArchiveState()) {
    on<LoadItemsArchive>(_onLoad);
    on<SearchItemsArchive>(_onSearch);
    on<ToggleItemSelection>(_onToggleSelection);
    on<ToggleAllSelection>(_onToggleAll);
    on<RestoreItem>(_onRestoreItem);
    on<RestoreSelected>(_onRestoreSelected);
    on<DeleteItem>(_onDeleteItem);
    on<DeleteSelected>(_onDeleteSelected);
  }

  @override
  Future<void> close() {
    _subscription?.cancel();
    return super.close();
  }

  Future<void> _onLoad(LoadItemsArchive event, Emitter<ItemsArchiveState> emit) async {
    if (!canManage) return;
    emit(state.copyWith(status: ItemsArchiveStatus.loading));
    try {
      final all = Hive.box('medicines').values.whereType<MedicineModel>().toList();
      _source = all
          .where((m) => m.branchId == _branchId && m.isDeleted)
          .toList(growable: false)
        ..sort((a, b) => b.lastModified.compareTo(a.lastModified));
      _applyFilter(emit, '');
      _subscription?.cancel();
      _subscription = Hive.box('medicines').watch().listen((_) {
        add(const LoadItemsArchive());
      });
    } on Object catch (_) {
      emit(state.copyWith(status: ItemsArchiveStatus.error));
    }
  }

  void _onSearch(SearchItemsArchive event, Emitter<ItemsArchiveState> emit) {
    _applyFilter(emit, event.query);
  }

  void _applyFilter(Emitter<ItemsArchiveState> emit, String query) {
    final normalized = _SearchNormalizer.normalize(query);
    final filtered = _source.where((item) {
      if (normalized.isEmpty) return true;
      final barcodes = [
        ...item.barcodes,
        ...item.units.map((u) => u.barcode),
      ];
      return _SearchNormalizer
          .combine([
            item.name,
            item.nameEn,
            ...barcodes,
            item.category,
            item.manufacturer,
          ])
          .contains(normalized);
    }).toList();
    final validIds =
        state.selectedIds.where((id) => filtered.any((i) => i.id == id)).toSet();
    emit(state.copyWith(
      status: ItemsArchiveStatus.loaded,
      items: filtered,
      selectedIds: validIds,
    ));
  }

  void _onToggleSelection(ToggleItemSelection event, Emitter<ItemsArchiveState> emit) {
    final ids = Set<String>.from(state.selectedIds);
    ids.contains(event.id) ? ids.remove(event.id) : ids.add(event.id);
    emit(state.copyWith(selectedIds: ids));
  }

  void _onToggleAll(ToggleAllSelection event, Emitter<ItemsArchiveState> emit) {
    final allSelected =
        state.items.isNotEmpty && state.items.every((i) => state.selectedIds.contains(i.id));
    emit(state.copyWith(
      selectedIds: allSelected ? const {} : state.items.map((i) => i.id).toSet(),
    ));
  }

  Future<void> _onRestoreItem(RestoreItem event, Emitter<ItemsArchiveState> emit) async {
    final idx = _source.indexWhere((i) => i.id == event.id);
    if (idx == -1) return;
    await _restore([_source[idx]], emit);
  }

  Future<void> _onRestoreSelected(RestoreSelected event, Emitter<ItemsArchiveState> emit) async {
    final items = _source.where((i) => state.selectedIds.contains(i.id)).toList();
    await _restore(items, emit);
  }

  Future<void> _restore(List<MedicineModel> items, Emitter<ItemsArchiveState> emit) async {
    if (!canManage || items.isEmpty || state.isWorking) return;
    emit(state.copyWith(isWorking: true));
    var failed = 0;
    try {
      for (final item in items) {
        try {
          await BranchDataService.updateMedicine(item.copyWith(isDeleted: false));
        } on Object catch (_) {
          failed++;
        }
      }
      emit(state.copyWith(selectedIds: const {}));
      if (failed == 0) {
        AppSnackbar.success('عادت الأصناف المحددة إلى دليل الأصناف.', title: 'تمت الاستعادة');
      } else {
        AppSnackbar.warning('تعذر استعادة $failed صنف.', title: 'اكتملت العملية جزئيًا');
      }
      add(const LoadItemsArchive());
    } finally {
      emit(state.copyWith(isWorking: false));
    }
  }

  Future<void> _onDeleteItem(DeleteItem event, Emitter<ItemsArchiveState> emit) async {
    final idx = _source.indexWhere((i) => i.id == event.id);
    if (idx == -1) return;
    await _executeDelete([_source[idx]], emit);
  }

  Future<void> _onDeleteSelected(DeleteSelected event, Emitter<ItemsArchiveState> emit) async {
    final items = _source.where((i) => state.selectedIds.contains(i.id)).toList();
    await _executeDelete(items, emit);
  }

  Future<void> _executeDelete(List<MedicineModel> items, Emitter<ItemsArchiveState> emit) async {
    emit(state.copyWith(isWorking: true));
    var failed = 0;
    try {
      final box = Hive.box('medicines');
      for (final item in items) {
        try {
          await box.delete(item.id);
        } on Object catch (_) {
          failed++;
        }
      }
      emit(state.copyWith(selectedIds: const {}));
      if (failed == 0) {
        AppSnackbar.error('تم حذف الأصناف المحددة نهائيًا.', title: 'تم الحذف النهائي');
      } else {
        AppSnackbar.warning('تعذر حذف $failed صنف.', title: 'اكتملت العملية جزئيًا');
      }
      add(const LoadItemsArchive());
    } finally {
      emit(state.copyWith(isWorking: false));
    }
  }
}
