import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../models/medicine_variant_model.dart';

class VariantService {
  static Box get _box => Hive.box('medicine_variants');
  static const _uuid = Uuid();

  static List<MedicineVariantModel> getByMedicine(String medicineId) {
    return _box.values
        .map((e) => MedicineVariantModel.fromJson(Map<String, dynamic>.from(e)))
        .where((v) => v.medicineId == medicineId)
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  static MedicineVariantModel? getById(String? id) {
    if (id == null) return null;
    final data = _box.get(id);
    if (data == null) return null;
    return MedicineVariantModel.fromJson(Map<String, dynamic>.from(data));
  }

  static MedicineVariantModel? getBySku(String sku) {
    try {
      return _box.values
          .map((e) => MedicineVariantModel.fromJson(Map<String, dynamic>.from(e)))
          .firstWhere(
              (v) => v.sku.toLowerCase() == sku.toLowerCase().trim());
    } catch (_) {
      return null;
    }
  }

  static bool skuExists(String sku, {String? excludeId}) {
    return _box.values
        .map((e) => MedicineVariantModel.fromJson(Map<String, dynamic>.from(e)))
        .any((v) =>
            v.sku.toLowerCase() == sku.toLowerCase().trim() &&
            v.id != excludeId);
  }

  static Future<MedicineVariantModel> add({
    required String medicineId,
    required String name,
    required String sku,
    required double price,
    required double cost,
    Map<String, String>? attributes,
  }) async {
    final variant = MedicineVariantModel(
      id: _uuid.v4(),
      medicineId: medicineId,
      name: name,
      sku: sku,
      price: price,
      cost: cost,
      attributes: attributes ?? {},
    );
    await _box.putSynced(variant.id, variant.toJson(), table: 'medicine_variants', branchId: AuthService.currentBranchId ?? '');
    return variant;
  }

  static Future<void> update(MedicineVariantModel variant) async {
    await _box.putSynced(variant.id, variant.toJson(), table: 'medicine_variants', branchId: AuthService.currentBranchId ?? '');
  }

  static Future<void> delete(String id) async {
    await _box.delete(id);
  }

  static Future<void> deleteByMedicine(String medicineId) async {
    final keys = _box.keys.toList();
    for (final key in keys) {
      final data = _box.get(key);
      if (data == null) continue;
      final v = MedicineVariantModel.fromJson(Map<String, dynamic>.from(data));
      if (v.medicineId == medicineId) {
        await _box.delete(key);
      }
    }
  }
}
