import 'package:hive/hive.dart';
import '../models/barcode_settings_model.dart';

class BarcodeSettingsService {
  static Box get _box => Hive.box('settings');

  static BarcodeSettingsModel get settings {
    final data = _box.get('barcode_settings');
    if (data == null) return const BarcodeSettingsModel();
    return BarcodeSettingsModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<void> save(BarcodeSettingsModel settings) async {
    await _box.put('barcode_settings', settings.toJson());
  }
}
