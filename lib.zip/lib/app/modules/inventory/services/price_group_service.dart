import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../models/price_group_model.dart';

class PriceGroupService {
  static Box get _box => Hive.box('price_groups');
  static const _uuid = Uuid();

  static List<PriceGroupModel> getAll() {
    return _box.values
        .map((e) => PriceGroupModel.fromJson(Map<String, dynamic>.from(e)))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  static PriceGroupModel? getById(String? id) {
    if (id == null) return null;
    final data = _box.get(id);
    if (data == null) return null;
    return PriceGroupModel.fromJson(Map<String, dynamic>.from(data));
  }

  static PriceGroupModel? getDefault() {
    final all = getAll();
    try {
      return all.firstWhere((g) => g.isDefault);
    } catch (_) {
      return null;
    }
  }

  static Future<PriceGroupModel> add({
    required String name,
    double markupPercentage = 0,
    double discountPercentage = 0,
    bool isDefault = false,
  }) async {
    if (isDefault) await _clearDefault();
    final group = PriceGroupModel(
      id: _uuid.v4(),
      name: name,
      markupPercentage: markupPercentage,
      discountPercentage: discountPercentage,
      isDefault: isDefault,
    );
    await _box.putSynced(group.id, group.toJson(), table: 'price_groups', branchId: AuthService.currentBranchId ?? '');
    return group;
  }

  static Future<void> update(PriceGroupModel group) async {
    if (group.isDefault) await _clearDefault(excludeId: group.id);
    await _box.putSynced(group.id, group.toJson(), table: 'price_groups', branchId: AuthService.currentBranchId ?? '');
  }

  static Future<void> delete(String id) async {
    await _box.delete(id);
  }

  static Future<void> _clearDefault({String? excludeId}) async {
    final keys = _box.keys.toList();
    for (final key in keys) {
      if (key == excludeId) continue;
      final raw = _box.get(key);
      if (raw == null) continue;
      final data = Map<String, dynamic>.from(raw);
      data['is_default'] = false;
      await _box.putSynced(key, data, table: 'price_groups', branchId: AuthService.currentBranchId ?? '');
    }
  }

  static bool nameExists(String name, {String? excludeId}) {
    return getAll().any((g) =>
        g.name.toLowerCase() == name.toLowerCase().trim() &&
        g.id != excludeId);
  }

  static double applyMarkup(double basePrice, String priceGroupId) {
    final group = getById(priceGroupId);
    if (group == null) return basePrice;
    final markedUp = basePrice * (1 + group.markupPercentage / 100);
    return markedUp * (1 - group.discountPercentage / 100);
  }
}
