import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../models/medicine_brand_model.dart';

class BrandService {
  static Box get _box => Hive.box('medicine_brands');
  static const _uuid = Uuid();

  static List<MedicineBrandModel> getAll() {
    return _box.values
        .map((e) => MedicineBrandModel.fromJson(Map<String, dynamic>.from(e)))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  static MedicineBrandModel? getById(String? id) {
    if (id == null) return null;
    final data = _box.get(id);
    if (data == null) return null;
    return MedicineBrandModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<MedicineBrandModel> add({
    required String name,
    String? description,
    String? logo,
  }) async {
    final brand = MedicineBrandModel(
      id: _uuid.v4(),
      name: name,
      description: description,
      logo: logo,
      createdAt: DateTime.now(),
    );
    await _box.putSynced(brand.id, brand.toJson(), table: 'medicines', branchId: AuthService.currentBranchId ?? '');
    return brand;
  }

  static Future<void> update(MedicineBrandModel brand) async {
    await _box.putSynced(brand.id, brand.toJson(), table: 'medicines', branchId: AuthService.currentBranchId ?? '');
  }

  static Future<void> delete(String id) async {
    await _box.delete(id);
  }

  static bool nameExists(String name, {String? excludeId}) {
    return getAll().any((b) =>
        b.name.toLowerCase() == name.toLowerCase().trim() &&
        b.id != excludeId);
  }
}
