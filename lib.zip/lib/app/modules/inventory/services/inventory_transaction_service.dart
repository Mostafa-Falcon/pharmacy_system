import 'dart:convert';
import 'package:hive/hive.dart';
import 'package:get_it/get_it.dart';

import '../models/inventory_enums.dart';
import '../models/stock_adjustment_model.dart';
import '../models/stock_movement_model.dart';
import '../models/stock_transfer_model.dart';

class InventoryTransactionService {
  static final InventoryTransactionService _instance = InventoryTransactionService._internal();
  factory InventoryTransactionService() => _instance;
  InventoryTransactionService._internal();

  static InventoryTransactionService get to => GetIt.instance<InventoryTransactionService>();

  late Box _movementBox;
  late Box _adjustmentBox;
  late Box _transferBox;

  Future<void> init() async {
    _movementBox = await Hive.openBox('stock_movements');
    _adjustmentBox = await Hive.openBox('stock_adjustments');
    _transferBox = await Hive.openBox('stock_transfers');
  }

  Future<void> recordMovement(StockMovementModel movement) async {
    await _movementBox.put(movement.id, jsonEncode(movement.toJson()));
  }

  List<StockMovementModel> getMovements({
    String? branchId,
    String? medicineId,
    int limit = 100,
  }) {
    var all = _movementBox.values
        .whereType<String>()
        .map((json) {
          try {
            return StockMovementModel.fromJson(
                jsonDecode(json) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<StockMovementModel>()
        .toList();

    if (branchId != null) {
      all = all.where((m) => m.branchId == branchId).toList();
    }
    if (medicineId != null) {
      all = all.where((m) => m.medicineId == medicineId).toList();
    }

    all.sort((a, b) => b.occurredAt.compareTo(a.occurredAt));
    if (all.length > limit) all = all.sublist(0, limit);
    return all;
  }

  Future<void> adjustStock({
    required StockAdjustmentModel adjustment,
    required String actorId,
  }) async {
    await _adjustmentBox.put(
        adjustment.id, jsonEncode(adjustment.toJson()));

    for (final line in adjustment.items) {
      final movement = StockMovementModel(
        id: 'mov_${line.id}',
        operationId: 'adjustment:${adjustment.id}',
        pharmacyId: adjustment.pharmacyId,
        branchId: adjustment.branchId,
        medicineId: line.itemId,
        medicineName: line.itemName,
        batchId: line.batchId,
        unitId: line.unitId,
        type: line.type == AdjustmentType.addition
            ? MovementType.adjustmentIncrease
            : MovementType.adjustmentDecrease,
        quantity: line.type == AdjustmentType.reduction
            ? -line.quantity
            : line.quantity,
        unitCost: line.unitCost ?? 0,
        referenceType: 'stock_adjustment',
        referenceId: adjustment.id,
        actorId: actorId,
        occurredAt: DateTime.now().toUtc(),
      );
      await recordMovement(movement);
    }
  }

  Future<void> transferStock({
    required StockTransferModel transfer,
    required String actorId,
  }) async {
    await _transferBox.put(transfer.id, jsonEncode(transfer.toJson()));

    for (final line in transfer.items) {
      final outMovement = StockMovementModel(
        id: 'mov_out_${line.medicineId}_${DateTime.now().millisecondsSinceEpoch}',
        operationId: 'transfer:${transfer.id}',
        pharmacyId: transfer.branchId.isNotEmpty ? transfer.branchId : '',
        branchId: transfer.fromBranchId,
        medicineId: line.medicineId,
        medicineName: line.medicineName,
        batchId: line.batchId,
        type: MovementType.transferOut,
        quantity: -line.quantity.toDouble(),
        unitCost: line.unitCost,
        referenceType: 'stock_transfer',
        referenceId: transfer.id,
        actorId: actorId,
        occurredAt: DateTime.now().toUtc(),
      );
      await recordMovement(outMovement);

      final inMovement = StockMovementModel(
        id: 'mov_in_${line.medicineId}_${DateTime.now().millisecondsSinceEpoch}',
        operationId: 'transfer:${transfer.id}',
        pharmacyId: transfer.branchId.isNotEmpty ? transfer.branchId : '',
        branchId: transfer.toBranchId,
        medicineId: line.medicineId,
        medicineName: line.medicineName,
        batchId: line.batchId,
        type: MovementType.transferIn,
        quantity: line.quantity.toDouble(),
        unitCost: line.unitCost,
        referenceType: 'stock_transfer',
        referenceId: transfer.id,
        actorId: actorId,
        occurredAt: DateTime.now().toUtc(),
      );
      await recordMovement(inMovement);
    }
  }
}
