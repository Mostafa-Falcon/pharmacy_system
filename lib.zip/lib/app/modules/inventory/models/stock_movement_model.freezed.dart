// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'stock_movement_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

StockMovementModel _$StockMovementModelFromJson(Map<String, dynamic> json) {
  return _StockMovementModel.fromJson(json);
}

/// @nodoc
mixin _$StockMovementModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'operation_id')
  String get operationId => throw _privateConstructorUsedError;
  @JsonKey(name: 'pharmacy_id')
  String get pharmacyId => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'medicine_id')
  String get medicineId => throw _privateConstructorUsedError;
  @JsonKey(name: 'medicine_name')
  String? get medicineName => throw _privateConstructorUsedError;
  @JsonKey(name: 'batch_id')
  String? get batchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_id')
  String? get unitId => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
  MovementType get type => throw _privateConstructorUsedError;
  double get quantity => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_cost')
  double get unitCost => throw _privateConstructorUsedError;
  @JsonKey(name: 'before_quantity')
  double? get beforeQuantity => throw _privateConstructorUsedError;
  @JsonKey(name: 'after_quantity')
  double? get afterQuantity => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_type')
  String get referenceType => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_id')
  String get referenceId => throw _privateConstructorUsedError;
  @JsonKey(name: 'actor_id')
  String get actorId => throw _privateConstructorUsedError;
  @JsonKey(
      name: 'occurred_at',
      fromJson: _parseOccurredAt,
      toJson: _occurredAtToJson)
  DateTime get occurredAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockMovementModelCopyWith<StockMovementModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockMovementModelCopyWith<$Res> {
  factory $StockMovementModelCopyWith(
          StockMovementModel value, $Res Function(StockMovementModel) then) =
      _$StockMovementModelCopyWithImpl<$Res, StockMovementModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'operation_id') String operationId,
      @JsonKey(name: 'pharmacy_id') String pharmacyId,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'medicine_id') String medicineId,
      @JsonKey(name: 'medicine_name') String? medicineName,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'unit_id') String? unitId,
      @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
      MovementType type,
      double quantity,
      @JsonKey(name: 'unit_cost') double unitCost,
      @JsonKey(name: 'before_quantity') double? beforeQuantity,
      @JsonKey(name: 'after_quantity') double? afterQuantity,
      @JsonKey(name: 'reference_type') String referenceType,
      @JsonKey(name: 'reference_id') String referenceId,
      @JsonKey(name: 'actor_id') String actorId,
      @JsonKey(
          name: 'occurred_at',
          fromJson: _parseOccurredAt,
          toJson: _occurredAtToJson)
      DateTime occurredAt});
}

/// @nodoc
class _$StockMovementModelCopyWithImpl<$Res, $Val extends StockMovementModel>
    implements $StockMovementModelCopyWith<$Res> {
  _$StockMovementModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? operationId = null,
    Object? pharmacyId = null,
    Object? branchId = null,
    Object? medicineId = null,
    Object? medicineName = freezed,
    Object? batchId = freezed,
    Object? unitId = freezed,
    Object? type = null,
    Object? quantity = null,
    Object? unitCost = null,
    Object? beforeQuantity = freezed,
    Object? afterQuantity = freezed,
    Object? referenceType = null,
    Object? referenceId = null,
    Object? actorId = null,
    Object? occurredAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      operationId: null == operationId
          ? _value.operationId
          : operationId // ignore: cast_nullable_to_non_nullable
              as String,
      pharmacyId: null == pharmacyId
          ? _value.pharmacyId
          : pharmacyId // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineName: freezed == medicineName
          ? _value.medicineName
          : medicineName // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      unitId: freezed == unitId
          ? _value.unitId
          : unitId // ignore: cast_nullable_to_non_nullable
              as String?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as MovementType,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as double,
      unitCost: null == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double,
      beforeQuantity: freezed == beforeQuantity
          ? _value.beforeQuantity
          : beforeQuantity // ignore: cast_nullable_to_non_nullable
              as double?,
      afterQuantity: freezed == afterQuantity
          ? _value.afterQuantity
          : afterQuantity // ignore: cast_nullable_to_non_nullable
              as double?,
      referenceType: null == referenceType
          ? _value.referenceType
          : referenceType // ignore: cast_nullable_to_non_nullable
              as String,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String,
      actorId: null == actorId
          ? _value.actorId
          : actorId // ignore: cast_nullable_to_non_nullable
              as String,
      occurredAt: null == occurredAt
          ? _value.occurredAt
          : occurredAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockMovementModelImplCopyWith<$Res>
    implements $StockMovementModelCopyWith<$Res> {
  factory _$$StockMovementModelImplCopyWith(_$StockMovementModelImpl value,
          $Res Function(_$StockMovementModelImpl) then) =
      __$$StockMovementModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'operation_id') String operationId,
      @JsonKey(name: 'pharmacy_id') String pharmacyId,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'medicine_id') String medicineId,
      @JsonKey(name: 'medicine_name') String? medicineName,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'unit_id') String? unitId,
      @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
      MovementType type,
      double quantity,
      @JsonKey(name: 'unit_cost') double unitCost,
      @JsonKey(name: 'before_quantity') double? beforeQuantity,
      @JsonKey(name: 'after_quantity') double? afterQuantity,
      @JsonKey(name: 'reference_type') String referenceType,
      @JsonKey(name: 'reference_id') String referenceId,
      @JsonKey(name: 'actor_id') String actorId,
      @JsonKey(
          name: 'occurred_at',
          fromJson: _parseOccurredAt,
          toJson: _occurredAtToJson)
      DateTime occurredAt});
}

/// @nodoc
class __$$StockMovementModelImplCopyWithImpl<$Res>
    extends _$StockMovementModelCopyWithImpl<$Res, _$StockMovementModelImpl>
    implements _$$StockMovementModelImplCopyWith<$Res> {
  __$$StockMovementModelImplCopyWithImpl(_$StockMovementModelImpl _value,
      $Res Function(_$StockMovementModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? operationId = null,
    Object? pharmacyId = null,
    Object? branchId = null,
    Object? medicineId = null,
    Object? medicineName = freezed,
    Object? batchId = freezed,
    Object? unitId = freezed,
    Object? type = null,
    Object? quantity = null,
    Object? unitCost = null,
    Object? beforeQuantity = freezed,
    Object? afterQuantity = freezed,
    Object? referenceType = null,
    Object? referenceId = null,
    Object? actorId = null,
    Object? occurredAt = null,
  }) {
    return _then(_$StockMovementModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      operationId: null == operationId
          ? _value.operationId
          : operationId // ignore: cast_nullable_to_non_nullable
              as String,
      pharmacyId: null == pharmacyId
          ? _value.pharmacyId
          : pharmacyId // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineName: freezed == medicineName
          ? _value.medicineName
          : medicineName // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      unitId: freezed == unitId
          ? _value.unitId
          : unitId // ignore: cast_nullable_to_non_nullable
              as String?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as MovementType,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as double,
      unitCost: null == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double,
      beforeQuantity: freezed == beforeQuantity
          ? _value.beforeQuantity
          : beforeQuantity // ignore: cast_nullable_to_non_nullable
              as double?,
      afterQuantity: freezed == afterQuantity
          ? _value.afterQuantity
          : afterQuantity // ignore: cast_nullable_to_non_nullable
              as double?,
      referenceType: null == referenceType
          ? _value.referenceType
          : referenceType // ignore: cast_nullable_to_non_nullable
              as String,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String,
      actorId: null == actorId
          ? _value.actorId
          : actorId // ignore: cast_nullable_to_non_nullable
              as String,
      occurredAt: null == occurredAt
          ? _value.occurredAt
          : occurredAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockMovementModelImpl implements _StockMovementModel {
  const _$StockMovementModelImpl(
      {required this.id,
      @JsonKey(name: 'operation_id') required this.operationId,
      @JsonKey(name: 'pharmacy_id') required this.pharmacyId,
      @JsonKey(name: 'branch_id') required this.branchId,
      @JsonKey(name: 'medicine_id') required this.medicineId,
      @JsonKey(name: 'medicine_name') this.medicineName,
      @JsonKey(name: 'batch_id') this.batchId,
      @JsonKey(name: 'unit_id') this.unitId,
      @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
      required this.type,
      required this.quantity,
      @JsonKey(name: 'unit_cost') this.unitCost = 0,
      @JsonKey(name: 'before_quantity') this.beforeQuantity,
      @JsonKey(name: 'after_quantity') this.afterQuantity,
      @JsonKey(name: 'reference_type') required this.referenceType,
      @JsonKey(name: 'reference_id') required this.referenceId,
      @JsonKey(name: 'actor_id') required this.actorId,
      @JsonKey(
          name: 'occurred_at',
          fromJson: _parseOccurredAt,
          toJson: _occurredAtToJson)
      required this.occurredAt});

  factory _$StockMovementModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockMovementModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'operation_id')
  final String operationId;
  @override
  @JsonKey(name: 'pharmacy_id')
  final String pharmacyId;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey(name: 'medicine_id')
  final String medicineId;
  @override
  @JsonKey(name: 'medicine_name')
  final String? medicineName;
  @override
  @JsonKey(name: 'batch_id')
  final String? batchId;
  @override
  @JsonKey(name: 'unit_id')
  final String? unitId;
  @override
  @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
  final MovementType type;
  @override
  final double quantity;
  @override
  @JsonKey(name: 'unit_cost')
  final double unitCost;
  @override
  @JsonKey(name: 'before_quantity')
  final double? beforeQuantity;
  @override
  @JsonKey(name: 'after_quantity')
  final double? afterQuantity;
  @override
  @JsonKey(name: 'reference_type')
  final String referenceType;
  @override
  @JsonKey(name: 'reference_id')
  final String referenceId;
  @override
  @JsonKey(name: 'actor_id')
  final String actorId;
  @override
  @JsonKey(
      name: 'occurred_at',
      fromJson: _parseOccurredAt,
      toJson: _occurredAtToJson)
  final DateTime occurredAt;

  @override
  String toString() {
    return 'StockMovementModel(id: $id, operationId: $operationId, pharmacyId: $pharmacyId, branchId: $branchId, medicineId: $medicineId, medicineName: $medicineName, batchId: $batchId, unitId: $unitId, type: $type, quantity: $quantity, unitCost: $unitCost, beforeQuantity: $beforeQuantity, afterQuantity: $afterQuantity, referenceType: $referenceType, referenceId: $referenceId, actorId: $actorId, occurredAt: $occurredAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockMovementModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.operationId, operationId) ||
                other.operationId == operationId) &&
            (identical(other.pharmacyId, pharmacyId) ||
                other.pharmacyId == pharmacyId) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.medicineId, medicineId) ||
                other.medicineId == medicineId) &&
            (identical(other.medicineName, medicineName) ||
                other.medicineName == medicineName) &&
            (identical(other.batchId, batchId) || other.batchId == batchId) &&
            (identical(other.unitId, unitId) || other.unitId == unitId) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.unitCost, unitCost) ||
                other.unitCost == unitCost) &&
            (identical(other.beforeQuantity, beforeQuantity) ||
                other.beforeQuantity == beforeQuantity) &&
            (identical(other.afterQuantity, afterQuantity) ||
                other.afterQuantity == afterQuantity) &&
            (identical(other.referenceType, referenceType) ||
                other.referenceType == referenceType) &&
            (identical(other.referenceId, referenceId) ||
                other.referenceId == referenceId) &&
            (identical(other.actorId, actorId) || other.actorId == actorId) &&
            (identical(other.occurredAt, occurredAt) ||
                other.occurredAt == occurredAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      operationId,
      pharmacyId,
      branchId,
      medicineId,
      medicineName,
      batchId,
      unitId,
      type,
      quantity,
      unitCost,
      beforeQuantity,
      afterQuantity,
      referenceType,
      referenceId,
      actorId,
      occurredAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockMovementModelImplCopyWith<_$StockMovementModelImpl> get copyWith =>
      __$$StockMovementModelImplCopyWithImpl<_$StockMovementModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockMovementModelImplToJson(
      this,
    );
  }
}

abstract class _StockMovementModel implements StockMovementModel {
  const factory _StockMovementModel(
      {required final String id,
      @JsonKey(name: 'operation_id') required final String operationId,
      @JsonKey(name: 'pharmacy_id') required final String pharmacyId,
      @JsonKey(name: 'branch_id') required final String branchId,
      @JsonKey(name: 'medicine_id') required final String medicineId,
      @JsonKey(name: 'medicine_name') final String? medicineName,
      @JsonKey(name: 'batch_id') final String? batchId,
      @JsonKey(name: 'unit_id') final String? unitId,
      @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
      required final MovementType type,
      required final double quantity,
      @JsonKey(name: 'unit_cost') final double unitCost,
      @JsonKey(name: 'before_quantity') final double? beforeQuantity,
      @JsonKey(name: 'after_quantity') final double? afterQuantity,
      @JsonKey(name: 'reference_type') required final String referenceType,
      @JsonKey(name: 'reference_id') required final String referenceId,
      @JsonKey(name: 'actor_id') required final String actorId,
      @JsonKey(
          name: 'occurred_at',
          fromJson: _parseOccurredAt,
          toJson: _occurredAtToJson)
      required final DateTime occurredAt}) = _$StockMovementModelImpl;

  factory _StockMovementModel.fromJson(Map<String, dynamic> json) =
      _$StockMovementModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'operation_id')
  String get operationId;
  @override
  @JsonKey(name: 'pharmacy_id')
  String get pharmacyId;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  @JsonKey(name: 'medicine_id')
  String get medicineId;
  @override
  @JsonKey(name: 'medicine_name')
  String? get medicineName;
  @override
  @JsonKey(name: 'batch_id')
  String? get batchId;
  @override
  @JsonKey(name: 'unit_id')
  String? get unitId;
  @override
  @JsonKey(fromJson: _parseMovementType, toJson: _movementTypeToJson)
  MovementType get type;
  @override
  double get quantity;
  @override
  @JsonKey(name: 'unit_cost')
  double get unitCost;
  @override
  @JsonKey(name: 'before_quantity')
  double? get beforeQuantity;
  @override
  @JsonKey(name: 'after_quantity')
  double? get afterQuantity;
  @override
  @JsonKey(name: 'reference_type')
  String get referenceType;
  @override
  @JsonKey(name: 'reference_id')
  String get referenceId;
  @override
  @JsonKey(name: 'actor_id')
  String get actorId;
  @override
  @JsonKey(
      name: 'occurred_at',
      fromJson: _parseOccurredAt,
      toJson: _occurredAtToJson)
  DateTime get occurredAt;
  @override
  @JsonKey(ignore: true)
  _$$StockMovementModelImplCopyWith<_$StockMovementModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
