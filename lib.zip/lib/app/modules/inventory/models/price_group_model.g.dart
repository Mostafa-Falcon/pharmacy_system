// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'price_group_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PriceGroupModelImpl _$$PriceGroupModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PriceGroupModelImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      markupPercentage: (json['markup_percentage'] as num?)?.toDouble() ?? 0,
      discountPercentage:
          (json['discount_percentage'] as num?)?.toDouble() ?? 0,
      isDefault: json['is_default'] as bool? ?? false,
    );

Map<String, dynamic> _$$PriceGroupModelImplToJson(
        _$PriceGroupModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'markup_percentage': instance.markupPercentage,
      'discount_percentage': instance.discountPercentage,
      'is_default': instance.isDefault,
    };
