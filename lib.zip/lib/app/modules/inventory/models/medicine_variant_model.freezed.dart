// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'medicine_variant_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MedicineVariantModel _$MedicineVariantModelFromJson(Map<String, dynamic> json) {
  return _MedicineVariantModel.fromJson(json);
}

/// @nodoc
mixin _$MedicineVariantModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'medicine_id')
  String get medicineId => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  double get price => throw _privateConstructorUsedError;
  double get cost => throw _privateConstructorUsedError;
  String get sku => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
  Map<String, String> get attributes => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MedicineVariantModelCopyWith<MedicineVariantModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MedicineVariantModelCopyWith<$Res> {
  factory $MedicineVariantModelCopyWith(MedicineVariantModel value,
          $Res Function(MedicineVariantModel) then) =
      _$MedicineVariantModelCopyWithImpl<$Res, MedicineVariantModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'medicine_id') String medicineId,
      String name,
      double price,
      double cost,
      String sku,
      @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
      Map<String, String> attributes});
}

/// @nodoc
class _$MedicineVariantModelCopyWithImpl<$Res,
        $Val extends MedicineVariantModel>
    implements $MedicineVariantModelCopyWith<$Res> {
  _$MedicineVariantModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? medicineId = null,
    Object? name = null,
    Object? price = null,
    Object? cost = null,
    Object? sku = null,
    Object? attributes = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      price: null == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as double,
      cost: null == cost
          ? _value.cost
          : cost // ignore: cast_nullable_to_non_nullable
              as double,
      sku: null == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String,
      attributes: null == attributes
          ? _value.attributes
          : attributes // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MedicineVariantModelImplCopyWith<$Res>
    implements $MedicineVariantModelCopyWith<$Res> {
  factory _$$MedicineVariantModelImplCopyWith(_$MedicineVariantModelImpl value,
          $Res Function(_$MedicineVariantModelImpl) then) =
      __$$MedicineVariantModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'medicine_id') String medicineId,
      String name,
      double price,
      double cost,
      String sku,
      @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
      Map<String, String> attributes});
}

/// @nodoc
class __$$MedicineVariantModelImplCopyWithImpl<$Res>
    extends _$MedicineVariantModelCopyWithImpl<$Res, _$MedicineVariantModelImpl>
    implements _$$MedicineVariantModelImplCopyWith<$Res> {
  __$$MedicineVariantModelImplCopyWithImpl(_$MedicineVariantModelImpl _value,
      $Res Function(_$MedicineVariantModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? medicineId = null,
    Object? name = null,
    Object? price = null,
    Object? cost = null,
    Object? sku = null,
    Object? attributes = null,
  }) {
    return _then(_$MedicineVariantModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      price: null == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as double,
      cost: null == cost
          ? _value.cost
          : cost // ignore: cast_nullable_to_non_nullable
              as double,
      sku: null == sku
          ? _value.sku
          : sku // ignore: cast_nullable_to_non_nullable
              as String,
      attributes: null == attributes
          ? _value._attributes
          : attributes // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MedicineVariantModelImpl implements _MedicineVariantModel {
  const _$MedicineVariantModelImpl(
      {required this.id,
      @JsonKey(name: 'medicine_id') required this.medicineId,
      required this.name,
      required this.price,
      required this.cost,
      required this.sku,
      @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
      final Map<String, String> attributes = const {}})
      : _attributes = attributes;

  factory _$MedicineVariantModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$MedicineVariantModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'medicine_id')
  final String medicineId;
  @override
  final String name;
  @override
  final double price;
  @override
  final double cost;
  @override
  final String sku;
  final Map<String, String> _attributes;
  @override
  @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
  Map<String, String> get attributes {
    if (_attributes is EqualUnmodifiableMapView) return _attributes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_attributes);
  }

  @override
  String toString() {
    return 'MedicineVariantModel(id: $id, medicineId: $medicineId, name: $name, price: $price, cost: $cost, sku: $sku, attributes: $attributes)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MedicineVariantModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.medicineId, medicineId) ||
                other.medicineId == medicineId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.price, price) || other.price == price) &&
            (identical(other.cost, cost) || other.cost == cost) &&
            (identical(other.sku, sku) || other.sku == sku) &&
            const DeepCollectionEquality()
                .equals(other._attributes, _attributes));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, medicineId, name, price,
      cost, sku, const DeepCollectionEquality().hash(_attributes));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MedicineVariantModelImplCopyWith<_$MedicineVariantModelImpl>
      get copyWith =>
          __$$MedicineVariantModelImplCopyWithImpl<_$MedicineVariantModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MedicineVariantModelImplToJson(
      this,
    );
  }
}

abstract class _MedicineVariantModel implements MedicineVariantModel {
  const factory _MedicineVariantModel(
      {required final String id,
      @JsonKey(name: 'medicine_id') required final String medicineId,
      required final String name,
      required final double price,
      required final double cost,
      required final String sku,
      @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
      final Map<String, String> attributes}) = _$MedicineVariantModelImpl;

  factory _MedicineVariantModel.fromJson(Map<String, dynamic> json) =
      _$MedicineVariantModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'medicine_id')
  String get medicineId;
  @override
  String get name;
  @override
  double get price;
  @override
  double get cost;
  @override
  String get sku;
  @override
  @JsonKey(fromJson: _stringMapFromJson, toJson: _stringMapToJson)
  Map<String, String> get attributes;
  @override
  @JsonKey(ignore: true)
  _$$MedicineVariantModelImplCopyWith<_$MedicineVariantModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
