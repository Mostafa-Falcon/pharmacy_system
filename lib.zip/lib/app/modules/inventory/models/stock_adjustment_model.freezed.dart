// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'stock_adjustment_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

StockAdjustmentModel _$StockAdjustmentModelFromJson(Map<String, dynamic> json) {
  return _StockAdjustmentModel.fromJson(json);
}

/// @nodoc
mixin _$StockAdjustmentModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'pharmacy_id')
  String get pharmacyId => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'adjustment_number')
  String get adjustmentNumber => throw _privateConstructorUsedError;
  @JsonKey(name: 'adjustment_date')
  DateTime get adjustmentDate => throw _privateConstructorUsedError;
  List<StockAdjustmentItemModel> get items =>
      throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_id')
  String? get createdById => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_name')
  String? get createdByName => throw _privateConstructorUsedError;
  String? get notes => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockAdjustmentModelCopyWith<StockAdjustmentModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockAdjustmentModelCopyWith<$Res> {
  factory $StockAdjustmentModelCopyWith(StockAdjustmentModel value,
          $Res Function(StockAdjustmentModel) then) =
      _$StockAdjustmentModelCopyWithImpl<$Res, StockAdjustmentModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'pharmacy_id') String pharmacyId,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'adjustment_number') String adjustmentNumber,
      @JsonKey(name: 'adjustment_date') DateTime adjustmentDate,
      List<StockAdjustmentItemModel> items,
      @JsonKey(name: 'created_by_id') String? createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      String? notes,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$StockAdjustmentModelCopyWithImpl<$Res,
        $Val extends StockAdjustmentModel>
    implements $StockAdjustmentModelCopyWith<$Res> {
  _$StockAdjustmentModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? pharmacyId = null,
    Object? branchId = null,
    Object? adjustmentNumber = null,
    Object? adjustmentDate = null,
    Object? items = null,
    Object? createdById = freezed,
    Object? createdByName = freezed,
    Object? notes = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      pharmacyId: null == pharmacyId
          ? _value.pharmacyId
          : pharmacyId // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      adjustmentNumber: null == adjustmentNumber
          ? _value.adjustmentNumber
          : adjustmentNumber // ignore: cast_nullable_to_non_nullable
              as String,
      adjustmentDate: null == adjustmentDate
          ? _value.adjustmentDate
          : adjustmentDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      items: null == items
          ? _value.items
          : items // ignore: cast_nullable_to_non_nullable
              as List<StockAdjustmentItemModel>,
      createdById: freezed == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String?,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockAdjustmentModelImplCopyWith<$Res>
    implements $StockAdjustmentModelCopyWith<$Res> {
  factory _$$StockAdjustmentModelImplCopyWith(_$StockAdjustmentModelImpl value,
          $Res Function(_$StockAdjustmentModelImpl) then) =
      __$$StockAdjustmentModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'pharmacy_id') String pharmacyId,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'adjustment_number') String adjustmentNumber,
      @JsonKey(name: 'adjustment_date') DateTime adjustmentDate,
      List<StockAdjustmentItemModel> items,
      @JsonKey(name: 'created_by_id') String? createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      String? notes,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$StockAdjustmentModelImplCopyWithImpl<$Res>
    extends _$StockAdjustmentModelCopyWithImpl<$Res, _$StockAdjustmentModelImpl>
    implements _$$StockAdjustmentModelImplCopyWith<$Res> {
  __$$StockAdjustmentModelImplCopyWithImpl(_$StockAdjustmentModelImpl _value,
      $Res Function(_$StockAdjustmentModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? pharmacyId = null,
    Object? branchId = null,
    Object? adjustmentNumber = null,
    Object? adjustmentDate = null,
    Object? items = null,
    Object? createdById = freezed,
    Object? createdByName = freezed,
    Object? notes = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$StockAdjustmentModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      pharmacyId: null == pharmacyId
          ? _value.pharmacyId
          : pharmacyId // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      adjustmentNumber: null == adjustmentNumber
          ? _value.adjustmentNumber
          : adjustmentNumber // ignore: cast_nullable_to_non_nullable
              as String,
      adjustmentDate: null == adjustmentDate
          ? _value.adjustmentDate
          : adjustmentDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      items: null == items
          ? _value._items
          : items // ignore: cast_nullable_to_non_nullable
              as List<StockAdjustmentItemModel>,
      createdById: freezed == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String?,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockAdjustmentModelImpl extends _StockAdjustmentModel {
  const _$StockAdjustmentModelImpl(
      {required this.id,
      @JsonKey(name: 'pharmacy_id') required this.pharmacyId,
      @JsonKey(name: 'branch_id') required this.branchId,
      @JsonKey(name: 'adjustment_number') required this.adjustmentNumber,
      @JsonKey(name: 'adjustment_date') required this.adjustmentDate,
      final List<StockAdjustmentItemModel> items = const [],
      @JsonKey(name: 'created_by_id') this.createdById,
      @JsonKey(name: 'created_by_name') this.createdByName,
      this.notes,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : _items = items,
        super._();

  factory _$StockAdjustmentModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockAdjustmentModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'pharmacy_id')
  final String pharmacyId;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey(name: 'adjustment_number')
  final String adjustmentNumber;
  @override
  @JsonKey(name: 'adjustment_date')
  final DateTime adjustmentDate;
  final List<StockAdjustmentItemModel> _items;
  @override
  @JsonKey()
  List<StockAdjustmentItemModel> get items {
    if (_items is EqualUnmodifiableListView) return _items;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_items);
  }

  @override
  @JsonKey(name: 'created_by_id')
  final String? createdById;
  @override
  @JsonKey(name: 'created_by_name')
  final String? createdByName;
  @override
  final String? notes;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'StockAdjustmentModel(id: $id, pharmacyId: $pharmacyId, branchId: $branchId, adjustmentNumber: $adjustmentNumber, adjustmentDate: $adjustmentDate, items: $items, createdById: $createdById, createdByName: $createdByName, notes: $notes, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockAdjustmentModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.pharmacyId, pharmacyId) ||
                other.pharmacyId == pharmacyId) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.adjustmentNumber, adjustmentNumber) ||
                other.adjustmentNumber == adjustmentNumber) &&
            (identical(other.adjustmentDate, adjustmentDate) ||
                other.adjustmentDate == adjustmentDate) &&
            const DeepCollectionEquality().equals(other._items, _items) &&
            (identical(other.createdById, createdById) ||
                other.createdById == createdById) &&
            (identical(other.createdByName, createdByName) ||
                other.createdByName == createdByName) &&
            (identical(other.notes, notes) || other.notes == notes) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      pharmacyId,
      branchId,
      adjustmentNumber,
      adjustmentDate,
      const DeepCollectionEquality().hash(_items),
      createdById,
      createdByName,
      notes,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockAdjustmentModelImplCopyWith<_$StockAdjustmentModelImpl>
      get copyWith =>
          __$$StockAdjustmentModelImplCopyWithImpl<_$StockAdjustmentModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockAdjustmentModelImplToJson(
      this,
    );
  }
}

abstract class _StockAdjustmentModel extends StockAdjustmentModel {
  const factory _StockAdjustmentModel(
      {required final String id,
      @JsonKey(name: 'pharmacy_id') required final String pharmacyId,
      @JsonKey(name: 'branch_id') required final String branchId,
      @JsonKey(name: 'adjustment_number')
      required final String adjustmentNumber,
      @JsonKey(name: 'adjustment_date') required final DateTime adjustmentDate,
      final List<StockAdjustmentItemModel> items,
      @JsonKey(name: 'created_by_id') final String? createdById,
      @JsonKey(name: 'created_by_name') final String? createdByName,
      final String? notes,
      @JsonKey(name: 'created_at') required final DateTime createdAt,
      @JsonKey(name: 'updated_at')
      required final DateTime updatedAt}) = _$StockAdjustmentModelImpl;
  const _StockAdjustmentModel._() : super._();

  factory _StockAdjustmentModel.fromJson(Map<String, dynamic> json) =
      _$StockAdjustmentModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'pharmacy_id')
  String get pharmacyId;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  @JsonKey(name: 'adjustment_number')
  String get adjustmentNumber;
  @override
  @JsonKey(name: 'adjustment_date')
  DateTime get adjustmentDate;
  @override
  List<StockAdjustmentItemModel> get items;
  @override
  @JsonKey(name: 'created_by_id')
  String? get createdById;
  @override
  @JsonKey(name: 'created_by_name')
  String? get createdByName;
  @override
  String? get notes;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$StockAdjustmentModelImplCopyWith<_$StockAdjustmentModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

StockAdjustmentItemModel _$StockAdjustmentItemModelFromJson(
    Map<String, dynamic> json) {
  return _StockAdjustmentItemModel.fromJson(json);
}

/// @nodoc
mixin _$StockAdjustmentItemModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'item_id')
  String get itemId => throw _privateConstructorUsedError;
  @JsonKey(name: 'item_name')
  String? get itemName => throw _privateConstructorUsedError;
  String? get barcode => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_id')
  String? get unitId => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_name')
  String? get unitName => throw _privateConstructorUsedError;
  @JsonKey(name: 'batch_id')
  String? get batchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'batch_number')
  String? get batchNumber => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
  AdjustmentType get type => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
  AdjustmentReason get reason => throw _privateConstructorUsedError;
  double get quantity => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_cost')
  double? get unitCost => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockAdjustmentItemModelCopyWith<StockAdjustmentItemModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockAdjustmentItemModelCopyWith<$Res> {
  factory $StockAdjustmentItemModelCopyWith(StockAdjustmentItemModel value,
          $Res Function(StockAdjustmentItemModel) then) =
      _$StockAdjustmentItemModelCopyWithImpl<$Res, StockAdjustmentItemModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'item_id') String itemId,
      @JsonKey(name: 'item_name') String? itemName,
      String? barcode,
      @JsonKey(name: 'unit_id') String? unitId,
      @JsonKey(name: 'unit_name') String? unitName,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'batch_number') String? batchNumber,
      @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
      AdjustmentType type,
      @JsonKey(
          fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
      AdjustmentReason reason,
      double quantity,
      @JsonKey(name: 'unit_cost') double? unitCost});
}

/// @nodoc
class _$StockAdjustmentItemModelCopyWithImpl<$Res,
        $Val extends StockAdjustmentItemModel>
    implements $StockAdjustmentItemModelCopyWith<$Res> {
  _$StockAdjustmentItemModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? itemId = null,
    Object? itemName = freezed,
    Object? barcode = freezed,
    Object? unitId = freezed,
    Object? unitName = freezed,
    Object? batchId = freezed,
    Object? batchNumber = freezed,
    Object? type = null,
    Object? reason = null,
    Object? quantity = null,
    Object? unitCost = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      itemId: null == itemId
          ? _value.itemId
          : itemId // ignore: cast_nullable_to_non_nullable
              as String,
      itemName: freezed == itemName
          ? _value.itemName
          : itemName // ignore: cast_nullable_to_non_nullable
              as String?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String?,
      unitId: freezed == unitId
          ? _value.unitId
          : unitId // ignore: cast_nullable_to_non_nullable
              as String?,
      unitName: freezed == unitName
          ? _value.unitName
          : unitName // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      batchNumber: freezed == batchNumber
          ? _value.batchNumber
          : batchNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as AdjustmentType,
      reason: null == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as AdjustmentReason,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as double,
      unitCost: freezed == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockAdjustmentItemModelImplCopyWith<$Res>
    implements $StockAdjustmentItemModelCopyWith<$Res> {
  factory _$$StockAdjustmentItemModelImplCopyWith(
          _$StockAdjustmentItemModelImpl value,
          $Res Function(_$StockAdjustmentItemModelImpl) then) =
      __$$StockAdjustmentItemModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'item_id') String itemId,
      @JsonKey(name: 'item_name') String? itemName,
      String? barcode,
      @JsonKey(name: 'unit_id') String? unitId,
      @JsonKey(name: 'unit_name') String? unitName,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'batch_number') String? batchNumber,
      @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
      AdjustmentType type,
      @JsonKey(
          fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
      AdjustmentReason reason,
      double quantity,
      @JsonKey(name: 'unit_cost') double? unitCost});
}

/// @nodoc
class __$$StockAdjustmentItemModelImplCopyWithImpl<$Res>
    extends _$StockAdjustmentItemModelCopyWithImpl<$Res,
        _$StockAdjustmentItemModelImpl>
    implements _$$StockAdjustmentItemModelImplCopyWith<$Res> {
  __$$StockAdjustmentItemModelImplCopyWithImpl(
      _$StockAdjustmentItemModelImpl _value,
      $Res Function(_$StockAdjustmentItemModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? itemId = null,
    Object? itemName = freezed,
    Object? barcode = freezed,
    Object? unitId = freezed,
    Object? unitName = freezed,
    Object? batchId = freezed,
    Object? batchNumber = freezed,
    Object? type = null,
    Object? reason = null,
    Object? quantity = null,
    Object? unitCost = freezed,
  }) {
    return _then(_$StockAdjustmentItemModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      itemId: null == itemId
          ? _value.itemId
          : itemId // ignore: cast_nullable_to_non_nullable
              as String,
      itemName: freezed == itemName
          ? _value.itemName
          : itemName // ignore: cast_nullable_to_non_nullable
              as String?,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String?,
      unitId: freezed == unitId
          ? _value.unitId
          : unitId // ignore: cast_nullable_to_non_nullable
              as String?,
      unitName: freezed == unitName
          ? _value.unitName
          : unitName // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      batchNumber: freezed == batchNumber
          ? _value.batchNumber
          : batchNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as AdjustmentType,
      reason: null == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as AdjustmentReason,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as double,
      unitCost: freezed == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockAdjustmentItemModelImpl extends _StockAdjustmentItemModel {
  const _$StockAdjustmentItemModelImpl(
      {required this.id,
      @JsonKey(name: 'item_id') required this.itemId,
      @JsonKey(name: 'item_name') this.itemName,
      this.barcode,
      @JsonKey(name: 'unit_id') this.unitId,
      @JsonKey(name: 'unit_name') this.unitName,
      @JsonKey(name: 'batch_id') this.batchId,
      @JsonKey(name: 'batch_number') this.batchNumber,
      @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
      required this.type,
      @JsonKey(
          fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
      required this.reason,
      required this.quantity,
      @JsonKey(name: 'unit_cost') this.unitCost})
      : super._();

  factory _$StockAdjustmentItemModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockAdjustmentItemModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'item_id')
  final String itemId;
  @override
  @JsonKey(name: 'item_name')
  final String? itemName;
  @override
  final String? barcode;
  @override
  @JsonKey(name: 'unit_id')
  final String? unitId;
  @override
  @JsonKey(name: 'unit_name')
  final String? unitName;
  @override
  @JsonKey(name: 'batch_id')
  final String? batchId;
  @override
  @JsonKey(name: 'batch_number')
  final String? batchNumber;
  @override
  @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
  final AdjustmentType type;
  @override
  @JsonKey(fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
  final AdjustmentReason reason;
  @override
  final double quantity;
  @override
  @JsonKey(name: 'unit_cost')
  final double? unitCost;

  @override
  String toString() {
    return 'StockAdjustmentItemModel(id: $id, itemId: $itemId, itemName: $itemName, barcode: $barcode, unitId: $unitId, unitName: $unitName, batchId: $batchId, batchNumber: $batchNumber, type: $type, reason: $reason, quantity: $quantity, unitCost: $unitCost)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockAdjustmentItemModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.itemId, itemId) || other.itemId == itemId) &&
            (identical(other.itemName, itemName) ||
                other.itemName == itemName) &&
            (identical(other.barcode, barcode) || other.barcode == barcode) &&
            (identical(other.unitId, unitId) || other.unitId == unitId) &&
            (identical(other.unitName, unitName) ||
                other.unitName == unitName) &&
            (identical(other.batchId, batchId) || other.batchId == batchId) &&
            (identical(other.batchNumber, batchNumber) ||
                other.batchNumber == batchNumber) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.reason, reason) || other.reason == reason) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.unitCost, unitCost) ||
                other.unitCost == unitCost));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, itemId, itemName, barcode,
      unitId, unitName, batchId, batchNumber, type, reason, quantity, unitCost);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockAdjustmentItemModelImplCopyWith<_$StockAdjustmentItemModelImpl>
      get copyWith => __$$StockAdjustmentItemModelImplCopyWithImpl<
          _$StockAdjustmentItemModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockAdjustmentItemModelImplToJson(
      this,
    );
  }
}

abstract class _StockAdjustmentItemModel extends StockAdjustmentItemModel {
  const factory _StockAdjustmentItemModel(
      {required final String id,
      @JsonKey(name: 'item_id') required final String itemId,
      @JsonKey(name: 'item_name') final String? itemName,
      final String? barcode,
      @JsonKey(name: 'unit_id') final String? unitId,
      @JsonKey(name: 'unit_name') final String? unitName,
      @JsonKey(name: 'batch_id') final String? batchId,
      @JsonKey(name: 'batch_number') final String? batchNumber,
      @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
      required final AdjustmentType type,
      @JsonKey(
          fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
      required final AdjustmentReason reason,
      required final double quantity,
      @JsonKey(name: 'unit_cost')
      final double? unitCost}) = _$StockAdjustmentItemModelImpl;
  const _StockAdjustmentItemModel._() : super._();

  factory _StockAdjustmentItemModel.fromJson(Map<String, dynamic> json) =
      _$StockAdjustmentItemModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'item_id')
  String get itemId;
  @override
  @JsonKey(name: 'item_name')
  String? get itemName;
  @override
  String? get barcode;
  @override
  @JsonKey(name: 'unit_id')
  String? get unitId;
  @override
  @JsonKey(name: 'unit_name')
  String? get unitName;
  @override
  @JsonKey(name: 'batch_id')
  String? get batchId;
  @override
  @JsonKey(name: 'batch_number')
  String? get batchNumber;
  @override
  @JsonKey(fromJson: _adjustmentTypeFromJson, toJson: _adjustmentTypeToJson)
  AdjustmentType get type;
  @override
  @JsonKey(fromJson: _adjustmentReasonFromJson, toJson: _adjustmentReasonToJson)
  AdjustmentReason get reason;
  @override
  double get quantity;
  @override
  @JsonKey(name: 'unit_cost')
  double? get unitCost;
  @override
  @JsonKey(ignore: true)
  _$$StockAdjustmentItemModelImplCopyWith<_$StockAdjustmentItemModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
