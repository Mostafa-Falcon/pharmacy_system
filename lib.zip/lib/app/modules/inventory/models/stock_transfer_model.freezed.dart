// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'stock_transfer_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

StockTransferItemModel _$StockTransferItemModelFromJson(
    Map<String, dynamic> json) {
  return _StockTransferItemModel.fromJson(json);
}

/// @nodoc
mixin _$StockTransferItemModel {
  @JsonKey(name: 'medicine_id')
  String get medicineId => throw _privateConstructorUsedError;
  @JsonKey(name: 'medicine_name')
  String get medicineName => throw _privateConstructorUsedError;
  int get quantity => throw _privateConstructorUsedError;
  @JsonKey(name: 'unit_cost')
  double get unitCost => throw _privateConstructorUsedError;
  String? get barcode => throw _privateConstructorUsedError;
  @JsonKey(name: 'batch_id')
  String? get batchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'batch_number')
  String? get batchNumber => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockTransferItemModelCopyWith<StockTransferItemModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockTransferItemModelCopyWith<$Res> {
  factory $StockTransferItemModelCopyWith(StockTransferItemModel value,
          $Res Function(StockTransferItemModel) then) =
      _$StockTransferItemModelCopyWithImpl<$Res, StockTransferItemModel>;
  @useResult
  $Res call(
      {@JsonKey(name: 'medicine_id') String medicineId,
      @JsonKey(name: 'medicine_name') String medicineName,
      int quantity,
      @JsonKey(name: 'unit_cost') double unitCost,
      String? barcode,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'batch_number') String? batchNumber});
}

/// @nodoc
class _$StockTransferItemModelCopyWithImpl<$Res,
        $Val extends StockTransferItemModel>
    implements $StockTransferItemModelCopyWith<$Res> {
  _$StockTransferItemModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? medicineId = null,
    Object? medicineName = null,
    Object? quantity = null,
    Object? unitCost = null,
    Object? barcode = freezed,
    Object? batchId = freezed,
    Object? batchNumber = freezed,
  }) {
    return _then(_value.copyWith(
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineName: null == medicineName
          ? _value.medicineName
          : medicineName // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      unitCost: null == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      batchNumber: freezed == batchNumber
          ? _value.batchNumber
          : batchNumber // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockTransferItemModelImplCopyWith<$Res>
    implements $StockTransferItemModelCopyWith<$Res> {
  factory _$$StockTransferItemModelImplCopyWith(
          _$StockTransferItemModelImpl value,
          $Res Function(_$StockTransferItemModelImpl) then) =
      __$$StockTransferItemModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'medicine_id') String medicineId,
      @JsonKey(name: 'medicine_name') String medicineName,
      int quantity,
      @JsonKey(name: 'unit_cost') double unitCost,
      String? barcode,
      @JsonKey(name: 'batch_id') String? batchId,
      @JsonKey(name: 'batch_number') String? batchNumber});
}

/// @nodoc
class __$$StockTransferItemModelImplCopyWithImpl<$Res>
    extends _$StockTransferItemModelCopyWithImpl<$Res,
        _$StockTransferItemModelImpl>
    implements _$$StockTransferItemModelImplCopyWith<$Res> {
  __$$StockTransferItemModelImplCopyWithImpl(
      _$StockTransferItemModelImpl _value,
      $Res Function(_$StockTransferItemModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? medicineId = null,
    Object? medicineName = null,
    Object? quantity = null,
    Object? unitCost = null,
    Object? barcode = freezed,
    Object? batchId = freezed,
    Object? batchNumber = freezed,
  }) {
    return _then(_$StockTransferItemModelImpl(
      medicineId: null == medicineId
          ? _value.medicineId
          : medicineId // ignore: cast_nullable_to_non_nullable
              as String,
      medicineName: null == medicineName
          ? _value.medicineName
          : medicineName // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as int,
      unitCost: null == unitCost
          ? _value.unitCost
          : unitCost // ignore: cast_nullable_to_non_nullable
              as double,
      barcode: freezed == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String?,
      batchId: freezed == batchId
          ? _value.batchId
          : batchId // ignore: cast_nullable_to_non_nullable
              as String?,
      batchNumber: freezed == batchNumber
          ? _value.batchNumber
          : batchNumber // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockTransferItemModelImpl extends _StockTransferItemModel {
  const _$StockTransferItemModelImpl(
      {@JsonKey(name: 'medicine_id') required this.medicineId,
      @JsonKey(name: 'medicine_name') required this.medicineName,
      required this.quantity,
      @JsonKey(name: 'unit_cost') required this.unitCost,
      this.barcode,
      @JsonKey(name: 'batch_id') this.batchId,
      @JsonKey(name: 'batch_number') this.batchNumber})
      : super._();

  factory _$StockTransferItemModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockTransferItemModelImplFromJson(json);

  @override
  @JsonKey(name: 'medicine_id')
  final String medicineId;
  @override
  @JsonKey(name: 'medicine_name')
  final String medicineName;
  @override
  final int quantity;
  @override
  @JsonKey(name: 'unit_cost')
  final double unitCost;
  @override
  final String? barcode;
  @override
  @JsonKey(name: 'batch_id')
  final String? batchId;
  @override
  @JsonKey(name: 'batch_number')
  final String? batchNumber;

  @override
  String toString() {
    return 'StockTransferItemModel(medicineId: $medicineId, medicineName: $medicineName, quantity: $quantity, unitCost: $unitCost, barcode: $barcode, batchId: $batchId, batchNumber: $batchNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockTransferItemModelImpl &&
            (identical(other.medicineId, medicineId) ||
                other.medicineId == medicineId) &&
            (identical(other.medicineName, medicineName) ||
                other.medicineName == medicineName) &&
            (identical(other.quantity, quantity) ||
                other.quantity == quantity) &&
            (identical(other.unitCost, unitCost) ||
                other.unitCost == unitCost) &&
            (identical(other.barcode, barcode) || other.barcode == barcode) &&
            (identical(other.batchId, batchId) || other.batchId == batchId) &&
            (identical(other.batchNumber, batchNumber) ||
                other.batchNumber == batchNumber));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, medicineId, medicineName,
      quantity, unitCost, barcode, batchId, batchNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockTransferItemModelImplCopyWith<_$StockTransferItemModelImpl>
      get copyWith => __$$StockTransferItemModelImplCopyWithImpl<
          _$StockTransferItemModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockTransferItemModelImplToJson(
      this,
    );
  }
}

abstract class _StockTransferItemModel extends StockTransferItemModel {
  const factory _StockTransferItemModel(
          {@JsonKey(name: 'medicine_id') required final String medicineId,
          @JsonKey(name: 'medicine_name') required final String medicineName,
          required final int quantity,
          @JsonKey(name: 'unit_cost') required final double unitCost,
          final String? barcode,
          @JsonKey(name: 'batch_id') final String? batchId,
          @JsonKey(name: 'batch_number') final String? batchNumber}) =
      _$StockTransferItemModelImpl;
  const _StockTransferItemModel._() : super._();

  factory _StockTransferItemModel.fromJson(Map<String, dynamic> json) =
      _$StockTransferItemModelImpl.fromJson;

  @override
  @JsonKey(name: 'medicine_id')
  String get medicineId;
  @override
  @JsonKey(name: 'medicine_name')
  String get medicineName;
  @override
  int get quantity;
  @override
  @JsonKey(name: 'unit_cost')
  double get unitCost;
  @override
  String? get barcode;
  @override
  @JsonKey(name: 'batch_id')
  String? get batchId;
  @override
  @JsonKey(name: 'batch_number')
  String? get batchNumber;
  @override
  @JsonKey(ignore: true)
  _$$StockTransferItemModelImplCopyWith<_$StockTransferItemModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

StockTransferModel _$StockTransferModelFromJson(Map<String, dynamic> json) {
  return _StockTransferModel.fromJson(json);
}

/// @nodoc
mixin _$StockTransferModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'from_branch_id')
  String get fromBranchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'to_branch_id')
  String get toBranchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'from_branch_name')
  String get fromBranchName => throw _privateConstructorUsedError;
  @JsonKey(name: 'to_branch_name')
  String get toBranchName => throw _privateConstructorUsedError;
  @JsonKey(name: 'transfer_number')
  int get transferNumber => throw _privateConstructorUsedError;
  List<StockTransferItemModel> get items => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
  TransferStatus get status => throw _privateConstructorUsedError;
  String? get notes => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by')
  String get createdBy => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'received_at')
  DateTime? get receivedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'received_by')
  String? get receivedBy => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StockTransferModelCopyWith<StockTransferModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StockTransferModelCopyWith<$Res> {
  factory $StockTransferModelCopyWith(
          StockTransferModel value, $Res Function(StockTransferModel) then) =
      _$StockTransferModelCopyWithImpl<$Res, StockTransferModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'from_branch_id') String fromBranchId,
      @JsonKey(name: 'to_branch_id') String toBranchId,
      @JsonKey(name: 'from_branch_name') String fromBranchName,
      @JsonKey(name: 'to_branch_name') String toBranchName,
      @JsonKey(name: 'transfer_number') int transferNumber,
      List<StockTransferItemModel> items,
      @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
      TransferStatus status,
      String? notes,
      @JsonKey(name: 'created_by') String createdBy,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt,
      @JsonKey(name: 'received_at') DateTime? receivedAt,
      @JsonKey(name: 'received_by') String? receivedBy});
}

/// @nodoc
class _$StockTransferModelCopyWithImpl<$Res, $Val extends StockTransferModel>
    implements $StockTransferModelCopyWith<$Res> {
  _$StockTransferModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? fromBranchId = null,
    Object? toBranchId = null,
    Object? fromBranchName = null,
    Object? toBranchName = null,
    Object? transferNumber = null,
    Object? items = null,
    Object? status = null,
    Object? notes = freezed,
    Object? createdBy = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? receivedAt = freezed,
    Object? receivedBy = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      fromBranchId: null == fromBranchId
          ? _value.fromBranchId
          : fromBranchId // ignore: cast_nullable_to_non_nullable
              as String,
      toBranchId: null == toBranchId
          ? _value.toBranchId
          : toBranchId // ignore: cast_nullable_to_non_nullable
              as String,
      fromBranchName: null == fromBranchName
          ? _value.fromBranchName
          : fromBranchName // ignore: cast_nullable_to_non_nullable
              as String,
      toBranchName: null == toBranchName
          ? _value.toBranchName
          : toBranchName // ignore: cast_nullable_to_non_nullable
              as String,
      transferNumber: null == transferNumber
          ? _value.transferNumber
          : transferNumber // ignore: cast_nullable_to_non_nullable
              as int,
      items: null == items
          ? _value.items
          : items // ignore: cast_nullable_to_non_nullable
              as List<StockTransferItemModel>,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as TransferStatus,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: null == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      receivedAt: freezed == receivedAt
          ? _value.receivedAt
          : receivedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      receivedBy: freezed == receivedBy
          ? _value.receivedBy
          : receivedBy // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StockTransferModelImplCopyWith<$Res>
    implements $StockTransferModelCopyWith<$Res> {
  factory _$$StockTransferModelImplCopyWith(_$StockTransferModelImpl value,
          $Res Function(_$StockTransferModelImpl) then) =
      __$$StockTransferModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'from_branch_id') String fromBranchId,
      @JsonKey(name: 'to_branch_id') String toBranchId,
      @JsonKey(name: 'from_branch_name') String fromBranchName,
      @JsonKey(name: 'to_branch_name') String toBranchName,
      @JsonKey(name: 'transfer_number') int transferNumber,
      List<StockTransferItemModel> items,
      @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
      TransferStatus status,
      String? notes,
      @JsonKey(name: 'created_by') String createdBy,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt,
      @JsonKey(name: 'received_at') DateTime? receivedAt,
      @JsonKey(name: 'received_by') String? receivedBy});
}

/// @nodoc
class __$$StockTransferModelImplCopyWithImpl<$Res>
    extends _$StockTransferModelCopyWithImpl<$Res, _$StockTransferModelImpl>
    implements _$$StockTransferModelImplCopyWith<$Res> {
  __$$StockTransferModelImplCopyWithImpl(_$StockTransferModelImpl _value,
      $Res Function(_$StockTransferModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? fromBranchId = null,
    Object? toBranchId = null,
    Object? fromBranchName = null,
    Object? toBranchName = null,
    Object? transferNumber = null,
    Object? items = null,
    Object? status = null,
    Object? notes = freezed,
    Object? createdBy = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? receivedAt = freezed,
    Object? receivedBy = freezed,
  }) {
    return _then(_$StockTransferModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      fromBranchId: null == fromBranchId
          ? _value.fromBranchId
          : fromBranchId // ignore: cast_nullable_to_non_nullable
              as String,
      toBranchId: null == toBranchId
          ? _value.toBranchId
          : toBranchId // ignore: cast_nullable_to_non_nullable
              as String,
      fromBranchName: null == fromBranchName
          ? _value.fromBranchName
          : fromBranchName // ignore: cast_nullable_to_non_nullable
              as String,
      toBranchName: null == toBranchName
          ? _value.toBranchName
          : toBranchName // ignore: cast_nullable_to_non_nullable
              as String,
      transferNumber: null == transferNumber
          ? _value.transferNumber
          : transferNumber // ignore: cast_nullable_to_non_nullable
              as int,
      items: null == items
          ? _value._items
          : items // ignore: cast_nullable_to_non_nullable
              as List<StockTransferItemModel>,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as TransferStatus,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdBy: null == createdBy
          ? _value.createdBy
          : createdBy // ignore: cast_nullable_to_non_nullable
              as String,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      receivedAt: freezed == receivedAt
          ? _value.receivedAt
          : receivedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      receivedBy: freezed == receivedBy
          ? _value.receivedBy
          : receivedBy // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StockTransferModelImpl extends _StockTransferModel {
  const _$StockTransferModelImpl(
      {required this.id,
      @JsonKey(name: 'branch_id') required this.branchId,
      @JsonKey(name: 'from_branch_id') required this.fromBranchId,
      @JsonKey(name: 'to_branch_id') required this.toBranchId,
      @JsonKey(name: 'from_branch_name') required this.fromBranchName,
      @JsonKey(name: 'to_branch_name') required this.toBranchName,
      @JsonKey(name: 'transfer_number') required this.transferNumber,
      required final List<StockTransferItemModel> items,
      @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
      this.status = TransferStatus.draft,
      this.notes,
      @JsonKey(name: 'created_by') required this.createdBy,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt,
      @JsonKey(name: 'received_at') this.receivedAt,
      @JsonKey(name: 'received_by') this.receivedBy})
      : _items = items,
        super._();

  factory _$StockTransferModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$StockTransferModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey(name: 'from_branch_id')
  final String fromBranchId;
  @override
  @JsonKey(name: 'to_branch_id')
  final String toBranchId;
  @override
  @JsonKey(name: 'from_branch_name')
  final String fromBranchName;
  @override
  @JsonKey(name: 'to_branch_name')
  final String toBranchName;
  @override
  @JsonKey(name: 'transfer_number')
  final int transferNumber;
  final List<StockTransferItemModel> _items;
  @override
  List<StockTransferItemModel> get items {
    if (_items is EqualUnmodifiableListView) return _items;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_items);
  }

  @override
  @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
  final TransferStatus status;
  @override
  final String? notes;
  @override
  @JsonKey(name: 'created_by')
  final String createdBy;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;
  @override
  @JsonKey(name: 'received_at')
  final DateTime? receivedAt;
  @override
  @JsonKey(name: 'received_by')
  final String? receivedBy;

  @override
  String toString() {
    return 'StockTransferModel(id: $id, branchId: $branchId, fromBranchId: $fromBranchId, toBranchId: $toBranchId, fromBranchName: $fromBranchName, toBranchName: $toBranchName, transferNumber: $transferNumber, items: $items, status: $status, notes: $notes, createdBy: $createdBy, createdAt: $createdAt, updatedAt: $updatedAt, receivedAt: $receivedAt, receivedBy: $receivedBy)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StockTransferModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.fromBranchId, fromBranchId) ||
                other.fromBranchId == fromBranchId) &&
            (identical(other.toBranchId, toBranchId) ||
                other.toBranchId == toBranchId) &&
            (identical(other.fromBranchName, fromBranchName) ||
                other.fromBranchName == fromBranchName) &&
            (identical(other.toBranchName, toBranchName) ||
                other.toBranchName == toBranchName) &&
            (identical(other.transferNumber, transferNumber) ||
                other.transferNumber == transferNumber) &&
            const DeepCollectionEquality().equals(other._items, _items) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.notes, notes) || other.notes == notes) &&
            (identical(other.createdBy, createdBy) ||
                other.createdBy == createdBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.receivedAt, receivedAt) ||
                other.receivedAt == receivedAt) &&
            (identical(other.receivedBy, receivedBy) ||
                other.receivedBy == receivedBy));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      branchId,
      fromBranchId,
      toBranchId,
      fromBranchName,
      toBranchName,
      transferNumber,
      const DeepCollectionEquality().hash(_items),
      status,
      notes,
      createdBy,
      createdAt,
      updatedAt,
      receivedAt,
      receivedBy);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StockTransferModelImplCopyWith<_$StockTransferModelImpl> get copyWith =>
      __$$StockTransferModelImplCopyWithImpl<_$StockTransferModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StockTransferModelImplToJson(
      this,
    );
  }
}

abstract class _StockTransferModel extends StockTransferModel {
  const factory _StockTransferModel(
      {required final String id,
      @JsonKey(name: 'branch_id') required final String branchId,
      @JsonKey(name: 'from_branch_id') required final String fromBranchId,
      @JsonKey(name: 'to_branch_id') required final String toBranchId,
      @JsonKey(name: 'from_branch_name') required final String fromBranchName,
      @JsonKey(name: 'to_branch_name') required final String toBranchName,
      @JsonKey(name: 'transfer_number') required final int transferNumber,
      required final List<StockTransferItemModel> items,
      @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
      final TransferStatus status,
      final String? notes,
      @JsonKey(name: 'created_by') required final String createdBy,
      @JsonKey(name: 'created_at') required final DateTime createdAt,
      @JsonKey(name: 'updated_at') required final DateTime updatedAt,
      @JsonKey(name: 'received_at') final DateTime? receivedAt,
      @JsonKey(name: 'received_by')
      final String? receivedBy}) = _$StockTransferModelImpl;
  const _StockTransferModel._() : super._();

  factory _StockTransferModel.fromJson(Map<String, dynamic> json) =
      _$StockTransferModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  @JsonKey(name: 'from_branch_id')
  String get fromBranchId;
  @override
  @JsonKey(name: 'to_branch_id')
  String get toBranchId;
  @override
  @JsonKey(name: 'from_branch_name')
  String get fromBranchName;
  @override
  @JsonKey(name: 'to_branch_name')
  String get toBranchName;
  @override
  @JsonKey(name: 'transfer_number')
  int get transferNumber;
  @override
  List<StockTransferItemModel> get items;
  @override
  @JsonKey(fromJson: _transferStatusFromJson, toJson: _transferStatusToJson)
  TransferStatus get status;
  @override
  String? get notes;
  @override
  @JsonKey(name: 'created_by')
  String get createdBy;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(name: 'received_at')
  DateTime? get receivedAt;
  @override
  @JsonKey(name: 'received_by')
  String? get receivedBy;
  @override
  @JsonKey(ignore: true)
  _$$StockTransferModelImplCopyWith<_$StockTransferModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
