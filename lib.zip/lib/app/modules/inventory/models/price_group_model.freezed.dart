// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'price_group_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PriceGroupModel _$PriceGroupModelFromJson(Map<String, dynamic> json) {
  return _PriceGroupModel.fromJson(json);
}

/// @nodoc
mixin _$PriceGroupModel {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  @JsonKey(name: 'markup_percentage')
  double get markupPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: 'discount_percentage')
  double get discountPercentage => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_default')
  bool get isDefault => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PriceGroupModelCopyWith<PriceGroupModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PriceGroupModelCopyWith<$Res> {
  factory $PriceGroupModelCopyWith(
          PriceGroupModel value, $Res Function(PriceGroupModel) then) =
      _$PriceGroupModelCopyWithImpl<$Res, PriceGroupModel>;
  @useResult
  $Res call(
      {String id,
      String name,
      @JsonKey(name: 'markup_percentage') double markupPercentage,
      @JsonKey(name: 'discount_percentage') double discountPercentage,
      @JsonKey(name: 'is_default') bool isDefault});
}

/// @nodoc
class _$PriceGroupModelCopyWithImpl<$Res, $Val extends PriceGroupModel>
    implements $PriceGroupModelCopyWith<$Res> {
  _$PriceGroupModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? markupPercentage = null,
    Object? discountPercentage = null,
    Object? isDefault = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      markupPercentage: null == markupPercentage
          ? _value.markupPercentage
          : markupPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      discountPercentage: null == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      isDefault: null == isDefault
          ? _value.isDefault
          : isDefault // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PriceGroupModelImplCopyWith<$Res>
    implements $PriceGroupModelCopyWith<$Res> {
  factory _$$PriceGroupModelImplCopyWith(_$PriceGroupModelImpl value,
          $Res Function(_$PriceGroupModelImpl) then) =
      __$$PriceGroupModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      @JsonKey(name: 'markup_percentage') double markupPercentage,
      @JsonKey(name: 'discount_percentage') double discountPercentage,
      @JsonKey(name: 'is_default') bool isDefault});
}

/// @nodoc
class __$$PriceGroupModelImplCopyWithImpl<$Res>
    extends _$PriceGroupModelCopyWithImpl<$Res, _$PriceGroupModelImpl>
    implements _$$PriceGroupModelImplCopyWith<$Res> {
  __$$PriceGroupModelImplCopyWithImpl(
      _$PriceGroupModelImpl _value, $Res Function(_$PriceGroupModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? markupPercentage = null,
    Object? discountPercentage = null,
    Object? isDefault = null,
  }) {
    return _then(_$PriceGroupModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      markupPercentage: null == markupPercentage
          ? _value.markupPercentage
          : markupPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      discountPercentage: null == discountPercentage
          ? _value.discountPercentage
          : discountPercentage // ignore: cast_nullable_to_non_nullable
              as double,
      isDefault: null == isDefault
          ? _value.isDefault
          : isDefault // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PriceGroupModelImpl implements _PriceGroupModel {
  const _$PriceGroupModelImpl(
      {required this.id,
      required this.name,
      @JsonKey(name: 'markup_percentage') this.markupPercentage = 0,
      @JsonKey(name: 'discount_percentage') this.discountPercentage = 0,
      @JsonKey(name: 'is_default') this.isDefault = false});

  factory _$PriceGroupModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PriceGroupModelImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  @JsonKey(name: 'markup_percentage')
  final double markupPercentage;
  @override
  @JsonKey(name: 'discount_percentage')
  final double discountPercentage;
  @override
  @JsonKey(name: 'is_default')
  final bool isDefault;

  @override
  String toString() {
    return 'PriceGroupModel(id: $id, name: $name, markupPercentage: $markupPercentage, discountPercentage: $discountPercentage, isDefault: $isDefault)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PriceGroupModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.markupPercentage, markupPercentage) ||
                other.markupPercentage == markupPercentage) &&
            (identical(other.discountPercentage, discountPercentage) ||
                other.discountPercentage == discountPercentage) &&
            (identical(other.isDefault, isDefault) ||
                other.isDefault == isDefault));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, markupPercentage, discountPercentage, isDefault);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PriceGroupModelImplCopyWith<_$PriceGroupModelImpl> get copyWith =>
      __$$PriceGroupModelImplCopyWithImpl<_$PriceGroupModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PriceGroupModelImplToJson(
      this,
    );
  }
}

abstract class _PriceGroupModel implements PriceGroupModel {
  const factory _PriceGroupModel(
          {required final String id,
          required final String name,
          @JsonKey(name: 'markup_percentage') final double markupPercentage,
          @JsonKey(name: 'discount_percentage') final double discountPercentage,
          @JsonKey(name: 'is_default') final bool isDefault}) =
      _$PriceGroupModelImpl;

  factory _PriceGroupModel.fromJson(Map<String, dynamic> json) =
      _$PriceGroupModelImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  @JsonKey(name: 'markup_percentage')
  double get markupPercentage;
  @override
  @JsonKey(name: 'discount_percentage')
  double get discountPercentage;
  @override
  @JsonKey(name: 'is_default')
  bool get isDefault;
  @override
  @JsonKey(ignore: true)
  _$$PriceGroupModelImplCopyWith<_$PriceGroupModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
