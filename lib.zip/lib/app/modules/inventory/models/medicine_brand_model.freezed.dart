// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'medicine_brand_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MedicineBrandModel _$MedicineBrandModelFromJson(Map<String, dynamic> json) {
  return _MedicineBrandModel.fromJson(json);
}

/// @nodoc
mixin _$MedicineBrandModel {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String? get logo => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MedicineBrandModelCopyWith<MedicineBrandModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MedicineBrandModelCopyWith<$Res> {
  factory $MedicineBrandModelCopyWith(
          MedicineBrandModel value, $Res Function(MedicineBrandModel) then) =
      _$MedicineBrandModelCopyWithImpl<$Res, MedicineBrandModel>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? description,
      String? logo,
      @JsonKey(name: 'created_at') DateTime createdAt});
}

/// @nodoc
class _$MedicineBrandModelCopyWithImpl<$Res, $Val extends MedicineBrandModel>
    implements $MedicineBrandModelCopyWith<$Res> {
  _$MedicineBrandModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? logo = freezed,
    Object? createdAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MedicineBrandModelImplCopyWith<$Res>
    implements $MedicineBrandModelCopyWith<$Res> {
  factory _$$MedicineBrandModelImplCopyWith(_$MedicineBrandModelImpl value,
          $Res Function(_$MedicineBrandModelImpl) then) =
      __$$MedicineBrandModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? description,
      String? logo,
      @JsonKey(name: 'created_at') DateTime createdAt});
}

/// @nodoc
class __$$MedicineBrandModelImplCopyWithImpl<$Res>
    extends _$MedicineBrandModelCopyWithImpl<$Res, _$MedicineBrandModelImpl>
    implements _$$MedicineBrandModelImplCopyWith<$Res> {
  __$$MedicineBrandModelImplCopyWithImpl(_$MedicineBrandModelImpl _value,
      $Res Function(_$MedicineBrandModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? logo = freezed,
    Object? createdAt = null,
  }) {
    return _then(_$MedicineBrandModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      logo: freezed == logo
          ? _value.logo
          : logo // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MedicineBrandModelImpl implements _MedicineBrandModel {
  const _$MedicineBrandModelImpl(
      {required this.id,
      required this.name,
      this.description,
      this.logo,
      @JsonKey(name: 'created_at') required this.createdAt});

  factory _$MedicineBrandModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$MedicineBrandModelImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final String? description;
  @override
  final String? logo;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;

  @override
  String toString() {
    return 'MedicineBrandModel(id: $id, name: $name, description: $description, logo: $logo, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MedicineBrandModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.logo, logo) || other.logo == logo) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, name, description, logo, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MedicineBrandModelImplCopyWith<_$MedicineBrandModelImpl> get copyWith =>
      __$$MedicineBrandModelImplCopyWithImpl<_$MedicineBrandModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MedicineBrandModelImplToJson(
      this,
    );
  }
}

abstract class _MedicineBrandModel implements MedicineBrandModel {
  const factory _MedicineBrandModel(
          {required final String id,
          required final String name,
          final String? description,
          final String? logo,
          @JsonKey(name: 'created_at') required final DateTime createdAt}) =
      _$MedicineBrandModelImpl;

  factory _MedicineBrandModel.fromJson(Map<String, dynamic> json) =
      _$MedicineBrandModelImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  String? get description;
  @override
  String? get logo;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$MedicineBrandModelImplCopyWith<_$MedicineBrandModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
