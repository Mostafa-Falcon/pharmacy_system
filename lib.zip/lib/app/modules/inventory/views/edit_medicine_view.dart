import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:collection/collection.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/models/inventory/medicine_unit_model.dart';
import '../../../core/models/base/lookup_model.dart';
import '../../../core/models/supplier/supplier_model.dart';
import '../../../core/services/inventory/barcode_service.dart';
import '../../../core/services/lookup_service.dart';
import '../../../core/services/supplier/supplier_service.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/widgets/index.dart';
import '../bloc/medicines_bloc.dart';

class EditMedicineView extends StatelessWidget {
  final MedicineModel? medicine;
  const EditMedicineView({super.key, this.medicine});

  @override
  Widget build(BuildContext context) {
    if (medicine == null) {
      return HomeShell(
        title: AppStrings.editMedicine,
        child: Center(
          child: ReusableText(
            AppStrings.medicineNotFound,
            style: TextStyle(fontSize: 16.sp),
          ),
        ),
      );
    }
    return BlocProvider(
      create: (_) => MedicinesBloc(),
      child: _EditMedicineBody(medicine: medicine!),
    );
  }
}

class _EditMedicineBody extends StatelessWidget {
  final MedicineModel medicine;
  const _EditMedicineBody({required this.medicine});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return HomeShell(
      title: '${AppStrings.editMedicineFor}${medicine.name}',
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.15),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: AppSpacing.xl.w,
            vertical: AppSpacing.xl.h,
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 1100.w),
              child: _EditMedicineForm(medicine: medicine),
            ),
          ),
        ),
      ),
    );
  }
}

class _EditMedicineForm extends StatefulWidget {
  final MedicineModel medicine;
  const _EditMedicineForm({required this.medicine});

  @override
  State<_EditMedicineForm> createState() => _EditMedicineFormState();
}

class _EditMedicineFormState extends State<_EditMedicineForm> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _nameEnController;
  late final TextEditingController _strengthController;
  late final TextEditingController _packageSizeController;
  late final TextEditingController _descriptionController;
  late final TextEditingController _barcodeController;
  late final TextEditingController _locationController;
  late final TextEditingController _taxValueController;
  late final List<TextEditingController> _additionalBarcodeControllers;

  late String? _selectedItemTypeId;
  late String? _selectedGroupId;
  late String? _selectedSupplierId;
  late String? _selectedDosageForm;

  late bool _dosageFormEnabled;
  late bool _alertEnabled;
  late bool _expiryTrackingEnabled;
  late bool _showOldPrice;
  late bool _isTaxable;
  late bool _pricesIncludeTax;
  late bool _allowNegativeStock;
  late bool _isActive;
  late String? _selectedTaxType;
  bool _isDirty = false;
  late bool _containerShapeEnabled;
  late DateTime? _expiryDate;

  late String? _imageUrl;
  late String? _selectedContainerShape;

  late final List<_EditUnitFormData> _units;
  bool _isSubmitting = false;

  static const _dosageForms = [
    AppStrings.dosageFormTablets,
    AppStrings.dosageFormCapsules,
    AppStrings.dosageFormSyrup,
    AppStrings.dosageFormInjection,
    AppStrings.dosageFormCream,
    AppStrings.dosageFormDrops,
    AppStrings.dosageFormPowder,
    AppStrings.dosageFormInhaler,
    AppStrings.dosageFormPatch,
    AppStrings.dosageFormSuppository,
    AppStrings.dosageFormOther,
  ];
  static const _containerShapes = [
    AppStrings.containerShapeBox,
    AppStrings.containerShapeStrip,
    AppStrings.containerShapeBottle,
    AppStrings.containerShapeTube,
    AppStrings.containerShapePlastic,
    AppStrings.containerShapeAmpoule,
    AppStrings.containerShapeVial,
    AppStrings.containerShapePreFilledSyringe,
    AppStrings.containerShapeSachet,
    AppStrings.containerShapeSpray,
    AppStrings.containerShapeDropper,
    AppStrings.containerShapeMetalCan,
    AppStrings.containerShapeOther,
  ];

  @override
  void initState() {
    super.initState();
    final m = widget.medicine;
    _nameController = TextEditingController(text: m.name);
    _nameEnController = TextEditingController(text: m.nameEn ?? '');
    _strengthController = TextEditingController(text: m.strength ?? '');
    _packageSizeController = TextEditingController(text: m.packageSize ?? '');
    _descriptionController = TextEditingController(text: m.description ?? '');
    _barcodeController = TextEditingController(text: m.barcodes.isNotEmpty ? m.barcodes.first : '');
    _locationController = TextEditingController(text: m.location ?? '');
    _taxValueController = TextEditingController(text: m.taxValue?.toString() ?? '');
    _additionalBarcodeControllers = m.barcodes.length > 1
        ? m.barcodes.skip(1).map((b) => TextEditingController(text: b)).toList()
        : [];

    _selectedItemTypeId = m.itemTypeId;
    _selectedGroupId = m.groupId;
    _selectedSupplierId = m.supplierName;
    _selectedDosageForm = m.dosageForm;

    _dosageFormEnabled = m.dosageFormEnabled;
    _alertEnabled = m.alertEnabled;
    _expiryTrackingEnabled = m.expiryTrackingEnabled;
    _showOldPrice = m.oldSellPrice != null;
    _containerShapeEnabled = m.containerShape != null;
    _expiryDate = m.expiryDate;
    _imageUrl = m.imageUrl;
    _selectedContainerShape = m.containerShape;

    _isTaxable = m.isTaxable;
    _pricesIncludeTax = m.pricesIncludeTax;
    _allowNegativeStock = m.allowNegativeStock;
    _isActive = m.isActive;
    _selectedTaxType = m.taxType;

    _units = m.units.isNotEmpty
        ? m.units.map((u) => _EditUnitFormData(
      name: u.name, level: u.level,
      buyPrice: u.buyPrice.toString(), sellPrice: u.sellPrice.toString(),
      oldPrice: u.oldSellPrice?.toString() ?? '',
      quantity: u.quantity.toString(),
      factor: u.conversionFactor.toString(),
      minStock: m.minStock.toString(),
      discount: u.discountPercent?.toString() ?? '',
      allowSale: u.allowSale,
    )).toList()
        : [_EditUnitFormData(name: AppStrings.defaultUnitBox, level: 1, buyPrice: m.buyPrice.toString(), sellPrice: m.sellPrice.toString(),
        quantity: m.quantity.toString(), minStock: m.minStock.toString())];
  }

  @override
  void dispose() {
    _nameController.dispose();
    _nameEnController.dispose();
    _strengthController.dispose();
    _packageSizeController.dispose();
    _descriptionController.dispose();
    _barcodeController.dispose();
    _locationController.dispose();
    _taxValueController.dispose();
    for (final c in _additionalBarcodeControllers) { c.dispose(); }
    for (final u in _units) { u.dispose(); }
    super.dispose();
  }

  double get _totalQuantity {
    if (_units.isEmpty) return 0;
    final mainQty = int.tryParse(_units.first.quantityController.text) ?? 0;
    var total = mainQty.toDouble();
    for (var i = 1; i < _units.length; i++) {
      final subQty = int.tryParse(_units[i].quantityController.text) ?? 0;
      final factor = double.tryParse(_units[i].factorController.text) ?? 10;
      total += subQty * factor;
    }
    return total;
  }

  double get _profitMargin {
    if (_units.isEmpty) return 0;
    final buy = double.tryParse(_units.first.buyPriceController.text) ?? 0;
    final sell = double.tryParse(_units.first.sellPriceController.text) ?? 0;
    if (buy <= 0) return 0;
    return ((sell - buy) / buy) * 100;
  }

  void _showAddLookupDialog(BuildContext context, LookupType type) async {
    final nameController = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => ReusableDialog(
        title: type == LookupType.itemType ? AppStrings.addNewItemType : AppStrings.addNewGroup,
        children: [
          ReusableInput(
            controller: nameController,
            label: AppStrings.newNameLabel,
            autofocus: true,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancel,
            confirmText: AppStrings.confirmSave,
            onCancel: () => Navigator.pop(ctx),
            onConfirm: () => Navigator.pop(ctx, nameController.text.trim()),
          ),
        ],
      ),
    );
    nameController.dispose();
    if (result != null && result.isNotEmpty) {
      final lookup = await LookupService.addByName(name: result, type: type);
      setState(() {
        _isDirty = true;
        if (type == LookupType.itemType) { _selectedItemTypeId = lookup.id; }
        else { _selectedGroupId = lookup.id; }
      });
    }
  }

  void _showAddSupplierDialog() async {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    SupplierType selectedType = SupplierType.supplier;
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => ReusableDialog(
          title: AppStrings.addNewApprovedSupplier,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ReusableInput(controller: nameController, label: AppStrings.companyOrSupplierNameRequired,
                    prefixIcon: const Icon(Icons.business_rounded), autofocus: true),
                SizedBox(height: AppSpacing.md.h),
                ReusableDropdown<SupplierType>(
                  hintText: AppStrings.supplyType,
                  items: SupplierType.values,
                  value: selectedType,
                  itemAsString: (t) => t == SupplierType.supplier ? AppStrings.supplierOnly : AppStrings.customerSupplierJoint,
                  onChanged: (v) { if (v != null) setDialogState(() => selectedType = v); },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            DialogActions(
              cancelText: AppStrings.cancelAction,
              confirmText: AppStrings.saveSupplier,
              onCancel: () => Navigator.pop(ctx, false),
              onConfirm: () => Navigator.pop(ctx, true),
            ),
          ],
        ),
      ),
    );
    if (result == true && nameController.text.trim().isNotEmpty) {
      final supplier = await SupplierService.add(
          name: nameController.text.trim(), type: selectedType,
          phone: phoneController.text.trim().isEmpty ? null : phoneController.text.trim());
      setState(() {
        _selectedSupplierId = supplier.id;
        _isDirty = true;
      });
    }
    nameController.dispose();
    phoneController.dispose();
  }

  void _addUnit() {
    final level = _units.length + 1;
    setState(() {
      _units.add(_EditUnitFormData(name: level == 2 ? AppStrings.defaultUnitStrip : level == 3 ? AppStrings.defaultUnitPill : '${AppStrings.unitLevelPrefix}$level', level: level));
      _isDirty = true;
    });
  }

  void _removeUnit(int index) {
    if (index <= 0 || index >= _units.length) return;
    setState(() {
      _units[index].dispose();
      _units.removeAt(index);
      _isDirty = true;
    });
  }

  void _generateBarcode() {
    final code = BarcodeService.generate();
    _barcodeController.text = code;
    setState(() => _isDirty = true);
  }

  void _addBarcodeField() {
    setState(() {
      _additionalBarcodeControllers.add(TextEditingController());
      _isDirty = true;
    });
  }

  void _removeBarcodeField(int index) {
    setState(() {
      _additionalBarcodeControllers[index].dispose();
      _additionalBarcodeControllers.removeAt(index);
      _isDirty = true;
    });
  }

  void _markDirty() {
    if (!_isDirty) setState(() => _isDirty = true);
  }

  Future<void> _editImageUrl() async {
    final controller = TextEditingController(text: _imageUrl ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => ReusableDialog(
        title: AppStrings.imageUrlTitle,
        children: [
          ReusableInput(
            controller: controller,
            label: AppStrings.imageUrlLabel,
            prefixIcon: const Icon(Icons.link_rounded),
            keyboardType: TextInputType.url,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancel,
            confirmText: AppStrings.confirmSave,
            onCancel: () => Navigator.pop(ctx),
            onConfirm: () => Navigator.pop(ctx, controller.text.trim()),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() {
        _imageUrl = result.isEmpty ? null : result;
        _isDirty = true;
      });
    }
    controller.dispose();
  }

  void _removeImage() {
    setState(() {
      _imageUrl = null;
      _isDirty = true;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);

    final barcodes = <String>[];
    final primaryBarcode = _barcodeController.text.trim();
    if (primaryBarcode.isNotEmpty) {
      if (BarcodeService.isBarcodeTaken(primaryBarcode, excludeMedicineId: widget.medicine.id)) {
        setState(() => _isSubmitting = false);
        AppSnackbar.error(AppStrings.barcodeTakenElsewhereError.replaceFirst('%s', primaryBarcode), title: AppStrings.inventorySystemSecurity);
        return;
      }
      barcodes.add(primaryBarcode);
    }
    for (final c in _additionalBarcodeControllers) {
      final code = c.text.trim();
      if (code.isEmpty) continue;
      if (barcodes.contains(code)) continue;
      if (BarcodeService.isBarcodeTaken(code, excludeMedicineId: widget.medicine.id)) {
        setState(() => _isSubmitting = false);
        AppSnackbar.error(AppStrings.barcodeTakenElsewhereError.replaceFirst('%s', code), title: AppStrings.inventorySystemSecurity);
        return;
      }
      barcodes.add(code);
    }
    if (barcodes.isEmpty) {
      final autoBarcode = BarcodeService.generate();
      barcodes.add(autoBarcode);
    }

    final units = <MedicineUnitModel>[];
    for (var i = 0; i < _units.length; i++) {
      final u = _units[i];
      units.add(MedicineUnitModel(
        id: '${widget.medicine.id}_unit_${i + 1}',
        name: u.nameController.text.trim().isNotEmpty ? u.nameController.text.trim() : (i == 0 ? AppStrings.defaultUnitBox : '${AppStrings.unitLevelPrefix}${i + 1}'),
        level: u.level,
        conversionFactor: i == 0 ? 1 : (double.tryParse(u.factorController.text) ?? 10),
        buyPrice: double.tryParse(u.buyPriceController.text) ?? 0,
        sellPrice: double.tryParse(u.sellPriceController.text) ?? 0,
        oldSellPrice: _showOldPrice ? (double.tryParse(u.oldPriceController.text)) : null,
        discountPercent: double.tryParse(u.discountController.text),
        quantity: int.tryParse(u.quantityController.text) ?? 0,
        allowSale: u.allowSale,
      ));
    }

    final mainUnit = units.isNotEmpty ? units.first : null;

    final updated = widget.medicine.copyWith(
      name: _nameController.text.trim(),
      nameEn: _nameEnController.text.trim().isEmpty ? null : _nameEnController.text.trim(),
      itemTypeId: _selectedItemTypeId,
      groupId: _selectedGroupId,
      category: LookupService.getNameById(_selectedItemTypeId),
      barcodes: barcodes,
      buyPrice: mainUnit?.buyPrice ?? 0,
      sellPrice: mainUnit?.sellPrice ?? 0,
      oldSellPrice: _showOldPrice ? mainUnit?.oldSellPrice : null,
      quantity: _totalQuantity.toInt(),
      minStock: _alertEnabled ? (int.tryParse(_units.first.minStockController.text) ?? 10) : 0,
      alertEnabled: _alertEnabled,
      expiryTrackingEnabled: _expiryTrackingEnabled,
      expiryDate: _expiryTrackingEnabled ? _expiryDate : null,
      dosageFormEnabled: _dosageFormEnabled,
      dosageForm: _dosageFormEnabled ? _selectedDosageForm : null,
      strength: _strengthController.text.trim().isEmpty ? null : _strengthController.text.trim(),
      packageSize: _packageSizeController.text.trim().isEmpty ? null : _packageSizeController.text.trim(),
      supplierName: _selectedSupplierId,
      description: _descriptionController.text.trim().isEmpty ? null : _descriptionController.text.trim(),
      imageUrl: _imageUrl,
      containerShape: _containerShapeEnabled ? _selectedContainerShape : null,
      location: _locationController.text.trim().isEmpty ? null : _locationController.text.trim(),
      isTaxable: _isTaxable,
      taxType: _isTaxable ? _selectedTaxType : null,
      taxValue: _isTaxable ? (double.tryParse(_taxValueController.text)) : null,
      pricesIncludeTax: _pricesIncludeTax,
      allowNegativeStock: _allowNegativeStock,
      isActive: _isActive,
      units: units,
    );

    if (!mounted) return;
    context.read<MedicinesBloc>().add(UpdateMedicine(updated));
    setState(() => _isSubmitting = false);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      onChanged: _markDirty,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBasicInfoCard(),
          SizedBox(height: AppSpacing.lg.h),
          _buildBarcodeAndClassificationCard(),
          SizedBox(height: AppSpacing.lg.h),
          _buildPricingAndUnitsCard(),
          SizedBox(height: AppSpacing.lg.h),
          _buildTaxAndAdvancedCard(),
          SizedBox(height: AppSpacing.lg.h),
          _buildInventoryControlCard(),
          SizedBox(height: AppSpacing.xl.h),
          _buildActionButtons(),
          SizedBox(height: AppSpacing.xl.h),
        ],
      ),
    );
  }

  // ════════════════ PART 1: التعريف والبيانات الأساسية ════════════════
  Widget _buildBasicInfoCard() {
    final scheme = Theme.of(context).colorScheme;
    return FormCard(
      child: Column(
        children: [
          const SectionHeader(
            title: AppStrings.basicInfo,
            icon: Icons.assignment_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ReusableInput(
                  controller: _nameController,
                  label: AppStrings.medicineNameAr,
                  prefixIcon: Icon(Icons.medication_rounded, size: 18.sp, color: scheme.primary),
                  validator: (v) => (v == null || v.trim().isEmpty) ? AppStrings.medicineNameArRequired : null,
                ),
              ),
              SizedBox(width: AppSpacing.xl.w),
              Expanded(
                child: ReusableInput(
                  controller: _nameEnController,
                  label: AppStrings.medicineNameEn,
                  prefixIcon: Icon(Icons.font_download_outlined, size: 18.sp),
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Container(
            padding: EdgeInsets.all(AppSpacing.md.w),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerLowest,
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                ReusableItemImage(imageUrl: _imageUrl, size: 64, borderRadius: 12),
                SizedBox(width: AppSpacing.md.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ReusableText(AppStrings.itemVisualImage, style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold)),
                      SizedBox(height: 4.h),
                      ReusableText(
                        _imageUrl != null && _imageUrl!.isNotEmpty ? _imageUrl! : AppStrings.imageNotSelected,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 11.sp, color: scheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.link_outlined, color: scheme.primary, size: 22.sp),
                  onPressed: _editImageUrl,
                ),
                if (_imageUrl != null && _imageUrl!.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppColors.error),
                    onPressed: _removeImage,
                  ),
              ],
            ),
          ),
          SizedBox(height: AppSpacing.lg.h),
          _buildToggleCardTile(
            label: AppStrings.extraOptionsToggle,
            value: _dosageFormEnabled,
            icon: Icons.auto_awesome,
            onChanged: (v) => setState(() => _dosageFormEnabled = v),
          ),
          if (_dosageFormEnabled) ...[
            SizedBox(height: AppSpacing.lg.h),
            Row(
              children: [
                Expanded(
                  child: ReusableInput(
                    controller: _strengthController,
                    label: AppStrings.strength,
                    prefixIcon: const Icon(Icons.biotech_rounded),
                  ),
                ),
                SizedBox(width: AppSpacing.lg.w),
                Expanded(
                  child: ReusableInput(
                    controller: _packageSizeController,
                    label: AppStrings.packageSize,
                    prefixIcon: const Icon(Icons.inventory_2_outlined),
                  ),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.lg.h),
            Row(
              children: [
                Expanded(
                  child: ReusableDropdown<String>(
                    hintText: AppStrings.dosageFormHint,
                    labelText: AppStrings.dosageFormLabel,
                    items: _dosageForms,
                    value: _selectedDosageForm,
                    itemAsString: (v) => v,
                    onChanged: (v) => setState(() => _selectedDosageForm = v),
                  ),
                ),
                SizedBox(width: AppSpacing.lg.w),
                Expanded(
                  child: ReusableDropdown<String>(
                    hintText: AppStrings.containerShapeHint,
                    labelText: AppStrings.containerShapeLabel,
                    items: _containerShapes,
                    value: _selectedContainerShape,
                    itemAsString: (v) => v,
                    onChanged: (v) => setState(() {
                      _selectedContainerShape = v;
                      _containerShapeEnabled = v != null;
                    }),
                  ),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.lg.h),
            ReusableInput(
              controller: _locationController,
              label: AppStrings.storageLocation,
              prefixIcon: Icon(Icons.location_on_outlined, size: 18.sp, color: scheme.primary),
            ),
          ],
        ],
      ),
    );
  }

  // ════════════════ PART 2: التصنيف والباركود الذكي ════════════════
  Widget _buildBarcodeAndClassificationCard() {
    final scheme = Theme.of(context).colorScheme;
    final itemTypes = LookupService.getAll(type: LookupType.itemType);
    final groups = LookupService.getAll(type: LookupType.group);

    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.classificationAndBarcode,
            icon: Icons.qr_code_scanner_rounded,
          ),
          SizedBox(height: AppSpacing.xl.h),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: ReusableDropdown<LookupModel>(
                  labelText: AppStrings.itemTypeLabel,
                  hintText: AppStrings.searchHint,
                  items: itemTypes,
                  value: _selectedItemTypeId != null ? itemTypes.firstWhereOrNull((l) => l.id == _selectedItemTypeId) : null,
                  itemAsString: (l) => l.name,
                  onChanged: (v) => setState(() => _selectedItemTypeId = v?.id),
                ),
              ),
              SizedBox(width: AppSpacing.xs.w),
              IconButton.filledTonal(
                onPressed: () => _showAddLookupDialog(context, LookupType.itemType),
                icon: const Icon(Icons.add_rounded),
                style: IconButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
                  minimumSize: Size(46.w, 46.h),
                ),
              ),
              SizedBox(width: AppSpacing.lg.w),
              Expanded(
                child: ReusableDropdown<LookupModel>(
                  labelText: AppStrings.groupLabel,
                  hintText: AppStrings.searchHint,
                  items: groups,
                  value: _selectedGroupId != null ? groups.firstWhereOrNull((l) => l.id == _selectedGroupId) : null,
                  itemAsString: (l) => l.name,
                  onChanged: (v) => setState(() => _selectedGroupId = v?.id),
                ),
              ),
              SizedBox(width: AppSpacing.xs.w),
              IconButton.filledTonal(
                onPressed: () => _showAddLookupDialog(context, LookupType.group),
                icon: const Icon(Icons.add_rounded),
                style: IconButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
                  minimumSize: Size(46.w, 46.h),
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          _buildSupplierDropdownSection(),
          SizedBox(height: AppSpacing.lg.h),
          Wrap(spacing: AppSpacing.sm.w, runSpacing: AppSpacing.xs.h, children: [
            ReusableButton(text: AppStrings.generateBarcode, prefixIcon: Icons.auto_awesome_rounded, type: ButtonType.outlined, onPressed: _generateBarcode),
            ReusableButton(text: AppStrings.linkExtraBarcode, prefixIcon: Icons.add_rounded, type: ButtonType.outlined, onPressed: _addBarcodeField),
          ]),
          SizedBox(height: AppSpacing.md.h),
          ReusableInput(
            controller: _barcodeController,
            label: AppStrings.mainBarcode,
            prefixIcon: Icon(Icons.qr_code_2_rounded, size: 20.sp, color: scheme.primary),
            inputFormatters: [LengthLimitingTextInputFormatter(32)],
          ),
          for (var i = 0; i < _additionalBarcodeControllers.length; i++)
            Padding(
              padding: EdgeInsets.only(top: AppSpacing.sm.h),
              child: ReusableInput(
                controller: _additionalBarcodeControllers[i],
                label: '${AppStrings.extraBarcodePrefix}${i + 2}',
                prefixIcon: Icon(Icons.view_week_rounded, size: 20.sp, color: scheme.primary),
                inputFormatters: [LengthLimitingTextInputFormatter(32)],
                suffixIcon: IconButton(
                  icon: Icon(Icons.close_rounded, size: 18.sp, color: AppColors.error),
                  onPressed: () => _removeBarcodeField(i),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSupplierDropdownSection() {
    final suppliers = SupplierService.getAll();
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: ReusableDropdown<SupplierModel>(
            labelText: AppStrings.supplierLabel,
            hintText: AppStrings.supplierHint,
            items: suppliers,
            value: _selectedSupplierId != null ? suppliers.firstWhereOrNull((s) => s.id == _selectedSupplierId) : null,
            itemAsString: (s) => '${s.name} — [${s.typeName}]',
            onChanged: (v) => setState(() => _selectedSupplierId = v?.id),
          ),
        ),
        SizedBox(width: AppSpacing.xs.w),
        IconButton.filledTonal(
          onPressed: _showAddSupplierDialog,
          icon: const Icon(Icons.person_add_alt_1_rounded),
          style: IconButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
            minimumSize: Size(44.w, 44.h),
          ),
        ),
      ],
    );
  }

  // ════════════════ PART 3: الأسعار والوحدات بالتجزئة ════════════════
  Widget _buildPricingAndUnitsCard() {
    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.pricingAndUnits,
            icon: Icons.monetization_on_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),
          _buildToggleCardTile(
            label: AppStrings.dualPricingToggle,
            value: _showOldPrice,
            icon: Icons.swap_horizontal_circle_outlined,
            onChanged: (v) => setState(() => _showOldPrice = v),
          ),
          SizedBox(height: AppSpacing.xl.h),
          ..._units.asMap().entries.map((entry) {
            return _EditUnitCard(
              data: entry.value,
              index: entry.key,
              showOldPrice: _showOldPrice,
              canDelete: entry.key > 0 && entry.key == _units.length - 1,
              onDelete: () => _removeUnit(entry.key),
              onPriceChanged: () => setState(() {}), // تمرير الـ Callback النضيف لمنع الكراش
            );
          }),
          SizedBox(height: AppSpacing.md.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (_units.isNotEmpty)
                ReusableButton(
                  text: _units.length == 1 ? AppStrings.addSubUnit : AppStrings.addSubSubUnit,
                  prefixIcon: Icons.playlist_add_rounded,
                  type: ButtonType.outlined,
                  onPressed: _addUnit,
                ),
              if (_units.isNotEmpty && _units.first.buyPriceController.text.isNotEmpty && _units.first.sellPriceController.text.isNotEmpty)
                _buildCleanProfitBadge(),
            ],
          ),
        ],
      ),
    );
  }

  // ════════════════ PART 4: الضرائب والإعدادات المتقدمة ════════════════
  Widget _buildTaxAndAdvancedCard() {
    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.taxAndAdvanced,
            icon: Icons.tune_rounded,
          ),
          SizedBox(height: AppSpacing.xl.h),
          Row(
            children: [
              Expanded(
                child: _buildToggleTile(
                  label: AppStrings.isTaxable,
                  value: _isTaxable,
                  icon: Icons.receipt_long_rounded,
                  onChanged: (v) => setState(() {
                    _isTaxable = v;
                    if (!v) {
                      _taxValueController.clear();
                      _selectedTaxType = null;
                      _pricesIncludeTax = false;
                    }
                    _isDirty = true;
                  }),
                ),
              ),
              SizedBox(width: AppSpacing.lg.w),
              Expanded(
                child: _buildToggleTile(
                  label: AppStrings.allowNegativeStock,
                  value: _allowNegativeStock,
                  icon: Icons.unpublished_rounded,
                  onChanged: (v) => setState(() {
                    _allowNegativeStock = v;
                    _isDirty = true;
                  }),
                ),
              ),
            ],
          ),
          if (_isTaxable) ...[
            SizedBox(height: AppSpacing.lg.h),
            Row(
              children: [
                Expanded(
                  child: ReusableDropdown<String>(
                    hintText: AppStrings.taxType,
                    labelText: AppStrings.taxType,
                    items: const ['percentage', 'fixed'],
                    value: _selectedTaxType,
                    itemAsString: (v) => v == 'percentage' ? AppStrings.cartDiscountPercent : 'قيمة ثابتة برقم محدد',
                    onChanged: (v) => setState(() {
                      _selectedTaxType = v;
                      _taxValueController.clear();
                      _isDirty = true;
                    }),
                  ),
                ),
                SizedBox(width: AppSpacing.lg.w),
                Expanded(
                  child: ReusableInput(
                    controller: _taxValueController,
                    label: _selectedTaxType == 'percentage' ? AppStrings.taxPercentage : AppStrings.fixedTax,
                    prefixIcon: const Icon(Icons.monetization_on_outlined),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (_) => setState(() => _isDirty = true),
                  ),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.lg.h),
            _buildToggleTile(
              label: AppStrings.pricesIncludeTax,
              value: _pricesIncludeTax,
              icon: Icons.price_check_rounded,
              onChanged: (v) => setState(() {
                _pricesIncludeTax = v;
                _isDirty = true;
              }),
            ),
          ],
          SizedBox(height: AppSpacing.lg.h),
          _buildToggleTile(
            label: AppStrings.isActiveItem,
            value: _isActive,
            icon: Icons.toggle_on_rounded,
            onChanged: (v) => setState(() {
              _isActive = v;
              _isDirty = true;
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleTile({
    required String label,
    required bool value,
    required IconData icon,
    required ValueChanged<bool> onChanged,
  }) {
    return SettingsToggleTile(
      icon: icon,
      title: label,
      value: value,
      onChanged: onChanged,
    );
  }

  // ════════════════ PART 5: أمان المخزون والنواقص والصلاحية ════════════════
  Widget _buildInventoryControlCard() {
    return FormCard(
      child: Column(
        children: [
          const SectionHeader(
            title: AppStrings.inventorySecurity,
            icon: Icons.shield_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    _buildToggleCardTile(
                      label: AppStrings.lowStockAlert,
                      value: _alertEnabled,
                      icon: Icons.notifications_none_rounded,
                      onChanged: (v) => setState(() => _alertEnabled = v),
                    ),
                    if (_alertEnabled) ...[
                      SizedBox(height: AppSpacing.lg.h),
                      ReusableInput(
                        controller: _units.first.minStockController,
                        label: AppStrings.minStockLimit,
                        prefixIcon: const Icon(Icons.report_problem_outlined),
                        keyboardType: TextInputType.number,
                      ),
                    ],
                  ],
                ),
              ),
              SizedBox(width: AppSpacing.lg.w),
              Expanded(
                child: Column(
                  children: [
                    _buildToggleCardTile(
                      label: AppStrings.expiryTracking,
                      value: _expiryTrackingEnabled,
                      icon: Icons.calendar_today_outlined,
                      onChanged: (v) => setState(() => _expiryTrackingEnabled = v),
                    ),
                    if (_expiryTrackingEnabled) ...[
                      SizedBox(height: AppSpacing.lg.h),
                      _buildPremiumDateField(
                        label: AppStrings.currentExpiryDate,
                        date: _expiryDate,
                        onTap: () => _pickDate(),
                        onClear: () => setState(() => _expiryDate = null),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          ReusableInput(
            controller: _descriptionController,
            label: AppStrings.notesAndFormulas,
            prefixIcon: const Icon(Icons.edit_note_rounded),
            maxLines: 2,
          ),
        ],
      ),
    );
  }

  // ════════════════ PART 6: أزرار التحكم وحفظ التعديلات المحدثة ════════════════
  Widget _buildActionButtons() {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        ReusableButton(
          text: AppStrings.cancelEdit,
          onPressed: () async {
            if (_isDirty) {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => ReusableDialog(
                  title: AppStrings.confirmCancelEdit,
                  children: [
                    const ReusableText(
                      AppStrings.unsavedChangesMessage,
                    ),
                    SizedBox(height: 16.h),
                    DialogActions(
                      cancelText: AppStrings.continueEditing,
                      confirmText: AppStrings.exitWithoutSave,
                      onCancel: () => Navigator.pop(context, false),
                      onConfirm: () => Navigator.pop(context, true),
                    ),
                  ],
                ),
              );
              if (confirm != true) return;
            }
            if (!mounted) return;
            Navigator.pop(context);
          },
          type: ButtonType.outlined,
        ),
        SizedBox(width: AppSpacing.xl.w),
        Expanded(
          child: Container(
            height: 48.h, // تظبيط مقاس الزرار ليكون فخم وعريض
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: scheme.primary.withValues(alpha: 0.25),
                  blurRadius: 15,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ReusableButton(
              text: _isSubmitting ? AppStrings.submittingChanges : AppStrings.saveAllChanges,
              onPressed: _isSubmitting ? null : _submit,
              prefixIcon: Icons.save_rounded,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildToggleCardTile({
    required String label,
    required bool value,
    required IconData icon,
    required ValueChanged<bool> onChanged,
  }) {
    return SettingsToggleTile(
      icon: icon,
      title: label,
      value: value,
      onChanged: onChanged,
    );
  }

  Widget _buildPremiumDateField({
    required String label,
    required DateTime? date,
    required VoidCallback onTap,
    required VoidCallback onClear,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w),
        height: 46.h,
        decoration: BoxDecoration(
          color: scheme.surfaceContainerLowest,
          border: Border.all(color: scheme.outline),
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        child: Row(
          children: [
            Icon(Icons.edit_calendar_rounded, size: 20.sp, color: scheme.primary),
            SizedBox(width: AppSpacing.sm.w),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ReusableText(label, style: TextStyle(fontSize: 10.sp, color: scheme.onSurfaceVariant, fontWeight: FontWeight.bold)),
                  ReusableText(
                    date != null ? '${date.day} / ${date.month} / ${date.year}' : AppStrings.selectNewExpiryDateHint,
                    style: TextStyle(fontSize: 12.sp, fontWeight: date != null ? FontWeight.bold : FontWeight.normal),
                  ),
                ],
              ),
            ),
            if (date != null)
              InkWell(
                onTap: onClear,
                child: Padding(
                  padding: EdgeInsets.all(4.w),
                  child: Icon(Icons.cancel_rounded, size: 18.sp, color: AppColors.error),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCleanProfitBadge() {
    return StatusBadge(
      label: '${AppStrings.profitMarginPrefix}${_profitMargin.toStringAsFixed(1)}%',
      color: _profitMargin >= 0 ? AppColors.success : AppColors.error,
      icon: _profitMargin >= 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded,
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _expiryDate ?? now.add(const Duration(days: 365)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 365 * 10)),
      helpText: AppStrings.updateExpiryDateHelp,
      cancelText: AppStrings.cancel,
      confirmText: AppStrings.confirmDateAction,
    );
    if (picked != null) setState(() => _expiryDate = picked);
  }
}


class _EditUnitFormData {
  final int level;
  final TextEditingController nameController;
  final TextEditingController factorController;
  final TextEditingController buyPriceController;
  final TextEditingController sellPriceController;
  final TextEditingController oldPriceController;
  final TextEditingController quantityController;
  final TextEditingController minStockController;
  final TextEditingController discountController;
  bool allowSale;

  _EditUnitFormData({
    required String name,
    required this.level,
    String factor = '10',
    String buyPrice = '0',
    String sellPrice = '0',
    String oldPrice = '',
    String quantity = '0',
    String minStock = '10',
    String discount = '',
    this.allowSale = true,
  }) : nameController = TextEditingController(text: name),
        factorController = TextEditingController(text: factor),
        buyPriceController = TextEditingController(text: buyPrice),
        sellPriceController = TextEditingController(text: sellPrice),
        oldPriceController = TextEditingController(text: oldPrice),
        quantityController = TextEditingController(text: quantity),
        minStockController = TextEditingController(text: minStock),
        discountController = TextEditingController(text: discount);

  void dispose() {
    nameController.dispose();
    factorController.dispose();
    buyPriceController.dispose();
    sellPriceController.dispose();
    oldPriceController.dispose();
    quantityController.dispose();
    minStockController.dispose();
    discountController.dispose();
  }
}

class _EditUnitCard extends StatefulWidget {
  final _EditUnitFormData data;
  final int index;
  final bool showOldPrice;
  final bool canDelete;
  final VoidCallback onDelete;
  final VoidCallback onPriceChanged; // المندوب الذكي لمنع الكراش
  const _EditUnitCard({
    required this.data,
    required this.index,
    required this.showOldPrice,
    required this.canDelete,
    required this.onDelete,
    required this.onPriceChanged,
  });
  @override
  State<_EditUnitCard> createState() => _EditUnitCardState();
}

class _EditUnitCardState extends State<_EditUnitCard> {
  bool get isMain => widget.index == 0;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final data = widget.data;
    return Container(
      padding: EdgeInsets.all(AppSpacing.lg.w),
      margin: EdgeInsets.only(bottom: AppSpacing.lg.h),
      decoration: BoxDecoration(
        color: isMain ? scheme.primary.withValues(alpha: 0.015) : scheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(
          color: isMain ? scheme.primary.withValues(alpha: 0.25) : scheme.outline.withValues(alpha: 0.45),
          width: isMain ? 1.6 : 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28.w,
                height: 28.w,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isMain ? scheme.primary : scheme.outline,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                ),
                child: ReusableText(
                  '${widget.index + 1}',
                  style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w900, color: Colors.white),
                ),
              ),
              SizedBox(width: AppSpacing.sm.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ReusableText(
                      isMain ? AppStrings.mainUnitTitle : AppStrings.subUnitTitle,
                      style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.bold),
                    ),
                    if (!isMain)
                      Padding(
                        padding: EdgeInsets.only(top: 3.h),
                        child: ReusableText(
                          '${AppStrings.conversionFactorInfoPrefix}${data.factorController.text} من هذه الوحدة',
                          style: TextStyle(fontSize: 11.sp, color: scheme.primary, fontWeight: FontWeight.bold),
                        ),
                      ),
                  ],
                ),
              ),
              if (widget.canDelete)
                IconButton(
                  icon: Icon(Icons.delete_forever_rounded, color: AppColors.error, size: 22.sp),
                  onPressed: widget.onDelete,
                ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Row(
            children: [
              Expanded(
                child: ReusableInput(
                  controller: data.nameController,
                  label: isMain ? AppStrings.mainUnitNameLabel : AppStrings.subUnitNameLabel,
                  prefixIcon: const Icon(Icons.straighten_rounded),
                ),
              ),
              if (!isMain) ...[
                SizedBox(width: AppSpacing.lg.w),
                Expanded(
                  child: ReusableInput(
                    controller: data.factorController,
                    label: AppStrings.internalConversionFactorLabel,
                    prefixIcon: const Icon(Icons.pin_outlined),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Row(
            children: [
              Expanded(
                child: ReusableInput(
                  controller: data.buyPriceController,
                  label: AppStrings.buyPriceLabel,
                  prefixIcon: Icon(Icons.price_change_outlined, color: Colors.green[600]),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => widget.onPriceChanged(), // الاستدعاء النظيف لمنع كراش المترجم
                ),
              ),
              SizedBox(width: AppSpacing.lg.w),
              Expanded(
                child: ReusableInput(
                  controller: data.sellPriceController,
                  label: AppStrings.sellPriceLabel,
                  prefixIcon: Icon(Icons.sell_outlined, color: scheme.primary),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => widget.onPriceChanged(), // الاستدعاء النظيف لمنع كراش المترجم
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Row(
            children: [
              if (widget.showOldPrice) ...[
                Expanded(
                  child: ReusableInput(
                    controller: data.oldPriceController,
                    label: AppStrings.oldSellPriceLabel,
                    prefixIcon: const Icon(Icons.money_off_rounded),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
                ),
                SizedBox(width: AppSpacing.lg.w),
              ],
              Expanded(
                child: ReusableInput(
                  controller: data.quantityController,
                  label: AppStrings.currentStockLabel,
                  prefixIcon: const Icon(Icons.store_rounded),
                  keyboardType: TextInputType.number,
                ),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Row(
            children: [
              Expanded(
                child: ReusableInput(
                  controller: data.discountController,
                  label: AppStrings.discountLabel,
                  prefixIcon: const Icon(Icons.percent_rounded),
                  keyboardType: TextInputType.number,
                ),
              ),
              SizedBox(width: AppSpacing.lg.w),
              Expanded(
                child: Center(
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => setState(() => data.allowSale = !data.allowSale),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: EdgeInsets.symmetric(horizontal: AppSpacing.xl.w, vertical: AppSpacing.sm.h),
                          decoration: BoxDecoration(
                            color: data.allowSale ? AppColors.success.withValues(alpha: 0.08) : AppColors.error.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(AppRadius.md),
                            border: Border.all(
                              color: data.allowSale ? AppColors.success.withValues(alpha: 0.3) : AppColors.error.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                data.allowSale ? Icons.check_circle_rounded : Icons.block_rounded,
                                size: 18.sp,
                                color: data.allowSale ? AppColors.success : AppColors.error,
                              ),
                              SizedBox(width: AppSpacing.xs.w),
                              ReusableText(
                                data.allowSale ? AppStrings.allowSaleLabel : AppStrings.blockSaleLabel,
                                style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.bold, color: data.allowSale ? AppColors.success : AppColors.error),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}



