import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../bloc/items_archive_bloc.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/widgets/index.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';

class ItemsArchiveView extends StatelessWidget {
  const ItemsArchiveView({super.key});

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<ItemsArchiveBloc>();
    if (!bloc.canManage) {
      return const HomeShell(
        title: 'أرشيف الأصناف',
        child: ReusableStateView.permissionDenied(
          title: 'دخول غير مصرح',
          message: 'أرشيف الأصناف المحذوفة متاح فقط لمدير النظام أو صاحب الصيدلية.',
        ),
      );
    }

    final scheme = Theme.of(context).colorScheme;

    return HomeShell(
      title: 'أرشيف الأصناف المؤرشفة',
      subtitle: 'استعادة الأدوية المحذوفة سابقاً أو مسحها نهائياً من قاعدة البيانات',
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.15),
        padding: EdgeInsets.all(AppSpacing.lg.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: ReusableInput(
                    hint: 'ابحث في الأرشيف بالاسم أو الباركود...',
                    prefixIcon: const Icon(Icons.search_rounded),
                    showClearButton: true,
                    textDirection: TextDirection.rtl,
                    onChanged: (v) => bloc.add(SearchItemsArchive(v)),
                    onClear: () => bloc.add(const SearchItemsArchive('')),
                  ),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.md.h),
            BlocBuilder<ItemsArchiveBloc, ItemsArchiveState>(
              builder: (context, state) {
                if (state.selectedIds.isEmpty) return const SizedBox.shrink();
                return Padding(
                  padding: EdgeInsets.only(bottom: AppSpacing.sm.h),
                  child: _SelectionToolbar(),
                );
              },
            ),
            Expanded(
              child: BlocBuilder<ItemsArchiveBloc, ItemsArchiveState>(
                builder: (context, state) {
                  if (state.status == ItemsArchiveStatus.loading) {
                    return const LoadingIndicator(message: 'جاري تحميل الأرشيف...');
                  }
                  final items = state.items;
                  if (items.isEmpty) {
                    return const EmptyState(
                      icon: Icons.inventory_2_outlined,
                      title: 'الأرشيف فارغ',
                      subtitle: 'لا توجد أصناف مؤرشفة مطابقة لبحثك في قاعدة البيانات حالياً.',
                    );
                  }
                  return LayoutBuilder(
                    builder: (context, constraints) {
                      if (constraints.maxWidth < 800) {
                        return ListView.separated(
                          itemCount: items.length,
                          separatorBuilder: (_, index) => SizedBox(height: AppSpacing.sm.h),
                          itemBuilder: (_, index) => _ArchiveCard(item: items[index]),
                        );
                      }
                      return _ArchiveTable(items: items);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SelectionToolbar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final bloc = context.read<ItemsArchiveBloc>();
    final scheme = Theme.of(context).colorScheme;
    
    return BlocBuilder<ItemsArchiveBloc, ItemsArchiveState>(
      builder: (context, state) {
        return AppCard(
          backgroundColor: scheme.primary.withValues(alpha: 0.05),
          padding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w, vertical: AppSpacing.sm.h),
          child: Row(
            children: [
              ReusableText(
                'تم تحديد ${state.selectedIds.length} صنف',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(width: AppSpacing.lg.w),
              ReusableButton(
                text: 'استعادة المختار',
                prefixIcon: Icons.restore_rounded,
                onPressed: state.isWorking ? null : () => bloc.add(const RestoreSelected()),
                type: ButtonType.text,
              ),
              SizedBox(width: AppSpacing.sm.w),
              ReusableButton(
                text: 'حذف نهائي',
                prefixIcon: Icons.delete_forever_rounded,
                onPressed: state.isWorking ? null : () => bloc.add(const DeleteSelected()),
                type: ButtonType.outlined,
                color: AppColors.error,
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: () => bloc.add(const ToggleAllSelection()),
                tooltip: 'إلغاء التحديد',
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ArchiveTable extends StatelessWidget {
  final List<MedicineModel> items;
  const _ArchiveTable({required this.items});

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<ItemsArchiveBloc>();
    final scheme = Theme.of(context).colorScheme;
    
    return BlocBuilder<ItemsArchiveBloc, ItemsArchiveState>(
      builder: (context, state) {
        return AppCard(
          padding: EdgeInsets.zero,
          child: SingleChildScrollView(
            child: DataTable(
              showCheckboxColumn: false,
              headingRowColor: WidgetStatePropertyAll(scheme.surfaceContainerLow.withValues(alpha: 0.5)),
              columns: [
                DataColumn(
                  label: Checkbox(
                    value: items.isNotEmpty && items.every((i) => state.selectedIds.contains(i.id)),
                    onChanged: (_) => bloc.add(const ToggleAllSelection()),
                  ),
                ),
                const DataColumn(label: ReusableText('الصنف والباركود', style: TextStyle(fontWeight: FontWeight.bold))),
                const DataColumn(label: ReusableText('التصنيف', style: TextStyle(fontWeight: FontWeight.bold))),
                const DataColumn(label: ReusableText('سعر البيع', style: TextStyle(fontWeight: FontWeight.bold))),
                const DataColumn(label: ReusableText('المخزون', style: TextStyle(fontWeight: FontWeight.bold))),
                const DataColumn(label: ReusableText('تاريخ الأرشفة', style: TextStyle(fontWeight: FontWeight.bold))),
                const DataColumn(label: ReusableText('الإجراءات', style: TextStyle(fontWeight: FontWeight.bold))),
              ],
              rows: [
                for (final item in items)
                  DataRow(cells: [
                    DataCell(
                      Checkbox(
                        value: state.selectedIds.contains(item.id),
                        onChanged: (_) => bloc.add(ToggleItemSelection(item.id)),
                      ),
                    ),
                    DataCell(
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ReusableText(item.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          if (item.barcodes.isNotEmpty)
                            ReusableText(item.barcodes.first, variant: ReusableTextVariant.caption),
                        ],
                      ),
                    ),
                    DataCell(ReusableText(item.category ?? '—')),
                    DataCell(
                      ReusableText(
                        '${item.sellPrice.toStringAsFixed(2)} ج.م',
                        style: TextStyle(fontWeight: FontWeight.bold, color: scheme.primary),
                      ),
                    ),
                    DataCell(ReusableText('${item.quantity}')),
                    DataCell(
                      ReusableText(
                        DateFormat('yyyy/MM/dd HH:mm').format(item.lastModified.toLocal()),
                        style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondaryOf(context)),
                      ),
                    ),
                    DataCell(
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'استعادة',
                            onPressed: state.isWorking ? null : () => bloc.add(RestoreItem(item.id)),
                            icon: const Icon(Icons.restore_rounded, color: AppColors.success),
                          ),
                          IconButton(
                            tooltip: 'حذف نهائي',
                            onPressed: state.isWorking ? null : () => bloc.add(DeleteItem(item.id)),
                            icon: const Icon(Icons.delete_forever_rounded, color: AppColors.error),
                          ),
                        ],
                      ),
                    ),
                  ]),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ArchiveCard extends StatelessWidget {
  final MedicineModel item;
  const _ArchiveCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<ItemsArchiveBloc>();
    final scheme = Theme.of(context).colorScheme;
    
    return BlocBuilder<ItemsArchiveBloc, ItemsArchiveState>(
      builder: (context, state) {
        return AppCard(
          padding: EdgeInsets.all(AppSpacing.sm.w),
          child: Row(
            children: [
              Checkbox(
                value: state.selectedIds.contains(item.id),
                onChanged: (_) => bloc.add(ToggleItemSelection(item.id)),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ReusableText(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    ReusableText(
                      '${item.barcodes.firstOrNull ?? 'بدون باركود'} | ${item.category ?? 'بدون تصنيف'}',
                      variant: ReusableTextVariant.caption,
                    ),
                    ReusableText(
                      'المخزون عند الأرشفة: ${item.quantity}',
                      style: TextStyle(fontSize: 10.sp, color: AppColors.textMutedOf(context)),
                    ),
                  ],
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  ReusableText(
                    '${item.sellPrice.toStringAsFixed(2)} ج.م',
                    style: TextStyle(fontWeight: FontWeight.bold, color: scheme.primary),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: state.isWorking ? null : () => bloc.add(RestoreItem(item.id)),
                        icon: const Icon(Icons.restore_rounded, color: AppColors.success, size: 20),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: state.isWorking ? null : () => bloc.add(DeleteItem(item.id)),
                        icon: const Icon(Icons.delete_forever_rounded, color: AppColors.error, size: 20),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
