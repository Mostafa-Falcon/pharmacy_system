import 'dart:async';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/navigation/route_cubit.dart';
import '../../../core/services/lookup_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/widgets/index.dart';
import '../../../routes/app_routes.dart';
import '../bloc/medicines_bloc.dart';

class MedicinesListView extends StatefulWidget {
  const MedicinesListView({super.key});

  @override
  State<MedicinesListView> createState() => _MedicinesListViewState();
}

class _MedicinesListViewState extends State<MedicinesListView> {
  Timer? _debounce;
  StreamSubscription<String>? _routeSubscription;
  String? _previousRoute;

  @override
  void initState() {
    super.initState();
    _previousRoute = routeCubit.currentRoute;
    _routeSubscription = routeCubit.stream.listen((route) {
      if (route == Routes.INVENTORY_LIST &&
          _previousRoute != Routes.INVENTORY_LIST) {
        if (mounted) {
          final bloc = context.read<MedicinesBloc>();
          if (!bloc.isClosed) bloc.add(const LoadMedicines());
        }
      }
      _previousRoute = route;
    });
    final bloc = context.read<MedicinesBloc>();
    if (!bloc.isClosed) bloc.add(const LoadMedicines());
  }

  @override
  void dispose() {
    _routeSubscription?.cancel();
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      if (mounted) {
        context.read<MedicinesBloc>().add(SearchMedicines(query));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return HomeShell(
      title: AppStrings.inventoryTitle,
      subtitle: AppStrings.inventorySubtitle,
      child: Stack(
        children: [
          Container(
            color: scheme.surfaceContainerLow.withValues(alpha: 0.15),
            padding: EdgeInsets.all(AppSpacing.lg.w),
            child: BlocBuilder<MedicinesBloc, MedicinesState>(
              builder: (context, state) {
                if (state.dataState.isLoading &&
                    state.allMedicines.isEmpty) {
                  return const LoadingIndicator();
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildHeader(context, state),
                    SizedBox(height: AppSpacing.lg.h),
                    _buildFilters(context, state),
                    SizedBox(height: AppSpacing.md.h),
                    Expanded(child: _buildTable(context, state)),
                  ],
                );
              },
            ),
          ),

          // مُكون التراكب الموحد لإظهار التقدم الحقيقي (حذف، استيراد، إلخ)
          BlocBuilder<MedicinesBloc, MedicinesState>(
            buildWhen: (prev, current) =>
                prev.isLoadingAction != current.isLoadingAction ||
                prev.bulkActionProgress != current.bulkActionProgress ||
                prev.bulkActionTitle != current.bulkActionTitle,
            builder: (context, state) {
              return ReusableProgressOverlay(
                isVisible: state.isLoadingAction,
                progress: state.bulkActionProgress,
                title: state.bulkActionTitle ?? AppStrings.executingOperation,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context, MedicinesState state) {
    final scheme = Theme.of(context).colorScheme;
    return Wrap(
      spacing: AppSpacing.md.w,
      runSpacing: AppSpacing.md.h,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        ReusableButton(
          text: AppStrings.addMedicine,
          prefixIcon: Icons.add_rounded,
          onPressed: () => context.push(Routes.INVENTORY_ADD),
        ),
        ReusableButton(
          text: AppStrings.importExcel,
          type: ButtonType.outlined,
          prefixIcon: Icons.file_upload_rounded,
          onPressed: () => context.push(Routes.INVENTORY_IMPORT),
        ),
        ReusableButton(
          text: 'استيراد منتجات (Excel)',
          type: ButtonType.outlined,
          prefixIcon: Icons.inventory_2_rounded,
          onPressed: () => context.push(Routes.INVENTORY_IMPORT_PRODUCTS),
        ),
        ReusableButton(
          text: 'مسح الكل',
          type: ButtonType.outlined,
          prefixIcon: Icons.delete_sweep_rounded,
          onPressed: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                icon: Icon(
                  Icons.warning_rounded,
                  color: Theme.of(context).colorScheme.error,
                  size: 32.sp,
                ),
                title: ReusableText(
                  'تأكيد مسح الكل',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                content: ReusableText(
                  'هل تريد حذف كل الأدوية (${state.totalCount})؟ هذا الإجراء لا يمكن التراجع عنه.',
                  style: TextStyle(fontSize: 13.sp),
                ),
                actions: [
                  TextButton(
                    onPressed: () => ctx.pop(),
                    child: ReusableText('إلغاء'),
                  ),
                  FilledButton(
                    onPressed: () {
                      ctx.pop();
                      context.read<MedicinesBloc>().add(
                        const DeleteAllMedicines(),
                      );
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.error,
                    ),
                    child: ReusableText(
                      'مسح الكل',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onError,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),

        // استخدام Row للإحصائيات في نهاية الـ Wrap
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildStatCard(
              AppStrings.totalItems,
              '${state.totalCount}',
              scheme.primary,
              icon: Icons.inventory_2_rounded,
            ),
            SizedBox(width: AppSpacing.sm.w),
            _buildStatCard(
              AppStrings.lowStock,
              '${state.lowStockCount}',
              AppColors.error,
              icon: Icons.warning_amber_rounded,
            ),
            SizedBox(width: AppSpacing.sm.w),
            _buildStatCard(
              AppStrings.expired,
              '${state.expiredCount}',
              AppColors.warning,
              icon: Icons.running_with_errors_rounded,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard(String label, String value, Color color, {IconData? icon}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            color.withValues(alpha: 0.12),
            color.withValues(alpha: 0.04),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppRadius.md.r),
        border: Border.all(color: color.withValues(alpha: 0.25)),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.05),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Container(
              padding: EdgeInsets.all(5.w),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 15.sp, color: color),
            ),
            SizedBox(width: 8.w),
          ],
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              ReusableText(
                value,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: color,
                  fontSize: 15.sp,
                ),
              ),
              ReusableText(
                label,
                style: TextStyle(
                  fontSize: 9.sp,
                  color: color.withValues(alpha: 0.85),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilters(BuildContext context, MedicinesState state) {
    final bloc = context.read<MedicinesBloc>();
    final categories = [
      'الكل',
      ...LookupService.getItemTypes().map((e) => e.name),
    ];

    return AppCard(
      padding: EdgeInsets.all(AppSpacing.md.w),
      child: Wrap(
        spacing: AppSpacing.md.w,
        runSpacing: AppSpacing.md.h,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: 320.w,
            child: MedicineSearchField(
              hint: AppStrings.searchInventoryHint,
              clearOnSelect: false,
              onChanged: _onSearchChanged,
              onSelected: (m) => bloc.add(SearchMedicines(m.name)),
            ),
          ),
          SizedBox(
            width: 200.w,
            child: ReusableDropdown<String>(
              items: categories,
              value: state.selectedCategory ?? AppStrings.all,
              hintText: AppStrings.displayCategory,
              itemAsString: (cat) => cat,
              onChanged: (v) =>
                  bloc.add(FilterByCategory(v == AppStrings.all ? null : v)),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip(
                  AppStrings.all,
                  'all',
                  state.selectedFilter,
                  bloc,
                ),
                SizedBox(width: AppSpacing.xs.w),
                _buildFilterChip(
                  AppStrings.lowStock,
                  'low_stock',
                  state.selectedFilter,
                  bloc,
                ),
                SizedBox(width: AppSpacing.xs.w),
                _buildFilterChip(
                  AppStrings.outOfStock,
                  'out_of_stock',
                  state.selectedFilter,
                  bloc,
                ),
                SizedBox(width: AppSpacing.xs.w),
                _buildFilterChip(
                  AppStrings.expiringSoon,
                  'expiring',
                  state.selectedFilter,
                  bloc,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(
    String label,
    String value,
    String selected,
    MedicinesBloc bloc,
  ) {
    final isSelected = selected == value;
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () => bloc.add(FilterMedicines(value)),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
        decoration: BoxDecoration(
          color: isSelected ? scheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? scheme.primary
                : scheme.outline.withValues(alpha: 0.5),
          ),
        ),
        child: ReusableText(
          label,
          style: TextStyle(
            fontSize: 11.sp,
            color: isSelected ? scheme.onPrimary : scheme.onSurfaceVariant,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildTable(BuildContext context, MedicinesState state) {
    final bloc = context.read<MedicinesBloc>();
    final f = NumberFormat('#,##0.##');

    final columns = [
      ReusableTableColumn<MedicineModel>(
        id: 'name',
        title: 'الصنف',
        flex: 3,
        isSortable: true,
        cellBuilder: (m) => Row(
          children: [
            Container(
              width: 32.w,
              height: 32.w,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(6.r),
              ),
              child: Icon(
                Icons.medication_rounded,
                size: 16.sp,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            SizedBox(width: 10.w),
            Expanded(
              child: ReusableText(
                m.name,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'barcode',
        title: 'الباركود',
        width: 150.w,
        isSortable: true,
        cellBuilder: (m) {
          String? barcode;
          if (m.barcodes.isNotEmpty) {
            barcode = m.barcodes.first;
          } else if (m.units.isNotEmpty) {
            // البحث عن أول وحدة تحتوي على باركود
            final unitWithBarcode = m.units.firstWhereOrNull(
              (u) => u.barcode != null && u.barcode!.isNotEmpty,
            );
            barcode = unitWithBarcode?.barcode;
          }

          return ReusableText(
            barcode ?? '-',
            style: TextStyle(
              fontSize: 12.sp,
              color: Colors.grey.shade700,
              fontWeight: FontWeight.w500,
            ),
          );
        },
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'category',
        title: AppStrings.displayCategory,
        width: 120.w,
        isSortable: true,
        textBuilder: (m) => m.category ?? '-',
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'location',
        title: 'المكان',
        width: 120.w,
        isSortable: true,
        cellBuilder: (m) => ReusableText(
          m.location ?? '-',
          style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500),
        ),
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'quantity',
        title: 'الكمية',
        width: 90.w,
        isSortable: true,
        isNumeric: true,
        cellBuilder: (m) {
          final isLow = m.quantity <= m.minStock;
          return ReusableText(
            '${m.quantity}',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: isLow ? AppColors.error : AppColors.success,
            ),
          );
        },
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'sellPrice',
        title: 'سعر البيع',
        width: 110.w,
        isSortable: true,
        isNumeric: true,
        textBuilder: (m) => '${f.format(m.sellPrice)} ج.م',
      ),
      ReusableTableColumn<MedicineModel>(
        id: 'expiry',
        title: 'الصلاحية',
        width: 100.w,
        isSortable: true,
        cellBuilder: (m) {
          if (m.expiryDate == null) return const ReusableText('-');
          final now = DateTime.now();
          final isExpired = m.expiryDate!.isBefore(now);
          final isExpiring = m.expiryDate!.isBefore(
            now.add(const Duration(days: 90)),
          );
          return ReusableText(
            DateFormat('yyyy/MM').format(m.expiryDate!),
            style: TextStyle(
              color: isExpired
                  ? AppColors.error
                  : (isExpiring ? AppColors.warning : null),
              fontWeight: (isExpired || isExpiring) ? FontWeight.bold : null,
              fontSize: 12.sp,
            ),
          );
        },
      ),
    ];

    if (state.allMedicines.isEmpty && !state.dataState.isLoading) {
      return const EmptyState(
        icon: Icons.medication_liquid_rounded,
        title: AppStrings.emptyInventoryTitle,
        subtitle: AppStrings.emptyInventorySubtitle,
      );
    }

    final scheme = Theme.of(context).colorScheme;

    return ReusableTable<MedicineModel>(
      columns: columns,
      items: state.pagedMedicines,
      isLoading: state.dataState.isLoading,
      currentPage: state.currentPage + 1,
      totalPages: state.totalPages,
      totalItems: state.filteredMedicines.length,
      pageSize: state.pageSize,
      pageSizeOptions: state.pageSizeOptions,
      onPageSizeChanged: (newSize) => bloc.add(ChangePageSize(newSize)),
      onNextPage: () => bloc.add(const NextPage()),
      onPreviousPage: () => bloc.add(const PreviousPage()),
      onFirstPage: () => bloc.add(const GoToPage(0)),
      onLastPage: () => bloc.add(GoToPage(state.totalPages - 1)),
      onGoToPage: (page) => bloc.add(GoToPage(page - 1)),
      onSort: (colId) => bloc.add(SortMedicines(colId)),
      sortColumnId: state.sortColumnId,
      isSortAscending: state.isSortAscending,
      itemLabel: AppStrings.itemLabel,
      showCheckbox: true,
      selectedIds: state.selectedIds,
      rowIdGetter: (m) => m.id,
      onSelectRow: (id) => bloc.add(ToggleSelectRow(id)),
      onToggleAll: (selectAll) => bloc.add(ToggleSelectAll(selectAll)),
      bulkActions: [
        ReusableButton(
          text: AppStrings.delete,
          type: ButtonType.outlined,
          color: AppColors.error,
          prefixIcon: Icons.delete_sweep_rounded,
          onPressed: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                icon: Icon(
                  Icons.warning_rounded,
                  color: Theme.of(context).colorScheme.error,
                  size: 32.sp,
                ),
                title: ReusableText(
                  'تأكيد الحذف',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                content: ReusableText(
                  'هل تريد حذف ${state.selectedIds.length} دواء محدّد؟',
                  style: TextStyle(fontSize: 13.sp),
                ),
                actions: [
                  TextButton(
                    onPressed: () => ctx.pop(),
                    child: ReusableText('إلغاء'),
                  ),
                  FilledButton(
                    onPressed: () {
                      ctx.pop();
                      bloc.add(const DeleteSelectedMedicines());
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.error,
                    ),
                    child: ReusableText(
                      'حذف',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onError,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ReusableButton(
          text: 'تعديل السعر',
          type: ButtonType.outlined,
          prefixIcon: Icons.price_change_rounded,
          onPressed: () {
            // Bulk price change logic
          },
        ),
      ],
      rowActions: (m) => PopupMenuButton<String>(
        offset: const Offset(0, 40),
        onSelected: (v) {
          switch (v) {
            case 'edit':
              context.push('/admin/inventory/edit/${m.id}');
              break;
            case 'delete':
              ConfirmDeleteDialog.show(
                context,
                title: 'حذف صنف',
                message: 'هل أنت متأكد من حذف ${m.name}؟',
                onConfirm: () => bloc.add(DeleteMedicine(m)),
              );
              break;
          }
        },
        itemBuilder: (_) => [
          const PopupMenuItem(value: 'edit', child: ReusableText(AppStrings.edit)),
          const PopupMenuItem(value: 'delete', child: ReusableText(AppStrings.delete, color: AppColors.error)),
        ],
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(8.r),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ReusableText(
                'خيارات',
                style: TextStyle(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.bold,
                  color: scheme.primary,
                ),
              ),
              SizedBox(width: 4.w),
              Icon(Icons.more_vert_rounded, size: 14.sp, color: scheme.primary),
            ],
          ),
        ),
      ),
    );
  }
}
