import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pharmacy_system/app/core/constants/app_strings.dart';
import 'package:pharmacy_system/app/core/models/inventory/medicine_search_extension.dart';
import 'package:pharmacy_system/app/core/utils/app_snackbar.dart';

import '../../../core/widgets/index.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../bloc/medicines_bloc.dart';

class InventoryHealthView extends StatelessWidget {
  const InventoryHealthView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => MedicinesBloc(),
      child: const _InventoryHealthBody(),
    );
  }
}

class _InventoryHealthBody extends StatefulWidget {
  const _InventoryHealthBody();

  @override
  State<_InventoryHealthBody> createState() => _InventoryHealthViewState();
}

class _InventoryHealthViewState extends State<_InventoryHealthBody> {
  final TextEditingController _searchController = TextEditingController();

  int _selectedSectionIndex = 0;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<MedicineModel> _getExpiringWithin(List<MedicineModel> medicines, int days) {
    final now = DateTime.now();
    final threshold = now.add(Duration(days: days));
    return medicines.where((m) =>
    m.expiryDate != null &&
        m.expiryDate!.isAfter(now) &&
        m.expiryDate!.isBefore(threshold)
    ).toList();
  }

  List<MedicineModel> _getActiveItems(List<MedicineModel> medicines) {
    List<MedicineModel> rawList = [];
    final now = DateTime.now();

    switch (_selectedSectionIndex) {
      case 0:
        rawList = medicines.where((m) =>
        m.expiryDate != null && m.expiryDate!.isBefore(now)
        ).toList();
        break;
      case 1:
        rawList = _getExpiringWithin(medicines, 30);
        break;
      case 2:
        rawList = _getExpiringWithin(medicines, 90);
        break;
      case 3:
        rawList = medicines.where((m) =>
        m.alertEnabled && m.quantity <= m.minStock && m.quantity > 0
        ).toList();
        break;
      case 4:
        rawList = medicines.where((m) => m.quantity <= 0).toList();
        break;
    }

    return rawList.filterByNameOrBarcode(_searchController.text);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return HomeShell(
      title: AppStrings.inventoryHealthTitle,
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.15),
        padding: EdgeInsets.all(AppSpacing.xl.w),
        child: BlocBuilder<MedicinesBloc, MedicinesState>(
          builder: (context, state) {
            final medicines = state.allMedicines;
            final isLoading = state.dataState.isLoading && medicines.isEmpty;

            return LayoutBuilder(
              builder: (context, constraints) {
                final isNarrow = constraints.maxWidth < 900;

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // كروت الملخصات العلوية بتصميم انسيابي فخم
                    _buildSummaryCards(medicines, constraints.maxWidth),
                    SizedBox(height: AppSpacing.xl.h),

                    // لوحة التحكم المتجاوبة (التقسيم الجانبي ومحتوى الأدوية)
                    Expanded(
                      child: isLoading
                          ? const Center(child: LoadingIndicator())
                          : isNarrow 
                            ? Column(
                                children: [
                                  _buildNavigationRail(scheme, isHorizontal: true),
                                  SizedBox(height: AppSpacing.md.h),
                                  Expanded(
                                    child: _buildItemsContentSection(scheme, medicines),
                                  ),
                                ],
                              )
                            : Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // القائمة الجانبية للتنقل السريع بين أقسام التنبيهات
                                  _buildNavigationRail(scheme),
                                  SizedBox(width: AppSpacing.xl.w),

                                  // الجزء المخصص لعرض الأدوية والبحث والتصفية
                                  Expanded(
                                    child: _buildItemsContentSection(scheme, medicines),
                                  ),
                                ],
                              ),
                    ),
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildSummaryCards(List<MedicineModel> medicines, double maxWidth) {
    // حسابات سريعة للكروت العلوية لمنع تكرار اللوب
    final expiredCount = medicines.where((m) => m.expiryDate != null && m.expiryDate!.isBefore(DateTime.now())).length;
    final lowStockCount = medicines.where((m) => m.alertEnabled && m.quantity <= m.minStock && m.quantity > 0).length;
    final outOfStockCount = medicines.where((m) => m.quantity <= 0).length;

    final spacing = AppSpacing.lg.w;
    int itemsPerRow = 5;
    if (maxWidth < 600) {
      itemsPerRow = 1;
    } else if (maxWidth < 900) {
      itemsPerRow = 2;
    } else if (maxWidth < 1200) {
      itemsPerRow = 3;
    }

    final cardWidth = (maxWidth - (spacing * (itemsPerRow - 1))) / itemsPerRow;

    return Wrap(
      spacing: spacing,
      runSpacing: AppSpacing.md.h,
      children: [
        _SummaryCard(
          title: AppStrings.expiredItems,
          count: expiredCount,
          color: AppColors.error,
          icon: Icons.event_busy_rounded,
          isSelected: _selectedSectionIndex == 0,
          onTap: () => setState(() => _selectedSectionIndex = 0),
          width: cardWidth,
        ),
        _SummaryCard(
          title: AppStrings.expires30Days,
          count: _getExpiringWithin(medicines, 30).length,
          color: AppColors.error,
          icon: Icons.schedule_rounded,
          isSelected: _selectedSectionIndex == 1,
          onTap: () => setState(() => _selectedSectionIndex = 1),
          width: cardWidth,
        ),
        _SummaryCard(
          title: AppStrings.expires90Days,
          count: _getExpiringWithin(medicines, 90).length,
          color: AppColors.warning,
          icon: Icons.warning_amber_rounded,
          isSelected: _selectedSectionIndex == 2,
          onTap: () => setState(() => _selectedSectionIndex = 2),
          width: cardWidth,
        ),
        _SummaryCard(
          title: AppStrings.lowStockItems,
          count: lowStockCount,
          color: AppColors.warning,
          icon: Icons.trending_down_rounded,
          isSelected: _selectedSectionIndex == 3,
          onTap: () => setState(() => _selectedSectionIndex = 3),
          width: cardWidth,
        ),
        _SummaryCard(
          title: AppStrings.outOfStockItems,
          count: outOfStockCount,
          color: AppColors.error,
          icon: Icons.remove_shopping_cart_rounded,
          isSelected: _selectedSectionIndex == 4,
          onTap: () => setState(() => _selectedSectionIndex = 4),
          width: cardWidth,
        ),
      ],
    );
  }

  Widget _buildNavigationRail(ColorScheme scheme, {bool isHorizontal = false}) {
    if (isHorizontal) {
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildRailItem(0, AppStrings.expiredItemsDetailed, Icons.event_busy_rounded, AppColors.error, isHorizontal: true),
            _buildRailItem(1, AppStrings.expires30DaysDetailed, Icons.schedule_rounded, AppColors.error, isHorizontal: true),
            _buildRailItem(2, AppStrings.expires90DaysDetailed, Icons.warning_amber_rounded, AppColors.warning, isHorizontal: true),
            _buildRailItem(3, AppStrings.lowStockItemsDetailed, Icons.trending_down_rounded, AppColors.warning, isHorizontal: true),
            _buildRailItem(4, AppStrings.outOfStockItemsDetailed, Icons.remove_shopping_cart_rounded, AppColors.error, isHorizontal: true),
          ],
        ),
      );
    }

    return SizedBox(
      width: 250.w, // تظبيط العرض ليكون مريح ومناسب للنصوص العربية
      child: AppCard(
        padding: EdgeInsets.zero,
        child: ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(vertical: AppSpacing.md.h),
          children: [
          _buildRailItem(0, AppStrings.expiredItemsDetailed, Icons.event_busy_rounded, AppColors.error),
          _buildRailItem(1, AppStrings.expires30DaysDetailed, Icons.schedule_rounded, AppColors.error),
          _buildRailItem(2, AppStrings.expires90DaysDetailed, Icons.warning_amber_rounded, AppColors.warning),
          _buildRailItem(3, AppStrings.lowStockItemsDetailed, Icons.trending_down_rounded, AppColors.warning),
          _buildRailItem(4, AppStrings.outOfStockItemsDetailed, Icons.remove_shopping_cart_rounded, AppColors.error),
        ],
        ),
      ),
    );
  }

  Widget _buildRailItem(int index, String label, IconData icon, Color color, {bool isHorizontal = false}) {
    final isSelected = _selectedSectionIndex == index;
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isHorizontal ? AppSpacing.xs.w : AppSpacing.md.w, vertical: isHorizontal ? 0 : AppSpacing.xs.h),
      child: InkWell(
        onTap: () => setState(() {
          _selectedSectionIndex = index;
          _searchController.clear();
        }),
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          width: isHorizontal ? null : double.infinity,
          padding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w, vertical: isHorizontal ? AppSpacing.sm.h : AppSpacing.md.h),
          decoration: BoxDecoration(
            color: isSelected ? color.withValues(alpha: 0.06) : Colors.transparent,
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(
              color: isSelected ? color.withValues(alpha: 0.3) : Colors.transparent,
              width: 1.2,
            ),
          ),
          child: Row(
            children: [
              Icon(icon, size: 20.sp, color: isSelected ? color : scheme.onSurfaceVariant),
              SizedBox(width: AppSpacing.md.w),
              Expanded(
                child: ReusableText(
                  label,
                  style: TextStyle(
                    fontSize: 13.sp,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                    color: isSelected ? scheme.onSurface : scheme.onSurfaceVariant,
                  ),
                ),
              ),
              if (!isHorizontal)
                Icon(
                  Icons.arrow_back_ios_new_rounded,
                  size: 12.sp,
                  color: isSelected ? color : Colors.transparent,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildItemsContentSection(ColorScheme scheme, List<MedicineModel> medicines) {
    final filteredItems = _getActiveItems(medicines);

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(AppSpacing.lg.w),
            child: MedicineSearchField(
              controller: _searchController,
              customItems: medicines,
              onSelected: (m) => setState(() {
                _searchController.text = m.name;
              }),
            ),
          ),
          Divider(height: 1, color: scheme.outlineVariant.withValues(alpha: 0.4)),

          Expanded(
            child: filteredItems.isEmpty
                ? _buildEmptyState(scheme)
                : ListView.separated(
              padding: EdgeInsets.all(AppSpacing.lg.w),
              physics: const BouncingScrollPhysics(),
              itemCount: filteredItems.length,
              separatorBuilder: (_, _) => SizedBox(height: AppSpacing.sm.h),
              itemBuilder: (context, idx) {
                return _HealthItem(
                  medicine: filteredItems[idx],
                  color: _getSectionColor(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _getSectionColor() {
    if (_selectedSectionIndex == 2 || _selectedSectionIndex == 3) {
      return AppColors.warning;
    }
    return AppColors.error;
  }

  Widget _buildEmptyState(ColorScheme scheme) {
    return EmptyState(
      icon: Icons.check_circle_outline_rounded,
      title: _searchController.text.isNotEmpty ? AppStrings.noMatchingResults : AppStrings.cleanSectionMessage,
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final int count;
  final Color color;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;
  final double? width;

  const _SummaryCard({
    required this.title,
    required this.count,
    required this.color,
    required this.icon,
    required this.isSelected,
    required this.onTap,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: EdgeInsets.all(AppSpacing.lg.w),
          decoration: BoxDecoration(
            color: color.withValues(alpha: isSelected ? 0.12 : 0.03),
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(
              color: isSelected ? color : color.withValues(alpha: 0.15),
              width: isSelected ? 1.8 : 1.2,
            ),
            boxShadow: isSelected ? [
              BoxShadow(
                color: color.withValues(alpha: 0.08),
                blurRadius: 10,
                offset: const Offset(0, 4),
              )
            ] : null,
          ),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(AppSpacing.sm.w),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 22.sp, color: color),
              ),
              SizedBox(width: AppSpacing.md.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ReusableText(
                      count.toString(),
                      style: TextStyle(fontSize: 22.sp, fontWeight: FontWeight.w900, color: color),
                    ),
                    SizedBox(height: 2.h),
                    ReusableText(
                      title,
                      style: TextStyle(fontSize: 12.sp, color: color, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HealthItem extends StatelessWidget {
  final MedicineModel medicine;
  final Color color;

  const _HealthItem({
    required this.medicine,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return AppCard(
      padding: EdgeInsets.all(AppSpacing.lg.w),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(AppSpacing.md.w),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Icon(Icons.medication_rounded, size: 24.sp, color: color),
          ),
          SizedBox(width: AppSpacing.lg.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ReusableText(
                  medicine.name,
                  style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w700, color: scheme.onSurface),
                ),
                SizedBox(height: 6.h),
                Row(
                  children: [
                    Icon(Icons.inventory_2_outlined, size: 14.sp, color: scheme.onSurfaceVariant),
                    SizedBox(width: AppSpacing.xs.w),
                    ReusableText(
                      '${AppStrings.stockBalanceLabel}${medicine.quantity} ${AppStrings.unit}',
                      style: TextStyle(fontSize: 12.sp, color: scheme.onSurfaceVariant, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(width: AppSpacing.lg.w),
                    Container(width: 4, height: 4, decoration: BoxDecoration(color: scheme.outline, shape: BoxShape.circle)),
                    SizedBox(width: AppSpacing.lg.w),
                    Icon(Icons.notifications_active_outlined, size: 14.sp, color: color),
                    SizedBox(width: AppSpacing.xs.w),
                    ReusableText(
                      '${AppStrings.safetyLimitLabel}${medicine.minStock}',
                      style: TextStyle(fontSize: 12.sp, color: color, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (medicine.expiryDate != null) ...[
            Tag(
              label: '${AppStrings.expiryLabel}${medicine.expiryDate!.day}/${medicine.expiryDate!.month}/${medicine.expiryDate!.year}',
              color: color,
            ),
            SizedBox(width: AppSpacing.xl.w),
          ],
          SizedBox(
            height: 38.h,
            child: ReusableButton(
              text: AppStrings.quickPurchaseRequest,
              prefixIcon: Icons.add_shopping_cart_rounded,
              onPressed: () {
                AppSnackbar.info(AppStrings.openingShortageInvoicesFormat.replaceFirst('%s', medicine.name), title: AppStrings.advancedPurchaseRequest);
              },
              type: ButtonType.outlined,
            ),
          ),
        ],
      ),
    );
  }
}
