import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:collection/collection.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_strings.dart';
import '../../../core/widgets/index.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/models/inventory/medicine_model.dart';
import '../../../core/models/inventory/medicine_unit_model.dart';
import '../../../core/models/base/lookup_model.dart';
import '../../../core/models/supplier/supplier_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/lookup_service.dart';
import '../../../core/services/inventory/barcode_service.dart';
import '../../../core/services/supplier/supplier_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../bloc/medicines_bloc.dart';
import 'add_medicine_form_data.dart';
import 'add_medicine_unit_card.dart';

class AddMedicineView extends StatelessWidget {
  const AddMedicineView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => MedicinesBloc(),
      child: const _AddMedicineBody(),
    );
  }
}

class _AddMedicineBody extends StatelessWidget {
  const _AddMedicineBody();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return HomeShell(
      title: AppStrings.addMedicine,
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.3),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: AppSpacing.xl.w,
            vertical: AppSpacing.xl.h,
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 1000.w),
              child: const _AddMedicineForm(),
            ),
          ),
        ),
      ),
    );
  }
}

class _AddMedicineForm extends StatefulWidget {
  const _AddMedicineForm();

  @override
  State<_AddMedicineForm> createState() => _AddMedicineFormState();
}

class _AddMedicineFormState extends State<_AddMedicineForm> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _nameEnController;
  late final TextEditingController _strengthController;
  late final TextEditingController _packageSizeController;
  late final TextEditingController _descriptionController;
  late final TextEditingController _barcodeController;
  late final TextEditingController _locationController;
  late final TextEditingController _taxValueController;
  late final List<TextEditingController> _additionalBarcodeControllers;

  String? _selectedItemTypeId;
  String? _selectedGroupId;
  String? _selectedSupplierId;
  String? _selectedDosageForm;
  String? _selectedContainerShape;

  bool _appearanceSpecsEnabled = false;
  bool _alertEnabled = false;
  bool _expiryTrackingEnabled = false;
  bool _showOldPrice = false;
  bool _isTaxable = false;
  bool _pricesIncludeTax = false;
  bool _allowNegativeStock = false;
  bool _isActive = true;
  DateTime? _expiryDate;
  String? _imageUrl;
  String? _selectedTaxType;
  bool _isDirty = false;
  bool _allowPop = false;

  late final List<AddUnitFormData> _units;
  bool _isSubmitting = false;

  static const _dosageForms = [
    AppStrings.dosageFormTablets,
    AppStrings.dosageFormCapsules,
    AppStrings.dosageFormSyrup,
    AppStrings.dosageFormInjection,
    AppStrings.dosageFormCream,
    AppStrings.dosageFormDrops,
    AppStrings.dosageFormPowder,
    AppStrings.dosageFormOther,
  ];
  static const _containerShapes = [
    AppStrings.containerShapeBox,
    AppStrings.containerShapeStrip,
    AppStrings.containerShapeBottle,
    AppStrings.containerShapeTube,
    AppStrings.containerShapePlastic,
    AppStrings.containerShapeAmpoule,
    AppStrings.containerShapeOther,
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _nameEnController = TextEditingController();
    _strengthController = TextEditingController();
    _packageSizeController = TextEditingController();
    _descriptionController = TextEditingController();
    _barcodeController = TextEditingController();
    _locationController = TextEditingController();
    _taxValueController = TextEditingController();
    _additionalBarcodeControllers = [];
    _units = [AddUnitFormData(name: AppStrings.defaultUnitBox, level: 1)];
  }

  @override
  void dispose() {
    _nameController.dispose();
    _nameEnController.dispose();
    _strengthController.dispose();
    _packageSizeController.dispose();
    _descriptionController.dispose();
    _barcodeController.dispose();
    _locationController.dispose();
    _taxValueController.dispose();
    for (final c in _additionalBarcodeControllers) {
      c.dispose();
    }
    for (final u in _units) {
      u.dispose();
    }
    super.dispose();
  }

  double get _totalQuantity {
    if (_units.isEmpty) return 0;
    final mainQty = int.tryParse(_units.first.quantityController.text) ?? 0;
    var total = mainQty.toDouble();
    for (var i = 1; i < _units.length; i++) {
      final subQty = int.tryParse(_units[i].quantityController.text) ?? 0;
      final factor = double.tryParse(_units[i].factorController.text) ?? 10;
      total += subQty * factor;
    }
    return total;
  }

  double get _profitMargin {
    if (_units.isEmpty) return 0;
    final buy = double.tryParse(_units.first.buyPriceController.text) ?? 0;
    final sell = double.tryParse(_units.first.sellPriceController.text) ?? 0;
    if (buy <= 0) return 0;
    return ((sell - buy) / buy) * 100;
  }

  void _markDirty() {
    if (!_isDirty) setState(() => _isDirty = true);
  }

  Future<bool> _confirmExit() async {
    if (!_isDirty || _allowPop) return true;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => ReusableDialog(
        title: AppStrings.cancel,
        headerIcon: const Icon(Icons.warning_amber_rounded),
        children: [
          const ReusableText(AppStrings.unsavedChangesSimple),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.continueEditing,
            confirmText: AppStrings.exit,
            onCancel: () => Navigator.pop(context, false),
            onConfirm: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );
    if (confirm == true) {
      setState(() => _allowPop = true);
    }
    return confirm ?? false;
  }

  void _addBarcodeField() {
    setState(() {
      _additionalBarcodeControllers.add(TextEditingController());
      _isDirty = true;
    });
  }

  void _removeBarcodeField(int index) {
    setState(() {
      _additionalBarcodeControllers[index].dispose();
      _additionalBarcodeControllers.removeAt(index);
      _isDirty = true;
    });
  }

  Future<void> _editImageUrl() async {
    final controller = TextEditingController(text: _imageUrl ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => ReusableDialog(
        title: AppStrings.imageUrlTitle,
        children: [
          ReusableInput(
            controller: controller,
            label: AppStrings.imageUrlLabel,
            prefixIcon: const Icon(Icons.link_rounded),
            keyboardType: TextInputType.url,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancel,
            confirmText: AppStrings.confirmSave,
            onCancel: () => Navigator.pop(ctx),
            onConfirm: () => Navigator.pop(ctx, controller.text.trim()),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() {
        _imageUrl = result.isEmpty ? null : result;
        _isDirty = true;
      });
    }
    controller.dispose();
  }

  void _removeImage() {
    setState(() {
      _imageUrl = null;
      _isDirty = true;
    });
  }

  void _showAddLookupDialog(BuildContext context, LookupType type) async {
    final nameController = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => ReusableDialog(
        title: type == LookupType.itemType
            ? AppStrings.addNewItemType
            : AppStrings.addNewGroup,
        children: [
          ReusableInput(
            controller: nameController,
            label: AppStrings.newNameLabel,
            autofocus: true,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancel,
            confirmText: AppStrings.confirmSave,
            onCancel: () => Navigator.pop(ctx),
            onConfirm: () => Navigator.pop(ctx, nameController.text.trim()),
          ),
        ],
      ),
    );
    nameController.dispose();
    if (result != null && result.isNotEmpty) {
      final lookup = await LookupService.addByName(name: result, type: type);
      setState(() {
        _isDirty = true;
        if (type == LookupType.itemType) {
          _selectedItemTypeId = lookup.id;
        } else {
          _selectedGroupId = lookup.id;
        }
      });
    }
  }

  void _showAddSupplierDialog() async {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    SupplierType selectedType = SupplierType.supplier;
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => ReusableDialog(
          title: AppStrings.addNewApprovedSupplier,
          children: [
            ReusableInput(
              controller: nameController,
              label: AppStrings.companyOrSupplierNameRequired,
              prefixIcon: const Icon(Icons.business_rounded),
              autofocus: true,
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput(
              controller: phoneController,
              label: AppStrings.phone,
              prefixIcon: const Icon(Icons.phone_rounded),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<SupplierType>(
              hintText: AppStrings.supplyType,
              items: SupplierType.values,
              value: selectedType,
              itemAsString: (t) =>
                  t == SupplierType.supplier ? AppStrings.supplierOnly : AppStrings.customerSupplierJoint,
              onChanged: (v) {
                if (v != null) setDialogState(() => selectedType = v);
              },
            ),
            SizedBox(height: 16.h),
            DialogActions(
              cancelText: AppStrings.cancelAction,
              confirmText: AppStrings.saveSupplier,
              onCancel: () => Navigator.pop(ctx, false),
              onConfirm: () => Navigator.pop(ctx, true),
            ),
          ],
        ),
      ),
    );
    if (result == true && nameController.text.trim().isNotEmpty) {
      final supplier = await SupplierService.add(
        name: nameController.text.trim(),
        type: selectedType,
        phone: phoneController.text.trim().isEmpty
            ? null
            : phoneController.text.trim(),
      );
      setState(() {
        _selectedSupplierId = supplier.id;
        _isDirty = true;
      });
    }
    nameController.dispose();
    phoneController.dispose();
  }

  void _addUnit() {
    final level = _units.length + 1;
    setState(() {
      _units.add(
        AddUnitFormData(
          name: level == 2
              ? AppStrings.defaultUnitStrip
              : level == 3
              ? AppStrings.defaultUnitPill
              : '${AppStrings.unitLevelPrefix}$level',
          level: level,
        ),
      );
      _isDirty = true;
    });
  }

  void _removeUnit(int index) {
    if (index <= 0 || index >= _units.length) return;
    setState(() {
      _units[index].dispose();
      _units.removeAt(index);
      _isDirty = true;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);

    var primaryBarcode = _barcodeController.text.trim();
    if (primaryBarcode.isEmpty) {
      primaryBarcode = BarcodeService.generate();
      _barcodeController.text = primaryBarcode;
    }

    if (BarcodeService.isBarcodeTaken(primaryBarcode)) {
      setState(() => _isSubmitting = false);
      AppSnackbar.error(
        AppStrings.barcodeTakenError,
        title: AppStrings.inventorySystemSecurity,
      );
      return;
    }

    final barcodes = [primaryBarcode];
    for (final c in _additionalBarcodeControllers) {
      final code = c.text.trim();
      if (code.isNotEmpty && !barcodes.contains(code)) barcodes.add(code);
    }
    final units = _units.asMap().entries.map((entry) {
      final i = entry.key;
      final u = entry.value;
      return MedicineUnitModel(
        id: 'unit_${i + 1}',
        name: u.nameController.text.trim().isNotEmpty
            ? u.nameController.text.trim()
            : (i == 0 ? AppStrings.defaultUnitBox : '${AppStrings.unitLevelPrefix}${i + 1}'),
        level: u.level,
        conversionFactor: i == 0
            ? 1
            : (double.tryParse(u.factorController.text) ?? 10),
        buyPrice: double.tryParse(u.buyPriceController.text) ?? 0,
        sellPrice: double.tryParse(u.sellPriceController.text) ?? 0,
        oldSellPrice: _showOldPrice
            ? (double.tryParse(u.oldPriceController.text))
            : null,
        discountPercent: double.tryParse(u.discountController.text),
        quantity: int.tryParse(u.quantityController.text) ?? 0,
        allowSale: u.allowSale,
      );
    }).toList();

    final mainUnit = units.isNotEmpty ? units.first : null;
    final location = _locationController.text.trim();
    final taxValue = double.tryParse(_taxValueController.text);
    final medicine = MedicineModel(
      id: '${DateTime.now().millisecondsSinceEpoch}_med',
      name: _nameController.text.trim(),
      nameEn: _nameEnController.text.trim().isEmpty
          ? null
          : _nameEnController.text.trim(),
      itemTypeId: _selectedItemTypeId,
      groupId: _selectedGroupId,
      category: LookupService.getNameById(_selectedItemTypeId),
      barcodes: barcodes,
      buyPrice: mainUnit?.buyPrice ?? 0,
      sellPrice: mainUnit?.sellPrice ?? 0,
      oldSellPrice: _showOldPrice ? mainUnit?.oldSellPrice : null,
      quantity: _totalQuantity.toInt(),
      minStock: _alertEnabled
          ? (int.tryParse(_units.first.minStockController.text) ?? 10)
          : 0,
      alertEnabled: _alertEnabled,
      expiryTrackingEnabled: _expiryTrackingEnabled,
      expiryDate: _expiryTrackingEnabled ? _expiryDate : null,
      dosageFormEnabled: _appearanceSpecsEnabled,
      dosageForm: _appearanceSpecsEnabled ? _selectedDosageForm : null,
      strength: _strengthController.text.trim().isEmpty
          ? null
          : _strengthController.text.trim(),
      packageSize: _packageSizeController.text.trim().isEmpty
          ? null
          : _packageSizeController.text.trim(),
      supplierName: _selectedSupplierId,
      description: _descriptionController.text.trim().isEmpty
          ? null
          : _descriptionController.text.trim(),
      imageUrl: _imageUrl,
      containerShape: _appearanceSpecsEnabled ? _selectedContainerShape : null,
      branchId: AuthService.currentBranchId ?? '',
      units: units,
      location: location.isNotEmpty ? location : null,
      isTaxable: _isTaxable,
      taxType: _isTaxable ? _selectedTaxType : null,
      taxValue: _isTaxable && taxValue != null ? taxValue : null,
      pricesIncludeTax: _pricesIncludeTax,
      allowNegativeStock: _allowNegativeStock,
      isActive: _isActive,
    );

    if (!mounted) return;
    final bloc = context.read<MedicinesBloc>();
    if (bloc.isClosed) return;
    bloc.add(AddMedicine(medicine));

    setState(() {
      _isSubmitting = false;
      _allowPop = true;
    });
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isDirty || _allowPop,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop) {
          final shouldPop = await _confirmExit();
          if (shouldPop && context.mounted) {
            context.pop();
          }
        }
      },
      child: Form(
        key: _formKey,
        onChanged: _markDirty,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBasicInfoCard(),
            SizedBox(height: AppSpacing.lg.h),
            _buildBarcodeAndClassificationCard(),
            SizedBox(height: AppSpacing.lg.h),
            _buildPricingAndUnitsCard(),
            SizedBox(height: AppSpacing.lg.h),
            _buildTaxAndAdvancedCard(),
            SizedBox(height: AppSpacing.lg.h),
            _buildInventoryControlCard(),
            SizedBox(height: AppSpacing.xl.h),
            _buildActionButtons(),
            SizedBox(height: AppSpacing.xl.h),
          ],
        ),
      ),
    );
  }

  // ════════════════ PART 1: التعريف والبيانات الأساسية ════════════════
  Widget _buildBasicInfoCard() {
    final scheme = Theme.of(context).colorScheme;
    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.basicInfo,
            icon: Icons.assignment_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),

          _buildResponsiveGrid(
            children: [
              ReusableInput(
                controller: _nameController,
                label: AppStrings.medicineNameAr,
                prefixIcon: Icon(
                  Icons.medication_rounded,
                  size: 18.sp,
                  color: scheme.primary,
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? AppStrings.medicineNameArRequired
                    : null,
              ),
              ReusableInput(
                controller: _nameEnController,
                label: AppStrings.medicineNameEn,
                prefixIcon: Icon(Icons.font_download_outlined, size: 18.sp),
              ),
            ],
          ),

          SizedBox(height: AppSpacing.lg.h),

          // قسم الصورة بتنسيق عصري ومدمج
          Container(
            padding: EdgeInsets.all(AppSpacing.md.w),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerLowest,
              borderRadius: BorderRadius.circular(AppRadius.md.r),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.15)),
            ),
            child: Row(
              children: [
                ReusableItemImage(
                  imageUrl: _imageUrl,
                  size: 56,
                  borderRadius: 12,
                ),
                SizedBox(width: AppSpacing.md.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ReusableText(
                        AppStrings.itemVisualImageOptional,
                        style: TextStyle(
                          fontSize: 12.5.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      ReusableText(
                        _imageUrl != null && _imageUrl!.isNotEmpty
                            ? _imageUrl!
                            : AppStrings.imageUploadHint,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11.sp,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  icon: Icon(Icons.link_outlined, size: 20.sp),
                  onPressed: _editImageUrl,
                  tooltip: 'إضافة رابط خارجي',
                ),
                if (_imageUrl != null && _imageUrl!.isNotEmpty) ...[
                  SizedBox(width: 8.w),
                  IconButton(
                    icon: Icon(Icons.delete_outline_rounded, color: AppColors.error, size: 20.sp),
                    onPressed: _removeImage,
                  ),
                ],
              ],
            ),
          ),

          SizedBox(height: AppSpacing.lg.h),

          _buildToggleCardTile(
            label: AppStrings.extraOptionsToggle,
            value: _appearanceSpecsEnabled,
            icon: Icons.auto_awesome,
            onChanged: (v) => setState(() => _appearanceSpecsEnabled = v),
          ),

          if (_appearanceSpecsEnabled) ...[
            SizedBox(height: AppSpacing.lg.h),
            _buildResponsiveGrid(
              children: [
                ReusableInput(
                  controller: _strengthController,
                  label: AppStrings.strength,
                  prefixIcon: const Icon(Icons.biotech_rounded),
                ),
                ReusableInput(
                  controller: _packageSizeController,
                  label: AppStrings.packageSize,
                  prefixIcon: const Icon(Icons.inventory_2_outlined),
                ),
                ReusableDropdown<String>(
                  hintText: AppStrings.dosageFormHint,
                  labelText: AppStrings.dosageFormLabel,
                  items: _dosageForms,
                  value: _selectedDosageForm,
                  itemAsString: (v) => v,
                  onChanged: (v) => setState(() => _selectedDosageForm = v),
                ),
                ReusableDropdown<String>(
                  hintText: AppStrings.containerShapeHint,
                  labelText: AppStrings.containerShapeLabel,
                  items: _containerShapes,
                  value: _selectedContainerShape,
                  itemAsString: (v) => v,
                  onChanged: (v) => setState(() => _selectedContainerShape = v),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.lg.h),
            ReusableInput(
              controller: _locationController,
              label: AppStrings.storageLocation,
              prefixIcon: Icon(
                Icons.location_on_outlined,
                size: 18.sp,
                color: scheme.primary,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ════════════════ PART 2: التصنيف والباركود الذكي ════════════════
  Widget _buildBarcodeAndClassificationCard() {
    final scheme = Theme.of(context).colorScheme;
    final itemTypes = LookupService.getAll(type: LookupType.itemType);
    final groups = LookupService.getAll(type: LookupType.group);

    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.classificationAndBarcode,
            icon: Icons.qr_code_scanner_rounded,
          ),
          SizedBox(height: AppSpacing.xl.h),

          _buildResponsiveGrid(
            children: [
              _buildDropdownWithAdd(
                label: AppStrings.itemTypeLabel,
                items: itemTypes,
                value: _selectedItemTypeId,
                onChanged: (v) => setState(() => _selectedItemTypeId = v),
                onAdd: () => _showAddLookupDialog(context, LookupType.itemType),
              ),
              _buildDropdownWithAdd(
                label: AppStrings.groupLabel,
                items: groups,
                value: _selectedGroupId,
                onChanged: (v) => setState(() => _selectedGroupId = v),
                onAdd: () => _showAddLookupDialog(context, LookupType.group),
              ),
            ],
          ),

          SizedBox(height: AppSpacing.lg.h),
          _buildSupplierDropdownSection(),
          SizedBox(height: AppSpacing.xl.h),

          const ReusableText(
            'أكواد التعريف (الباركود)',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          ),
          SizedBox(height: AppSpacing.md.h),

          ReusableInput(
            controller: _barcodeController,
            label: AppStrings.barcodeMainLabel,
            prefixIcon: Icon(
              Icons.qr_code_2_rounded,
              size: 20.sp,
              color: scheme.primary,
            ),
            suffixIcon: IconButton(
              tooltip: AppStrings.generateBarcodeTooltip,
              icon: Icon(
                Icons.autorenew_rounded,
                color: scheme.primary,
                size: 20.sp,
              ),
              onPressed: () {
                final generated = BarcodeService.generate();
                _barcodeController.text = generated;
                _markDirty();
                AppSnackbar.success(
                  '${AppStrings.barcodeGeneratedSuccess}$generated',
                  title: AppStrings.generateBarcode,
                );
              },
            ),
            inputFormatters: [LengthLimitingTextInputFormatter(32)],
          ),

          if (_additionalBarcodeControllers.isNotEmpty) ...[
            SizedBox(height: AppSpacing.md.h),
            ..._additionalBarcodeControllers.asMap().entries.map((entry) {
              return Padding(
                padding: EdgeInsets.only(bottom: AppSpacing.md.h),
                child: ReusableInput(
                  controller: entry.value,
                  label: '${AppStrings.extraBarcodePrefix}${entry.key + 2}',
                  prefixIcon: Icon(
                    Icons.view_week_rounded,
                    size: 20.sp,
                    color: scheme.primary,
                  ),
                  inputFormatters: [LengthLimitingTextInputFormatter(32)],
                  suffixIcon: IconButton(
                    icon: Icon(
                      Icons.remove_circle_outline_rounded,
                      size: 18.sp,
                      color: AppColors.error,
                    ),
                    onPressed: () => _removeBarcodeField(entry.key),
                  ),
                ),
              );
            }),
          ],

          SizedBox(height: AppSpacing.xs.h),
          TextButton.icon(
            onPressed: _addBarcodeField,
            icon: const Icon(Icons.add_circle_outline_rounded),
            label: ReusableText(
              '${AppStrings.addExtraBarcodePrefix}${_additionalBarcodeControllers.length + 2}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Helpers للشبكة والتصميم المنظم ───

  Widget _buildResponsiveGrid({required List<Widget> children, int crossAxisCount = 2}) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth < 600) {
        return Column(
          children: children.expand((w) => [w, SizedBox(height: AppSpacing.lg.h)]).toList()..removeLast(),
        );
      }
      return Wrap(
        spacing: AppSpacing.lg.w,
        runSpacing: AppSpacing.lg.h,
        children: children.map((w) => SizedBox(
          width: (constraints.maxWidth - AppSpacing.lg.w) / crossAxisCount,
          child: w,
        )).toList(),
      );
    });
  }

  Widget _buildDropdownWithAdd({
    required String label,
    required List<LookupModel> items,
    required String? value,
    required ValueChanged<String?> onChanged,
    required VoidCallback onAdd,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: ReusableDropdown<LookupModel>(
            labelText: label,
            hintText: AppStrings.searchHint,
            items: items,
            value: items.firstWhereOrNull((l) => l.id == value),
            itemAsString: (l) => l.name,
            onChanged: (v) => onChanged(v?.id),
          ),
        ),
        SizedBox(width: AppSpacing.xs.w),
        IconButton.filledTonal(
          onPressed: onAdd,
          icon: const Icon(Icons.add_rounded),
          style: IconButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppRadius.md.r),
            ),
            minimumSize: Size(46.w, 46.h),
          ),
        ),
      ],
    );
  }

  Widget _buildSupplierDropdownSection() {
    final suppliers = SupplierService.getAll();
    return _buildResponsiveGrid(
      crossAxisCount: 1, // المورد بياخد العرض كامل أو نخليه جزء من الشبكة؟ الأفضل كامل عشان الاسم بيبقى طويل
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: ReusableDropdown<SupplierModel>(
                labelText: AppStrings.supplierLabel,
                hintText: AppStrings.supplierHint,
                items: suppliers,
                value: suppliers.firstWhereOrNull((s) => s.id == _selectedSupplierId),
                itemAsString: (s) => '${s.name} — [${s.typeName}]',
                onChanged: (v) => setState(() => _selectedSupplierId = v?.id),
              ),
            ),
            SizedBox(width: AppSpacing.xs.w),
            IconButton.filledTonal(
              onPressed: _showAddSupplierDialog,
              icon: const Icon(Icons.person_add_alt_1_rounded),
              style: IconButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.md.r),
                ),
                minimumSize: Size(46.w, 46.h),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ════════════════ PART 3: التسعير والوحدات ════════════════
  Widget _buildPricingAndUnitsCard() {
    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.pricingAndUnitsAdd,
            icon: Icons.monetization_on_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),
          _buildToggleCardTile(
            label: AppStrings.dualPricingToggle,
            value: _showOldPrice,
            icon: Icons.swap_horizontal_circle_outlined,
            onChanged: (v) => setState(() => _showOldPrice = v),
          ),
          SizedBox(height: AppSpacing.xl.h),
          ..._units.asMap().entries.map((entry) {
            return AddUnitCard(
              data: entry.value,
              index: entry.key,
              showOldPrice: _showOldPrice,
              canDelete: entry.key > 0 && entry.key == _units.length - 1,
              onDelete: () => _removeUnit(entry.key),
              onPriceChanged: () => setState(() {}),
            );
          }),
          SizedBox(height: AppSpacing.md.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (_units.isNotEmpty)
                ReusableButton(
                  text: _units.length == 1
                      ? AppStrings.addSubUnitSimple
                      : AppStrings.addSubSubUnit,
                  prefixIcon: Icons.playlist_add_rounded,
                  type: ButtonType.outlined,
                  onPressed: _addUnit,
                ),
              if (_units.isNotEmpty &&
                  _units.first.buyPriceController.text.isNotEmpty &&
                  _units.first.sellPriceController.text.isNotEmpty)
                _buildCleanProfitBadge(),
            ],
          ),
        ],
      ),
    );
  }

  // ════════════════ PART 4: الضرائب والإعدادات المتقدمة ════════════════
  Widget _buildTaxAndAdvancedCard() {
    return FormCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(
            title: AppStrings.taxAndAdvancedSimple,
            icon: Icons.tune_rounded,
          ),
          SizedBox(height: AppSpacing.xl.h),
          _buildResponsiveGrid(
            children: [
              _buildToggleTile(
                label: AppStrings.isTaxableSimple,
                value: _isTaxable,
                icon: Icons.receipt_long_rounded,
                onChanged: (v) => setState(() {
                  _isTaxable = v;
                  if (!v) {
                    _taxValueController.clear();
                    _selectedTaxType = null;
                    _pricesIncludeTax = false;
                  }
                  _isDirty = true;
                }),
              ),
              _buildToggleTile(
                label: AppStrings.allowNegativeStockSimple,
                value: _allowNegativeStock,
                icon: Icons.unpublished_rounded,
                onChanged: (v) => setState(() {
                  _allowNegativeStock = v;
                  _isDirty = true;
                }),
              ),
            ],
          ),
          if (_isTaxable) ...[
            SizedBox(height: AppSpacing.lg.h),
            _buildResponsiveGrid(
              children: [
                ReusableDropdown<String>(
                  hintText: AppStrings.taxType,
                  labelText: AppStrings.taxType,
                  items: const ['percentage', 'fixed'],
                  value: _selectedTaxType,
                  itemAsString: (v) =>
                      v == 'percentage' ? AppStrings.cartDiscountPercent : AppStrings.cartDiscountFixed,
                  onChanged: (v) => setState(() {
                    _selectedTaxType = v;
                    _taxValueController.clear();
                    _isDirty = true;
                  }),
                ),
                ReusableInput(
                  controller: _taxValueController,
                  label: _selectedTaxType == 'percentage'
                      ? AppStrings.taxPercentage
                      : AppStrings.fixedTax,
                  prefixIcon: const Icon(Icons.monetization_on_outlined),
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  onChanged: (_) => setState(() => _isDirty = true),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.md.h),
            _buildToggleTile(
              label: AppStrings.pricesIncludeTaxSimple,
              value: _pricesIncludeTax,
              icon: Icons.price_check_rounded,
              onChanged: (v) => setState(() {
                _pricesIncludeTax = v;
                _isDirty = true;
              }),
            ),
          ],
          SizedBox(height: AppSpacing.md.h),
          _buildToggleTile(
            label: AppStrings.isActiveLabel,
            value: _isActive,
            icon: Icons.toggle_on_rounded,
            onChanged: (v) => setState(() {
              _isActive = v;
              _isDirty = true;
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleTile({
    required String label,
    required bool value,
    required IconData icon,
    required ValueChanged<bool> onChanged,
  }) {
    return SettingsToggleTile(
      icon: icon,
      title: label,
      value: value,
      onChanged: onChanged,
    );
  }

  // ════════════════ PART 5: أمان ومراقبة المخزون ════════════════
  Widget _buildInventoryControlCard() {
    return FormCard(
      child: Column(
        children: [
          const SectionHeader(
            title: AppStrings.inventorySecurityAdd,
            icon: Icons.shield_outlined,
          ),
          SizedBox(height: AppSpacing.xl.h),
          _buildResponsiveGrid(
            children: [
              Column(
                children: [
                  _buildToggleCardTile(
                    label: AppStrings.lowStockAlertOptional,
                    value: _alertEnabled,
                    icon: Icons.notifications_none_rounded,
                    onChanged: (v) => setState(() => _alertEnabled = v),
                  ),
                  if (_alertEnabled) ...[
                    SizedBox(height: AppSpacing.lg.h),
                    ReusableInput(
                      controller: _units.first.minStockController,
                      label: AppStrings.minStockLimitSimple,
                      prefixIcon: const Icon(Icons.report_problem_outlined),
                      keyboardType: TextInputType.number,
                    ),
                  ],
                ],
              ),
              Column(
                children: [
                  _buildToggleCardTile(
                    label: AppStrings.expiryTrackingOptional,
                    value: _expiryTrackingEnabled,
                    icon: Icons.calendar_today_outlined,
                    onChanged: (v) =>
                        setState(() => _expiryTrackingEnabled = v),
                  ),
                  if (_expiryTrackingEnabled) ...[
                    SizedBox(height: AppSpacing.lg.h),
                    _buildPremiumDateField(
                      label: AppStrings.currentExpiryDateAdd,
                      date: _expiryDate,
                      onTap: () => _pickDate(),
                      onClear: () => setState(() => _expiryDate = null),
                    ),
                  ],
                ],
              ),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          ReusableInput(
            controller: _descriptionController,
            label: AppStrings.notesAndFormulasAdd,
            prefixIcon: const Icon(Icons.edit_note_rounded),
            maxLines: 2,
          ),
        ],
      ),
    );
  }

  // ════════════════ PART 6: أزرار التحكم والتحميل الأساسية ════════════════
  Widget _buildActionButtons() {
    final scheme = Theme.of(context).colorScheme;
    return Wrap(
      spacing: AppSpacing.xl.w,
      runSpacing: AppSpacing.md.h,
      alignment: WrapAlignment.end,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        ReusableButton(
          text: AppStrings.cancelAndBack,
          onPressed: () => context.pop(),
          type: ButtonType.outlined,
        ),
        SizedBox(
          width: 300.w,
          child: Container(
            height: 46.h,
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: scheme.primary.withValues(alpha: 0.15),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ReusableButton(
              text: _isSubmitting
                  ? AppStrings.submittingMedicine
                  : AppStrings.saveMedicineFull,
              onPressed: _isSubmitting ? null : _submit,
              prefixIcon: Icons.check_circle_rounded,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildToggleCardTile({
    required String label,
    required bool value,
    required IconData icon,
    required ValueChanged<bool> onChanged,
  }) {
    return SettingsToggleTile(
      icon: icon,
      title: label,
      value: value,
      onChanged: onChanged,
    );
  }

  Widget _buildPremiumDateField({
    required String label,
    required DateTime? date,
    required VoidCallback onTap,
    required VoidCallback onClear,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w),
        height: 44.h,
        decoration: BoxDecoration(
          color: scheme.surfaceContainerLowest,
          border: Border.all(color: scheme.outline),
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        child: Row(
          children: [
            Icon(
              Icons.edit_calendar_rounded,
              size: 18.sp,
              color: scheme.primary,
            ),
            SizedBox(width: AppSpacing.sm.w),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ReusableText(
                    label,
                    style: TextStyle(
                      fontSize: 10.sp,
                      color: scheme.onSurfaceVariant,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ReusableText(
                    date != null
                        ? '${date.day} / ${date.month} / ${date.year}'
                        : AppStrings.datePickerHint,
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: date != null
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
            if (date != null)
              InkWell(
                onTap: () {
                  onClear();
                  _markDirty();
                },
                child: Icon(
                  Icons.cancel_rounded,
                  size: 18.sp,
                  color: AppColors.error,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCleanProfitBadge() {
    final color = _profitMargin >= 0 ? AppColors.success : AppColors.error;
    return StatusBadge(
      label:
          '${AppStrings.profitMarginSimplePrefix}${_profitMargin.toStringAsFixed(1)}%',
      color: color,
      icon: _profitMargin >= 0
          ? Icons.trending_up_rounded
          : Icons.trending_down_rounded,
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _expiryDate ?? now.add(const Duration(days: 365)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 365 * 10)),
    );
    if (picked != null) {
      setState(() {
        _expiryDate = picked;
        _isDirty = true;
      });
    }
  }
}