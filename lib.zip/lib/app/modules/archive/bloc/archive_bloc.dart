import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';

import '../../../core/models/archive/archive_record_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../services/archive_service.dart';
import 'archive_event.dart';
import 'archive_state.dart';

export 'archive_event.dart';
export 'archive_state.dart';

class ArchiveBloc extends Bloc<ArchiveEvent, ArchiveState> {
  ArchiveBloc() : super(const ArchiveState()) {
    on<LoadArchive>(_onLoad);
    on<ChangeArchiveEntityType>(_onChangeType);
    on<SearchArchive>(_onSearch);
    on<NextArchivePage>(_onNextPage);
    on<PreviousArchivePage>(_onPreviousPage);
    on<RestoreArchiveItem>(_onRestore);
    on<PermanentDeleteArchiveItem>(_onPermanentDelete);

    Hive.box<ArchiveRecordModel>('archive_records').watch().listen((_) {
      if (!isClosed) add(const LoadArchive());
    });
  }

  bool get canManage => AuthService.currentUser?.isOwner ?? false;

  void _onLoad(LoadArchive event, Emitter<ArchiveState> emit) {
    emit(state.copyWith(status: ArchiveStatus.loading));
    try {
      _applyFilter(emit);
    } on Object catch (e) {
      emit(state.copyWith(status: ArchiveStatus.error, error: e.toString()));
    }
  }

  void _onChangeType(ChangeArchiveEntityType event, Emitter<ArchiveState> emit) {
    emit(state.copyWith(
      selectedType: event.entityType,
      currentPage: 1,
      query: '',
    ));
    _applyFilter(emit);
  }

  void _onSearch(SearchArchive event, Emitter<ArchiveState> emit) {
    emit(state.copyWith(query: event.query, currentPage: 1));
    _applyFilter(emit);
  }

  void _onNextPage(NextArchivePage event, Emitter<ArchiveState> emit) {
    if (!state.hasNextPage) return;
    emit(state.copyWith(currentPage: state.currentPage + 1));
    _applyFilter(emit);
  }

  void _onPreviousPage(PreviousArchivePage event, Emitter<ArchiveState> emit) {
    if (!state.hasPreviousPage) return;
    emit(state.copyWith(currentPage: state.currentPage - 1));
    _applyFilter(emit);
  }

  void _applyFilter(Emitter<ArchiveState> emit) {
    final query = state.query.trim();
    final type = state.selectedType;
    final page = state.currentPage;
    final pageSize = state.pageSize;

    List<ArchiveRecordModel> records;
    int total;

    if (query.isNotEmpty) {
      records = ArchiveService.search(
        query: query,
        entityType: type,
        page: page,
        pageSize: pageSize,
      );
      total = ArchiveService.searchCount(
        query: query,
        entityType: type,
      );
    } else {
      records = ArchiveService.getAll(
        entityType: type,
        page: page,
        pageSize: pageSize,
      );
      total = ArchiveService.count(entityType: type);
    }

    emit(state.copyWith(
      status: ArchiveStatus.loaded,
      records: records,
      totalRecords: total,
    ));
  }

  Future<void> _onRestore(RestoreArchiveItem event, Emitter<ArchiveState> emit) async {
    emit(state.copyWith(isWorking: true));
    try {
      final success = await ArchiveService.restore(event.recordId, modifiedData: event.modifiedData);
      if (success) {
        add(const LoadArchive());
      }
    } finally {
      emit(state.copyWith(isWorking: false));
    }
  }

  Future<void> _onPermanentDelete(PermanentDeleteArchiveItem event, Emitter<ArchiveState> emit) async {
    emit(state.copyWith(isWorking: true));
    try {
      final success = await ArchiveService.permanentDelete(event.recordId);
      if (success) {
        add(const LoadArchive());
      }
    } finally {
      emit(state.copyWith(isWorking: false));
    }
  }
}
