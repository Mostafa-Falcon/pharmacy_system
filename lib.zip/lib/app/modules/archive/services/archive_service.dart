import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

import '../../../core/models/archive/archive_record_model.dart';
import '../../../core/services/sync_service.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/utils/app_utils.dart';

class ArchiveService {
  static Box<ArchiveRecordModel> get _box => Hive.box<ArchiveRecordModel>('archive_records');
  static const _uuid = Uuid();

  static Future<void> record({
    required String entityType,
    required String entityId,
    required String entityName,
    required Map<String, dynamic> entityData,
    String? deletedBy,
    String? deletedByName,
    String? branchId,
  }) async {
    try {
      final record = ArchiveRecordModel(
        id: _uuid.v4(),
        entityType: archiveEntityTypeFromString(entityType) ?? ArchiveEntityType.medicine,
        entityId: entityId,
        entityName: entityName,
        entityData: entityData,
        deletedBy: deletedBy ?? AuthService.currentUser?.id ?? '',
        deletedByName: deletedByName ?? AuthService.currentUser?.name ?? '',
        deletedAt: DateTime.now(),
        branchId: branchId ?? AuthService.currentBranchId ?? '',
      );

      await SyncService.create(
        boxName: 'archive_records',
        entity: record,
        branchId: record.branchId,
        toJson: record.toJson(),
      );
    } catch (e, s) {
      safeDebugPrint('ArchiveService.record failed: $e\n$s');
    }
  }

  static List<ArchiveRecordModel> getAll({
    ArchiveEntityType? entityType,
    bool activeOnly = true,
    int page = 1,
    int pageSize = 50,
  }) {
    var items = _box.values.toList();

    if (entityType != null) {
      items = items.where((r) => r.entityType == entityType).toList();
    }

    if (activeOnly) {
      items = items.where((r) => r.isActive).toList();
    }

    items.sort((a, b) => b.deletedAt.compareTo(a.deletedAt));

    final start = (page - 1) * pageSize;
    if (start >= items.length) return [];
    final end = start + pageSize;
    return items.sublist(start, end > items.length ? items.length : end);
  }

  static int count({
    ArchiveEntityType? entityType,
    bool activeOnly = true,
  }) {
    var items = _box.values.toList();

    if (entityType != null) {
      items = items.where((r) => r.entityType == entityType).toList();
    }

    if (activeOnly) {
      items = items.where((r) => r.isActive).toList();
    }

    return items.length;
  }

  static List<ArchiveRecordModel> search({
    required String query,
    ArchiveEntityType? entityType,
    bool activeOnly = true,
    int page = 1,
    int pageSize = 50,
  }) {
    final q = query.toLowerCase().trim();
    if (q.isEmpty) return getAll(entityType: entityType, activeOnly: activeOnly, page: page, pageSize: pageSize);

    var items = _box.values.toList();

    if (entityType != null) {
      items = items.where((r) => r.entityType == entityType).toList();
    }

    if (activeOnly) {
      items = items.where((r) => r.isActive).toList();
    }

    items = items.where((r) =>
      r.entityName.toLowerCase().contains(q) ||
      r.deletedByName.toLowerCase().contains(q) ||
      r.entityId.toLowerCase().contains(q)
    ).toList();

    items.sort((a, b) => b.deletedAt.compareTo(a.deletedAt));

    final start = (page - 1) * pageSize;
    if (start >= items.length) return [];
    final end = start + pageSize;
    return items.sublist(start, end > items.length ? items.length : end);
  }

  static int searchCount({
    required String query,
    ArchiveEntityType? entityType,
    bool activeOnly = true,
  }) {
    final q = query.toLowerCase().trim();
    if (q.isEmpty) return count(entityType: entityType, activeOnly: activeOnly);

    var items = _box.values.toList();

    if (entityType != null) {
      items = items.where((r) => r.entityType == entityType).toList();
    }

    if (activeOnly) {
      items = items.where((r) => r.isActive).toList();
    }

    return items.where((r) =>
      r.entityName.toLowerCase().contains(q) ||
      r.deletedByName.toLowerCase().contains(q) ||
      r.entityId.toLowerCase().contains(q)
    ).length;
  }

  static ArchiveRecordModel? getById(String id) {
    return _box.get(id);
  }

  static Future<bool> restore(String recordId, {Map<String, dynamic>? modifiedData}) async {
    try {
      final record = _box.get(recordId);
      if (record == null || !record.isActive) return false;

      final updated = record.copyWith(
        restoredAt: DateTime.now().toIso8601String(),
        restoredBy: AuthService.currentUser?.id ?? '',
      );

      await SyncService.update(
        boxName: 'archive_records',
        entity: updated,
        branchId: record.branchId,
        toJson: updated.toJson(),
      );

      return true;
    } catch (e, s) {
      safeDebugPrint('ArchiveService.restore failed: $e\n$s');
      return false;
    }
  }

  static Future<bool> permanentDelete(String recordId) async {
    try {
      final record = _box.get(recordId);
      if (record == null || !record.isActive) return false;

      final updated = record.copyWith(
        permanentlyDeletedAt: DateTime.now().toIso8601String(),
      );

      await SyncService.update(
        boxName: 'archive_records',
        entity: updated,
        branchId: record.branchId,
        toJson: updated.toJson(),
      );

      return true;
    } catch (e, s) {
      safeDebugPrint('ArchiveService.permanentDelete failed: $e\n$s');
      return false;
    }
  }
}
