import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import 'package:get_it/get_it.dart';
import '../models/permission_catalog.dart';
import '../models/role_definition_model.dart';
import '../models/pharmacy_member_model.dart';
import '../models/audit_log_model.dart';
import '../../../core/models/security/branch_model.dart';
import '../../../core/services/sync_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/auth/auth_service.dart';

class AdminService {
  static final AdminService _instance = AdminService._internal();
  factory AdminService() => _instance;
  AdminService._internal();

  static AdminService get to => GetIt.instance<AdminService>();
  final _uuid = const Uuid();

  // ─── Branches ───

  Future<List<BranchModel>> getBranches() async {
    final box = Hive.box('branches');
    return box.values.whereType<BranchModel>().toList();
  }

  Future<BranchModel> createBranch({
    required String name,
    String? address,
    String? phone,
  }) async {
    final branch = BranchModel(
      id: _uuid.v4(),
      name: name.trim(),
      address: address?.trim(),
      phone: phone?.trim(),
      createdAt: DateTime.now(),
    );
    final box = Hive.box('branches');
    await box.putSynced(branch.id, branch, table: 'branches', branchId: branch.id);
    await SyncService.create(
      boxName: 'branches',
      entity: branch,
      branchId: branch.id,
      toJson: branch.toJson(),
    );
    return branch;
  }

  Future<void> updateBranch(String id,
      {String? name, String? address, String? phone}) async {
    final box = Hive.box('branches');
    final branch = box.get(id) as BranchModel?;
    if (branch == null) return;
    if (name != null) branch.name = name.trim();
    if (address != null) branch.address = address.trim();
    if (phone != null) branch.phone = phone.trim();
    await branch.save();
    await SyncService.update(
      boxName: 'branches',
      entity: branch,
      branchId: id,
      toJson: branch.toJson(),
    );
  }

  Future<void> deleteBranch(String id) async {
    final box = Hive.box('branches');
    await box.delete(id);
    await SyncService.softDelete(
      boxName: 'branches',
      key: id,
      branchId: id,
      currentData: {'id': id, 'is_deleted': true},
    );
  }

  Future<void> toggleBranch(String id) async {
    final box = Hive.box('branches');
    final branch = box.get(id) as BranchModel?;
    if (branch == null) return;
    branch.isActive = !branch.isActive;
    await branch.save();
    await SyncService.update(
      boxName: 'branches',
      entity: branch,
      branchId: id,
      toJson: branch.toJson(),
    );
  }

  // ─── Members ───

  Future<List<PharmacyMemberModel>> getMembers() async {
    final box = Hive.box('admin_members');
    return box.values.whereType<PharmacyMemberModel>().toList();
  }

  Future<PharmacyMemberModel> createMember({
    required String name,
    required String email,
    required String roleId,
    required Set<String> branchIds,
    String? phone,
  }) async {
    final role = await getRole(roleId);
    final member = PharmacyMemberModel(
      id: _uuid.v4(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone?.trim(),
      roleId: roleId,
      branchIds: branchIds,
      permissions: role?.permissions ?? {PermissionCatalog.dashboardRead},
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    final box = Hive.box('admin_members');
    await box.putSynced(member.id, member, table: 'users', branchId: member.branchIds.firstOrNull ?? 'admin');
    return member;
  }

  Future<void> updateMember(String id,
      {String? name, String? email, String? roleId, Set<String>? branchIds}) async {
    final box = Hive.box('admin_members');
    final member = box.get(id) as PharmacyMemberModel?;
    if (member == null) return;
    PharmacyMemberModel updated;
    if (roleId != null && roleId != member.roleId) {
      final role = await getRole(roleId);
      updated = member.copyWith(
        name: name ?? member.name,
        email: email ?? member.email,
        roleId: roleId,
        branchIds: branchIds ?? member.branchIds,
        permissions: role?.permissions ?? member.permissions,
        updatedAt: DateTime.now(),
      );
    } else {
      updated = member.copyWith(
        name: name ?? member.name,
        email: email ?? member.email,
        branchIds: branchIds ?? member.branchIds,
        updatedAt: DateTime.now(),
      );
    }
    await box.putSynced(updated.id, updated, table: 'users', branchId: updated.branchIds.firstOrNull ?? 'admin', type: SyncOperationType.update);
    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: 'admin_members',
      data: updated.toJson(),
      branchId: updated.branchIds.firstOrNull ?? 'admin',
    );
  }

  Future<void> toggleMemberActive(String id) async {
    final box = Hive.box('admin_members');
    final member = box.get(id) as PharmacyMemberModel?;
    if (member == null) return;
    final updated = member.copyWith(
      isActive: !member.isActive,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(updated.id, updated, table: 'users', branchId: updated.branchIds.firstOrNull ?? 'admin', type: SyncOperationType.update);
    await SyncService.queueOperation(
      type: SyncOperationType.update,
      table: 'admin_members',
      data: updated.toJson(),
      branchId: updated.branchIds.firstOrNull ?? 'admin',
    );
  }

  // ─── Roles ───

  Future<List<RoleDefinitionModel>> getRoles() async {
    final box = Hive.box('admin_roles');
    final roles = box.values.whereType<RoleDefinitionModel>().toList();
    final existingIds = roles.map((r) => r.id).toSet();
    for (final systemRole in _systemRoles()) {
      if (!existingIds.contains(systemRole.id)) {
        roles.add(systemRole);
      }
    }
    roles.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return roles;
  }

  Future<RoleDefinitionModel?> getRole(String id) async {
    final box = Hive.box('admin_roles');
    if (box.containsKey(id)) return box.get(id) as RoleDefinitionModel;
    for (final sr in _systemRoles()) {
      if (sr.id == id) return sr;
    }
    return null;
  }

  Future<RoleDefinitionModel> createRole({
    required String name,
    String? description,
    required Set<String> permissions,
  }) async {
    final now = DateTime.now();
    final role = RoleDefinitionModel(
      id: _uuid.v4(),
      name: name.trim(),
      description: description?.trim(),
      permissions: permissions,
      isSystem: false,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    );
    final box = Hive.box('admin_roles');
    await box.put(role.id, role);
    return role;
  }

  Future<void> updateRole(String id,
      {String? name, String? description, Set<String>? permissions, bool? isActive}) async {
    final box = Hive.box('admin_roles');
    final role = box.get(id) as RoleDefinitionModel?;
    if (role == null || role.isSystem) return;
    final updated = role.copyWith(
      name: name ?? role.name,
      description: description ?? role.description,
      permissions: permissions ?? role.permissions,
      isActive: isActive ?? role.isActive,
      updatedAt: DateTime.now(),
    );
    await box.put(updated.id, updated);
  }

  // ─── Audit Log ───

  Future<List<AuditLogModel>> getAuditLogs() async {
    final box = Hive.box('admin_audit_logs');
    final logs = box.values.whereType<AuditLogModel>().toList();
    logs.sort((a, b) => b.occurredAt.compareTo(a.occurredAt));
    return logs;
  }

  Future<void> addAuditLog(AuditLogModel log) async {
    final box = Hive.box('admin_audit_logs');
    await box.putSynced(log.id, log, table: 'audit_logs', branchId: log.branchId ?? AuthService.currentBranchId ?? '');
  }

  // ─── Private ───

  List<RoleDefinitionModel> _systemRoles() {
    final now = DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    return [
      RoleDefinitionModel(
        id: 'owner',
        name: 'مالك الصيدلية',
        permissions: {PermissionCatalog.wildcard},
        isSystem: true,
        createdAt: now,
        updatedAt: now,
      ),
      RoleDefinitionModel(
        id: 'manager',
        name: 'مدير',
        permissions: {...PermissionCatalog.all},
        isSystem: true,
        createdAt: now,
        updatedAt: now,
      ),
      RoleDefinitionModel(
        id: 'pharmacist',
        name: 'صيدلي',
        permissions: PermissionCatalog.defaultsForRole('pharmacist'),
        isSystem: true,
        createdAt: now,
        updatedAt: now,
      ),
      RoleDefinitionModel(
        id: 'accountant',
        name: 'محاسب',
        permissions: PermissionCatalog.defaultsForRole('accountant'),
        isSystem: true,
        createdAt: now,
        updatedAt: now,
      ),
      RoleDefinitionModel(
        id: 'cashier',
        name: 'كاشير',
        permissions: PermissionCatalog.defaultsForRole('cashier'),
        isSystem: true,
        createdAt: now,
        updatedAt: now,
      ),
    ];
  }
}

