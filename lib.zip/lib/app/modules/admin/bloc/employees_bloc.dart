import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import '../../../core/models/security/user_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_service.dart';
import '../../../core/services/admin/permission_service.dart';
import '../../../core/utils/app_utils.dart';
import '../../admin/services/access_control_service.dart';

part 'employees_event.dart';
part 'employees_state.dart';

class EmployeesBloc extends Bloc<EmployeesEvent, EmployeesState> {
  final AccessControlService _access = AccessControlService.to;

  EmployeesBloc() : super(const EmployeesState()) {
    on<LoadEmployees>(_onLoadEmployees);
    on<AddEmployee>(_onAddEmployee);
    on<UpdateEmployee>(_onUpdateEmployee);
    on<DeleteEmployee>(_onDeleteEmployee);
    on<SelectEmployee>(_onSelectEmployee);
    on<LoadEmployeePermissions>(_onLoadEmployeePermissions);
  }

  Future<void> _onLoadEmployees(LoadEmployees event, Emitter<EmployeesState> emit) async {
    emit(state.copyWith(status: EmployeesStatus.loading));
    try {
      final box = Hive.box('users');
      final employees = box.values
          .whereType<UserModel>()
          .where((u) => u.isEmployee)
          .toList();
      emit(state.copyWith(
        status: EmployeesStatus.loaded,
        employees: employees,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: EmployeesStatus.error,
        error: e.toString(),
      ));
    }
  }

  Future<void> _onAddEmployee(AddEmployee event, Emitter<EmployeesState> emit) async {
    _access.require('users.write');
    emit(state.copyWith(status: EmployeesStatus.loading));
    try {
      final result = await AuthService.register(
        name: event.name,
        email: event.email,
        password: event.password,
        role: UserRole.employee,
        assignedBranchId: event.assignedBranchId,
      );
      if (result['success'] == true) {
        add(const LoadEmployees());
      } else {
        emit(state.copyWith(
          status: EmployeesStatus.error,
          error: result['message'] as String? ?? 'فشل إضافة الموظف',
        ));
      }
    } catch (e) {
      emit(state.copyWith(
        status: EmployeesStatus.error,
        error: e.toString(),
      ));
    }
  }

  Future<void> _onUpdateEmployee(UpdateEmployee event, Emitter<EmployeesState> emit) async {
    _access.require('users.write');
    final box = Hive.box('users');
    final user = box.get(event.id) as UserModel?;
    if (user == null) return;
    if (event.name != null) user.name = event.name!;
    if (event.email != null) user.email = event.email!;
    await user.save();
    emit(state.copyWith(status: EmployeesStatus.loading));
    add(const LoadEmployees());
    try {
      await SyncService.update(
        boxName: 'users',
        entity: user,
        branchId: user.assignedBranchId ?? '',
        toJson: user.toJson(),
      );
    } catch (e, st) {
      safeDebugPrint('EmployeesBloc: فشل مزامنة تحديث الموظف ${user.id}: $e\n$st');
    }
  }

  Future<void> _onDeleteEmployee(DeleteEmployee event, Emitter<EmployeesState> emit) async {
    _access.require('users.write');
    final box = Hive.box('users');
    final user = box.get(event.id) as UserModel?;
    if (user == null) return;
    user.isActive = false;
    await user.save();
    emit(state.copyWith(status: EmployeesStatus.loading));
    add(const LoadEmployees());
    try {
      await SyncService.update(
        boxName: 'users',
        entity: user,
        branchId: user.assignedBranchId ?? '',
        toJson: user.toJson(),
      );
    } catch (e, st) {
      safeDebugPrint('EmployeesBloc: فشل مزامنة حذف الموظف ${user.id}: $e\n$st');
    }
  }

  void _onSelectEmployee(SelectEmployee event, Emitter<EmployeesState> emit) {
    final box = Hive.box('users');
    final user = box.get(event.id) as UserModel?;
    emit(state.copyWith(selectedEmployee: user));
  }

  void _onLoadEmployeePermissions(LoadEmployeePermissions event, Emitter<EmployeesState> emit) {
    final permissions = PermissionService.getPermissionsForUser(event.userId);
    emit(state.copyWith(selectedEmployeePermissions: permissions));
  }
}
