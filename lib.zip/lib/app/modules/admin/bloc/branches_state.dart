import 'package:equatable/equatable.dart';
import '../../../core/models/security/branch_model.dart';
import '../../../core/bloc/base_state.dart';

class BranchesState extends Equatable {
  final AsyncState<List<BranchModel>> branchesState;

  const BranchesState({
    this.branchesState = const Initial(),
  });

  List<BranchModel> get branches => branchesState.dataOrNull ?? [];
  String? get error => branchesState.errorOrNull;
  bool get isLoading => branchesState.isLoading;

  BranchesState copyWith({
    AsyncState<List<BranchModel>>? branchesState,
  }) {
    return BranchesState(
      branchesState: branchesState ?? this.branchesState,
    );
  }

  @override
  List<Object?> get props => [branchesState];
}
