// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'role_definition_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

RoleDefinitionModel _$RoleDefinitionModelFromJson(Map<String, dynamic> json) {
  return _RoleDefinitionModel.fromJson(json);
}

/// @nodoc
mixin _$RoleDefinitionModel {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  Set<String> get permissions => throw _privateConstructorUsedError;
  bool get isSystem => throw _privateConstructorUsedError;
  bool get isActive => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RoleDefinitionModelCopyWith<RoleDefinitionModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RoleDefinitionModelCopyWith<$Res> {
  factory $RoleDefinitionModelCopyWith(
          RoleDefinitionModel value, $Res Function(RoleDefinitionModel) then) =
      _$RoleDefinitionModelCopyWithImpl<$Res, RoleDefinitionModel>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? description,
      Set<String> permissions,
      bool isSystem,
      bool isActive,
      DateTime createdAt,
      DateTime updatedAt});
}

/// @nodoc
class _$RoleDefinitionModelCopyWithImpl<$Res, $Val extends RoleDefinitionModel>
    implements $RoleDefinitionModelCopyWith<$Res> {
  _$RoleDefinitionModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? permissions = null,
    Object? isSystem = null,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      permissions: null == permissions
          ? _value.permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      isSystem: null == isSystem
          ? _value.isSystem
          : isSystem // ignore: cast_nullable_to_non_nullable
              as bool,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RoleDefinitionModelImplCopyWith<$Res>
    implements $RoleDefinitionModelCopyWith<$Res> {
  factory _$$RoleDefinitionModelImplCopyWith(_$RoleDefinitionModelImpl value,
          $Res Function(_$RoleDefinitionModelImpl) then) =
      __$$RoleDefinitionModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? description,
      Set<String> permissions,
      bool isSystem,
      bool isActive,
      DateTime createdAt,
      DateTime updatedAt});
}

/// @nodoc
class __$$RoleDefinitionModelImplCopyWithImpl<$Res>
    extends _$RoleDefinitionModelCopyWithImpl<$Res, _$RoleDefinitionModelImpl>
    implements _$$RoleDefinitionModelImplCopyWith<$Res> {
  __$$RoleDefinitionModelImplCopyWithImpl(_$RoleDefinitionModelImpl _value,
      $Res Function(_$RoleDefinitionModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? permissions = null,
    Object? isSystem = null,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$RoleDefinitionModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      permissions: null == permissions
          ? _value._permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      isSystem: null == isSystem
          ? _value.isSystem
          : isSystem // ignore: cast_nullable_to_non_nullable
              as bool,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RoleDefinitionModelImpl implements _RoleDefinitionModel {
  const _$RoleDefinitionModelImpl(
      {required this.id,
      required this.name,
      this.description,
      required final Set<String> permissions,
      this.isSystem = false,
      this.isActive = true,
      required this.createdAt,
      required this.updatedAt})
      : _permissions = permissions;

  factory _$RoleDefinitionModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$RoleDefinitionModelImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final String? description;
  final Set<String> _permissions;
  @override
  Set<String> get permissions {
    if (_permissions is EqualUnmodifiableSetView) return _permissions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableSetView(_permissions);
  }

  @override
  @JsonKey()
  final bool isSystem;
  @override
  @JsonKey()
  final bool isActive;
  @override
  final DateTime createdAt;
  @override
  final DateTime updatedAt;

  @override
  String toString() {
    return 'RoleDefinitionModel(id: $id, name: $name, description: $description, permissions: $permissions, isSystem: $isSystem, isActive: $isActive, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RoleDefinitionModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            const DeepCollectionEquality()
                .equals(other._permissions, _permissions) &&
            (identical(other.isSystem, isSystem) ||
                other.isSystem == isSystem) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      description,
      const DeepCollectionEquality().hash(_permissions),
      isSystem,
      isActive,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RoleDefinitionModelImplCopyWith<_$RoleDefinitionModelImpl> get copyWith =>
      __$$RoleDefinitionModelImplCopyWithImpl<_$RoleDefinitionModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RoleDefinitionModelImplToJson(
      this,
    );
  }
}

abstract class _RoleDefinitionModel implements RoleDefinitionModel {
  const factory _RoleDefinitionModel(
      {required final String id,
      required final String name,
      final String? description,
      required final Set<String> permissions,
      final bool isSystem,
      final bool isActive,
      required final DateTime createdAt,
      required final DateTime updatedAt}) = _$RoleDefinitionModelImpl;

  factory _RoleDefinitionModel.fromJson(Map<String, dynamic> json) =
      _$RoleDefinitionModelImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  String? get description;
  @override
  Set<String> get permissions;
  @override
  bool get isSystem;
  @override
  bool get isActive;
  @override
  DateTime get createdAt;
  @override
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$RoleDefinitionModelImplCopyWith<_$RoleDefinitionModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
