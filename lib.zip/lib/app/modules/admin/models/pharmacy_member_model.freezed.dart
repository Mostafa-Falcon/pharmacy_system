// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'pharmacy_member_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PharmacyMemberModel _$PharmacyMemberModelFromJson(Map<String, dynamic> json) {
  return _PharmacyMemberModel.fromJson(json);
}

/// @nodoc
mixin _$PharmacyMemberModel {
  String get id => throw _privateConstructorUsedError;
  String? get userId => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String? get phone => throw _privateConstructorUsedError;
  String get roleId => throw _privateConstructorUsedError;
  Set<String> get branchIds => throw _privateConstructorUsedError;
  Set<String> get permissions => throw _privateConstructorUsedError;
  bool get isActive => throw _privateConstructorUsedError;
  String? get invitationStatus => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PharmacyMemberModelCopyWith<PharmacyMemberModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PharmacyMemberModelCopyWith<$Res> {
  factory $PharmacyMemberModelCopyWith(
          PharmacyMemberModel value, $Res Function(PharmacyMemberModel) then) =
      _$PharmacyMemberModelCopyWithImpl<$Res, PharmacyMemberModel>;
  @useResult
  $Res call(
      {String id,
      String? userId,
      String name,
      String email,
      String? phone,
      String roleId,
      Set<String> branchIds,
      Set<String> permissions,
      bool isActive,
      String? invitationStatus,
      DateTime createdAt,
      DateTime updatedAt});
}

/// @nodoc
class _$PharmacyMemberModelCopyWithImpl<$Res, $Val extends PharmacyMemberModel>
    implements $PharmacyMemberModelCopyWith<$Res> {
  _$PharmacyMemberModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = freezed,
    Object? name = null,
    Object? email = null,
    Object? phone = freezed,
    Object? roleId = null,
    Object? branchIds = null,
    Object? permissions = null,
    Object? isActive = null,
    Object? invitationStatus = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      userId: freezed == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String?,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
      roleId: null == roleId
          ? _value.roleId
          : roleId // ignore: cast_nullable_to_non_nullable
              as String,
      branchIds: null == branchIds
          ? _value.branchIds
          : branchIds // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      permissions: null == permissions
          ? _value.permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      invitationStatus: freezed == invitationStatus
          ? _value.invitationStatus
          : invitationStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PharmacyMemberModelImplCopyWith<$Res>
    implements $PharmacyMemberModelCopyWith<$Res> {
  factory _$$PharmacyMemberModelImplCopyWith(_$PharmacyMemberModelImpl value,
          $Res Function(_$PharmacyMemberModelImpl) then) =
      __$$PharmacyMemberModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String? userId,
      String name,
      String email,
      String? phone,
      String roleId,
      Set<String> branchIds,
      Set<String> permissions,
      bool isActive,
      String? invitationStatus,
      DateTime createdAt,
      DateTime updatedAt});
}

/// @nodoc
class __$$PharmacyMemberModelImplCopyWithImpl<$Res>
    extends _$PharmacyMemberModelCopyWithImpl<$Res, _$PharmacyMemberModelImpl>
    implements _$$PharmacyMemberModelImplCopyWith<$Res> {
  __$$PharmacyMemberModelImplCopyWithImpl(_$PharmacyMemberModelImpl _value,
      $Res Function(_$PharmacyMemberModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = freezed,
    Object? name = null,
    Object? email = null,
    Object? phone = freezed,
    Object? roleId = null,
    Object? branchIds = null,
    Object? permissions = null,
    Object? isActive = null,
    Object? invitationStatus = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$PharmacyMemberModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      userId: freezed == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String?,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
      roleId: null == roleId
          ? _value.roleId
          : roleId // ignore: cast_nullable_to_non_nullable
              as String,
      branchIds: null == branchIds
          ? _value._branchIds
          : branchIds // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      permissions: null == permissions
          ? _value._permissions
          : permissions // ignore: cast_nullable_to_non_nullable
              as Set<String>,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      invitationStatus: freezed == invitationStatus
          ? _value.invitationStatus
          : invitationStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PharmacyMemberModelImpl extends _PharmacyMemberModel {
  const _$PharmacyMemberModelImpl(
      {required this.id,
      this.userId,
      required this.name,
      required this.email,
      this.phone,
      required this.roleId,
      required final Set<String> branchIds,
      required final Set<String> permissions,
      this.isActive = true,
      this.invitationStatus,
      required this.createdAt,
      required this.updatedAt})
      : _branchIds = branchIds,
        _permissions = permissions,
        super._();

  factory _$PharmacyMemberModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PharmacyMemberModelImplFromJson(json);

  @override
  final String id;
  @override
  final String? userId;
  @override
  final String name;
  @override
  final String email;
  @override
  final String? phone;
  @override
  final String roleId;
  final Set<String> _branchIds;
  @override
  Set<String> get branchIds {
    if (_branchIds is EqualUnmodifiableSetView) return _branchIds;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableSetView(_branchIds);
  }

  final Set<String> _permissions;
  @override
  Set<String> get permissions {
    if (_permissions is EqualUnmodifiableSetView) return _permissions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableSetView(_permissions);
  }

  @override
  @JsonKey()
  final bool isActive;
  @override
  final String? invitationStatus;
  @override
  final DateTime createdAt;
  @override
  final DateTime updatedAt;

  @override
  String toString() {
    return 'PharmacyMemberModel(id: $id, userId: $userId, name: $name, email: $email, phone: $phone, roleId: $roleId, branchIds: $branchIds, permissions: $permissions, isActive: $isActive, invitationStatus: $invitationStatus, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PharmacyMemberModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.roleId, roleId) || other.roleId == roleId) &&
            const DeepCollectionEquality()
                .equals(other._branchIds, _branchIds) &&
            const DeepCollectionEquality()
                .equals(other._permissions, _permissions) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.invitationStatus, invitationStatus) ||
                other.invitationStatus == invitationStatus) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      userId,
      name,
      email,
      phone,
      roleId,
      const DeepCollectionEquality().hash(_branchIds),
      const DeepCollectionEquality().hash(_permissions),
      isActive,
      invitationStatus,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PharmacyMemberModelImplCopyWith<_$PharmacyMemberModelImpl> get copyWith =>
      __$$PharmacyMemberModelImplCopyWithImpl<_$PharmacyMemberModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PharmacyMemberModelImplToJson(
      this,
    );
  }
}

abstract class _PharmacyMemberModel extends PharmacyMemberModel {
  const factory _PharmacyMemberModel(
      {required final String id,
      final String? userId,
      required final String name,
      required final String email,
      final String? phone,
      required final String roleId,
      required final Set<String> branchIds,
      required final Set<String> permissions,
      final bool isActive,
      final String? invitationStatus,
      required final DateTime createdAt,
      required final DateTime updatedAt}) = _$PharmacyMemberModelImpl;
  const _PharmacyMemberModel._() : super._();

  factory _PharmacyMemberModel.fromJson(Map<String, dynamic> json) =
      _$PharmacyMemberModelImpl.fromJson;

  @override
  String get id;
  @override
  String? get userId;
  @override
  String get name;
  @override
  String get email;
  @override
  String? get phone;
  @override
  String get roleId;
  @override
  Set<String> get branchIds;
  @override
  Set<String> get permissions;
  @override
  bool get isActive;
  @override
  String? get invitationStatus;
  @override
  DateTime get createdAt;
  @override
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$PharmacyMemberModelImplCopyWith<_$PharmacyMemberModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
