import 'package:flutter/material.dart';
import '../../../core/widgets/shareds/sidebar.dart';
import '../../../core/services/auth/auth_service.dart';

List<SidebarGroup> getAdminSidebarGroups() {
  final user = AuthService.currentUser;
  if (user == null) return [];

  final groups = <SidebarGroup>[];

  // ─── القائمة الرئيسية ───
  final mainChildren = <SidebarItem>[
    const SidebarItem(
      id: 'main_page',
      icon: Icons.home_rounded,
      label: 'الصفحة الرئيسية',
    ),
    const SidebarItem(
      id: 'admin_dashboard',
      icon: Icons.analytics_rounded,
      label: 'لوحة المتابعة',
    ),
  ];

  if (AuthService.hasPermission('sales.view')) {
    mainChildren.add(
      const SidebarItem(
        id: 'sales',
        icon: Icons.point_of_sale_rounded,
        label: 'المبيعات',
        children: [
          SidebarItem(
            id: 'pos',
            icon: Icons.shopping_cart_rounded,
            label: 'نقطة البيع',
          ),
          SidebarItem(
            id: 'cashier_shifts',
            icon: Icons.access_time_rounded,
            label: 'ورديات الكاشير',
          ),
          SidebarItem(
            id: 'sales_invoice',
            icon: Icons.description_rounded,
            label: 'فواتير المبيعات',
          ),
          SidebarItem(
            id: 'sales_return',
            icon: Icons.currency_exchange_rounded,
            label: 'مرتجعات المبيعات',
          ),
          SidebarItem(
            id: 'price_quotes',
            icon: Icons.sell_outlined,
            label: 'عروض الأسعار',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('purchases.view')) {
    mainChildren.add(
      const SidebarItem(
        id: 'purchases',
        icon: Icons.inventory_2_rounded,
        label: 'المشتريات',
        children: [
          SidebarItem(
            id: 'purchase_order',
            icon: Icons.add_shopping_cart_rounded,
            label: 'فاتورة شراء جديدة',
          ),
          SidebarItem(
            id: 'purchase_invoice',
            icon: Icons.receipt_rounded,
            label: 'فواتير المشتريات',
          ),
          SidebarItem(
            id: 'purchase_return',
            icon: Icons.inventory_rounded,
            label: 'مرتجعات المشتريات',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('inventory.view')) {
    mainChildren.add(
      const SidebarItem(
        id: 'items',
        icon: Icons.medication_rounded,
        label: 'الأدوية',
        children: [
          SidebarItem(
            id: 'items_list',
            icon: Icons.list_alt_rounded,
            label: 'قائمة الأدوية',
          ),
          SidebarItem(
            id: 'add_item',
            icon: Icons.add_circle_outline_rounded,
            label: 'إضافة دواء',
          ),
          SidebarItem(
            id: 'inventory_health',
            icon: Icons.health_and_safety_outlined,
            label: 'حالة المخزون',
          ),
          SidebarItem(
            id: 'barcode_label',
            icon: Icons.document_scanner_outlined,
            label: 'طباعة الباركود',
          ),
          SidebarItem(
            id: 'barcode_settings',
            icon: Icons.settings_rounded,
            label: 'إعدادات الباركود',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('contacts.view')) {
    mainChildren.add(
      const SidebarItem(
        id: 'contacts',
        icon: Icons.contacts_rounded,
        label: 'جهات الاتصال',
        children: [
          SidebarItem(
            id: 'customers',
            icon: Icons.group_outlined,
            label: 'العملاء',
          ),
          SidebarItem(
            id: 'suppliers',
            icon: Icons.business_outlined,
            label: 'الموردين',
          ),
          SidebarItem(
            id: 'customer_suppliers',
            icon: Icons.swap_horiz_rounded,
            label: 'عملاء/موردين',
          ),
          SidebarItem(
            id: 'customer_groups',
            icon: Icons.group_work_outlined,
            label: 'مجموعات العملاء',
          ),
          SidebarItem(
            id: 'crm',
            icon: Icons.trending_up_rounded,
            label: 'إدارة العملاء (CRM)',
          ),
        ],
      ),
    );
  }

  if (AuthService.hasPermission('reports.view')) {
    mainChildren.add(
      const SidebarItem(
        id: 'reports',
        icon: Icons.analytics_rounded,
        label: 'التقارير',
        children: [
          SidebarItem(
            id: 'sales_report',
            icon: Icons.bar_chart_rounded,
            label: 'تقرير المبيعات',
          ),
          SidebarItem(
            id: 'contacts_report',
            icon: Icons.contacts_rounded,
            label: 'تقرير العملاء والموردين',
          ),
          SidebarItem(
            id: 'purchase_report',
            icon: Icons.trending_up_rounded,
            label: 'تقرير المشتريات',
          ),
          SidebarItem(
            id: 'profit_report',
            icon: Icons.monetization_on_rounded,
            label: 'تقرير الأرباح',
          ),
        ],
      ),
    );
  }

  if (mainChildren.isNotEmpty) {
    groups.add(SidebarGroup(label: 'القائمة الرئيسية', children: mainChildren));
  }

  // ─── الإعدادات ───
  final settingsChildren = <SidebarItem>[
    const SidebarItem(
      id: 'settings',
      icon: Icons.settings_rounded,
      label: 'الإعدادات',
    ),
    const SidebarItem(
      id: 'profile',
      icon: Icons.person_rounded,
      label: 'الملف الشخصي',
    ),
  ];

  if (AuthService.hasPermission('employees.view')) {
    settingsChildren.add(
      const SidebarItem(
        id: 'employees',
        icon: Icons.people_rounded,
        label: 'الموظفين',
      ),
    );
  }

  if (AuthService.hasPermission('branches.view')) {
    settingsChildren.add(
      const SidebarItem(
        id: 'branches',
        icon: Icons.store_rounded,
        label: 'الفروع',
      ),
    );
  }

  if (AuthService.hasPermission('permissions.view')) {
    settingsChildren.add(
      const SidebarItem(
        id: 'permissions',
        icon: Icons.security_rounded,
        label: 'الصلاحيات',
      ),
    );
  }

  settingsChildren.add(
    const SidebarItem(
      id: 'activity_log',
      icon: Icons.assignment_outlined,
      label: 'سجل النشاط',
    ),
  );

  settingsChildren.add(
    const SidebarItem(
      id: 'document_control',
      icon: Icons.folder_open_rounded,
      label: 'مراقبة المستندات',
    ),
  );

  // Owner-only: الأرشيف
  if (user.isOwner) {
    settingsChildren.add(
      const SidebarItem(
        id: 'advanced_archive',
        icon: Icons.archive_outlined,
        label: 'الأرشيف',
      ),
    );
  }

  if (settingsChildren.isNotEmpty) {
    groups.add(SidebarGroup(label: 'الإعدادات', children: settingsChildren));
  }

  return groups;
}
