import 'package:flutter/material.dart';

class SettingsTab {
  final String id;
  final String label;
  final IconData icon;
  final List<String> keywords;

  const SettingsTab({
    required this.id,
    required this.label,
    required this.icon,
    this.keywords = const [],
  });
}

const settingsTabs = [
  SettingsTab(
    id: 'project',
    label: 'المشروع',
    icon: Icons.business_rounded,
    keywords: ['pharmacy', 'name', 'currency', 'باسم', 'عملة'],
  ),
  SettingsTab(
    id: 'tax',
    label: 'الضريبة',
    icon: Icons.percent_rounded,
    keywords: ['tax', 'vat', 'ضريبة', 'قيمة مضافة'],
  ),
  SettingsTab(
    id: 'items',
    label: 'الصنف',
    icon: Icons.inventory_2_rounded,
    keywords: ['item', 'product', 'صلاحية', 'مخزون', 'وحدة'],
  ),
  SettingsTab(
    id: 'sales',
    label: 'البيع',
    icon: Icons.shopping_cart_rounded,
    keywords: ['sale', 'خصم', 'تقسيط', 'credit'],
  ),
  SettingsTab(
    id: 'system',
    label: 'النظام',
    icon: Icons.settings_rounded,
    keywords: ['language', 'audit', 'backup', 'offline', 'جلسة'],
  ),
  SettingsTab(
    id: 'email',
    label: 'البريد الإلكتروني',
    icon: Icons.mail_rounded,
    keywords: ['email', 'smtp', 'mail', 'بريد'],
  ),
  SettingsTab(
    id: 'sms',
    label: 'الرسائل النصية',
    icon: Icons.sms_rounded,
    keywords: ['sms', 'message', 'رسالة', 'جوال'],
  ),
  SettingsTab(
    id: 'rewards',
    label: 'نقاط المكافآت',
    icon: Icons.card_giftcard_rounded,
    keywords: ['reward', 'points', 'loyalty', 'ولاء', 'نقاط'],
  ),
  SettingsTab(
    id: 'shortcuts',
    label: 'الاختصارات',
    icon: Icons.keyboard_rounded,
    keywords: ['shortcut', 'prefix', 'اختصار', 'كود'],
  ),
  SettingsTab(
    id: 'extraUnits',
    label: 'وحدات إضافية',
    icon: Icons.extension_rounded,
    keywords: ['extra', 'module', 'وحدة', 'إضافي'],
  ),
];
