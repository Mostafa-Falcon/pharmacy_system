import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/injection.dart';
import '../../../core/widgets/index.dart';
import '../../../core/models/security/user_model.dart';
import '../../../core/services/admin/permission_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../bloc/employees_bloc.dart';

class PermissionsManagementView extends StatelessWidget {
  const PermissionsManagementView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: sl<EmployeesBloc>(),
      child: const _PermissionsManagementBody(),
    );
  }
}

class _PermissionsManagementBody extends StatelessWidget {
  const _PermissionsManagementBody();

  @override
  Widget build(BuildContext context) {
    return HomeShell(
      title: 'إدارة صلاحيات الوصول',
      subtitle: 'تحديد وإعطاء صلاحيات العمل للموظفين على أقسام السيستم',
      child: Padding(
        padding: EdgeInsets.all(AppSpacing.lg.w),
        child: Column(
          children: [
            _buildEmployeeSelector(context),
            SizedBox(height: AppSpacing.md.h),
            Expanded(child: _buildPermissionsGrid(context)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmployeeSelector(BuildContext context) {
    final bloc = context.read<EmployeesBloc>();
    return BlocBuilder<EmployeesBloc, EmployeesState>(
      builder: (context, state) {
        final employees = state.employees;
        final selected = state.selectedEmployee;
        final employeeMap = <String, UserModel>{};
        for (final emp in employees) {
          employeeMap[emp.id] = emp;
        }

        return AppCard(
          padding: EdgeInsets.all(AppSpacing.md.w),
          child: Row(
            children: [
              Icon(Icons.badge_rounded, color: Theme.of(context).colorScheme.primary, size: 20.sp),
              SizedBox(width: AppSpacing.sm.w),
              ReusableText(
                'اختر موظف الصيدلية:',
                style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimaryOf(context)),
              ),
              SizedBox(width: AppSpacing.md.w),
              Expanded(
                child: ReusableDropdown<String?>(
                  hintText: 'اضغط هنا لاختيار اسم الموظف',
                  value: selected?.id,
                  items: employees.map((emp) => emp.id).toList(),
                  itemAsString: (id) {
                    final target = employeeMap[id];
                    return target?.name ?? 'اسم مجهول';
                  },
                  onChanged: (id) {
                    if (id != null) {
                      bloc.add(SelectEmployee(id: id));
                      bloc.add(LoadEmployeePermissions(id));
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPermissionsGrid(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final bloc = context.read<EmployeesBloc>();

    return BlocBuilder<EmployeesBloc, EmployeesState>(
      builder: (context, state) {
        final selected = state.selectedEmployee;
        if (selected == null) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.security_rounded, size: 60.sp, color: AppColors.textMutedOf(context).withValues(alpha: 0.4)),
                SizedBox(height: AppSpacing.sm.h),
                ReusableText(
                  'برجاء اختيار موظف أولاً لعرض وتعديل صلاحياته',
                  style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.bold, color: AppColors.textSecondaryOf(context)),
                ),
              ],
            ),
          );
        }

        final allPermissions = PermissionService.defaultOwnerPermissions;
        final userPermissions = state.selectedEmployeePermissions;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.shield_rounded, color: scheme.primary, size: 20.sp),
                    SizedBox(width: AppSpacing.xs.w),
                    ReusableText(
                      'لوحة صلاحيات: ${selected.name}',
                      style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimaryOf(context)),
                    ),
                  ],
                ),
                _buildQuickActions(context, selected.id),
              ],
            ),
            SizedBox(height: AppSpacing.md.h),
            Expanded(
              child: GridView.builder(
                physics: const BouncingScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: MediaQuery.of(context).size.width > 1100 ? 4 : (MediaQuery.of(context).size.width > 750 ? 3 : 2),
                  childAspectRatio: 2.5,
                  crossAxisSpacing: AppSpacing.sm.w,
                  mainAxisSpacing: AppSpacing.sm.h,
                ),
                itemCount: allPermissions.length,
                itemBuilder: (context, index) {
                  final perm = allPermissions[index];
                  final isAllowed = userPermissions.contains(perm);
                  return AppCard(
                    padding: EdgeInsets.zero,
                    borderRadius: AppRadius.md.r,
                    backgroundColor: isAllowed ? AppColors.primarySoftOf(context) : AppColors.inputFillOf(context).withValues(alpha: 0.3),
                    child: CheckboxListTile(
                      value: isAllowed,
                      activeColor: scheme.primary,
                      checkColor: Colors.white,
                      onChanged: (value) async {
                        if (value == true) {
                          await PermissionService.grantPermission(selected.id, perm);
                        } else {
                          await PermissionService.revokePermission(selected.id, perm);
                        }
                        bloc.add(LoadEmployeePermissions(selected.id));
                      },
                      title: ReusableText(
                        _getPermissionLabel(perm),
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: isAllowed ? FontWeight.bold : FontWeight.w500,
                          color: isAllowed ? scheme.primary : AppColors.textPrimaryOf(context),
                        ),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.symmetric(horizontal: AppSpacing.xs.w),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildQuickActions(BuildContext context, String userId) {
    final bloc = context.read<EmployeesBloc>();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ReusableButton(
          text: 'إعطاء الكل',
          prefixIcon: Icons.done_all_rounded,
          type: ButtonType.text,
          onPressed: () async {
            for (final perm in PermissionService.defaultOwnerPermissions) {
              await PermissionService.grantPermission(userId, perm);
            }
            bloc.add(LoadEmployeePermissions(userId));
          },
        ),
        SizedBox(width: AppSpacing.xs.w),
        ReusableButton(
          text: 'سحب الكل',
          prefixIcon: Icons.block_rounded,
          type: ButtonType.text,
          onPressed: () async {
            for (final perm in PermissionService.defaultOwnerPermissions) {
              await PermissionService.revokePermission(userId, perm);
            }
            bloc.add(LoadEmployeePermissions(userId));
          },
        ),
      ],
    );
  }

  String _getPermissionLabel(String key) {
    const labels = {
      'dashboard': 'لوحة التحكم العامة', 'pos': 'نقطة البيع (الكاشير)', 'inventory': 'إدارة المخازن',
      'medicines': 'إضافة وتعديل الأدوية', 'categories': 'تصنيفات الأدوية', 'stock': 'جرد الكميات والمخزون',
      'customers': 'سجلات العملاء', 'suppliers': 'سجلات الموردين', 'reports': 'التقارير الحسابية',
      'settings': 'إعدادات النظام العامة', 'admin_panel': 'لوحة الإدارة والملاك', 'employees': 'بيانات الموظفين',
      'branches': 'إدارة فروع الصيدليات', 'permissions': 'تعديل الصلاحيات والأدوار', 'create_invoice': 'إنشاء وطباعة الفواتير',
      'cancel_invoice': 'إلغاء وحذف الفواتير', 'refund': 'إجراء مرتجعات المبيعات', 'adjust_stock': 'تعديل وتصفير الكميات بالخطأ',
      'delete_medicine': 'حذف علبة دواء نهائياً', 'manage_users': 'إدارة صلاحيات الطاقم', 'manage_branches': 'إضافة وحذف الفروع',
      'view_reports': 'عرض تقارير الأرباح والخسائر', 'export_data': 'تصدير جرد المخزون إكسيل', 'manage_permissions': 'إدارة رتب الموظفين',
    };
    return labels[key] ?? key;
  }
}
