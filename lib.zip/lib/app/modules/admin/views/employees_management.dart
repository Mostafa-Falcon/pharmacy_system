import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive/hive.dart';
import 'package:collection/collection.dart';
import '../../../core/widgets/index.dart';
import '../../../core/models/security/user_model.dart';
import '../../../core/models/security/branch_model.dart';
import '../../../core/services/sound_service.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../bloc/employees_bloc.dart';

class EmployeesManagementView extends StatelessWidget {
  const EmployeesManagementView({super.key});

  @override
  Widget build(BuildContext context) {
    return HomeShell(
      title: AppStrings.empManagementTitle,
      subtitle: AppStrings.empManagementSubtitle,
      child: Padding(
        padding: EdgeInsets.all(AppSpacing.lg.w),
        child: Column(
          children: [
            Wrap(
              spacing: AppSpacing.md.w,
              runSpacing: AppSpacing.md.h,
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                ReusableButton(
                  text: AppStrings.empAddAction,
                  prefixIcon: Icons.person_add_alt_1_rounded,
                  type: ButtonType.primary,
                  onPressed: () => _showAddEmployeeDialog(context),
                ),
                BlocBuilder<EmployeesBloc, EmployeesState>(
                  buildWhen: (prev, current) => prev.employees.length != current.employees.length,
                  builder: (context, state) => Container(
                    padding: EdgeInsets.symmetric(horizontal: AppSpacing.sm.w, vertical: AppSpacing.xs.h),
                    decoration: BoxDecoration(
                      color: AppColors.primarySoftOf(context),
                      borderRadius: BorderRadius.circular(AppRadius.sm.r),
                    ),
                    child: ReusableText(
                      AppStrings.empTotalFormat.replaceFirst('%s', '${state.employees.length}'),
                      style: TextStyle(fontSize: 12.5.sp, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.md.h),
            Expanded(child: _buildEmployeesList(context)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmployeesList(BuildContext context) {
    return BlocBuilder<EmployeesBloc, EmployeesState>(
      buildWhen: (prev, current) => prev.employees != current.employees || prev.status != current.status,
      builder: (context, state) {
        if (state.status == EmployeesStatus.loading && state.employees.isEmpty) {
          return const LoadingIndicator();
        }
        if (state.employees.isEmpty) {
          return const EmptyState(
            icon: Icons.people_outline_rounded,
            title: AppStrings.empNoAccounts,
            subtitle: AppStrings.empAddStartHint,
          );
        }

        return ListView.builder(
          itemCount: state.employees.length,
          physics: const BouncingScrollPhysics(),
          itemBuilder: (context, index) {
            final emp = state.employees[index];
            return _EmployeeCard(
              employee: emp,
              onEdit: () => _showEditEmployeeDialog(context, emp),
              onDelete: () => _confirmDeleteEmployee(context, emp),
              onToggleActive: () => _toggleActiveStatus(context, emp),
            );
          },
        );
      },
    );
  }

  void _showAddEmployeeDialog(BuildContext context) {
    final bloc = context.read<EmployeesBloc>();
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    String? selectedBranchId;
    String selectedRole = 'employee';

    final branchesBox = Hive.box('branches');
    final branches = branchesBox.values.whereType<BranchModel>().toList();
    final scheme = Theme.of(context).colorScheme;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => ReusableDialog(
          title: AppStrings.empAddDialogTitle,
          headerIcon: Icon(Icons.person_add_rounded, color: scheme.primary),
          children: [
            ReusableInput(
              controller: nameController,
              label: AppStrings.empNameLabel,
              prefixIcon: const Icon(Icons.person_outline_rounded),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput.email(
              controller: emailController,
              label: AppStrings.empEmailLabel,
              prefixIcon: const Icon(Icons.email_outlined),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput.password(
              controller: passwordController,
              label: AppStrings.empDefaultPasswordLabel,
              prefixIcon: const Icon(Icons.lock_outline_rounded),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<String>(
              labelText: AppStrings.empRoleTasksLabel,
              hintText: AppStrings.empSelectRoleHint,
              prefixIcon: Icons.work_outline_rounded,
              value: selectedRole,
              items: const [
                'employee',
                'pharmacist',
                'cashier',
                'inventory_manager',
              ],
              itemAsString: (val) {
                switch (val) {
                  case 'pharmacist':
                    return AppStrings.empRolePharmacistLabel;
                  case 'cashier':
                    return AppStrings.empRoleCashierLabel;
                  case 'inventory_manager':
                    return AppStrings.empRoleInventoryLabel;
                  default:
                    return AppStrings.empRoleGeneralLabel;
                }
              },
              onChanged: (value) {
                setDialogState(() => selectedRole = value ?? 'employee');
              },
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<String?>(
              labelText: AppStrings.empBranchLabel,
              hintText: AppStrings.empSelectBranchHint,
              prefixIcon: Icons.storefront_rounded,
              value: selectedBranchId,
              items: [null, ...branches.map((b) => b.id)],
              itemAsString: (val) {
                if (val == null) return AppStrings.empNoBranchAssigned;
                final target = branches.firstWhereOrNull((b) => b.id == val);
                return target?.name ?? AppStrings.empUnknownBranch;
              },
              onChanged: (value) {
                setDialogState(() => selectedBranchId = value);
              },
            ),
            SizedBox(height: 16.h),
            DialogActions(
              cancelText: AppStrings.empCancelAction,
              confirmText: AppStrings.empConfirmAction,
              onCancel: () => Navigator.pop(context),
              onConfirm: () async {
                if (nameController.text.isEmpty ||
                    emailController.text.isEmpty ||
                    passwordController.text.isEmpty) {
                  AppSnackbar.error(
                    AppStrings.empFieldsRequiredError,
                    title: AppStrings.empSecurityAlertTitle,
                  );
                  return;
                }
                bloc.add(
                  AddEmployee(
                    name: nameController.text.trim(),
                    email: emailController.text.trim(),
                    password: passwordController.text.trim(),
                    assignedBranchId: selectedBranchId,
                  ),
                );
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showEditEmployeeDialog(BuildContext context, UserModel emp) {
    final bloc = context.read<EmployeesBloc>();
    final nameController = TextEditingController(text: emp.name);
    final emailController = TextEditingController(text: emp.email);
    String? selectedBranchId = emp.assignedBranchId;
    String selectedRole = emp.isEmployee ? 'employee' : 'owner';

    final branchesBox = Hive.box('branches');
    final branches = branchesBox.values.whereType<BranchModel>().toList();
    final scheme = Theme.of(context).colorScheme;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => ReusableDialog(
          title: AppStrings.empEditDialogTitle,
          headerIcon: Icon(Icons.edit_note_rounded, color: scheme.primary),
          children: [
            ReusableInput(
              controller: nameController,
              label: AppStrings.empEditNameLabel,
              prefixIcon: const Icon(Icons.person_outline_rounded),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput.email(
              controller: emailController,
              label: AppStrings.empEditEmailLabel,
              prefixIcon: const Icon(Icons.email_outlined),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<String>(
              labelText: AppStrings.empEditRoleLabel,
              hintText: AppStrings.empEditRoleHint,
              prefixIcon: Icons.work_outline_rounded,
              value: selectedRole,
              items: const [
                'employee',
                'pharmacist',
                'cashier',
                'inventory_manager',
              ],
              itemAsString: (val) {
                switch (val) {
                  case 'pharmacist':
                    return AppStrings.empRolePharmacistLabel;
                  case 'cashier':
                    return AppStrings.empRoleCashierLabel;
                  case 'inventory_manager':
                    return AppStrings.empRoleInventoryLabel;
                  default:
                    return AppStrings.empRoleGeneralLabel;
                }
              },
              onChanged: (value) {
                setDialogState(() => selectedRole = value ?? 'employee');
              },
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<String?>(
              labelText: AppStrings.empBranchLabel,
              hintText: AppStrings.empEditBranchHint,
              prefixIcon: Icons.storefront_rounded,
              value: selectedBranchId,
              items: [null, ...branches.map((b) => b.id)],
              itemAsString: (val) {
                if (val == null) return AppStrings.empNoBranchAssigned;
                final target = branches.where((b) => b.id == val).firstOrNull;
                return target?.name ?? AppStrings.empUnknownBranch;
              },
              onChanged: (value) {
                setDialogState(() => selectedBranchId = value);
              },
            ),
            SizedBox(height: 16.h),
            DialogActions(
              cancelText: AppStrings.empCancelAction,
              confirmText: AppStrings.empSaveChangesAction,
              onCancel: () => Navigator.pop(context),
              onConfirm: () async {
                if (nameController.text.isEmpty || emailController.text.isEmpty) {
                  AppSnackbar.error(
                    AppStrings.empRequiredFieldsError,
                    title: AppStrings.empSecurityAlertTitle,
                  );
                  return;
                }
                bloc.add(
                  UpdateEmployee(
                    id: emp.id,
                    name: nameController.text.trim(),
                    email: emailController.text.trim(),
                  ),
                );
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDeleteEmployee(BuildContext context, UserModel emp) {
    final bloc = context.read<EmployeesBloc>();
    ConfirmDeleteDialog.show(
      context,
      title: AppStrings.empDeleteConfirmTitle,
      message: AppStrings.empDeleteConfirmMessageFormat.replaceFirst('%s', emp.name),
      confirmText: AppStrings.empDeleteActionLabel,
      onConfirm: () {
        bloc.add(DeleteEmployee(id: emp.id));
        SoundService.instance.play(SoundEffect.error);
      },
    );
  }

  void _toggleActiveStatus(BuildContext context, UserModel emp) async {
    final bloc = context.read<EmployeesBloc>();
    emp.isActive = !emp.isActive;
    await emp.save();
    bloc.add(const LoadEmployees());

    if (emp.isActive) {
      AppSnackbar.success(AppStrings.empActivatedSuccessFormat.replaceFirst('%s', emp.name), title: AppStrings.empStatusUpdateTitle);
    } else {
      AppSnackbar.warning(AppStrings.empDeactivatedWarningFormat.replaceFirst('%s', emp.name), title: AppStrings.empStatusUpdateTitle);
    }
  }
}

class _EmployeeCard extends StatelessWidget {
  final UserModel employee;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onToggleActive;

  const _EmployeeCard({required this.employee, required this.onEdit, required this.onDelete, required this.onToggleActive});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return AppCard(
      margin: EdgeInsets.only(bottom: AppSpacing.sm.h),
      padding: EdgeInsets.all(AppSpacing.md.w),
      child: Row(
        children: [
          Container(
            width: 46.w, height: 46.w,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight, end: Alignment.bottomLeft,
                colors: [scheme.primary, scheme.primary.withValues(alpha: 0.85)],
              ),
              borderRadius: BorderRadius.circular(AppRadius.md.r),
              boxShadow: [BoxShadow(color: scheme.primary.withValues(alpha: 0.12), blurRadius: 6, offset: const Offset(0, 3))],
            ),
            child: Center(
              child: ReusableText(employee.name.isNotEmpty ? employee.name[0].toUpperCase() : '?',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
            ),
          ),
          SizedBox(width: AppSpacing.md.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ReusableText(employee.name, style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold, color: AppColors.textPrimaryOf(context))),
                SizedBox(height: 2.h),
                ReusableText(employee.email, style: TextStyle(fontSize: 12.sp, color: AppColors.textSecondaryOf(context))),
                SizedBox(height: 6.h),
                Row(
                  children: [
                    StatusBadge(label: employee.role == UserRole.owner ? AppStrings.empBadgeOwnerLabel : AppStrings.empRoleGeneralLabel, color: scheme.primary),
                    SizedBox(width: AppSpacing.xs.w),
                    StatusBadge(label: employee.isActive ? AppStrings.empBadgeActiveLabel : AppStrings.empBadgeFrozenLabel, color: employee.isActive ? AppColors.success : AppColors.error),
                  ],
                ),
              ],
            ),
          ),
          PopupMenuButton<String>(
            color: AppColors.surfaceOf(context),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md.r)),
            onSelected: (value) {
              switch (value) {
                case 'edit': onEdit(); break;
                case 'toggle': onToggleActive(); break;
                case 'delete': onDelete(); break;
              }
            },
            itemBuilder: (context) => [
              ReusableActionMenuItem(
                value: 'edit',
                icon: Icons.edit_note_rounded,
                label: AppStrings.editData,
              ),
              ReusableActionMenuItem(
                value: 'toggle',
                icon: employee.isActive ? Icons.lock_person_rounded : Icons.lock_open_rounded,
                label: employee.isActive ? AppStrings.empFreezeAction : AppStrings.empActivateAction,
                color: employee.isActive ? AppColors.warning : AppColors.success,
              ),
              ReusableActionMenuItem(
                value: 'delete',
                icon: Icons.person_remove_alt_1_rounded,
                label: AppStrings.deleteEmployee,
                color: AppColors.error,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
