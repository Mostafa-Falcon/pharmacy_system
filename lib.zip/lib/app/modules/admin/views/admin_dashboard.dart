import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/injection.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../core/widgets/index.dart';
import '../../../core/models/security/branch_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../bloc/branches_bloc.dart';
import '../bloc/branches_event.dart';
import '../bloc/branches_state.dart';

class AdminDashboardView extends StatelessWidget {
  const AdminDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: sl<BranchesBloc>(),
      child: const _AdminDashboardBody(),
    );
  }
}

class _AdminDashboardBody extends StatelessWidget {
  const _AdminDashboardBody();

  @override
  Widget build(BuildContext context) {
    return HomeShell(
      title: AppStrings.branchesManagementTitle,
      subtitle: AppStrings.branchesManagementSubtitle,
      child: Padding(
        padding: EdgeInsets.all(AppSpacing.lg.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Wrap(
              spacing: AppSpacing.md.w,
              runSpacing: AppSpacing.md.h,
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                ReusableText(
                  AppStrings.activeBranchesListLabel,
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimaryOf(context),
                  ),
                ),
                ReusableButton(
                  text: AppStrings.addBranchAction,
                  prefixIcon: Icons.add_rounded,
                  type: ButtonType.primary,
                  onPressed: () => _showAddBranchDialog(context),
                ),
              ],
            ),
            SizedBox(height: AppSpacing.md.h),
            Expanded(child: _buildBranchesList(context)),
          ],
        ),
      ),
    );
  }

  Widget _buildBranchesList(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return BlocBuilder<BranchesBloc, BranchesState>(
      builder: (context, state) {
        if (state.isLoading && state.branches.isEmpty) {
          return const Center(child: LoadingIndicator());
        }

        if (state.error != null && state.branches.isEmpty) {
          return Center(child: ReusableText(state.error!));
        }

        final branches = state.branches;
        if (branches.isEmpty) {
          return const EmptyState(
            icon: Icons.storefront_rounded,
            title: AppStrings.noBranchesFound,
          );
        }

        return ListView.builder(
          itemCount: branches.length,
          physics: const BouncingScrollPhysics(),
          itemBuilder: (context, index) {
            final branch = branches[index];
            return AppCard(
              margin: EdgeInsets.only(bottom: AppSpacing.sm.h),
              padding: EdgeInsets.zero,
              child: ListTile(
                contentPadding: EdgeInsets.symmetric(horizontal: AppSpacing.md.w, vertical: AppSpacing.xs.h),
                leading: CircleAvatar(
                  radius: 22.r,
                  backgroundColor: AppColors.primarySoftOf(context),
                  child: Icon(Icons.store_rounded, color: scheme.primary, size: 20.sp),
                ),
                title: ReusableText(
                  branch.name,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15.sp, color: AppColors.textPrimaryOf(context)),
                ),
                subtitle: Padding(
                  padding: EdgeInsets.only(top: 4.h),
                  child: Row(
                    children: [
                      Icon(Icons.location_on_rounded, size: 13.sp, color: AppColors.textMutedOf(context)),
                      SizedBox(width: 4.w),
                      Expanded(
                        child: ReusableText(
                          branch.address ?? AppStrings.noAddressDefined,
                          style: TextStyle(fontSize: 12.5.sp, color: AppColors.textSecondaryOf(context)),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit_note_rounded, size: 22.sp, color: scheme.primary),
                      tooltip: AppStrings.editBranchTooltip,
                      onPressed: () => _showEditBranchDialog(context, branch),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_sweep_rounded, size: 22.sp, color: scheme.error),
                      tooltip: AppStrings.deleteBranchTooltip,
                      onPressed: () => _confirmDeleteBranch(context, branch),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showAddBranchDialog(BuildContext context) {
    final nameController = TextEditingController();
    final addressController = TextEditingController();
    final phoneController = TextEditingController();
    final scheme = Theme.of(context).colorScheme;
    final bloc = context.read<BranchesBloc>();

    showDialog(
      context: context,
      builder: (context) => ReusableDialog(
        title: AppStrings.addBranchDialogTitle,
        headerIcon: Icon(Icons.add_business_rounded, color: scheme.primary),
        children: [
          ReusableInput(
            controller: nameController,
            label: AppStrings.branchFullNameLabel,
            hint: AppStrings.branchNameExampleHint,
          ),
          SizedBox(height: AppSpacing.md.h),
          ReusableInput(
            controller: addressController,
            label: AppStrings.branchDetailedAddressLabel,
            hint: AppStrings.branchAddressExampleHint,
          ),
          SizedBox(height: AppSpacing.md.h),
          ReusableInput(
            controller: phoneController,
            label: AppStrings.branchPhoneLabel,
            hint: AppStrings.branchPhoneExampleHint,
            keyboardType: TextInputType.phone,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancelAddBranchAction,
            confirmText: AppStrings.confirmAddBranchAction,
            onCancel: () => Navigator.pop(context),
            onConfirm: () {
              if (nameController.text.trim().isEmpty) {
                AppSnackbar.info(
                  AppStrings.enterBranchNameWarning,
                  title: AppStrings.importantWarningTitle,
                );
                return;
              }
              bloc.add(
                AddBranch(
                  name: nameController.text.trim(),
                  address: addressController.text.trim(),
                  phone: phoneController.text.trim(),
                ),
              );
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  void _showEditBranchDialog(BuildContext context, BranchModel branch) {
    final nameController = TextEditingController(text: branch.name);
    final addressController = TextEditingController(text: branch.address ?? '');
    final phoneController = TextEditingController(text: branch.phone ?? '');
    final scheme = Theme.of(context).colorScheme;
    final bloc = context.read<BranchesBloc>();

    showDialog(
      context: context,
      builder: (context) => ReusableDialog(
        title: AppStrings.editBranchDialogTitle,
        headerIcon: Icon(Icons.edit_road_rounded, color: scheme.primary),
        children: [
          ReusableInput(controller: nameController, label: AppStrings.branchFullNameLabel),
          SizedBox(height: AppSpacing.md.h),
          ReusableInput(
            controller: addressController,
            label: AppStrings.branchDetailedAddressLabel,
          ),
          SizedBox(height: AppSpacing.md.h),
          ReusableInput(
            controller: phoneController,
            label: AppStrings.branchPhoneLabel,
            keyboardType: TextInputType.phone,
          ),
          SizedBox(height: 16.h),
          DialogActions(
            cancelText: AppStrings.cancelEditBranchAction,
            confirmText: AppStrings.saveBranchChangesAction,
            onCancel: () => Navigator.pop(context),
            onConfirm: () {
              if (nameController.text.trim().isEmpty) {
                AppSnackbar.info(
                  AppStrings.cannotClearBranchNameWarning,
                  title: AppStrings.importantWarningTitle,
                );
                return;
              }
              bloc.add(
                UpdateBranch(
                  branch.id,
                  name: nameController.text.trim(),
                  address: addressController.text.trim(),
                  phone: phoneController.text.trim(),
                ),
              );
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  void _confirmDeleteBranch(BuildContext context, BranchModel branch) {
    final bloc = context.read<BranchesBloc>();
    ConfirmDeleteDialog.show(
      context,
      title: AppStrings.importantSecurityWarningTitle,
      message: AppStrings.deleteBranchConfirmFormat.replaceFirst('%s', branch.name),
      confirmText: AppStrings.confirmDeleteBranchAction,
      onConfirm: () => bloc.add(DeleteBranch(branch.id)),
    );
  }
}
