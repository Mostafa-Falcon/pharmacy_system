import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/models/base/app_notification_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/admin/branch_data_service.dart';
import 'notifications_event.dart';
import 'notifications_state.dart';

class NotificationsBloc extends Bloc<NotificationsEvent, NotificationsState> {
  NotificationsBloc() : super(const NotificationsState()) {
    on<LoadNotifications>(_onLoad);
    on<MarkAsRead>(_onMarkAsRead);
    on<MarkAllAsRead>(_onMarkAllAsRead);
    on<DeleteNotification>(_onDelete);
    on<ClearAllNotifications>(_onClearAll);
    on<GenerateSystemNotifications>(_onGenerateSystem);
    
    // التوليد التلقائي عند البدء
    add(const GenerateSystemNotifications());
  }

  Future<void> _onLoad(LoadNotifications event, Emitter<NotificationsState> emit) async {
    emit(state.copyWith(status: NotificationsStatus.loading));
    // في الوضع الحقيقي، قد يتم التحميل من قاعدة بيانات محلية (Hive)
    // هنا سنعتمد على التوليد اللحظي حالياً
    add(const GenerateSystemNotifications());
  }

  void _onMarkAsRead(MarkAsRead event, Emitter<NotificationsState> emit) {
    final updated = state.notifications.map((n) {
      if (n.id == event.notificationId) {
        return n.copyWith(isRead: true);
      }
      return n;
    }).toList();
    emit(state.copyWith(notifications: updated));
  }

  void _onMarkAllAsRead(MarkAllAsRead event, Emitter<NotificationsState> emit) {
    final updated = state.notifications.map((n) => n.copyWith(isRead: true)).toList();
    emit(state.copyWith(notifications: updated));
  }

  void _onDelete(DeleteNotification event, Emitter<NotificationsState> emit) {
    final updated = state.notifications.where((n) => n.id != event.notificationId).toList();
    emit(state.copyWith(notifications: updated));
  }

  void _onClearAll(ClearAllNotifications event, Emitter<NotificationsState> emit) {
    emit(state.copyWith(notifications: const []));
  }

  void _onGenerateSystem(GenerateSystemNotifications event, Emitter<NotificationsState> emit) async {
    final branchId = AuthService.currentBranchId ?? '';
    final allMedicines = BranchDataService.getMedicines(branchId: branchId);
    final now = DateTime.now();
    
    final List<AppNotification> systemNotifications = [];

    // 1. تنبيهات الأدوية المنتهية
    final expired = allMedicines.where((m) => m.expiryDate != null && m.expiryDate!.isBefore(now));
    for (final m in expired) {
      systemNotifications.add(AppNotification(
        id: 'expired_${m.id}',
        title: 'دواء منتهي الصلاحية',
        message: 'الصنف "${m.name}" انتهت صلاحيته في ${m.expiryDate!.toString().split(' ')[0]}',
        timestamp: m.expiryDate!,
        category: NotificationCategory.expiry,
        priority: NotificationPriority.critical,
        actionRoute: '/admin/inventory/edit/${m.id}',
        metadata: {'medicineId': m.id},
      ));
    }

    // 2. تنبيهات قرب انتهاء الصلاحية (أقل من 60 يوم)
    final nearExpiry = allMedicines.where((m) =>
        m.expiryDate != null &&
        !m.expiryDate!.isBefore(now) &&
        m.expiryDate!.difference(now).inDays <= 60);
    for (final m in nearExpiry) {
      final days = m.expiryDate!.difference(now).inDays;
      systemNotifications.add(AppNotification(
        id: 'near_expiry_${m.id}',
        title: 'قرب انتهاء الصلاحية',
        message: 'الصنف "${m.name}" سيقترب من الانتهاء خلال $days يوم',
        timestamp: now,
        category: NotificationCategory.expiry,
        priority: NotificationPriority.high,
        actionRoute: '/admin/inventory/edit/${m.id}',
        metadata: {'medicineId': m.id},
      ));
    }

    // 3. تنبيهات النواقص (مخزون منخفض)
    final lowStock = allMedicines.where((m) => m.quantity <= m.minStock);
    for (final m in lowStock) {
      systemNotifications.add(AppNotification(
        id: 'low_stock_${m.id}',
        title: 'نواقص / مخزون منخفض',
        message: 'الكمية الحالية للصنف "${m.name}" هي ${m.quantity}، وهي أقل من الحد الأدنى (${m.minStock})',
        timestamp: now,
        category: NotificationCategory.stock,
        priority: NotificationPriority.medium,
        actionRoute: '/admin/inventory/edit/${m.id}',
        metadata: {'medicineId': m.id},
      ));
    }

    // دمج الإشعارات الحالية مع الجديدة (مع تجنب التكرار)
    final existingIds = state.notifications.map((n) => n.id).toSet();
    final newOnes = systemNotifications.where((n) => !existingIds.contains(n.id)).toList();
    
    final all = [...state.notifications, ...newOnes]
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

    emit(state.copyWith(
      status: NotificationsStatus.loaded,
      notifications: all,
    ));
  }
}
