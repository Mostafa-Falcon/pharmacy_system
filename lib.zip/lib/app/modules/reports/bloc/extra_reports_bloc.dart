import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/services/auth/auth_service.dart';
import '../services/extra_reports_service.dart';

part 'extra_reports_event.dart';
part 'extra_reports_state.dart';

/// Bloc التقارير الإضافية.
class ExtraReportsBloc extends Bloc<ExtraReportsEvent, ExtraReportsState> {
  ExtraReportsBloc() : super(ExtraReportsState()) {
    on<LoadExtraReport>(_onLoad);
    on<SelectExtraReportType>(_onSelectType);
    on<SetExtraReportRange>(_onSetRange);
    on<SelectMovementMedicine>(_onSelectMedicine);
  }

  String get _branchId => AuthService.currentBranchId ?? '';

  String _typeLabelValue(ExtraReportType type) {
    switch (type) {
      case ExtraReportType.inventory:
        return 'تقرير المخزون';
      case ExtraReportType.inventoryCount:
        return 'الجرد المخزني';
      case ExtraReportType.popularItems:
        return 'الأصناف الشائعة';
      case ExtraReportType.itemMovement:
        return 'حركة الأصناف';
      case ExtraReportType.taxSummary:
        return 'ملخص الضريبة';
      case ExtraReportType.employeeActivity:
        return 'نشاطات الموظفين';
      case ExtraReportType.customerGroups:
        return 'مجموعات العملاء';
      case ExtraReportType.receipts:
        return 'سجل السندات';
    }
  }

  void _reload(Emitter<ExtraReportsState> emit) {
    emit(state.copyWith(isLoading: true));
    switch (state.selectedType) {
      case ExtraReportType.inventory:
        emit(state.copyWith(inventoryRows: ExtraReportsService.getInventoryReport(_branchId), isLoading: false));
        break;
      case ExtraReportType.inventoryCount:
        emit(state.copyWith(inventoryRows: ExtraReportsService.getInventoryReport(_branchId), isLoading: false));
        break;
      case ExtraReportType.popularItems:
        emit(state.copyWith(
          popularItemRows: ExtraReportsService.getPopularItemsReport(_branchId, state.fromDate, state.toDate),
          isLoading: false,
        ));
        break;
      case ExtraReportType.itemMovement:
        final medId = state.selectedMedicineId;
        emit(state.copyWith(
          movementRows: (medId != null && medId.isNotEmpty)
              ? ExtraReportsService.getItemMovementReport(_branchId, medId)
              : const [],
          isLoading: false,
        ));
        break;
      case ExtraReportType.taxSummary:
        emit(state.copyWith(
          taxSummaryRows: ExtraReportsService.getTaxSummaryReport(_branchId, state.fromDate, state.toDate),
          isLoading: false,
        ));
        break;
      case ExtraReportType.employeeActivity:
        emit(state.copyWith(
          employeeActivityRows: ExtraReportsService.getEmployeeActivityReport(_branchId, state.fromDate, state.toDate),
          isLoading: false,
        ));
        break;
      case ExtraReportType.customerGroups:
        emit(state.copyWith(
          customerGroupRows: ExtraReportsService.getCustomerGroupsReport(_branchId),
          isLoading: false,
        ));
        break;
      case ExtraReportType.receipts:
        emit(state.copyWith(
          receiptRows: ExtraReportsService.getReceiptsReport(_branchId, state.fromDate, state.toDate),
          isLoading: false,
        ));
        break;
    }
  }

  void _onLoad(LoadExtraReport event, Emitter<ExtraReportsState> emit) {
    emit(state.copyWith(
      dateLabel: state._dateLabel,
      typeLabel: _typeLabelValue(state.selectedType),
    ));
    _reload(emit);
  }

  void _onSelectType(SelectExtraReportType event, Emitter<ExtraReportsState> emit) {
    emit(state.copyWith(selectedType: event.type, typeLabel: _typeLabelValue(event.type)));
    _reload(emit);
  }

  void _onSetRange(SetExtraReportRange event, Emitter<ExtraReportsState> emit) {
    emit(state.copyWith(
      fromDate: event.from,
      toDate: event.to,
      dateLabel: '${event.from.year}/${event.from.month.toString().padLeft(2, '0')}/${event.from.day.toString().padLeft(2, '0')} — ${event.to.year}/${event.to.month.toString().padLeft(2, '0')}/${event.to.day.toString().padLeft(2, '0')}',
    ));
    _reload(emit);
  }

  void _onSelectMedicine(SelectMovementMedicine event, Emitter<ExtraReportsState> emit) {
    emit(state.copyWith(selectedMedicineId: event.medicineId));
    _reload(emit);
  }
}
