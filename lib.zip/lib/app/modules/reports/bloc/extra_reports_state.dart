part of 'extra_reports_bloc.dart';

class ExtraReportsState extends Equatable {
  final ExtraReportType selectedType;
  final DateTime fromDate;
  final DateTime toDate;
  final bool isLoading;
  final String dateLabel;
  final String typeLabel;
  final List<InventoryRow> inventoryRows;
  final List<PopularItemRow> popularItemRows;
  final List<MovementRow> movementRows;
  final List<TaxSummaryRow> taxSummaryRows;
  final List<EmployeeActivityRow> employeeActivityRows;
  final List<CustomerGroupRow> customerGroupRows;
  final List<ReceiptRow> receiptRows;
  final String? selectedMedicineId;

  ExtraReportsState({
    this.selectedType = ExtraReportType.inventory,
    DateTime? fromDate,
    DateTime? toDate,
    this.isLoading = false,
    this.dateLabel = '',
    this.typeLabel = '',
    this.inventoryRows = const [],
    this.popularItemRows = const [],
    this.movementRows = const [],
    this.taxSummaryRows = const [],
    this.employeeActivityRows = const [],
    this.customerGroupRows = const [],
    this.receiptRows = const [],
    this.selectedMedicineId,
  })  : fromDate = fromDate ?? DateTime(DateTime.now().year, DateTime.now().month, 1),
        toDate = toDate ?? DateTime.now();

  ExtraReportsState copyWith({
    ExtraReportType? selectedType,
    DateTime? fromDate,
    DateTime? toDate,
    bool? isLoading,
    String? dateLabel,
    String? typeLabel,
    List<InventoryRow>? inventoryRows,
    List<PopularItemRow>? popularItemRows,
    List<MovementRow>? movementRows,
    List<TaxSummaryRow>? taxSummaryRows,
      List<EmployeeActivityRow>? employeeActivityRows,
      List<CustomerGroupRow>? customerGroupRows,
      List<ReceiptRow>? receiptRows,
      String? selectedMedicineId,
  }) {
    return ExtraReportsState(
      selectedType: selectedType ?? this.selectedType,
      fromDate: fromDate ?? this.fromDate,
      toDate: toDate ?? this.toDate,
      isLoading: isLoading ?? this.isLoading,
      dateLabel: dateLabel ?? this.dateLabel,
      typeLabel: typeLabel ?? this.typeLabel,
      inventoryRows: inventoryRows ?? this.inventoryRows,
      popularItemRows: popularItemRows ?? this.popularItemRows,
      movementRows: movementRows ?? this.movementRows,
      taxSummaryRows: taxSummaryRows ?? this.taxSummaryRows,
      employeeActivityRows: employeeActivityRows ?? this.employeeActivityRows,
      customerGroupRows: customerGroupRows ?? this.customerGroupRows,
      receiptRows: receiptRows ?? this.receiptRows,
      selectedMedicineId: selectedMedicineId ?? this.selectedMedicineId,
    );
  }

  String _pad(int n) => n.toString().padLeft(2, '0');

  String get _dateLabel => '${fromDate.year}/${_pad(fromDate.month)}/${_pad(fromDate.day)} — ${toDate.year}/${_pad(toDate.month)}/${_pad(toDate.day)}';

  String get typeSubtitle {
    switch (selectedType) {
      case ExtraReportType.inventory:
        return 'قيمة المخزون الحالية بسعر الشراء والبيع مع الربح المحتمل';
      case ExtraReportType.inventoryCount:
        return 'إجمالي الداخل والخارج من سجل حركة المخزون';
      case ExtraReportType.popularItems:
        return 'الأصناف الأكثر مبيعاً حسب عدد الوحدات وقيمة البيع';
      case ExtraReportType.itemMovement:
        return 'حركة صنف ناتجة عن البيع أو الشراء أو المرتجعات';
      case ExtraReportType.taxSummary:
        return 'تفاصيل ضرائب المبيعات والمشتريات والمصاريف';
      case ExtraReportType.employeeActivity:
        return 'سجل مبسط للحركات التي تمت بواسطة الموظفين';
      case ExtraReportType.customerGroups:
        return 'تحليل مجموعات العملاء حسب المشتريات والمرتجعات';
      case ExtraReportType.receipts:
        return 'سجل السندات: مبيعات، مشتريات، مرتجعات';
    }
  }

  @override
  List<Object?> get props => [
        selectedType,
        fromDate,
        toDate,
        isLoading,
        dateLabel,
        typeLabel,
        inventoryRows,
        popularItemRows,
        movementRows,
        taxSummaryRows,
        employeeActivityRows,
        customerGroupRows,
        receiptRows,
        selectedMedicineId,
      ];
}
