import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/admin/branch_data_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/widgets/index.dart';
import '../bloc/extra_reports_bloc.dart';
import '../services/extra_reports_service.dart';
import '../widgets/employee_activity_section.dart';
import '../widgets/inventory_report_section.dart';
import '../widgets/tax_summary_section.dart';

class ExtraReportsView extends StatelessWidget {
  const ExtraReportsView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ExtraReportsBloc, ExtraReportsState>(
      builder: (context, state) {
        return HomeShell(
          title: 'تقارير إضافية',
          child: Container(
            color: Theme.of(context)
                .colorScheme
                .surfaceContainerLow
                .withValues(alpha: 0.3),
            padding: EdgeInsets.all(AppSpacing.xl.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeader(context, state),
                SizedBox(height: AppSpacing.lg.h),
                Expanded(child: _buildContent(context, state)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context, ExtraReportsState state) {
    final bloc = context.read<ExtraReportsBloc>();
    return Container(
      padding: EdgeInsets.all(AppSpacing.md.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(
            color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.date_range_rounded,
                  size: 18.sp, color: AppColors.textSecondaryOf(context)),
              SizedBox(width: 8.w),
              Expanded(
                child: ReusableText('الفترة: ${state.dateLabel}',
                    style: TextStyle(
                        fontSize: 13.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondaryOf(context))),
              ),
              ReusableButton(
                text: 'نطاق مخصص',
                prefixIcon: Icons.calendar_month_outlined,
                type: ButtonType.text,
                onPressed: () => _pickDateRange(context),
              ),
            ],
          ),
          SizedBox(height: AppSpacing.md.h),
          SizedBox(
            height: 38.h,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: ExtraReportType.values.map((type) {
                final isSelected = state.selectedType == type;
                return QuickFilterChip(
                  label: _typeLabel(type),
                  isSelected: isSelected,
                  onTap: () => bloc.add(SelectExtraReportType(type)),
                );
              }).toList(),
            ),
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableText(
            state.typeSubtitle,
            style: TextStyle(
                fontSize: 11.sp,
                color: AppColors.textMutedOf(context)),
          ),
        ],
      ),
    );
  }

  Future<void> _pickDateRange(BuildContext context) async {
    final bloc = context.read<ExtraReportsBloc>();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(
        start: bloc.state.fromDate,
        end: bloc.state.toDate,
      ),
    );
    if (range != null) {
      bloc.add(SetExtraReportRange(range.start, range.end));
    }
  }

  Widget _buildContent(BuildContext context, ExtraReportsState state) {
    if (state.isLoading) {
      return const LoadingIndicator(message: 'جاري تحميل التقرير...');
    }

    switch (state.selectedType) {
      case ExtraReportType.inventory:
        return SingleChildScrollView(
          child: InventoryReportSection(rows: state.inventoryRows),
        );
      case ExtraReportType.inventoryCount:
        return SingleChildScrollView(
          child: InventoryReportSection(rows: state.inventoryRows),
        );
      case ExtraReportType.popularItems:
        return SingleChildScrollView(
          child: _buildPopularItemsSection(context, state),
        );
      case ExtraReportType.itemMovement:
        return SingleChildScrollView(
          child: _buildItemMovementSection(context, state),
        );
      case ExtraReportType.taxSummary:
        return SingleChildScrollView(
          child: TaxSummarySection(rows: state.taxSummaryRows),
        );
      case ExtraReportType.employeeActivity:
        return SingleChildScrollView(
          child: EmployeeActivitySection(rows: state.employeeActivityRows),
        );
      case ExtraReportType.customerGroups:
        return SingleChildScrollView(
          child: _buildCustomerGroupsSection(context, state),
        );
      case ExtraReportType.receipts:
        return SingleChildScrollView(
          child: _buildReceiptsSection(context, state),
        );
    }
  }

  Widget _buildPopularItemsSection(BuildContext context, ExtraReportsState state) {
    final rows = state.popularItemRows;
    if (rows.isEmpty) {
      return const EmptyState(
        title: 'لا توجد مبيعات',
        subtitle: 'لا توجد مبيعات لعرض الأصناف الشائعة',
        icon: Icons.star_outline_rounded,
      );
    }

    final totalQuantity = rows.fold<int>(0, (s, r) => s + r.soldQuantity);
    final totalSales = rows.fold<double>(0, (s, r) => s + r.salesTotal);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 800 ? 3 : 2;
            return GridView.count(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: AppSpacing.md.w,
              mainAxisSpacing: AppSpacing.md.h,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.8,
              children: [
                ReportCard(
                  title: 'عدد الأصناف المباعة',
                  value: rows.length.toString(),
                  color: AppColors.info,
                  icon: Icons.inventory_rounded,
                ),
                ReportCard(
                  title: 'مجموع الوحدات المباعة',
                  value: totalQuantity.toString(),
                  color: AppColors.success,
                  icon: Icons.shopping_cart_rounded,
                ),
                ReportCard(
                  title: 'إجمالي المبيعات',
                  value: '${totalSales.toStringAsFixed(2)} ج.م',
                  color: AppColors.warning,
                  icon: Icons.attach_money_rounded,
                ),
              ],
            );
          },
        ),
        SizedBox(height: AppSpacing.lg.h),
        LayoutBuilder(
          builder: (context, constraints) {
            if (constraints.maxWidth > 700) {
              return _buildPopularDataTable(context, rows);
            }
            return _buildPopularCards(context, rows);
          },
        ),
      ],
    );
  }

  Widget _buildPopularDataTable(BuildContext context, List<PopularItemRow> rows) {
    return Container(
      padding: EdgeInsets.all(AppSpacing.sm.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(AppColors.primarySoftOf(context)),
          columnSpacing: 20.w,
          columns: [
            DataColumn(label: ReusableText('الصنف', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('المبيعات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('إجمالي المبيعات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('متوسط السعر', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('عدد الفواتير', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
          ],
          rows: rows.map((r) => DataRow(cells: [
            DataCell(ReusableText(r.item, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.soldQuantity.toString(), style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w700))),
            DataCell(ReusableText('${r.salesTotal.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp, color: AppColors.success))),
            DataCell(ReusableText('${r.avgPrice.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.invoices.toString(), style: TextStyle(fontSize: 11.sp))),
          ])).toList(),
        ),
      ),
    );
  }

  Widget _buildPopularCards(BuildContext context, List<PopularItemRow> rows) {
    return Column(
      children: rows.map((r) => Container(
        margin: EdgeInsets.only(bottom: AppSpacing.sm.h),
        padding: EdgeInsets.all(AppSpacing.md.w),
        decoration: BoxDecoration(
          color: AppColors.surfaceOf(context),
          borderRadius: BorderRadius.circular(AppRadius.md.r),
          border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ReusableText(r.item, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)),
                  SizedBox(height: 4.h),
                  ReusableText('${r.soldQuantity} وحدة — ${r.invoices} فاتورة',
                      style: TextStyle(fontSize: 10.sp, color: AppColors.textMutedOf(context))),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                ReusableText('${r.salesTotal.toStringAsFixed(2)} ج.م',
                    style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w700, color: AppColors.success)),
                ReusableText('@ ${r.avgPrice.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 10.sp, color: AppColors.textMutedOf(context))),
              ],
            ),
          ],
        ),
      )).toList(),
    );
  }

  Widget _buildItemMovementSection(BuildContext context, ExtraReportsState state) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildMedicineSelector(context, state),
        SizedBox(height: AppSpacing.md.h),
        Builder(
          builder: (context) {
            final rows = state.movementRows;
            if (state.selectedMedicineId == null) {
              return const EmptyState(
                title: 'اختر صنفاً',
                subtitle: 'اختر صنفاً من القائمة لعرض حركته',
                icon: Icons.search_rounded,
              );
            }
            if (rows.isEmpty) {
              return const EmptyState(
                title: 'لا توجد حركات',
                subtitle: 'لا توجد حركات لهذا الصنف',
                icon: Icons.motion_photos_off_rounded,
              );
            }
            return _buildMovementTable(context, rows);
          },
        ),
      ],
    );
  }

  Widget _buildMedicineSelector(BuildContext context, ExtraReportsState state) {
    final medicines = BranchDataService.getMedicines(
      branchId: AuthService.currentBranchId ?? '',
    ).where((m) => !m.isDeleted).toList();
    medicines.sort((a, b) => a.name.compareTo(b.name));

    return Container(
      padding: EdgeInsets.all(AppSpacing.md.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.md.r),
        border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ReusableText('اختر الصنف',
              style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w600, color: AppColors.textSecondaryOf(context))),
          SizedBox(height: AppSpacing.sm.h),
          SizedBox(
            height: 40.h,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: medicines.map((m) {
                final isSelected = state.selectedMedicineId == m.id;
                return Padding(
                  padding: EdgeInsetsDirectional.only(end: 8.w),
                  child: QuickFilterChip(
                    label: m.name,
                    isSelected: isSelected,
                    onTap: () => context.read<ExtraReportsBloc>().add(SelectMovementMedicine(m.id)),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMovementTable(BuildContext context, List<MovementRow> rows) {
    final totalQuantity = rows.fold<int>(0, (s, r) => s + r.quantity);
    final totalValue = rows.fold<double>(0, (s, r) => s + r.total);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 800 ? 3 : 2;
            return GridView.count(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: AppSpacing.md.w,
              mainAxisSpacing: AppSpacing.md.h,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.8,
              children: [
                ReportCard(
                  title: 'عدد الحركات',
                  value: rows.length.toString(),
                  color: AppColors.info,
                  icon: Icons.swap_horiz_rounded,
                ),
                ReportCard(
                  title: 'إجمالي الكميات',
                  value: totalQuantity.toString(),
                  color: AppColors.success,
                  icon: Icons.inventory_rounded,
                ),
                ReportCard(
                  title: 'إجمالي القيمة',
                  value: '${totalValue.toStringAsFixed(2)} ج.م',
                  color: AppColors.warning,
                  icon: Icons.attach_money_rounded,
                ),
              ],
            );
          },
        ),
        SizedBox(height: AppSpacing.lg.h),
        LayoutBuilder(
          builder: (context, constraints) {
            if (constraints.maxWidth > 700) {
              return _buildMovementDataTable(context, rows);
            }
            return _buildMovementCards(context, rows);
          },
        ),
      ],
    );
  }

  Widget _buildMovementDataTable(BuildContext context, List<MovementRow> rows) {
    return Container(
      padding: EdgeInsets.all(AppSpacing.sm.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(AppColors.primarySoftOf(context)),
          columnSpacing: 16.w,
          columns: [
            DataColumn(label: ReusableText('التاريخ', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('النوع', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('المرجع', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('الطرف', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('الكمية', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('سعر الوحدة', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('الإجمالي', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
          ],
          rows: rows.map((r) => DataRow(cells: [
            DataCell(ReusableText(r.date, style: TextStyle(fontSize: 11.sp))),
            DataCell(_movementTypeBadge(context, r.type)),
            DataCell(ReusableText(r.reference, style: TextStyle(fontSize: 11.sp, color: AppColors.textMutedOf(context)))),
            DataCell(ReusableText(r.party, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.quantity.toString(), style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w700))),
            DataCell(ReusableText(r.unitPrice.toStringAsFixed(2), style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.total.toStringAsFixed(2), style: TextStyle(fontSize: 11.sp, color: AppColors.warning))),
          ])).toList(),
        ),
      ),
    );
  }

  Widget _buildMovementCards(BuildContext context, List<MovementRow> rows) {
    return Column(
      children: rows.map((r) => Container(
        margin: EdgeInsets.only(bottom: AppSpacing.sm.h),
        padding: EdgeInsets.all(AppSpacing.md.w),
        decoration: BoxDecoration(
          color: AppColors.surfaceOf(context),
          borderRadius: BorderRadius.circular(AppRadius.md.r),
          border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _movementTypeBadge(context, r.type),
                const Spacer(),
                ReusableText(r.date, style: TextStyle(fontSize: 10.sp, color: AppColors.textMutedOf(context))),
              ],
            ),
            SizedBox(height: 6.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ReusableText(r.party, style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondaryOf(context))),
                ReusableText('${r.quantity} × ${r.unitPrice.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondaryOf(context))),
              ],
            ),
            SizedBox(height: 4.h),
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: ReusableText('${r.total.toStringAsFixed(2)} ج.م',
                  style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w700, color: AppColors.warning)),
            ),
          ],
        ),
      )).toList(),
    );
  }

  Widget _movementTypeBadge(BuildContext context, String type) {
    Color color;
    switch (type) {
      case 'بيع':
        color = AppColors.success;
        break;
      case 'شراء':
        color = AppColors.info;
        break;
      case 'مرتجع بيع':
        color = AppColors.error;
        break;
      case 'مرتجع شراء':
        color = AppColors.warning;
        break;
      default:
        color = AppColors.primary;
    }
    return StatusBadge(label: type, color: color);
  }

  String _typeLabel(ExtraReportType type) {
    switch (type) {
      case ExtraReportType.inventory: return 'المخزون';
      case ExtraReportType.inventoryCount: return 'الجرد';
      case ExtraReportType.popularItems: return 'الأصناف الشائعة';
      case ExtraReportType.itemMovement: return 'حركة الأصناف';
      case ExtraReportType.taxSummary: return 'الضريبة';
      case ExtraReportType.employeeActivity: return 'نشاطات الموظفين';
      case ExtraReportType.customerGroups: return 'مجموعات العملاء';
      case ExtraReportType.receipts: return 'السندات';
    }
  }

  Widget _buildCustomerGroupsSection(BuildContext context, ExtraReportsState state) {
    final rows = state.customerGroupRows;
    if (rows.isEmpty) {
      return const EmptyState(
        title: 'لا توجد بيانات',
        subtitle: 'لا يوجد عملاء مسجلين لعرض التحليل',
        icon: Icons.people_outline_rounded,
      );
    }

    final totalPurchases = rows.fold<double>(0, (s, r) => s + r.netPurchases);
    final totalCustomers = rows.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 800 ? 3 : 2;
            return GridView.count(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: AppSpacing.md.w,
              mainAxisSpacing: AppSpacing.md.h,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.8,
              children: [
                ReportCard(
                  title: 'عدد العملاء',
                  value: totalCustomers.toString(),
                  color: AppColors.info,
                  icon: Icons.people_rounded,
                ),
                ReportCard(
                  title: 'صافي المشتريات',
                  value: '${totalPurchases.toStringAsFixed(2)} ج.م',
                  color: AppColors.success,
                  icon: Icons.attach_money_rounded,
                ),
                ReportCard(
                  title: 'المجموعات',
                  value: rows.map((r) => r.groupName).toSet().length.toString(),
                  color: AppColors.warning,
                  icon: Icons.category_rounded,
                ),
              ],
            );
          },
        ),
        SizedBox(height: AppSpacing.lg.h),
        _buildCustomerGroupsTable(context, rows),
      ],
    );
  }

  Widget _buildCustomerGroupsTable(BuildContext context, List<CustomerGroupRow> rows) {
    return Container(
      padding: EdgeInsets.all(AppSpacing.sm.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(AppColors.primarySoftOf(context)),
          columnSpacing: 16.w,
          columns: [
            DataColumn(label: ReusableText('المجموعة', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('العميل', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('الهاتف', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('الزيارات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('المشتريات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('المرتجعات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('الصافي', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
          ],
          rows: rows.map((r) => DataRow(cells: [
            DataCell(ReusableText(r.groupName, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.customerName, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.phone, style: TextStyle(fontSize: 11.sp, color: AppColors.textMutedOf(context)))),
            DataCell(ReusableText(r.visits.toString(), style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w700))),
            DataCell(ReusableText('${r.totalPurchases.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp, color: AppColors.success))),
            DataCell(ReusableText('${r.totalReturns.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp, color: AppColors.error))),
            DataCell(ReusableText('${r.netPurchases.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp, color: AppColors.warning))),
          ])).toList(),
        ),
      ),
    );
  }

  Widget _buildReceiptsSection(BuildContext context, ExtraReportsState state) {
    final rows = state.receiptRows;
    if (rows.isEmpty) {
      return const EmptyState(
        title: 'لا توجد سندات',
        subtitle: 'لا توجد سندات مسجلة في الفترة المحددة',
        icon: Icons.receipt_long_outlined,
      );
    }

    final totalAmount = rows.fold<double>(0, (s, r) => s + r.amount);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth > 800 ? 3 : 2;
            return GridView.count(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: AppSpacing.md.w,
              mainAxisSpacing: AppSpacing.md.h,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.8,
              children: [
                ReportCard(
                  title: 'عدد السندات',
                  value: rows.length.toString(),
                  color: AppColors.info,
                  icon: Icons.receipt_long_rounded,
                ),
                ReportCard(
                  title: 'إجمالي المبالغ',
                  value: '${totalAmount.toStringAsFixed(2)} ج.م',
                  color: AppColors.success,
                  icon: Icons.attach_money_rounded,
                ),
                ReportCard(
                  title: 'المبيعات',
                  value: rows.where((r) => r.type == 'فاتورة بيع').length.toString(),
                  color: AppColors.primary,
                  icon: Icons.shopping_cart_rounded,
                ),
              ],
            );
          },
        ),
        SizedBox(height: AppSpacing.lg.h),
        _buildReceiptsTable(context, rows),
      ],
    );
  }

  Widget _buildReceiptsTable(BuildContext context, List<ReceiptRow> rows) {
    return Container(
      padding: EdgeInsets.all(AppSpacing.sm.w),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppRadius.lg.r),
        border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.3)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(AppColors.primarySoftOf(context)),
          columnSpacing: 16.w,
          columns: [
            DataColumn(label: ReusableText('التاريخ', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('النوع', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('المرجع', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('الطرف', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('المبلغ', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp)), numeric: true),
            DataColumn(label: ReusableText('طريقة الدفع', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
            DataColumn(label: ReusableText('ملاحظات', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.sp))),
          ],
          rows: rows.map((r) => DataRow(cells: [
            DataCell(ReusableText(r.date, style: TextStyle(fontSize: 11.sp))),
            DataCell(_receiptTypeBadge(context, r.type)),
            DataCell(ReusableText(r.reference.substring(0, 8).toUpperCase(), style: TextStyle(fontSize: 11.sp, color: AppColors.textMutedOf(context)))),
            DataCell(ReusableText(r.contact, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText('${r.amount.toStringAsFixed(2)} ج.م', style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w700, color: AppColors.success))),
            DataCell(ReusableText(r.paymentMethod, style: TextStyle(fontSize: 11.sp))),
            DataCell(ReusableText(r.notes, style: TextStyle(fontSize: 11.sp, color: AppColors.textMutedOf(context)))),
          ])).toList(),
        ),
      ),
    );
  }

  Widget _receiptTypeBadge(BuildContext context, String type) {
    Color color;
    switch (type) {
      case 'فاتورة بيع':
        color = AppColors.success;
        break;
      case 'فاتورة شراء':
        color = AppColors.info;
        break;
      case 'مرتجع بيع':
        color = AppColors.error;
        break;
      case 'مرتجع شراء':
        color = AppColors.warning;
        break;
      default:
        color = AppColors.primary;
    }
    return StatusBadge(label: type, color: color);
  }
}

