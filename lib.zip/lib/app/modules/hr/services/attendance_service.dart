import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/sync_service.dart';
import '../models/attendance_model.dart';

class AttendanceService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static Box _box() => Hive.box('hr_attendance');

  static List<AttendanceModel> getAll({String? branchId, String? date}) {
    final bid = branchId ?? _currentBranchId;
    final box = _box();
    var records = box.values
        .whereType<Map>()
        .map((e) => AttendanceModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => branchId == null || e.branchId == bid)
        .toList();
    if (date != null) {
      records = records.where((e) => e.date == date).toList();
    }
    records.sort((a, b) => b.date.compareTo(a.date));
    return records;
  }

  static AttendanceModel? getById(String id) {
    final box = _box();
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return AttendanceModel.fromJson(Map<String, dynamic>.from(data));
  }

  static List<AttendanceModel> getByEmployee(String employeeId) {
    return getAll().where((e) => e.employeeId == employeeId).toList();
  }

  static AttendanceModel? getTodayRecord(String employeeId) {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final records = getAll(date: today);
    return records.where((e) => e.employeeId == employeeId).firstOrNull;
  }

  static Future<String> clockIn({
    required String employeeId,
    String employeeName = '',
    String? notes,
  }) async {
    final box = _box();
    final id = const Uuid().v4();
    final now = DateTime.now();
    final today = now.toIso8601String().substring(0, 10);
    final nowStr = now.toIso8601String();

    final record = AttendanceModel(
      id: id,
      employeeId: employeeId,
      employeeName: employeeName,
      branchId: _currentBranchId,
      clockIn: nowStr,
      clockOut: null,
      date: today,
      status: 'present',
      notes: notes,
      createdAt: now,
      updatedAt: now,
    );
    await box.putSynced(id, record.toJson(), table: 'attendance', branchId: _currentBranchId);
    return id;
  }

  static Future<void> clockOut(String id, {String? notes}) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final now = DateTime.now().toIso8601String();
    final updated = existing.copyWith(
      clockOut: now,
      notes: notes ?? existing.notes,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'attendance', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> approve(String id, String approvedBy) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      approvedBy: approvedBy,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'attendance', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> reject(String id, {String? reason}) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      status: 'absent',
      notes: reason ?? existing.notes,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'attendance', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> delete(String id) async {
    final box = _box();
    await box.delete(id);
  }

  static List<AttendanceModel> getByDateRange(
      String startDate, String endDate,
      {String? branchId}) {
    return getAll(branchId: branchId).where((e) {
      final date = DateTime.tryParse(e.date);
      final start = DateTime.tryParse(startDate);
      final end = DateTime.tryParse(endDate);
      if (date == null || start == null || end == null) return false;
      return !date.isBefore(start) && !date.isAfter(end);
    }).toList();
  }

  static AttendanceReport getReport(
      {required int month, required int year, String? branchId}) {
    final monthStr = month.toString().padLeft(2, '0');
    final startDate = '$year-$monthStr-01';
    final endDate = '$year-$monthStr-31';

    final records = getByDateRange(startDate, endDate, branchId: branchId);

    final summary = AttendanceSummary(
      present: records.where((r) => r.status == 'present').length,
      late: records.where((r) => r.status == 'late').length,
      absent: records.where((r) => r.status == 'absent').length,
      halfDay: records.where((r) => r.status == 'half-day').length,
    );

    final employeeIds = records.map((r) => r.employeeId).toSet();
    final workingDays = records.map((r) => r.date).toSet();

    return AttendanceReport(
      month: monthStr,
      year: year,
      totalEmployees: employeeIds.length,
      totalWorkingDays: workingDays.length,
      summary: summary,
      records: records,
    );
  }
}
