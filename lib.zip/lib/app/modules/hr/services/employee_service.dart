import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/sync_service.dart';
import '../models/employee_model.dart';

class EmployeeService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static Box _box() => Hive.box('hr_employees');

  static List<EmployeeModel> getAll({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = _box();
    final employees = box.values
        .whereType<Map>()
        .map((e) => EmployeeModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => branchId == null || e.branchId == bid)
        .toList();
    employees.sort((a, b) => a.name.compareTo(b.name));
    return employees;
  }

  static List<EmployeeModel> getActive({String? branchId}) {
    return getAll(branchId: branchId)
        .where((e) => e.status == 'active')
        .toList();
  }

  static EmployeeModel? getById(String id) {
    final box = _box();
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return EmployeeModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<String> create({
    required String name,
    String phone = '',
    String email = '',
    String departmentId = '',
    String departmentName = '',
    String jobTitle = '',
    double salary = 0,
    String? notes,
  }) async {
    final box = _box();
    final id = const Uuid().v4();
    final now = DateTime.now();
    final employee = EmployeeModel(
      id: id,
      name: name,
      phone: phone,
      email: email,
      departmentId: departmentId,
      departmentName: departmentName,
      jobTitle: jobTitle,
      salary: salary,
      status: 'active',
      branchId: _currentBranchId,
      createdById: AuthService.currentUser?.id ?? '',
      createdByName: AuthService.currentUser?.name,
      notes: notes,
      createdAt: now,
      updatedAt: now,
    );
    await box.putSynced(id, employee.toJson(), table: 'employees', branchId: _currentBranchId);
    return id;
  }

  static Future<void> update(String id, {
    String? name,
    String? phone,
    String? email,
    String? departmentId,
    String? departmentName,
    String? jobTitle,
    double? salary,
    String? status,
    String? notes,
  }) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      name: name ?? existing.name,
      phone: phone ?? existing.phone,
      email: email ?? existing.email,
      departmentId: departmentId ?? existing.departmentId,
      departmentName: departmentName ?? existing.departmentName,
      jobTitle: jobTitle ?? existing.jobTitle,
      salary: salary ?? existing.salary,
      status: status ?? existing.status,
      notes: notes ?? existing.notes,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'employees', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> delete(String id) async {
    final box = _box();
    await box.delete(id);
  }

  static Future<void> deactivate(String id) async {
    await update(id, status: 'inactive');
  }

  static int nextNumber() {
    final employees = getAll();
    if (employees.isEmpty) return 1;
    return employees.length + 1;
  }
}
