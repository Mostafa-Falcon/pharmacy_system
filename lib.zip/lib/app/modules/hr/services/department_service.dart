import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/sync_service.dart';
import '../models/department_model.dart';

class DepartmentService {
  static Box _box() => Hive.box('hr_departments');

  static List<DepartmentModel> getAll() {
    final box = _box();
    final departments = box.values
        .whereType<Map>()
        .map((e) => DepartmentModel.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    departments.sort((a, b) => a.name.compareTo(b.name));
    return departments;
  }

  static DepartmentModel? getById(String id) {
    final box = _box();
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return DepartmentModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<String> create({
    required String name,
    String? managerId,
    String? managerName,
    String? description,
  }) async {
    final box = _box();
    final id = const Uuid().v4();
    final now = DateTime.now();

    final department = DepartmentModel(
      id: id,
      name: name,
      managerId: managerId,
      managerName: managerName,
      description: description,
      employeeCount: 0,
      createdAt: now,
      updatedAt: now,
    );
    await box.putSynced(id, department.toJson(), table: 'departments', branchId: AuthService.currentBranchId ?? '');
    return id;
  }

  static Future<void> update(String id, {
    String? name,
    String? managerId,
    String? managerName,
    String? description,
    int? employeeCount,
  }) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      name: name ?? existing.name,
      managerId: managerId,
      managerName: managerName,
      description: description,
      employeeCount: employeeCount ?? existing.employeeCount,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'departments', branchId: AuthService.currentBranchId ?? '', type: SyncOperationType.update);
  }

  static Future<void> delete(String id) async {
    final box = _box();
    await box.delete(id);
  }

  static Future<void> incrementEmployeeCount(String id) async {
    final dept = getById(id);
    if (dept == null) return;
    await update(id, employeeCount: dept.employeeCount + 1);
  }

  static Future<void> decrementEmployeeCount(String id) async {
    final dept = getById(id);
    if (dept == null) return;
    await update(id,
        employeeCount: (dept.employeeCount - 1).clamp(0, 999999));
  }
}
