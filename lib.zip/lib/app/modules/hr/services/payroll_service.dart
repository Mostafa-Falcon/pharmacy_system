import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/sync_service.dart';
import '../models/payroll_model.dart';
import '../models/employee_model.dart';
import 'employee_service.dart';

class PayrollService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static Box _payrollBox() => Hive.box('hr_payroll');
  static Box _linesBox() => Hive.box('hr_payroll_lines');

  static List<PayrollModel> getAll({int? month, int? year, String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = _payrollBox();
    var records = box.values
        .whereType<Map>()
        .map((e) => PayrollModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => branchId == null || e.branchId == bid)
        .toList();
    if (month != null) {
      records = records.where((e) => e.month == month).toList();
    }
    if (year != null) {
      records = records.where((e) => e.year == year).toList();
    }
    records.sort((a, b) {
      final c = b.year.compareTo(a.year);
      if (c != 0) return c;
      return b.month.compareTo(a.month);
    });
    return records;
  }

  static PayrollModel? getById(String id) {
    final box = _payrollBox();
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return PayrollModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<String> create({
    required int month,
    required int year,
  }) async {
    final box = _payrollBox();
    final id = const Uuid().v4();
    final now = DateTime.now();

    final payroll = PayrollModel(
      id: id,
      month: month,
      year: year,
      branchId: _currentBranchId,
      status: 'draft',
      createdAt: now,
      updatedAt: now,
    );
    await box.putSynced(id, payroll.toJson(), table: 'payroll', branchId: _currentBranchId);
    return id;
  }

  static Future<void> update(String id, {
    String? status,
    double? totalSalaries,
    double? totalAdjustments,
    double? netTotal,
    int? employeeCount,
  }) async {
    final box = _payrollBox();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      status: status ?? existing.status,
      totalSalaries: totalSalaries ?? existing.totalSalaries,
      totalAdjustments: totalAdjustments ?? existing.totalAdjustments,
      netTotal: netTotal ?? existing.netTotal,
      employeeCount: employeeCount ?? existing.employeeCount,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'payroll', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> process(String id) async {
    final box = _payrollBox();
    final existing = getById(id);
    if (existing == null) return;

    final employees = EmployeeService.getActive();
    double totalSalaries = 0;
    double totalAdjustments = 0;

    for (final emp in employees) {
      final line = _calculatePayrollLine(id, emp);
      totalSalaries += line.baseSalary;
      totalAdjustments += (line.bonuses - line.deductions + line.overtime);
    }

    final netTotal = totalSalaries + totalAdjustments;

    final updated = existing.copyWith(
      status: 'processing',
      totalSalaries: totalSalaries,
      totalAdjustments: totalAdjustments,
      netTotal: netTotal,
      employeeCount: employees.length,
      processedAt: DateTime.now().toIso8601String(),
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'payroll', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static PayrollLineModel _calculatePayrollLine(
      String payrollId, EmployeeModel emp) {
    final id = '${payrollId}_${emp.id}';
    final now = DateTime.now();
    return PayrollLineModel(
      id: id,
      payrollId: payrollId,
      employeeId: emp.id,
      employeeName: emp.name,
      baseSalary: emp.salary,
      workingDays: 26,
      absentDays: 0,
      overtime: 0,
      bonuses: 0,
      deductions: 0,
      netSalary: emp.salary,
      createdAt: now,
      updatedAt: now,
    );
  }

  static Future<void> addLine(PayrollLineModel line) async {
    final box = _linesBox();
    await box.put(line.id, line.toJson());
    await _recalculatePayroll(line.payrollId);
  }

  static List<PayrollLineModel> getLines(String payrollId) {
    final box = _linesBox();
    return box.values
        .whereType<Map>()
        .map((e) => PayrollLineModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.payrollId == payrollId)
        .toList();
  }

  static Future<void> _recalculatePayroll(String payrollId) async {
    final lines = getLines(payrollId);
    final totalSalaries =
        lines.fold<double>(0, (sum, l) => sum + l.baseSalary);
    final totalAdjustments = lines.fold<double>(
        0, (sum, l) => sum + (l.bonuses - l.deductions + l.overtime));
    final netTotal = lines.fold<double>(0, (sum, l) => sum + l.netSalary);

    await update(
      payrollId,
      totalSalaries: totalSalaries,
      totalAdjustments: totalAdjustments,
      netTotal: netTotal,
      employeeCount: lines.length,
    );
  }

  static Future<void> approve(String id) async {
    final now = DateTime.now().toIso8601String();
    await update(
      id,
      status: 'approved',
    );
    final box = _payrollBox();
    final existing = getById(id);
    if (existing == null) return;
    final updated = existing.copyWith(
      status: 'approved',
      approvedAt: now,
      approvedBy: AuthService.currentUser?.id ?? '',
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'payroll', branchId: _currentBranchId, type: SyncOperationType.update);
  }

  static Future<void> markPaid(String id) async {
    await update(id, status: 'paid');
  }

  static Future<void> delete(String id) async {
    final box = _payrollBox();
    await box.delete(id);
    // Delete associated lines
    final lines = getLines(id);
    final linesBox = _linesBox();
    for (final line in lines) {
      await linesBox.delete(line.id);
    }
  }

  static PayrollModel? getCurrentPeriod() {
    final now = DateTime.now();
    final records = getAll(month: now.month, year: now.year);
    return records.isNotEmpty ? records.first : null;
  }
}
