import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/sync_service.dart';
import '../models/leave_model.dart';

class LeaveService {
  static Box _box() => Hive.box('hr_leave_records');

  static List<LeaveModel> getAll({String? status, String? employeeId}) {
    final box = _box();
    var records = box.values
        .whereType<Map>()
        .map((e) => LeaveModel.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    if (status != null) {
      records = records.where((e) => e.status == status).toList();
    }
    if (employeeId != null) {
      records = records.where((e) => e.employeeId == employeeId).toList();
    }
    records.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return records;
  }

  static LeaveModel? getById(String id) {
    final box = _box();
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return LeaveModel.fromJson(Map<String, dynamic>.from(data));
  }

  static int _calculateDuration(String startDate, String endDate) {
    final start = DateTime.tryParse(startDate);
    final end = DateTime.tryParse(endDate);
    if (start == null || end == null) return 1;
    return (end.difference(start).inDays + 1).clamp(1, 365);
  }

  static Future<String> create({
    required String employeeId,
    String employeeName = '',
    required String leaveType,
    required String startDate,
    required String endDate,
    String? reason,
  }) async {
    final box = _box();
    final id = const Uuid().v4();
    final duration = _calculateDuration(startDate, endDate);
    final now = DateTime.now();

    final record = LeaveModel(
      id: id,
      employeeId: employeeId,
      employeeName: employeeName,
      leaveType: leaveType,
      startDate: startDate,
      endDate: endDate,
      duration: duration,
      status: 'pending',
      reason: reason,
      createdAt: now,
      updatedAt: now,
    );
    await box.putSynced(id, record.toJson(), table: 'leaves', branchId: AuthService.currentBranchId ?? '');
    return id;
  }

  static Future<void> approve(String id, String approvedBy) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      status: 'approved',
      approvedBy: approvedBy,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'leaves', branchId: AuthService.currentBranchId ?? '', type: SyncOperationType.update);
  }

  static Future<void> reject(String id, {String? reason}) async {
    final box = _box();
    final existing = getById(id);
    if (existing == null) return;

    final updated = existing.copyWith(
      status: 'rejected',
      rejectionReason: reason,
      updatedAt: DateTime.now(),
    );
    await box.putSynced(id, updated.toJson(), table: 'leaves', branchId: AuthService.currentBranchId ?? '', type: SyncOperationType.update);
  }

  static Future<void> delete(String id) async {
    final box = _box();
    await box.delete(id);
  }

  static LeaveBalance getBalance(String employeeId) {
    final approvedRecords =
        getAll(status: 'approved', employeeId: employeeId);

    final sickDays = approvedRecords
        .where((r) => r.leaveType == 'sick')
        .fold<int>(0, (sum, r) => sum + r.duration);
    final annualDays = approvedRecords
        .where((r) => r.leaveType == 'annual')
        .fold<int>(0, (sum, r) => sum + r.duration);
    final emergencyDays = approvedRecords
        .where((r) => r.leaveType == 'emergency')
        .fold<int>(0, (sum, r) => sum + r.duration);
    final unpaidDays = approvedRecords
        .where((r) => r.leaveType == 'unpaid')
        .fold<int>(0, (sum, r) => sum + r.duration);

    return LeaveBalance(
      sick: LeaveTypeBalance(total: 30, used: sickDays),
      annual: LeaveTypeBalance(total: 21, used: annualDays),
      emergency: LeaveTypeBalance(total: 7, used: emergencyDays),
      unpaid: LeaveTypeBalance(total: 30, used: unpaidDays),
    );
  }
}
