// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'attendance_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AttendanceModel _$AttendanceModelFromJson(Map<String, dynamic> json) {
  return _AttendanceModel.fromJson(json);
}

/// @nodoc
mixin _$AttendanceModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_id')
  String get employeeId => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_name')
  String get employeeName => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'clock_in')
  String get clockIn => throw _privateConstructorUsedError;
  @JsonKey(name: 'clock_out')
  String? get clockOut => throw _privateConstructorUsedError;
  String get date => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'approved_by')
  String? get approvedBy => throw _privateConstructorUsedError;
  String? get notes => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AttendanceModelCopyWith<AttendanceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttendanceModelCopyWith<$Res> {
  factory $AttendanceModelCopyWith(
          AttendanceModel value, $Res Function(AttendanceModel) then) =
      _$AttendanceModelCopyWithImpl<$Res, AttendanceModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'clock_in') String clockIn,
      @JsonKey(name: 'clock_out') String? clockOut,
      String date,
      String status,
      @JsonKey(name: 'approved_by') String? approvedBy,
      String? notes,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$AttendanceModelCopyWithImpl<$Res, $Val extends AttendanceModel>
    implements $AttendanceModelCopyWith<$Res> {
  _$AttendanceModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? branchId = null,
    Object? clockIn = null,
    Object? clockOut = freezed,
    Object? date = null,
    Object? status = null,
    Object? approvedBy = freezed,
    Object? notes = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      clockIn: null == clockIn
          ? _value.clockIn
          : clockIn // ignore: cast_nullable_to_non_nullable
              as String,
      clockOut: freezed == clockOut
          ? _value.clockOut
          : clockOut // ignore: cast_nullable_to_non_nullable
              as String?,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AttendanceModelImplCopyWith<$Res>
    implements $AttendanceModelCopyWith<$Res> {
  factory _$$AttendanceModelImplCopyWith(_$AttendanceModelImpl value,
          $Res Function(_$AttendanceModelImpl) then) =
      __$$AttendanceModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'clock_in') String clockIn,
      @JsonKey(name: 'clock_out') String? clockOut,
      String date,
      String status,
      @JsonKey(name: 'approved_by') String? approvedBy,
      String? notes,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$AttendanceModelImplCopyWithImpl<$Res>
    extends _$AttendanceModelCopyWithImpl<$Res, _$AttendanceModelImpl>
    implements _$$AttendanceModelImplCopyWith<$Res> {
  __$$AttendanceModelImplCopyWithImpl(
      _$AttendanceModelImpl _value, $Res Function(_$AttendanceModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? branchId = null,
    Object? clockIn = null,
    Object? clockOut = freezed,
    Object? date = null,
    Object? status = null,
    Object? approvedBy = freezed,
    Object? notes = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$AttendanceModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      clockIn: null == clockIn
          ? _value.clockIn
          : clockIn // ignore: cast_nullable_to_non_nullable
              as String,
      clockOut: freezed == clockOut
          ? _value.clockOut
          : clockOut // ignore: cast_nullable_to_non_nullable
              as String?,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AttendanceModelImpl extends _AttendanceModel {
  const _$AttendanceModelImpl(
      {required this.id,
      @JsonKey(name: 'employee_id') required this.employeeId,
      @JsonKey(name: 'employee_name') this.employeeName = '',
      @JsonKey(name: 'branch_id') this.branchId = '',
      @JsonKey(name: 'clock_in') this.clockIn = '',
      @JsonKey(name: 'clock_out') this.clockOut,
      required this.date,
      this.status = 'present',
      @JsonKey(name: 'approved_by') this.approvedBy,
      this.notes,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : super._();

  factory _$AttendanceModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$AttendanceModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'employee_id')
  final String employeeId;
  @override
  @JsonKey(name: 'employee_name')
  final String employeeName;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey(name: 'clock_in')
  final String clockIn;
  @override
  @JsonKey(name: 'clock_out')
  final String? clockOut;
  @override
  final String date;
  @override
  @JsonKey()
  final String status;
  @override
  @JsonKey(name: 'approved_by')
  final String? approvedBy;
  @override
  final String? notes;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'AttendanceModel(id: $id, employeeId: $employeeId, employeeName: $employeeName, branchId: $branchId, clockIn: $clockIn, clockOut: $clockOut, date: $date, status: $status, approvedBy: $approvedBy, notes: $notes, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AttendanceModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.employeeId, employeeId) ||
                other.employeeId == employeeId) &&
            (identical(other.employeeName, employeeName) ||
                other.employeeName == employeeName) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.clockIn, clockIn) || other.clockIn == clockIn) &&
            (identical(other.clockOut, clockOut) ||
                other.clockOut == clockOut) &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.approvedBy, approvedBy) ||
                other.approvedBy == approvedBy) &&
            (identical(other.notes, notes) || other.notes == notes) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      employeeId,
      employeeName,
      branchId,
      clockIn,
      clockOut,
      date,
      status,
      approvedBy,
      notes,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AttendanceModelImplCopyWith<_$AttendanceModelImpl> get copyWith =>
      __$$AttendanceModelImplCopyWithImpl<_$AttendanceModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AttendanceModelImplToJson(
      this,
    );
  }
}

abstract class _AttendanceModel extends AttendanceModel {
  const factory _AttendanceModel(
          {required final String id,
          @JsonKey(name: 'employee_id') required final String employeeId,
          @JsonKey(name: 'employee_name') final String employeeName,
          @JsonKey(name: 'branch_id') final String branchId,
          @JsonKey(name: 'clock_in') final String clockIn,
          @JsonKey(name: 'clock_out') final String? clockOut,
          required final String date,
          final String status,
          @JsonKey(name: 'approved_by') final String? approvedBy,
          final String? notes,
          @JsonKey(name: 'created_at') required final DateTime createdAt,
          @JsonKey(name: 'updated_at') required final DateTime updatedAt}) =
      _$AttendanceModelImpl;
  const _AttendanceModel._() : super._();

  factory _AttendanceModel.fromJson(Map<String, dynamic> json) =
      _$AttendanceModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'employee_id')
  String get employeeId;
  @override
  @JsonKey(name: 'employee_name')
  String get employeeName;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  @JsonKey(name: 'clock_in')
  String get clockIn;
  @override
  @JsonKey(name: 'clock_out')
  String? get clockOut;
  @override
  String get date;
  @override
  String get status;
  @override
  @JsonKey(name: 'approved_by')
  String? get approvedBy;
  @override
  String? get notes;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$AttendanceModelImplCopyWith<_$AttendanceModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

AttendanceReport _$AttendanceReportFromJson(Map<String, dynamic> json) {
  return _AttendanceReport.fromJson(json);
}

/// @nodoc
mixin _$AttendanceReport {
  String get month => throw _privateConstructorUsedError;
  int get year => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_employees')
  int get totalEmployees => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_working_days')
  int get totalWorkingDays => throw _privateConstructorUsedError;
  AttendanceSummary get summary => throw _privateConstructorUsedError;
  List<AttendanceModel> get records => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AttendanceReportCopyWith<AttendanceReport> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttendanceReportCopyWith<$Res> {
  factory $AttendanceReportCopyWith(
          AttendanceReport value, $Res Function(AttendanceReport) then) =
      _$AttendanceReportCopyWithImpl<$Res, AttendanceReport>;
  @useResult
  $Res call(
      {String month,
      int year,
      @JsonKey(name: 'total_employees') int totalEmployees,
      @JsonKey(name: 'total_working_days') int totalWorkingDays,
      AttendanceSummary summary,
      List<AttendanceModel> records});

  $AttendanceSummaryCopyWith<$Res> get summary;
}

/// @nodoc
class _$AttendanceReportCopyWithImpl<$Res, $Val extends AttendanceReport>
    implements $AttendanceReportCopyWith<$Res> {
  _$AttendanceReportCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? month = null,
    Object? year = null,
    Object? totalEmployees = null,
    Object? totalWorkingDays = null,
    Object? summary = null,
    Object? records = null,
  }) {
    return _then(_value.copyWith(
      month: null == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as String,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      totalEmployees: null == totalEmployees
          ? _value.totalEmployees
          : totalEmployees // ignore: cast_nullable_to_non_nullable
              as int,
      totalWorkingDays: null == totalWorkingDays
          ? _value.totalWorkingDays
          : totalWorkingDays // ignore: cast_nullable_to_non_nullable
              as int,
      summary: null == summary
          ? _value.summary
          : summary // ignore: cast_nullable_to_non_nullable
              as AttendanceSummary,
      records: null == records
          ? _value.records
          : records // ignore: cast_nullable_to_non_nullable
              as List<AttendanceModel>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AttendanceSummaryCopyWith<$Res> get summary {
    return $AttendanceSummaryCopyWith<$Res>(_value.summary, (value) {
      return _then(_value.copyWith(summary: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$AttendanceReportImplCopyWith<$Res>
    implements $AttendanceReportCopyWith<$Res> {
  factory _$$AttendanceReportImplCopyWith(_$AttendanceReportImpl value,
          $Res Function(_$AttendanceReportImpl) then) =
      __$$AttendanceReportImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String month,
      int year,
      @JsonKey(name: 'total_employees') int totalEmployees,
      @JsonKey(name: 'total_working_days') int totalWorkingDays,
      AttendanceSummary summary,
      List<AttendanceModel> records});

  @override
  $AttendanceSummaryCopyWith<$Res> get summary;
}

/// @nodoc
class __$$AttendanceReportImplCopyWithImpl<$Res>
    extends _$AttendanceReportCopyWithImpl<$Res, _$AttendanceReportImpl>
    implements _$$AttendanceReportImplCopyWith<$Res> {
  __$$AttendanceReportImplCopyWithImpl(_$AttendanceReportImpl _value,
      $Res Function(_$AttendanceReportImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? month = null,
    Object? year = null,
    Object? totalEmployees = null,
    Object? totalWorkingDays = null,
    Object? summary = null,
    Object? records = null,
  }) {
    return _then(_$AttendanceReportImpl(
      month: null == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as String,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      totalEmployees: null == totalEmployees
          ? _value.totalEmployees
          : totalEmployees // ignore: cast_nullable_to_non_nullable
              as int,
      totalWorkingDays: null == totalWorkingDays
          ? _value.totalWorkingDays
          : totalWorkingDays // ignore: cast_nullable_to_non_nullable
              as int,
      summary: null == summary
          ? _value.summary
          : summary // ignore: cast_nullable_to_non_nullable
              as AttendanceSummary,
      records: null == records
          ? _value._records
          : records // ignore: cast_nullable_to_non_nullable
              as List<AttendanceModel>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AttendanceReportImpl extends _AttendanceReport {
  const _$AttendanceReportImpl(
      {required this.month,
      required this.year,
      @JsonKey(name: 'total_employees') this.totalEmployees = 0,
      @JsonKey(name: 'total_working_days') this.totalWorkingDays = 0,
      this.summary = const AttendanceSummary(),
      final List<AttendanceModel> records = const []})
      : _records = records,
        super._();

  factory _$AttendanceReportImpl.fromJson(Map<String, dynamic> json) =>
      _$$AttendanceReportImplFromJson(json);

  @override
  final String month;
  @override
  final int year;
  @override
  @JsonKey(name: 'total_employees')
  final int totalEmployees;
  @override
  @JsonKey(name: 'total_working_days')
  final int totalWorkingDays;
  @override
  @JsonKey()
  final AttendanceSummary summary;
  final List<AttendanceModel> _records;
  @override
  @JsonKey()
  List<AttendanceModel> get records {
    if (_records is EqualUnmodifiableListView) return _records;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_records);
  }

  @override
  String toString() {
    return 'AttendanceReport(month: $month, year: $year, totalEmployees: $totalEmployees, totalWorkingDays: $totalWorkingDays, summary: $summary, records: $records)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AttendanceReportImpl &&
            (identical(other.month, month) || other.month == month) &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.totalEmployees, totalEmployees) ||
                other.totalEmployees == totalEmployees) &&
            (identical(other.totalWorkingDays, totalWorkingDays) ||
                other.totalWorkingDays == totalWorkingDays) &&
            (identical(other.summary, summary) || other.summary == summary) &&
            const DeepCollectionEquality().equals(other._records, _records));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, month, year, totalEmployees,
      totalWorkingDays, summary, const DeepCollectionEquality().hash(_records));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AttendanceReportImplCopyWith<_$AttendanceReportImpl> get copyWith =>
      __$$AttendanceReportImplCopyWithImpl<_$AttendanceReportImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AttendanceReportImplToJson(
      this,
    );
  }
}

abstract class _AttendanceReport extends AttendanceReport {
  const factory _AttendanceReport(
      {required final String month,
      required final int year,
      @JsonKey(name: 'total_employees') final int totalEmployees,
      @JsonKey(name: 'total_working_days') final int totalWorkingDays,
      final AttendanceSummary summary,
      final List<AttendanceModel> records}) = _$AttendanceReportImpl;
  const _AttendanceReport._() : super._();

  factory _AttendanceReport.fromJson(Map<String, dynamic> json) =
      _$AttendanceReportImpl.fromJson;

  @override
  String get month;
  @override
  int get year;
  @override
  @JsonKey(name: 'total_employees')
  int get totalEmployees;
  @override
  @JsonKey(name: 'total_working_days')
  int get totalWorkingDays;
  @override
  AttendanceSummary get summary;
  @override
  List<AttendanceModel> get records;
  @override
  @JsonKey(ignore: true)
  _$$AttendanceReportImplCopyWith<_$AttendanceReportImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

AttendanceSummary _$AttendanceSummaryFromJson(Map<String, dynamic> json) {
  return _AttendanceSummary.fromJson(json);
}

/// @nodoc
mixin _$AttendanceSummary {
  int get present => throw _privateConstructorUsedError;
  int get late => throw _privateConstructorUsedError;
  int get absent => throw _privateConstructorUsedError;
  @JsonKey(name: 'half_day')
  int get halfDay => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AttendanceSummaryCopyWith<AttendanceSummary> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttendanceSummaryCopyWith<$Res> {
  factory $AttendanceSummaryCopyWith(
          AttendanceSummary value, $Res Function(AttendanceSummary) then) =
      _$AttendanceSummaryCopyWithImpl<$Res, AttendanceSummary>;
  @useResult
  $Res call(
      {int present,
      int late,
      int absent,
      @JsonKey(name: 'half_day') int halfDay});
}

/// @nodoc
class _$AttendanceSummaryCopyWithImpl<$Res, $Val extends AttendanceSummary>
    implements $AttendanceSummaryCopyWith<$Res> {
  _$AttendanceSummaryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? present = null,
    Object? late = null,
    Object? absent = null,
    Object? halfDay = null,
  }) {
    return _then(_value.copyWith(
      present: null == present
          ? _value.present
          : present // ignore: cast_nullable_to_non_nullable
              as int,
      late: null == late
          ? _value.late
          : late // ignore: cast_nullable_to_non_nullable
              as int,
      absent: null == absent
          ? _value.absent
          : absent // ignore: cast_nullable_to_non_nullable
              as int,
      halfDay: null == halfDay
          ? _value.halfDay
          : halfDay // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AttendanceSummaryImplCopyWith<$Res>
    implements $AttendanceSummaryCopyWith<$Res> {
  factory _$$AttendanceSummaryImplCopyWith(_$AttendanceSummaryImpl value,
          $Res Function(_$AttendanceSummaryImpl) then) =
      __$$AttendanceSummaryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int present,
      int late,
      int absent,
      @JsonKey(name: 'half_day') int halfDay});
}

/// @nodoc
class __$$AttendanceSummaryImplCopyWithImpl<$Res>
    extends _$AttendanceSummaryCopyWithImpl<$Res, _$AttendanceSummaryImpl>
    implements _$$AttendanceSummaryImplCopyWith<$Res> {
  __$$AttendanceSummaryImplCopyWithImpl(_$AttendanceSummaryImpl _value,
      $Res Function(_$AttendanceSummaryImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? present = null,
    Object? late = null,
    Object? absent = null,
    Object? halfDay = null,
  }) {
    return _then(_$AttendanceSummaryImpl(
      present: null == present
          ? _value.present
          : present // ignore: cast_nullable_to_non_nullable
              as int,
      late: null == late
          ? _value.late
          : late // ignore: cast_nullable_to_non_nullable
              as int,
      absent: null == absent
          ? _value.absent
          : absent // ignore: cast_nullable_to_non_nullable
              as int,
      halfDay: null == halfDay
          ? _value.halfDay
          : halfDay // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AttendanceSummaryImpl extends _AttendanceSummary {
  const _$AttendanceSummaryImpl(
      {this.present = 0,
      this.late = 0,
      this.absent = 0,
      @JsonKey(name: 'half_day') this.halfDay = 0})
      : super._();

  factory _$AttendanceSummaryImpl.fromJson(Map<String, dynamic> json) =>
      _$$AttendanceSummaryImplFromJson(json);

  @override
  @JsonKey()
  final int present;
  @override
  @JsonKey()
  final int late;
  @override
  @JsonKey()
  final int absent;
  @override
  @JsonKey(name: 'half_day')
  final int halfDay;

  @override
  String toString() {
    return 'AttendanceSummary(present: $present, late: $late, absent: $absent, halfDay: $halfDay)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AttendanceSummaryImpl &&
            (identical(other.present, present) || other.present == present) &&
            (identical(other.late, late) || other.late == late) &&
            (identical(other.absent, absent) || other.absent == absent) &&
            (identical(other.halfDay, halfDay) || other.halfDay == halfDay));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, present, late, absent, halfDay);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AttendanceSummaryImplCopyWith<_$AttendanceSummaryImpl> get copyWith =>
      __$$AttendanceSummaryImplCopyWithImpl<_$AttendanceSummaryImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AttendanceSummaryImplToJson(
      this,
    );
  }
}

abstract class _AttendanceSummary extends AttendanceSummary {
  const factory _AttendanceSummary(
      {final int present,
      final int late,
      final int absent,
      @JsonKey(name: 'half_day') final int halfDay}) = _$AttendanceSummaryImpl;
  const _AttendanceSummary._() : super._();

  factory _AttendanceSummary.fromJson(Map<String, dynamic> json) =
      _$AttendanceSummaryImpl.fromJson;

  @override
  int get present;
  @override
  int get late;
  @override
  int get absent;
  @override
  @JsonKey(name: 'half_day')
  int get halfDay;
  @override
  @JsonKey(ignore: true)
  _$$AttendanceSummaryImplCopyWith<_$AttendanceSummaryImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
