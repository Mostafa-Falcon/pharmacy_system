// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'payroll_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PayrollModel _$PayrollModelFromJson(Map<String, dynamic> json) {
  return _PayrollModel.fromJson(json);
}

/// @nodoc
mixin _$PayrollModel {
  String get id => throw _privateConstructorUsedError;
  int get month => throw _privateConstructorUsedError;
  int get year => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_salaries')
  double get totalSalaries => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_adjustments')
  double get totalAdjustments => throw _privateConstructorUsedError;
  @JsonKey(name: 'net_total')
  double get netTotal => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_count')
  int get employeeCount => throw _privateConstructorUsedError;
  @JsonKey(name: 'processed_at')
  String? get processedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'approved_at')
  String? get approvedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'approved_by')
  String? get approvedBy => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PayrollModelCopyWith<PayrollModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PayrollModelCopyWith<$Res> {
  factory $PayrollModelCopyWith(
          PayrollModel value, $Res Function(PayrollModel) then) =
      _$PayrollModelCopyWithImpl<$Res, PayrollModel>;
  @useResult
  $Res call(
      {String id,
      int month,
      int year,
      @JsonKey(name: 'branch_id') String branchId,
      String status,
      @JsonKey(name: 'total_salaries') double totalSalaries,
      @JsonKey(name: 'total_adjustments') double totalAdjustments,
      @JsonKey(name: 'net_total') double netTotal,
      @JsonKey(name: 'employee_count') int employeeCount,
      @JsonKey(name: 'processed_at') String? processedAt,
      @JsonKey(name: 'approved_at') String? approvedAt,
      @JsonKey(name: 'approved_by') String? approvedBy,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$PayrollModelCopyWithImpl<$Res, $Val extends PayrollModel>
    implements $PayrollModelCopyWith<$Res> {
  _$PayrollModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? month = null,
    Object? year = null,
    Object? branchId = null,
    Object? status = null,
    Object? totalSalaries = null,
    Object? totalAdjustments = null,
    Object? netTotal = null,
    Object? employeeCount = null,
    Object? processedAt = freezed,
    Object? approvedAt = freezed,
    Object? approvedBy = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      month: null == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      totalSalaries: null == totalSalaries
          ? _value.totalSalaries
          : totalSalaries // ignore: cast_nullable_to_non_nullable
              as double,
      totalAdjustments: null == totalAdjustments
          ? _value.totalAdjustments
          : totalAdjustments // ignore: cast_nullable_to_non_nullable
              as double,
      netTotal: null == netTotal
          ? _value.netTotal
          : netTotal // ignore: cast_nullable_to_non_nullable
              as double,
      employeeCount: null == employeeCount
          ? _value.employeeCount
          : employeeCount // ignore: cast_nullable_to_non_nullable
              as int,
      processedAt: freezed == processedAt
          ? _value.processedAt
          : processedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedAt: freezed == approvedAt
          ? _value.approvedAt
          : approvedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PayrollModelImplCopyWith<$Res>
    implements $PayrollModelCopyWith<$Res> {
  factory _$$PayrollModelImplCopyWith(
          _$PayrollModelImpl value, $Res Function(_$PayrollModelImpl) then) =
      __$$PayrollModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      int month,
      int year,
      @JsonKey(name: 'branch_id') String branchId,
      String status,
      @JsonKey(name: 'total_salaries') double totalSalaries,
      @JsonKey(name: 'total_adjustments') double totalAdjustments,
      @JsonKey(name: 'net_total') double netTotal,
      @JsonKey(name: 'employee_count') int employeeCount,
      @JsonKey(name: 'processed_at') String? processedAt,
      @JsonKey(name: 'approved_at') String? approvedAt,
      @JsonKey(name: 'approved_by') String? approvedBy,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$PayrollModelImplCopyWithImpl<$Res>
    extends _$PayrollModelCopyWithImpl<$Res, _$PayrollModelImpl>
    implements _$$PayrollModelImplCopyWith<$Res> {
  __$$PayrollModelImplCopyWithImpl(
      _$PayrollModelImpl _value, $Res Function(_$PayrollModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? month = null,
    Object? year = null,
    Object? branchId = null,
    Object? status = null,
    Object? totalSalaries = null,
    Object? totalAdjustments = null,
    Object? netTotal = null,
    Object? employeeCount = null,
    Object? processedAt = freezed,
    Object? approvedAt = freezed,
    Object? approvedBy = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$PayrollModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      month: null == month
          ? _value.month
          : month // ignore: cast_nullable_to_non_nullable
              as int,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as int,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      totalSalaries: null == totalSalaries
          ? _value.totalSalaries
          : totalSalaries // ignore: cast_nullable_to_non_nullable
              as double,
      totalAdjustments: null == totalAdjustments
          ? _value.totalAdjustments
          : totalAdjustments // ignore: cast_nullable_to_non_nullable
              as double,
      netTotal: null == netTotal
          ? _value.netTotal
          : netTotal // ignore: cast_nullable_to_non_nullable
              as double,
      employeeCount: null == employeeCount
          ? _value.employeeCount
          : employeeCount // ignore: cast_nullable_to_non_nullable
              as int,
      processedAt: freezed == processedAt
          ? _value.processedAt
          : processedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedAt: freezed == approvedAt
          ? _value.approvedAt
          : approvedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PayrollModelImpl extends _PayrollModel {
  const _$PayrollModelImpl(
      {required this.id,
      required this.month,
      required this.year,
      @JsonKey(name: 'branch_id') this.branchId = '',
      this.status = 'draft',
      @JsonKey(name: 'total_salaries') this.totalSalaries = 0,
      @JsonKey(name: 'total_adjustments') this.totalAdjustments = 0,
      @JsonKey(name: 'net_total') this.netTotal = 0,
      @JsonKey(name: 'employee_count') this.employeeCount = 0,
      @JsonKey(name: 'processed_at') this.processedAt,
      @JsonKey(name: 'approved_at') this.approvedAt,
      @JsonKey(name: 'approved_by') this.approvedBy,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : super._();

  factory _$PayrollModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PayrollModelImplFromJson(json);

  @override
  final String id;
  @override
  final int month;
  @override
  final int year;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey()
  final String status;
  @override
  @JsonKey(name: 'total_salaries')
  final double totalSalaries;
  @override
  @JsonKey(name: 'total_adjustments')
  final double totalAdjustments;
  @override
  @JsonKey(name: 'net_total')
  final double netTotal;
  @override
  @JsonKey(name: 'employee_count')
  final int employeeCount;
  @override
  @JsonKey(name: 'processed_at')
  final String? processedAt;
  @override
  @JsonKey(name: 'approved_at')
  final String? approvedAt;
  @override
  @JsonKey(name: 'approved_by')
  final String? approvedBy;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'PayrollModel(id: $id, month: $month, year: $year, branchId: $branchId, status: $status, totalSalaries: $totalSalaries, totalAdjustments: $totalAdjustments, netTotal: $netTotal, employeeCount: $employeeCount, processedAt: $processedAt, approvedAt: $approvedAt, approvedBy: $approvedBy, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PayrollModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.month, month) || other.month == month) &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.totalSalaries, totalSalaries) ||
                other.totalSalaries == totalSalaries) &&
            (identical(other.totalAdjustments, totalAdjustments) ||
                other.totalAdjustments == totalAdjustments) &&
            (identical(other.netTotal, netTotal) ||
                other.netTotal == netTotal) &&
            (identical(other.employeeCount, employeeCount) ||
                other.employeeCount == employeeCount) &&
            (identical(other.processedAt, processedAt) ||
                other.processedAt == processedAt) &&
            (identical(other.approvedAt, approvedAt) ||
                other.approvedAt == approvedAt) &&
            (identical(other.approvedBy, approvedBy) ||
                other.approvedBy == approvedBy) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      month,
      year,
      branchId,
      status,
      totalSalaries,
      totalAdjustments,
      netTotal,
      employeeCount,
      processedAt,
      approvedAt,
      approvedBy,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PayrollModelImplCopyWith<_$PayrollModelImpl> get copyWith =>
      __$$PayrollModelImplCopyWithImpl<_$PayrollModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PayrollModelImplToJson(
      this,
    );
  }
}

abstract class _PayrollModel extends PayrollModel {
  const factory _PayrollModel(
          {required final String id,
          required final int month,
          required final int year,
          @JsonKey(name: 'branch_id') final String branchId,
          final String status,
          @JsonKey(name: 'total_salaries') final double totalSalaries,
          @JsonKey(name: 'total_adjustments') final double totalAdjustments,
          @JsonKey(name: 'net_total') final double netTotal,
          @JsonKey(name: 'employee_count') final int employeeCount,
          @JsonKey(name: 'processed_at') final String? processedAt,
          @JsonKey(name: 'approved_at') final String? approvedAt,
          @JsonKey(name: 'approved_by') final String? approvedBy,
          @JsonKey(name: 'created_at') required final DateTime createdAt,
          @JsonKey(name: 'updated_at') required final DateTime updatedAt}) =
      _$PayrollModelImpl;
  const _PayrollModel._() : super._();

  factory _PayrollModel.fromJson(Map<String, dynamic> json) =
      _$PayrollModelImpl.fromJson;

  @override
  String get id;
  @override
  int get month;
  @override
  int get year;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  String get status;
  @override
  @JsonKey(name: 'total_salaries')
  double get totalSalaries;
  @override
  @JsonKey(name: 'total_adjustments')
  double get totalAdjustments;
  @override
  @JsonKey(name: 'net_total')
  double get netTotal;
  @override
  @JsonKey(name: 'employee_count')
  int get employeeCount;
  @override
  @JsonKey(name: 'processed_at')
  String? get processedAt;
  @override
  @JsonKey(name: 'approved_at')
  String? get approvedAt;
  @override
  @JsonKey(name: 'approved_by')
  String? get approvedBy;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$PayrollModelImplCopyWith<_$PayrollModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PayrollLineModel _$PayrollLineModelFromJson(Map<String, dynamic> json) {
  return _PayrollLineModel.fromJson(json);
}

/// @nodoc
mixin _$PayrollLineModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'payroll_id')
  String get payrollId => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_id')
  String get employeeId => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_name')
  String get employeeName => throw _privateConstructorUsedError;
  @JsonKey(name: 'base_salary')
  double get baseSalary => throw _privateConstructorUsedError;
  @JsonKey(name: 'working_days')
  int get workingDays => throw _privateConstructorUsedError;
  @JsonKey(name: 'absent_days')
  int get absentDays => throw _privateConstructorUsedError;
  double get overtime => throw _privateConstructorUsedError;
  double get bonuses => throw _privateConstructorUsedError;
  double get deductions => throw _privateConstructorUsedError;
  @JsonKey(name: 'net_salary')
  double get netSalary => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PayrollLineModelCopyWith<PayrollLineModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PayrollLineModelCopyWith<$Res> {
  factory $PayrollLineModelCopyWith(
          PayrollLineModel value, $Res Function(PayrollLineModel) then) =
      _$PayrollLineModelCopyWithImpl<$Res, PayrollLineModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'payroll_id') String payrollId,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'base_salary') double baseSalary,
      @JsonKey(name: 'working_days') int workingDays,
      @JsonKey(name: 'absent_days') int absentDays,
      double overtime,
      double bonuses,
      double deductions,
      @JsonKey(name: 'net_salary') double netSalary,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$PayrollLineModelCopyWithImpl<$Res, $Val extends PayrollLineModel>
    implements $PayrollLineModelCopyWith<$Res> {
  _$PayrollLineModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? payrollId = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? baseSalary = null,
    Object? workingDays = null,
    Object? absentDays = null,
    Object? overtime = null,
    Object? bonuses = null,
    Object? deductions = null,
    Object? netSalary = null,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      payrollId: null == payrollId
          ? _value.payrollId
          : payrollId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      baseSalary: null == baseSalary
          ? _value.baseSalary
          : baseSalary // ignore: cast_nullable_to_non_nullable
              as double,
      workingDays: null == workingDays
          ? _value.workingDays
          : workingDays // ignore: cast_nullable_to_non_nullable
              as int,
      absentDays: null == absentDays
          ? _value.absentDays
          : absentDays // ignore: cast_nullable_to_non_nullable
              as int,
      overtime: null == overtime
          ? _value.overtime
          : overtime // ignore: cast_nullable_to_non_nullable
              as double,
      bonuses: null == bonuses
          ? _value.bonuses
          : bonuses // ignore: cast_nullable_to_non_nullable
              as double,
      deductions: null == deductions
          ? _value.deductions
          : deductions // ignore: cast_nullable_to_non_nullable
              as double,
      netSalary: null == netSalary
          ? _value.netSalary
          : netSalary // ignore: cast_nullable_to_non_nullable
              as double,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PayrollLineModelImplCopyWith<$Res>
    implements $PayrollLineModelCopyWith<$Res> {
  factory _$$PayrollLineModelImplCopyWith(_$PayrollLineModelImpl value,
          $Res Function(_$PayrollLineModelImpl) then) =
      __$$PayrollLineModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'payroll_id') String payrollId,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'base_salary') double baseSalary,
      @JsonKey(name: 'working_days') int workingDays,
      @JsonKey(name: 'absent_days') int absentDays,
      double overtime,
      double bonuses,
      double deductions,
      @JsonKey(name: 'net_salary') double netSalary,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$PayrollLineModelImplCopyWithImpl<$Res>
    extends _$PayrollLineModelCopyWithImpl<$Res, _$PayrollLineModelImpl>
    implements _$$PayrollLineModelImplCopyWith<$Res> {
  __$$PayrollLineModelImplCopyWithImpl(_$PayrollLineModelImpl _value,
      $Res Function(_$PayrollLineModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? payrollId = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? baseSalary = null,
    Object? workingDays = null,
    Object? absentDays = null,
    Object? overtime = null,
    Object? bonuses = null,
    Object? deductions = null,
    Object? netSalary = null,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$PayrollLineModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      payrollId: null == payrollId
          ? _value.payrollId
          : payrollId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      baseSalary: null == baseSalary
          ? _value.baseSalary
          : baseSalary // ignore: cast_nullable_to_non_nullable
              as double,
      workingDays: null == workingDays
          ? _value.workingDays
          : workingDays // ignore: cast_nullable_to_non_nullable
              as int,
      absentDays: null == absentDays
          ? _value.absentDays
          : absentDays // ignore: cast_nullable_to_non_nullable
              as int,
      overtime: null == overtime
          ? _value.overtime
          : overtime // ignore: cast_nullable_to_non_nullable
              as double,
      bonuses: null == bonuses
          ? _value.bonuses
          : bonuses // ignore: cast_nullable_to_non_nullable
              as double,
      deductions: null == deductions
          ? _value.deductions
          : deductions // ignore: cast_nullable_to_non_nullable
              as double,
      netSalary: null == netSalary
          ? _value.netSalary
          : netSalary // ignore: cast_nullable_to_non_nullable
              as double,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PayrollLineModelImpl extends _PayrollLineModel {
  const _$PayrollLineModelImpl(
      {required this.id,
      @JsonKey(name: 'payroll_id') required this.payrollId,
      @JsonKey(name: 'employee_id') required this.employeeId,
      @JsonKey(name: 'employee_name') this.employeeName = '',
      @JsonKey(name: 'base_salary') this.baseSalary = 0,
      @JsonKey(name: 'working_days') this.workingDays = 0,
      @JsonKey(name: 'absent_days') this.absentDays = 0,
      this.overtime = 0,
      this.bonuses = 0,
      this.deductions = 0,
      @JsonKey(name: 'net_salary') this.netSalary = 0,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : super._();

  factory _$PayrollLineModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PayrollLineModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'payroll_id')
  final String payrollId;
  @override
  @JsonKey(name: 'employee_id')
  final String employeeId;
  @override
  @JsonKey(name: 'employee_name')
  final String employeeName;
  @override
  @JsonKey(name: 'base_salary')
  final double baseSalary;
  @override
  @JsonKey(name: 'working_days')
  final int workingDays;
  @override
  @JsonKey(name: 'absent_days')
  final int absentDays;
  @override
  @JsonKey()
  final double overtime;
  @override
  @JsonKey()
  final double bonuses;
  @override
  @JsonKey()
  final double deductions;
  @override
  @JsonKey(name: 'net_salary')
  final double netSalary;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'PayrollLineModel(id: $id, payrollId: $payrollId, employeeId: $employeeId, employeeName: $employeeName, baseSalary: $baseSalary, workingDays: $workingDays, absentDays: $absentDays, overtime: $overtime, bonuses: $bonuses, deductions: $deductions, netSalary: $netSalary, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PayrollLineModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.payrollId, payrollId) ||
                other.payrollId == payrollId) &&
            (identical(other.employeeId, employeeId) ||
                other.employeeId == employeeId) &&
            (identical(other.employeeName, employeeName) ||
                other.employeeName == employeeName) &&
            (identical(other.baseSalary, baseSalary) ||
                other.baseSalary == baseSalary) &&
            (identical(other.workingDays, workingDays) ||
                other.workingDays == workingDays) &&
            (identical(other.absentDays, absentDays) ||
                other.absentDays == absentDays) &&
            (identical(other.overtime, overtime) ||
                other.overtime == overtime) &&
            (identical(other.bonuses, bonuses) || other.bonuses == bonuses) &&
            (identical(other.deductions, deductions) ||
                other.deductions == deductions) &&
            (identical(other.netSalary, netSalary) ||
                other.netSalary == netSalary) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      payrollId,
      employeeId,
      employeeName,
      baseSalary,
      workingDays,
      absentDays,
      overtime,
      bonuses,
      deductions,
      netSalary,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PayrollLineModelImplCopyWith<_$PayrollLineModelImpl> get copyWith =>
      __$$PayrollLineModelImplCopyWithImpl<_$PayrollLineModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PayrollLineModelImplToJson(
      this,
    );
  }
}

abstract class _PayrollLineModel extends PayrollLineModel {
  const factory _PayrollLineModel(
          {required final String id,
          @JsonKey(name: 'payroll_id') required final String payrollId,
          @JsonKey(name: 'employee_id') required final String employeeId,
          @JsonKey(name: 'employee_name') final String employeeName,
          @JsonKey(name: 'base_salary') final double baseSalary,
          @JsonKey(name: 'working_days') final int workingDays,
          @JsonKey(name: 'absent_days') final int absentDays,
          final double overtime,
          final double bonuses,
          final double deductions,
          @JsonKey(name: 'net_salary') final double netSalary,
          @JsonKey(name: 'created_at') required final DateTime createdAt,
          @JsonKey(name: 'updated_at') required final DateTime updatedAt}) =
      _$PayrollLineModelImpl;
  const _PayrollLineModel._() : super._();

  factory _PayrollLineModel.fromJson(Map<String, dynamic> json) =
      _$PayrollLineModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'payroll_id')
  String get payrollId;
  @override
  @JsonKey(name: 'employee_id')
  String get employeeId;
  @override
  @JsonKey(name: 'employee_name')
  String get employeeName;
  @override
  @JsonKey(name: 'base_salary')
  double get baseSalary;
  @override
  @JsonKey(name: 'working_days')
  int get workingDays;
  @override
  @JsonKey(name: 'absent_days')
  int get absentDays;
  @override
  double get overtime;
  @override
  double get bonuses;
  @override
  double get deductions;
  @override
  @JsonKey(name: 'net_salary')
  double get netSalary;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$PayrollLineModelImplCopyWith<_$PayrollLineModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
