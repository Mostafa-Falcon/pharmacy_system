// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'leave_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

LeaveModel _$LeaveModelFromJson(Map<String, dynamic> json) {
  return _LeaveModel.fromJson(json);
}

/// @nodoc
mixin _$LeaveModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_id')
  String get employeeId => throw _privateConstructorUsedError;
  @JsonKey(name: 'employee_name')
  String get employeeName => throw _privateConstructorUsedError;
  @JsonKey(name: 'leave_type')
  String get leaveType => throw _privateConstructorUsedError;
  @JsonKey(name: 'start_date')
  String get startDate => throw _privateConstructorUsedError;
  @JsonKey(name: 'end_date')
  String get endDate => throw _privateConstructorUsedError;
  int get duration => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String? get reason => throw _privateConstructorUsedError;
  @JsonKey(name: 'approved_by')
  String? get approvedBy => throw _privateConstructorUsedError;
  @JsonKey(name: 'rejection_reason')
  String? get rejectionReason => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LeaveModelCopyWith<LeaveModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LeaveModelCopyWith<$Res> {
  factory $LeaveModelCopyWith(
          LeaveModel value, $Res Function(LeaveModel) then) =
      _$LeaveModelCopyWithImpl<$Res, LeaveModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'leave_type') String leaveType,
      @JsonKey(name: 'start_date') String startDate,
      @JsonKey(name: 'end_date') String endDate,
      int duration,
      String status,
      String? reason,
      @JsonKey(name: 'approved_by') String? approvedBy,
      @JsonKey(name: 'rejection_reason') String? rejectionReason,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$LeaveModelCopyWithImpl<$Res, $Val extends LeaveModel>
    implements $LeaveModelCopyWith<$Res> {
  _$LeaveModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? leaveType = null,
    Object? startDate = null,
    Object? endDate = null,
    Object? duration = null,
    Object? status = null,
    Object? reason = freezed,
    Object? approvedBy = freezed,
    Object? rejectionReason = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      leaveType: null == leaveType
          ? _value.leaveType
          : leaveType // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: null == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as String,
      endDate: null == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String,
      duration: null == duration
          ? _value.duration
          : duration // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      reason: freezed == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      rejectionReason: freezed == rejectionReason
          ? _value.rejectionReason
          : rejectionReason // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LeaveModelImplCopyWith<$Res>
    implements $LeaveModelCopyWith<$Res> {
  factory _$$LeaveModelImplCopyWith(
          _$LeaveModelImpl value, $Res Function(_$LeaveModelImpl) then) =
      __$$LeaveModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'employee_id') String employeeId,
      @JsonKey(name: 'employee_name') String employeeName,
      @JsonKey(name: 'leave_type') String leaveType,
      @JsonKey(name: 'start_date') String startDate,
      @JsonKey(name: 'end_date') String endDate,
      int duration,
      String status,
      String? reason,
      @JsonKey(name: 'approved_by') String? approvedBy,
      @JsonKey(name: 'rejection_reason') String? rejectionReason,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$LeaveModelImplCopyWithImpl<$Res>
    extends _$LeaveModelCopyWithImpl<$Res, _$LeaveModelImpl>
    implements _$$LeaveModelImplCopyWith<$Res> {
  __$$LeaveModelImplCopyWithImpl(
      _$LeaveModelImpl _value, $Res Function(_$LeaveModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? employeeId = null,
    Object? employeeName = null,
    Object? leaveType = null,
    Object? startDate = null,
    Object? endDate = null,
    Object? duration = null,
    Object? status = null,
    Object? reason = freezed,
    Object? approvedBy = freezed,
    Object? rejectionReason = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$LeaveModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      employeeId: null == employeeId
          ? _value.employeeId
          : employeeId // ignore: cast_nullable_to_non_nullable
              as String,
      employeeName: null == employeeName
          ? _value.employeeName
          : employeeName // ignore: cast_nullable_to_non_nullable
              as String,
      leaveType: null == leaveType
          ? _value.leaveType
          : leaveType // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: null == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as String,
      endDate: null == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as String,
      duration: null == duration
          ? _value.duration
          : duration // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      reason: freezed == reason
          ? _value.reason
          : reason // ignore: cast_nullable_to_non_nullable
              as String?,
      approvedBy: freezed == approvedBy
          ? _value.approvedBy
          : approvedBy // ignore: cast_nullable_to_non_nullable
              as String?,
      rejectionReason: freezed == rejectionReason
          ? _value.rejectionReason
          : rejectionReason // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LeaveModelImpl extends _LeaveModel {
  const _$LeaveModelImpl(
      {required this.id,
      @JsonKey(name: 'employee_id') required this.employeeId,
      @JsonKey(name: 'employee_name') this.employeeName = '',
      @JsonKey(name: 'leave_type') required this.leaveType,
      @JsonKey(name: 'start_date') required this.startDate,
      @JsonKey(name: 'end_date') required this.endDate,
      this.duration = 1,
      this.status = 'pending',
      this.reason,
      @JsonKey(name: 'approved_by') this.approvedBy,
      @JsonKey(name: 'rejection_reason') this.rejectionReason,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : super._();

  factory _$LeaveModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$LeaveModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'employee_id')
  final String employeeId;
  @override
  @JsonKey(name: 'employee_name')
  final String employeeName;
  @override
  @JsonKey(name: 'leave_type')
  final String leaveType;
  @override
  @JsonKey(name: 'start_date')
  final String startDate;
  @override
  @JsonKey(name: 'end_date')
  final String endDate;
  @override
  @JsonKey()
  final int duration;
  @override
  @JsonKey()
  final String status;
  @override
  final String? reason;
  @override
  @JsonKey(name: 'approved_by')
  final String? approvedBy;
  @override
  @JsonKey(name: 'rejection_reason')
  final String? rejectionReason;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'LeaveModel(id: $id, employeeId: $employeeId, employeeName: $employeeName, leaveType: $leaveType, startDate: $startDate, endDate: $endDate, duration: $duration, status: $status, reason: $reason, approvedBy: $approvedBy, rejectionReason: $rejectionReason, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LeaveModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.employeeId, employeeId) ||
                other.employeeId == employeeId) &&
            (identical(other.employeeName, employeeName) ||
                other.employeeName == employeeName) &&
            (identical(other.leaveType, leaveType) ||
                other.leaveType == leaveType) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate) &&
            (identical(other.duration, duration) ||
                other.duration == duration) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.reason, reason) || other.reason == reason) &&
            (identical(other.approvedBy, approvedBy) ||
                other.approvedBy == approvedBy) &&
            (identical(other.rejectionReason, rejectionReason) ||
                other.rejectionReason == rejectionReason) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      employeeId,
      employeeName,
      leaveType,
      startDate,
      endDate,
      duration,
      status,
      reason,
      approvedBy,
      rejectionReason,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LeaveModelImplCopyWith<_$LeaveModelImpl> get copyWith =>
      __$$LeaveModelImplCopyWithImpl<_$LeaveModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LeaveModelImplToJson(
      this,
    );
  }
}

abstract class _LeaveModel extends LeaveModel {
  const factory _LeaveModel(
          {required final String id,
          @JsonKey(name: 'employee_id') required final String employeeId,
          @JsonKey(name: 'employee_name') final String employeeName,
          @JsonKey(name: 'leave_type') required final String leaveType,
          @JsonKey(name: 'start_date') required final String startDate,
          @JsonKey(name: 'end_date') required final String endDate,
          final int duration,
          final String status,
          final String? reason,
          @JsonKey(name: 'approved_by') final String? approvedBy,
          @JsonKey(name: 'rejection_reason') final String? rejectionReason,
          @JsonKey(name: 'created_at') required final DateTime createdAt,
          @JsonKey(name: 'updated_at') required final DateTime updatedAt}) =
      _$LeaveModelImpl;
  const _LeaveModel._() : super._();

  factory _LeaveModel.fromJson(Map<String, dynamic> json) =
      _$LeaveModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'employee_id')
  String get employeeId;
  @override
  @JsonKey(name: 'employee_name')
  String get employeeName;
  @override
  @JsonKey(name: 'leave_type')
  String get leaveType;
  @override
  @JsonKey(name: 'start_date')
  String get startDate;
  @override
  @JsonKey(name: 'end_date')
  String get endDate;
  @override
  int get duration;
  @override
  String get status;
  @override
  String? get reason;
  @override
  @JsonKey(name: 'approved_by')
  String? get approvedBy;
  @override
  @JsonKey(name: 'rejection_reason')
  String? get rejectionReason;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$LeaveModelImplCopyWith<_$LeaveModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

LeaveBalance _$LeaveBalanceFromJson(Map<String, dynamic> json) {
  return _LeaveBalance.fromJson(json);
}

/// @nodoc
mixin _$LeaveBalance {
  LeaveTypeBalance get sick => throw _privateConstructorUsedError;
  LeaveTypeBalance get annual => throw _privateConstructorUsedError;
  LeaveTypeBalance get emergency => throw _privateConstructorUsedError;
  LeaveTypeBalance get unpaid => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LeaveBalanceCopyWith<LeaveBalance> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LeaveBalanceCopyWith<$Res> {
  factory $LeaveBalanceCopyWith(
          LeaveBalance value, $Res Function(LeaveBalance) then) =
      _$LeaveBalanceCopyWithImpl<$Res, LeaveBalance>;
  @useResult
  $Res call(
      {LeaveTypeBalance sick,
      LeaveTypeBalance annual,
      LeaveTypeBalance emergency,
      LeaveTypeBalance unpaid});

  $LeaveTypeBalanceCopyWith<$Res> get sick;
  $LeaveTypeBalanceCopyWith<$Res> get annual;
  $LeaveTypeBalanceCopyWith<$Res> get emergency;
  $LeaveTypeBalanceCopyWith<$Res> get unpaid;
}

/// @nodoc
class _$LeaveBalanceCopyWithImpl<$Res, $Val extends LeaveBalance>
    implements $LeaveBalanceCopyWith<$Res> {
  _$LeaveBalanceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sick = null,
    Object? annual = null,
    Object? emergency = null,
    Object? unpaid = null,
  }) {
    return _then(_value.copyWith(
      sick: null == sick
          ? _value.sick
          : sick // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      annual: null == annual
          ? _value.annual
          : annual // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      emergency: null == emergency
          ? _value.emergency
          : emergency // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      unpaid: null == unpaid
          ? _value.unpaid
          : unpaid // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $LeaveTypeBalanceCopyWith<$Res> get sick {
    return $LeaveTypeBalanceCopyWith<$Res>(_value.sick, (value) {
      return _then(_value.copyWith(sick: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $LeaveTypeBalanceCopyWith<$Res> get annual {
    return $LeaveTypeBalanceCopyWith<$Res>(_value.annual, (value) {
      return _then(_value.copyWith(annual: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $LeaveTypeBalanceCopyWith<$Res> get emergency {
    return $LeaveTypeBalanceCopyWith<$Res>(_value.emergency, (value) {
      return _then(_value.copyWith(emergency: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $LeaveTypeBalanceCopyWith<$Res> get unpaid {
    return $LeaveTypeBalanceCopyWith<$Res>(_value.unpaid, (value) {
      return _then(_value.copyWith(unpaid: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$LeaveBalanceImplCopyWith<$Res>
    implements $LeaveBalanceCopyWith<$Res> {
  factory _$$LeaveBalanceImplCopyWith(
          _$LeaveBalanceImpl value, $Res Function(_$LeaveBalanceImpl) then) =
      __$$LeaveBalanceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {LeaveTypeBalance sick,
      LeaveTypeBalance annual,
      LeaveTypeBalance emergency,
      LeaveTypeBalance unpaid});

  @override
  $LeaveTypeBalanceCopyWith<$Res> get sick;
  @override
  $LeaveTypeBalanceCopyWith<$Res> get annual;
  @override
  $LeaveTypeBalanceCopyWith<$Res> get emergency;
  @override
  $LeaveTypeBalanceCopyWith<$Res> get unpaid;
}

/// @nodoc
class __$$LeaveBalanceImplCopyWithImpl<$Res>
    extends _$LeaveBalanceCopyWithImpl<$Res, _$LeaveBalanceImpl>
    implements _$$LeaveBalanceImplCopyWith<$Res> {
  __$$LeaveBalanceImplCopyWithImpl(
      _$LeaveBalanceImpl _value, $Res Function(_$LeaveBalanceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sick = null,
    Object? annual = null,
    Object? emergency = null,
    Object? unpaid = null,
  }) {
    return _then(_$LeaveBalanceImpl(
      sick: null == sick
          ? _value.sick
          : sick // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      annual: null == annual
          ? _value.annual
          : annual // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      emergency: null == emergency
          ? _value.emergency
          : emergency // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
      unpaid: null == unpaid
          ? _value.unpaid
          : unpaid // ignore: cast_nullable_to_non_nullable
              as LeaveTypeBalance,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LeaveBalanceImpl extends _LeaveBalance {
  const _$LeaveBalanceImpl(
      {this.sick = const LeaveTypeBalance(total: 30),
      this.annual = const LeaveTypeBalance(total: 21),
      this.emergency = const LeaveTypeBalance(total: 7),
      this.unpaid = const LeaveTypeBalance(total: 30)})
      : super._();

  factory _$LeaveBalanceImpl.fromJson(Map<String, dynamic> json) =>
      _$$LeaveBalanceImplFromJson(json);

  @override
  @JsonKey()
  final LeaveTypeBalance sick;
  @override
  @JsonKey()
  final LeaveTypeBalance annual;
  @override
  @JsonKey()
  final LeaveTypeBalance emergency;
  @override
  @JsonKey()
  final LeaveTypeBalance unpaid;

  @override
  String toString() {
    return 'LeaveBalance(sick: $sick, annual: $annual, emergency: $emergency, unpaid: $unpaid)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LeaveBalanceImpl &&
            (identical(other.sick, sick) || other.sick == sick) &&
            (identical(other.annual, annual) || other.annual == annual) &&
            (identical(other.emergency, emergency) ||
                other.emergency == emergency) &&
            (identical(other.unpaid, unpaid) || other.unpaid == unpaid));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, sick, annual, emergency, unpaid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LeaveBalanceImplCopyWith<_$LeaveBalanceImpl> get copyWith =>
      __$$LeaveBalanceImplCopyWithImpl<_$LeaveBalanceImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LeaveBalanceImplToJson(
      this,
    );
  }
}

abstract class _LeaveBalance extends LeaveBalance {
  const factory _LeaveBalance(
      {final LeaveTypeBalance sick,
      final LeaveTypeBalance annual,
      final LeaveTypeBalance emergency,
      final LeaveTypeBalance unpaid}) = _$LeaveBalanceImpl;
  const _LeaveBalance._() : super._();

  factory _LeaveBalance.fromJson(Map<String, dynamic> json) =
      _$LeaveBalanceImpl.fromJson;

  @override
  LeaveTypeBalance get sick;
  @override
  LeaveTypeBalance get annual;
  @override
  LeaveTypeBalance get emergency;
  @override
  LeaveTypeBalance get unpaid;
  @override
  @JsonKey(ignore: true)
  _$$LeaveBalanceImplCopyWith<_$LeaveBalanceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

LeaveTypeBalance _$LeaveTypeBalanceFromJson(Map<String, dynamic> json) {
  return _LeaveTypeBalance.fromJson(json);
}

/// @nodoc
mixin _$LeaveTypeBalance {
  int get total => throw _privateConstructorUsedError;
  int get used => throw _privateConstructorUsedError;
  int get remaining => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $LeaveTypeBalanceCopyWith<LeaveTypeBalance> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LeaveTypeBalanceCopyWith<$Res> {
  factory $LeaveTypeBalanceCopyWith(
          LeaveTypeBalance value, $Res Function(LeaveTypeBalance) then) =
      _$LeaveTypeBalanceCopyWithImpl<$Res, LeaveTypeBalance>;
  @useResult
  $Res call({int total, int used, int remaining});
}

/// @nodoc
class _$LeaveTypeBalanceCopyWithImpl<$Res, $Val extends LeaveTypeBalance>
    implements $LeaveTypeBalanceCopyWith<$Res> {
  _$LeaveTypeBalanceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? total = null,
    Object? used = null,
    Object? remaining = null,
  }) {
    return _then(_value.copyWith(
      total: null == total
          ? _value.total
          : total // ignore: cast_nullable_to_non_nullable
              as int,
      used: null == used
          ? _value.used
          : used // ignore: cast_nullable_to_non_nullable
              as int,
      remaining: null == remaining
          ? _value.remaining
          : remaining // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LeaveTypeBalanceImplCopyWith<$Res>
    implements $LeaveTypeBalanceCopyWith<$Res> {
  factory _$$LeaveTypeBalanceImplCopyWith(_$LeaveTypeBalanceImpl value,
          $Res Function(_$LeaveTypeBalanceImpl) then) =
      __$$LeaveTypeBalanceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int total, int used, int remaining});
}

/// @nodoc
class __$$LeaveTypeBalanceImplCopyWithImpl<$Res>
    extends _$LeaveTypeBalanceCopyWithImpl<$Res, _$LeaveTypeBalanceImpl>
    implements _$$LeaveTypeBalanceImplCopyWith<$Res> {
  __$$LeaveTypeBalanceImplCopyWithImpl(_$LeaveTypeBalanceImpl _value,
      $Res Function(_$LeaveTypeBalanceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? total = null,
    Object? used = null,
    Object? remaining = null,
  }) {
    return _then(_$LeaveTypeBalanceImpl(
      total: null == total
          ? _value.total
          : total // ignore: cast_nullable_to_non_nullable
              as int,
      used: null == used
          ? _value.used
          : used // ignore: cast_nullable_to_non_nullable
              as int,
      remaining: null == remaining
          ? _value.remaining
          : remaining // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LeaveTypeBalanceImpl extends _LeaveTypeBalance {
  const _$LeaveTypeBalanceImpl(
      {this.total = 30, this.used = 0, this.remaining = 30})
      : super._();

  factory _$LeaveTypeBalanceImpl.fromJson(Map<String, dynamic> json) =>
      _$$LeaveTypeBalanceImplFromJson(json);

  @override
  @JsonKey()
  final int total;
  @override
  @JsonKey()
  final int used;
  @override
  @JsonKey()
  final int remaining;

  @override
  String toString() {
    return 'LeaveTypeBalance(total: $total, used: $used, remaining: $remaining)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LeaveTypeBalanceImpl &&
            (identical(other.total, total) || other.total == total) &&
            (identical(other.used, used) || other.used == used) &&
            (identical(other.remaining, remaining) ||
                other.remaining == remaining));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, total, used, remaining);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LeaveTypeBalanceImplCopyWith<_$LeaveTypeBalanceImpl> get copyWith =>
      __$$LeaveTypeBalanceImplCopyWithImpl<_$LeaveTypeBalanceImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LeaveTypeBalanceImplToJson(
      this,
    );
  }
}

abstract class _LeaveTypeBalance extends LeaveTypeBalance {
  const factory _LeaveTypeBalance(
      {final int total,
      final int used,
      final int remaining}) = _$LeaveTypeBalanceImpl;
  const _LeaveTypeBalance._() : super._();

  factory _LeaveTypeBalance.fromJson(Map<String, dynamic> json) =
      _$LeaveTypeBalanceImpl.fromJson;

  @override
  int get total;
  @override
  int get used;
  @override
  int get remaining;
  @override
  @JsonKey(ignore: true)
  _$$LeaveTypeBalanceImplCopyWith<_$LeaveTypeBalanceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
