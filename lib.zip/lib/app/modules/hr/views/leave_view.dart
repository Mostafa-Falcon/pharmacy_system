import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../bloc/hr_bloc.dart';
import '../models/leave_model.dart';
import '../models/employee_model.dart';
import '../services/leave_service.dart';
import '../../../core/widgets/index.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/utils/app_snackbar.dart';

class LeaveView extends StatelessWidget {
  const LeaveView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HrBloc, HrState>(
      builder: (context, state) {
        if (state.status == HrStatus.loading && state.leaveRecords.isEmpty) {
          return const LoadingIndicator();
        }
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: ListView(
            padding: EdgeInsets.all(AppSpacing.md.w),
            physics: const BouncingScrollPhysics(),
            children: [
              _LeaveBalanceCard(employees: state.employees),
              SizedBox(height: AppSpacing.md.h),
              _PendingLeavesCard(pending: state.pendingLeaves),
              SizedBox(height: AppSpacing.md.h),
              _LeaveHistoryCard(records: state.leaveRecords),
              SizedBox(height: AppSpacing.xxl.h),
            ],
          ),
          floatingActionButton: ReusableFab(
            icon: Icons.event_rounded,
            onPressed: () => _showRequestLeaveDialog(context, state.employees),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
        );
      },
    );
  }

  void _showRequestLeaveDialog(BuildContext context, List<EmployeeModel> employees) {
    final bloc = context.read<HrBloc>();
    final startDateCtrl = TextEditingController();
    final endDateCtrl = TextEditingController();
    final reasonCtrl = TextEditingController();
    final leaveTypes = <String>['sick', 'annual', 'emergency', 'unpaid'];
    var selectedType = 'annual';
    var selectedEmployeeId = '';
    var selectedEmployeeName = '';

    if (employees.isNotEmpty) {
      selectedEmployeeId = employees.first.id;
      selectedEmployeeName = employees.first.name;
    }

    showDialog(
      context: context,
      builder: (context) => ReusableDialog(
        title: 'طلب إجازة جديدة',
        headerIcon: const Icon(Icons.event_rounded),
        children: [
          if (employees.isNotEmpty)
            ReusableDropdown<String>(
              labelText: 'الموظف',
              hintText: 'اختر الموظف',
              items: employees.map((e) => e.name).toList(),
              value: selectedEmployeeName.isEmpty ? null : selectedEmployeeName,
              itemAsString: (s) => s,
              onChanged: (v) {
                if (v != null) {
                  final emp = employees.firstWhere((e) => e.name == v);
                  selectedEmployeeId = emp.id;
                  selectedEmployeeName = emp.name;
                }
              },
            ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableDropdown<String>(
            labelText: 'نوع الإجازة',
            hintText: 'اختر النوع',
            items: leaveTypes,
            value: selectedType,
            itemAsString: (s) => s == 'sick'
                ? 'مرضية'
                : s == 'annual'
                    ? 'سنوية'
                    : s == 'emergency'
                        ? 'طارئة'
                        : 'بدون راتب',
            onChanged: (v) {
              if (v != null) selectedType = v;
            },
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableInput(
            label: 'تاريخ البداية',
            hint: 'YYYY-MM-DD',
            controller: startDateCtrl,
            prefixIcon: const Icon(Icons.calendar_today_rounded, size: 18),
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableInput(
            label: 'تاريخ النهاية',
            hint: 'YYYY-MM-DD',
            controller: endDateCtrl,
            prefixIcon: const Icon(Icons.calendar_today_rounded, size: 18),
          ),
          SizedBox(height: AppSpacing.sm.h),
          ReusableInput(
            label: 'السبب',
            hint: 'سبب الإجازة...',
            controller: reasonCtrl,
            maxLines: 2,
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: AppSpacing.lg.h),
          DialogActions(
            confirmText: 'تقديم طلب الإجازة',
            onConfirm: () async {
              if (selectedEmployeeId.isEmpty) return;
              if (startDateCtrl.text.isEmpty || endDateCtrl.text.isEmpty) {
                AppSnackbar.error('يرجى تحديد تواريخ الإجازة');
                return;
              }
              bloc.add(RequestLeave(
                employeeId: selectedEmployeeId,
                employeeName: selectedEmployeeName,
                leaveType: selectedType,
                startDate: startDateCtrl.text.trim(),
                endDate: endDateCtrl.text.trim(),
                reason: reasonCtrl.text.trim().isEmpty ? null : reasonCtrl.text.trim(),
              ));
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}

class _LeaveBalanceCard extends StatelessWidget {
  final List<EmployeeModel> employees;
  const _LeaveBalanceCard({required this.employees});

  @override
  Widget build(BuildContext context) {
    if (employees.isEmpty) {
      return const AppCard(
        child: ReusableText('لا يوجد موظفون متاحون لعرض أرصدة الإجازات حالياً.'),
      );
    }
    final balance = LeaveService.getBalance(employees.first.id);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(icon: Icons.account_balance_wallet_rounded, title: 'أرصدة الإجازات المتاحة'),
          SizedBox(height: AppSpacing.sm.h),
          _BalanceRow(
              label: 'الإجازات المرضية',
              used: balance.sick.used,
              total: balance.sick.total,
              color: AppColors.error),
          _BalanceRow(
              label: 'الإجازات السنوية',
              used: balance.annual.used,
              total: balance.annual.total,
              color: AppColors.primary),
          _BalanceRow(
              label: 'إجازات طارئة',
              used: balance.emergency.used,
              total: balance.emergency.total,
              color: AppColors.warning),
          _BalanceRow(
              label: 'بدون راتب',
              used: balance.unpaid.used,
              total: balance.unpaid.total,
              color: AppColors.textSecondaryOf(context)),
        ],
      ),
    );
  }
}

class _BalanceRow extends StatelessWidget {
  final String label;
  final int used;
  final int total;
  final Color color;
  const _BalanceRow(
      {required this.label,
      required this.used,
      required this.total,
      required this.color});

  @override
  Widget build(BuildContext context) {
    final remaining = total - used;
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6.h),
      child: Row(
        children: [
          Container(
            width: 8.r,
            height: 8.r,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          SizedBox(width: 10.w),
          ReusableText(label,
              style: TextStyle(
                  fontSize: 13.sp,
                  color: AppColors.textPrimaryOf(context))),
          const Spacer(),
          ReusableText('$remaining',
              style: TextStyle(
                  fontSize: 13.5.sp,
                  fontWeight: FontWeight.bold,
                  color: color)),
          SizedBox(width: 6.w),
          ReusableText('/ $total يوم',
              style: TextStyle(
                  fontSize: 11.sp,
                  color: AppColors.textMutedOf(context))),
        ],
      ),
    );
  }
}

class _PendingLeavesCard extends StatelessWidget {
  final List<LeaveModel> pending;
  const _PendingLeavesCard({required this.pending});

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<HrBloc>();
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: SectionHeader(icon: Icons.pending_actions_rounded, title: 'طلبات الإجازة المعلقة')),
              if (pending.isNotEmpty)
                ReusableBadge.tone(
                  label: '${pending.length} طلبات',
                  tone: ReusableBadgeTone.warning,
                ),
            ],
          ),
          SizedBox(height: AppSpacing.sm.h),
          if (pending.isEmpty)
            Padding(
              padding: EdgeInsets.symmetric(vertical: AppSpacing.md.h),
              child: const ReusableText('لا توجد طلبات إجازة معلقة حالياً.',
                  style: TextStyle(color: Colors.grey)),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: pending.length,
              separatorBuilder: (_, index) => Divider(height: 1, color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.1)),
              itemBuilder: (_, i) => _LeaveRequestTile(leave: pending[i], bloc: bloc),
            ),
        ],
      ),
    );
  }
}

class _LeaveRequestTile extends StatelessWidget {
  final LeaveModel leave;
  final HrBloc bloc;
  const _LeaveRequestTile({required this.leave, required this.bloc});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      title: ReusableText(
        '${leave.employeeName} - ${_leaveTypeText(leave.leaveType)}',
        style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.bold),
      ),
      subtitle: ReusableText(
        'من ${leave.startDate} إلى ${leave.endDate} (${leave.duration} يوم)',
        style: TextStyle(
            fontSize: 11.5.sp,
            color: AppColors.textSecondaryOf(context)),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: Icon(Icons.check_circle_rounded,
                color: AppColors.success, size: 22.sp),
            onPressed: () => bloc.add(ApproveLeave(leave.id)),
            tooltip: 'قبول',
          ),
          IconButton(
            icon: Icon(Icons.cancel_rounded,
                color: AppColors.error, size: 22.sp),
            onPressed: () {
              ReusableDialog.show(
                context,
                title: 'رفض الإجازة',
                headerIcon: const Icon(Icons.cancel_rounded, color: AppColors.error),
                children: [
                  ReusableText('هل أنت متأكد من رغبتك في رفض طلب الإجازة للموظف "${leave.employeeName}"؟'),
                  SizedBox(height: 24.h),
                  DialogActions(
                    confirmText: 'رفض الطلب',
                    confirmType: ButtonType.primary,
                    onConfirm: () {
                      bloc.add(RejectLeave(leave.id));
                      Navigator.pop(context);
                    },
                  ),
                ],
              );
            },
            tooltip: 'رفض',
          ),
        ],
      ),
    );
  }

  String _leaveTypeText(String type) => switch (type) {
        'sick' => 'مرضية',
        'annual' => 'سنوية',
        'emergency' => 'طارئة',
        'unpaid' => 'بدون راتب',
        _ => type,
      };
}

class _LeaveHistoryCard extends StatelessWidget {
  final List<LeaveModel> records;
  const _LeaveHistoryCard({required this.records});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(icon: Icons.history_rounded, title: 'تاريخ طلبات الإجازة'),
          SizedBox(height: AppSpacing.sm.h),
          if (records.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(child: ReusableText('لا توجد سجلات إجازات سابقة.', style: TextStyle(color: Colors.grey))),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: records.take(15).length,
              separatorBuilder: (_, index) => Divider(height: 1, color: scheme.outline.withValues(alpha: 0.1)),
              itemBuilder: (context, i) {
                final leave = records[i];
                final (statusColor, statusLabel) = switch (leave.status) {
                  'approved' => (AppColors.success, 'مقبولة'),
                  'rejected' => (AppColors.error, 'مرفوضة'),
                  _ => (AppColors.warning, 'معلقة'),
                };
                return ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    radius: 14.r,
                    backgroundColor: statusColor.withValues(alpha: 0.1),
                    child: Icon(Icons.event_note_rounded, size: 14.sp, color: statusColor),
                  ),
                  title: ReusableText(
                    '${leave.employeeName} - ${_leaveTypeText(leave.leaveType)}',
                    style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w600),
                  ),
                  subtitle: ReusableText(
                    '${leave.startDate} → ${leave.endDate}',
                    style: TextStyle(
                        fontSize: 11.sp,
                        color: AppColors.textSecondaryOf(context)),
                  ),
                  trailing: StatusBadge(label: statusLabel, color: statusColor),
                );
              },
            ),
        ],
      ),
    );
  }

  String _leaveTypeText(String type) => switch (type) {
        'sick' => 'مرضية',
        'annual' => 'سنوية',
        'emergency' => 'طارئة',
        'unpaid' => 'بدون راتب',
        _ => type,
      };
}
