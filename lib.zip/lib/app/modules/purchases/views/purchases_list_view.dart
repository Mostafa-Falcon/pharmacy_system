import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:go_router/go_router.dart';

import '../../../core/models/sales/purchase_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format_utils.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../../../routes/app_routes.dart';
import '../../../core/widgets/index.dart';
import '../../../core/injection.dart';
import '../bloc/purchases_bloc.dart';
import '../bloc/purchases_event.dart';
import '../bloc/purchases_state.dart';

class PurchasesListView extends StatelessWidget {
  const PurchasesListView({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return BlocProvider.value(
      value: sl<PurchasesBloc>()..add(const LoadPurchases()),
      child: HomeShell(
        title: AppStrings.allPurchases,
        child: Container(
          color: scheme.surfaceContainerLow.withValues(alpha: 0.15),
          padding: EdgeInsets.all(AppSpacing.xl.w),
          child: BlocBuilder<PurchasesBloc, PurchasesState>(
            builder: (context, state) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildHeader(context, state),
                  SizedBox(height: AppSpacing.lg.h),
                  _buildFilters(context, state),
                  SizedBox(height: AppSpacing.md.h),
                  Expanded(child: _buildPurchasesList(context, state)),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, PurchasesState state) {
    return Row(
      children: [
        ReusableButton(
          text: AppStrings.add,
          prefixIcon: Icons.add_rounded,
          color: AppColors.homePurchases,
          onPressed: () => context.push(Routes.PURCHASE_ADD),
        ),
        const Spacer(),
        ReusableButton(
          text: AppStrings.back,
          type: ButtonType.outlined,
          prefixIcon: Icons.arrow_back_rounded,
          onPressed: () => context.pop(),
        ),
      ],
    );
  }

  Widget _buildFilters(BuildContext context, PurchasesState state) {
    final scheme = Theme.of(context).colorScheme;
    return AppCard(
      padding: EdgeInsets.all(AppSpacing.xl.w),
      child: Column(
        children: [
          Row(
            children: [
              SummaryCard(
                label: 'إجمالي الفواتير',
                value: '${state.totalCount}',
                color: scheme.primary,
                icon: Icons.inventory_2_rounded,
                minWidth: 160.w,
              ),
              SizedBox(width: AppSpacing.md.w),
              SummaryCard(
                label: 'ديون الموردين',
                value: FormatUtils.currency(state.creditTotal),
                color: AppColors.warning,
                icon: Icons.account_balance_wallet_rounded,
                minWidth: 180.w,
              ),
              const Spacer(),
              _buildDateRangePicker(context, state),
            ],
          ),
          SizedBox(height: AppSpacing.lg.h),
          Row(
            children: [
              _filterField(AppStrings.supplierLabel, ['الكل']),
              SizedBox(width: AppSpacing.md.w),
              _filterField(AppStrings.paymentStatus, ['الكل', 'مدفوع', 'جزئي', 'غير مدفوع']),
              SizedBox(width: AppSpacing.md.w),
              _filterField(AppStrings.purchaseStatusLabel, ['الكل', 'استلم', 'معلق', 'مطلوب']),
              SizedBox(width: AppSpacing.md.w),
              _filterField('المخزن', ['الكل']),
            ],
          ),
        ],
      ),
    );
  }

  Widget _filterField(String label, List<String> items) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ReusableText(label, style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold)),
          SizedBox(height: 6.h),
          ReusableDropdown<String>(
            hintText: label,
            items: items,
            itemAsString: (v) => v,
            value: items.first,
            onChanged: (v) {},
          ),
        ],
      ),
    );
  }

  Widget _buildDateRangePicker(BuildContext context, PurchasesState state) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _dateBox(context, state.dateFrom == null ? 'من تاريخ' : DateFormat('yyyy/MM/dd').format(state.dateFrom!)),
        Padding(padding: EdgeInsets.symmetric(horizontal: 8.w), child: const ReusableText('←')),
        _dateBox(context, state.dateTo == null ? 'إلى تاريخ' : DateFormat('yyyy/MM/dd').format(state.dateTo!)),
      ],
    );
  }

  Widget _dateBox(BuildContext context, String label) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: 180.w,
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: [
          Icon(Icons.calendar_month_rounded, size: 16.sp, color: Colors.grey),
          SizedBox(width: 8.w),
          ReusableText(label, style: TextStyle(fontSize: 12.sp, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildPurchasesList(BuildContext context, PurchasesState state) {
    final scheme = Theme.of(context).colorScheme;
    if (state.status == PurchasesStatus.loading && state.allPurchases.isEmpty) return const LoadingIndicator();

    final items = state.filteredPurchases;
    final totalAmount = items.fold(0.0, (sum, p) => sum + p.finalAmount);
    final totalRemaining = items.fold(0.0, (sum, p) => sum + p.remainingAmount);

    final columns = [
      ReusableTableColumn<PurchaseModel>(
        id: 'actions',
        title: 'خيار',
        width: 100.w,
        cellBuilder: (p) => _buildRowActions(context, p),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'date',
        title: AppStrings.date,
        width: 160.w,
        isSortable: true,
        textBuilder: (p) => DateFormat('yyyy/MM/dd HH:mm').format(p.createdAt),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'id',
        title: 'رقم الفاتورة',
        width: 120.w,
        isSortable: true,
        textBuilder: (p) => '#${p.id.substring(0, 8).toUpperCase()}',
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'supplier',
        title: 'المورد',
        flex: 2,
        isSortable: true,
        textBuilder: (p) => p.supplierName,
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'status',
        title: 'الحالة',
        width: 110.w,
        cellBuilder: (p) => StatusBadge(label: 'استلم', color: AppColors.success),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'payment_status',
        title: AppStrings.paymentStatus,
        width: 110.w,
        cellBuilder: (p) {
          final isPaid = p.remainingAmount <= 0;
          return StatusBadge(
            label: isPaid ? AppStrings.paymentPaid : AppStrings.paymentPartial,
            color: isPaid ? AppColors.success : AppColors.warning,
          );
        },
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'amount',
        title: 'المبلغ الإجمالي',
        width: 130.w,
        isNumeric: true,
        textBuilder: (p) => formatMoney(p.finalAmount),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'paid',
        title: AppStrings.paidAmount,
        width: 130.w,
        isNumeric: true,
        textBuilder: (p) => formatMoney(p.finalAmount - p.remainingAmount),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'due',
        title: AppStrings.dueAmount,
        width: 130.w,
        isNumeric: true,
        textBuilder: (p) => formatMoney(p.remainingAmount),
      ),
      ReusableTableColumn<PurchaseModel>(
        id: 'added_by',
        title: AppStrings.addedBy,
        width: 120.w,
        textBuilder: (p) => 'المسؤول',
      ),
    ];

    return Column(
      children: [
        _buildTableToolbar(context, state),
        Expanded(
          child: ReusableTable<PurchaseModel>(
            columns: columns,
            items: items,
            itemLabel: 'فاتورة مشتريات',
            bodyRowHeight: 56.h,
            tableFooter: Container(
              padding: EdgeInsets.symmetric(vertical: 12.h),
              decoration: BoxDecoration(
                color: scheme.surface,
                border: Border(top: BorderSide(color: scheme.outlineVariant, width: 2)),
              ),
              child: Row(
                children: [
                  SizedBox(width: 100.w), // actions
                  SizedBox(width: 160.w), // date
                  SizedBox(width: 120.w), // id
                  Expanded(flex: 2, child: const SizedBox()), // supplier
                  SizedBox(width: 110.w), // status
                  SizedBox(width: 110.w, child: _cellPadding(const ReusableText('المجموع:', style: TextStyle(fontWeight: FontWeight.bold)), false)),
                  SizedBox(width: 130.w, child: _cellPadding(ReusableText(formatMoney(totalAmount), style: const TextStyle(fontWeight: FontWeight.bold)), true)),
                  SizedBox(width: 130.w, child: _cellPadding(ReusableText(formatMoney(totalAmount - totalRemaining), style: const TextStyle(fontWeight: FontWeight.bold)), true)),
                  SizedBox(width: 130.w, child: _cellPadding(ReusableText(formatMoney(totalRemaining), style: const TextStyle(fontWeight: FontWeight.bold)), true)),
                  SizedBox(width: 120.w), // added_by
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _cellPadding(Widget child, bool isNumeric) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 12.w),
      child: Align(
        alignment: isNumeric ? Alignment.centerLeft : Alignment.centerRight,
        child: child,
      ),
    );
  }

  Widget _buildTableToolbar(BuildContext context, PurchasesState state) {
    final bloc = context.read<PurchasesBloc>();
    return Container(
      padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 8.w),
      child: Row(
        children: [
          ReusableText('إدخالات', style: TextStyle(fontSize: 12.sp)),
          SizedBox(width: 8.w),
          _rowsPerPageDropdown(),
          SizedBox(width: 8.w),
          ReusableText('عرض', style: TextStyle(fontSize: 12.sp)),
          const Spacer(),
          _toolbarButton(Icons.ios_share_rounded, 'تصدير إلى CSV', () => bloc.add(const ExportPurchasesCsv())),
          _toolbarButton(Icons.description_outlined, 'تصدير إلى Excel', () {}),
          _toolbarButton(Icons.print_outlined, AppStrings.print, () {}),
          _toolbarButton(Icons.view_column_outlined, AppStrings.viewColumns, () {}),
          SizedBox(width: 16.w),
          SizedBox(
            width: 250.w,
            child: ReusableInput(
              hint: 'بحث...',
              prefixIcon: const Icon(Icons.search_rounded),
              onChanged: (v) => bloc.add(SearchPurchases(v)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _rowsPerPageDropdown() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(6.r)),
      child: DropdownButton<int>(
        value: 25,
        items: [25, 50, 100].map((e) => DropdownMenuItem(value: e, child: ReusableText('$e'))).toList(),
        onChanged: (v) {},
        underline: const SizedBox(),
        isDense: true,
      ),
    );
  }

  Widget _toolbarButton(IconData icon, String label, VoidCallback onPressed) {
    return Padding(
      padding: EdgeInsetsDirectional.only(start: 8.w),
      child: ReusableButton(
        text: label,
        prefixIcon: icon,
        type: ButtonType.outlined,
        size: ButtonSize.small,
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildRowActions(BuildContext context, PurchaseModel p) {
    final scheme = Theme.of(context).colorScheme;
    final bloc = context.read<PurchasesBloc>();

    return PopupMenuButton<String>(
      offset: const Offset(0, 40),
      onSelected: (v) {
        if (v == 'view') context.push(Routes.PURCHASE_DETAILS, extra: p);
        if (v == 'edit') {
          bloc.add(LoadPurchaseForEdit(p));
          context.push(Routes.PURCHASE_ADD, extra: p);
        }
        if (v == 'delete') {
          ConfirmDeleteDialog.show(
            context,
            title: 'إلغاء فاتورة المشتريات',
            message: 'هل أنت متأكد من إلغاء الفاتورة؟ سيتم خصم الكميات من المخزون.',
            onConfirm: () => bloc.add(VoidPurchase(p.id)),
          );
        }
      },
      itemBuilder: (_) => [
        _menuItem('view', Icons.visibility_rounded, AppStrings.inspect),
        _menuItem('edit', Icons.edit_rounded, AppStrings.edit),
        _menuItem('payments', Icons.account_balance_wallet_rounded, AppStrings.invoicePayments),
        _menuItem('print', Icons.print_rounded, AppStrings.printInvoice),
        _menuItem('delete', Icons.delete_outline_rounded, AppStrings.delete, color: AppColors.error),
      ],
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 6.h),
        decoration: BoxDecoration(
          color: scheme.primary,
          borderRadius: BorderRadius.circular(6.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ReusableText('خيارات', style: TextStyle(fontSize: 11.sp, color: Colors.white, fontWeight: FontWeight.bold)),
            Icon(Icons.keyboard_arrow_down_rounded, size: 14.sp, color: Colors.white),
          ],
        ),
      ),
    );
  }

  PopupMenuItem<String> _menuItem(String value, IconData icon, String label, {Color? color}) {
    return PopupMenuItem(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18.sp, color: color ?? Colors.grey.shade700),
          SizedBox(width: 12.w),
          ReusableText(label, style: TextStyle(fontSize: 12.sp, color: color)),
        ],
      ),
    );
  }
}
