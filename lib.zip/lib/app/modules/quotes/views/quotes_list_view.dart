import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/models/sales/quote_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/format_utils.dart';
import '../../../core/widgets/index.dart';
import '../bloc/quotes_bloc.dart';
import '../bloc/quotes_event.dart';
import '../bloc/quotes_state.dart';
import 'widgets/create_quote_dialog.dart';

class QuotesListView extends StatelessWidget {
  const QuotesListView({super.key});

  @override
  Widget build(BuildContext context) {
    return const _QuotesBody();
  }
}

class _QuotesBody extends StatelessWidget {
  const _QuotesBody();

  static const _statusLabels = {
    QuoteStatus.draft: AppStrings.quoteStatusDraft,
    QuoteStatus.sent: AppStrings.quoteStatusSent,
    QuoteStatus.accepted: AppStrings.quoteStatusAccepted,
    QuoteStatus.rejected: AppStrings.quoteStatusRejected,
  };

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return HomeShell(
      title: AppStrings.quotesTitle,
      child: Container(
        color: scheme.surfaceContainerLow.withValues(alpha: 0.3),
        padding: EdgeInsets.all(AppSpacing.xl.w),
        child: BlocBuilder<QuotesBloc, QuotesState>(
          builder: (context, state) {
            if (state.status == QuotesStatus.initial || state.status == QuotesStatus.loading) {
              return const Center(child: LoadingIndicator());
            }
            if (state.status == QuotesStatus.error) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ReusableText(state.error ?? AppStrings.errorLoadingQuotes),
                    SizedBox(height: 16.h),
                    ReusableButton(
                      text: AppStrings.refresh,
                      onPressed: () => context.read<QuotesBloc>().add(const LoadQuotes()),
                    ),
                  ],
                ),
              );
            }
            return Column(
              children: [
                _buildHeader(context),
                SizedBox(height: AppSpacing.lg.h),
                Expanded(child: _buildList(context, state)),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        ReusableButton(
          text: AppStrings.createQuoteAction,
          prefixIcon: Icons.add_rounded,
          onPressed: () => _showCreateQuoteDialog(context),
        ),
        const Spacer(),
      ],
    );
  }

  Widget _buildList(BuildContext context, QuotesState state) {
    if (state.quotes.isEmpty) {
      return const EmptyState(
        icon: Icons.sell_outlined,
        title: AppStrings.noPriceQuotes,
      );
    }
    return ListView.separated(
      itemCount: state.quotes.length,
      separatorBuilder: (_, _) => SizedBox(height: AppSpacing.sm.h),
      itemBuilder: (_, i) {
        final q = state.quotes[i];
        final statusColor = switch (q.status) {
          QuoteStatus.draft => AppColors.textMutedOf(context),
          QuoteStatus.sent => AppColors.info,
          QuoteStatus.accepted => AppColors.success,
          QuoteStatus.rejected => AppColors.error,
        };
        return TransactionCard(
          icon: Icons.sell_outlined,
          iconColor: AppColors.primary,
          title: AppStrings.quoteNumberTitleFormat.replaceFirst('%s', q.number.toString()).replaceFirst('%s', q.customerName),
          tags: [
            Tag(
              label: _statusLabels[q.status] ?? '',
              color: statusColor,
            ),
          ],
          amount: formatMoney(q.total),
          date: formatDateTime(q.createdAt),
          menuItems: [
            ReusableActionMenuItem(
              value: 'delete',
              icon: Icons.delete_outline_rounded,
              label: AppStrings.delete,
              color: AppColors.error,
            ),
          ],
          onMenuSelected: (value) {
            if (value == 'delete') {
              _confirmDeleteQuote(context, q);
            }
          },
        );
      },
    );
  }

  void _confirmDeleteQuote(BuildContext context, QuoteModel quote) {
    final bloc = context.read<QuotesBloc>();
    ConfirmDeleteDialog.show(
      context,
      title: AppStrings.deleteQuoteTitle,
      message: AppStrings.deleteQuoteConfirmFormat.replaceFirst('%s', quote.number.toString()),
      onConfirm: () => bloc.add(DeleteQuote(quote.id)),
    );
  }

  void _showCreateQuoteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => CreateQuoteDialog(
        onConfirm: (customer, notes, items, subtotal, discount, total) {
          context.read<QuotesBloc>().add(CreateQuote(
                customerName: customer,
                notes: notes,
                items: items,
                subtotal: subtotal,
                discount: discount,
                total: total,
              ));
          Navigator.pop(context);
        },
      ),
    );
  }
}

