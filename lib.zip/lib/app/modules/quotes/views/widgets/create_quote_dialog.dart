import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pharmacy_system/app/core/theme/app_colors.dart';
import 'package:pharmacy_system/app/core/theme/app_sizes.dart';
import 'package:pharmacy_system/app/core/constants/app_strings.dart';
import 'package:pharmacy_system/app/core/utils/format_utils.dart';
import 'package:pharmacy_system/app/core/utils/app_snackbar.dart';
import 'package:pharmacy_system/app/core/widgets/reusables/index.dart';
import 'package:pharmacy_system/app/core/services/admin/branch_data_service.dart';
import 'package:pharmacy_system/app/core/models/inventory/medicine_model.dart';

class CreateQuoteDialog extends StatefulWidget {
  final Function(String customer, String? notes, List<Map<String, dynamic>> items, double subtotal, double discount, double total) onConfirm;

  const CreateQuoteDialog({super.key, required this.onConfirm});

  @override
  State<CreateQuoteDialog> createState() => _CreateQuoteDialogState();
}

class _CreateQuoteDialogState extends State<CreateQuoteDialog> {
  final _customerCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  final _discountCtrl = TextEditingController(text: '0');
  
  final List<_QuoteItemRowData> _items = [_QuoteItemRowData()];

  @override
  void dispose() {
    _customerCtrl.dispose();
    _notesCtrl.dispose();
    _discountCtrl.dispose();
    for (var item in _items) { item.dispose(); }
    super.dispose();
  }

  void _addItem() {
    setState(() {
      _items.add(_QuoteItemRowData());
    });
  }

  void _removeItem(int i) {
    if (_items.length > 1) {
      setState(() {
        _items[i].dispose();
        _items.removeAt(i);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double subtotal = 0;
    for (var item in _items) {
      final qty = double.tryParse(item.qtyCtrl.text) ?? 0;
      final price = double.tryParse(item.priceCtrl.text) ?? 0;
      subtotal += qty * price;
    }
    final discount = double.tryParse(_discountCtrl.text) ?? 0;
    final total = (subtotal - discount).clamp(0, double.infinity).toDouble();

    return ReusableDialog(
      title: AppStrings.createQuoteTitle,
      headerIcon: const Icon(Icons.sell_rounded, color: Colors.white),
      headerIconColor: AppColors.primary,
      maxWidth: 1000,
      children: [
        // قسم بيانات العميل
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: ReusableInput(
                label: AppStrings.quoteCustomerLabel,
                hint: AppStrings.quoteCustomerHint,
                controller: _customerCtrl,
                prefixIcon: const Icon(Icons.person_pin_rounded),
              ),
            ),
            SizedBox(width: AppSpacing.md.w),
            Expanded(
              flex: 2,
              child: ReusableInput(
                label: AppStrings.quoteNotesLabel,
                hint: AppStrings.quoteNotesHint,
                controller: _notesCtrl,
                maxLines: 1,
              ),
            ),
          ],
        ),
        
        SizedBox(height: AppSpacing.lg.h),
        const SectionHeader(title: AppStrings.quoteItemsSection, icon: Icons.list_alt_rounded),
        SizedBox(height: AppSpacing.sm.h),

        // ترويسة جدول الأصناف
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(AppRadius.md.r),
          ),
          child: Row(
            children: [
              Expanded(flex: 5, child: ReusableText(AppStrings.itemNameOrService, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12.sp))),
              SizedBox(width: AppSpacing.md.w),
              Expanded(flex: 2, child: ReusableText(AppStrings.quantityLabel, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12.sp))),
              SizedBox(width: AppSpacing.md.w),
              Expanded(flex: 2, child: ReusableText(AppStrings.unitPriceLabel, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12.sp))),
              SizedBox(width: AppSpacing.md.w),
              Expanded(flex: 2, child: ReusableText(AppStrings.totalLabel, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12.sp))),
              SizedBox(width: 56.w), 
            ],
          ),
        ),
        
        // قائمة الأصناف القابلة للتمرير
        ConstrainedBox(
          constraints: BoxConstraints(maxHeight: 400.h),
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: _items.length,
            padding: EdgeInsets.symmetric(vertical: 8.h),
            itemBuilder: (context, i) {
              return _QuoteItemRow(
                key: ValueKey(_items[i].id),
                data: _items[i],
                onRemove: () => _removeItem(i),
                onChanged: () => setState(() {}),
              );
            },
          ),
        ),

        SizedBox(height: AppSpacing.md.h),
        ReusableButton(
          text: AppStrings.addNewItemLine,
          prefixIcon: Icons.add_circle_outline_rounded,
          type: ButtonType.outlined,
          onPressed: _addItem,
        ),

        SizedBox(height: AppSpacing.xl.h),
        const Divider(),
        SizedBox(height: AppSpacing.lg.h),

        // قسم المخلص المالي
        Row(
          children: [
            const Spacer(),
            SizedBox(
              width: 350.w,
              child: AppCard(
                padding: EdgeInsets.all(AppSpacing.lg.w),
                backgroundColor: AppColors.primary.withValues(alpha: 0.04),
                child: Column(
                  children: [
                    _totalRow(AppStrings.subtotalBeforeDiscount, formatMoney(subtotal), context),
                    SizedBox(height: 12.h),
                    Row(
                      children: [
                        Expanded(
                          child: ReusableText(AppStrings.discountValueLabel, style: TextStyle(fontSize: 12.sp, color: AppColors.textSecondaryOf(context))),
                        ),
                        SizedBox(
                          width: 120.w,
                          child: ReusableInput(
                            controller: _discountCtrl,
                            textAlign: TextAlign.center,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            prefixIcon: const Icon(Icons.discount_outlined, size: 16),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16.h),
                    const Divider(),
                    SizedBox(height: 12.h),
                    _totalRow(AppStrings.finalNetTotal, formatMoney(total), context, isMain: true),
                  ],
                ),
              ),
            ),
          ],
        ),

        SizedBox(height: AppSpacing.xl.h),
        
        // أزرار التحكم
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            ReusableButton(
              text: AppStrings.empCancelAction,
              type: ButtonType.text,
              onPressed: () => Navigator.pop(context),
            ),
            SizedBox(width: AppSpacing.md.w),
            SizedBox(
              width: 280.w,
              child: ReusableButton(
                text: AppStrings.saveAndIssueQuote,
                prefixIcon: Icons.check_circle_rounded,
                onPressed: () {
                  final customer = _customerCtrl.text.trim();
                  if (customer.isEmpty) {
                    AppSnackbar.warning(AppStrings.enterCustomerNameWarning);
                    return;
                  }
                  final validItems = <Map<String, dynamic>>[];
                  for (var item in _items) {
                    final name = item.nameCtrl.text.trim();
                    final qty = double.tryParse(item.qtyCtrl.text) ?? 0;
                    final price = double.tryParse(item.priceCtrl.text) ?? 0;
                    if (name.isEmpty || qty <= 0) continue;
                    validItems.add({
                      'name': name,
                      'qty': qty,
                      'unit_price': price,
                      'total': qty * price,
                    });
                  }
                  if (validItems.isEmpty) {
                    AppSnackbar.warning(AppStrings.addAtLeastOneItemWarning);
                    return;
                  }
                  
                  widget.onConfirm(customer, _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(), validItems, subtotal, discount, total);
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _totalRow(String label, String value, BuildContext context, {bool isMain = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ReusableText(label, style: TextStyle(fontSize: isMain ? 14.sp : 12.sp, fontWeight: isMain ? FontWeight.bold : FontWeight.normal, color: AppColors.textSecondaryOf(context))),
        ReusableText(value, style: TextStyle(fontSize: isMain ? 22.sp : 14.sp, fontWeight: FontWeight.w900, color: isMain ? AppColors.primary : AppColors.textPrimaryOf(context))),
      ],
    );
  }
}

class _QuoteItemRowData {
  final String id = DateTime.now().microsecondsSinceEpoch.toString();
  final nameCtrl = TextEditingController();
  final qtyCtrl = TextEditingController(text: '1');
  final priceCtrl = TextEditingController(text: '0');

  void dispose() {
    nameCtrl.dispose();
    qtyCtrl.dispose();
    priceCtrl.dispose();
  }
}

class _QuoteItemRow extends StatelessWidget {
  final _QuoteItemRowData data;
  final VoidCallback onRemove;
  final VoidCallback onChanged;

  const _QuoteItemRow({super.key, required this.data, required this.onRemove, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final itemQty = double.tryParse(data.qtyCtrl.text) ?? 0;
    final itemPrice = double.tryParse(data.priceCtrl.text) ?? 0;
    final itemTotal = itemQty * itemPrice;

    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            flex: 5,
            child: _MedicineSearchField(
              controller: data.nameCtrl,
              onSelected: (m) {
                data.nameCtrl.text = m.name;
                data.priceCtrl.text = m.sellPrice.toStringAsFixed(2);
                onChanged();
              },
              onChanged: (v) => onChanged(),
            ),
          ),
          SizedBox(width: AppSpacing.md.w),
          Expanded(
            flex: 2,
            child: ReusableInput(
              controller: data.qtyCtrl,
              textAlign: TextAlign.center,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => onChanged(),
            ),
          ),
          SizedBox(width: AppSpacing.md.w),
          Expanded(
            flex: 2,
            child: ReusableInput(
              controller: data.priceCtrl,
              textAlign: TextAlign.center,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => onChanged(),
            ),
          ),
          SizedBox(width: AppSpacing.md.w),
          Expanded(
            flex: 2,
            child: Container(
              height: 48.h,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.inputFillOf(context),
                borderRadius: BorderRadius.circular(AppRadius.md.r),
                border: Border.all(color: AppColors.borderOf(context).withValues(alpha: 0.2)),
              ),
              child: ReusableText(
                itemTotal.toStringAsFixed(2),
                style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.primary, fontSize: 14.sp),
              ),
            ),
          ),
          SizedBox(width: 8.w),
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded, color: AppColors.error, size: 28),
            onPressed: onRemove,
            tooltip: AppStrings.deleteLineTooltip,
          ),
        ],
      ),
    );
  }
}

class _MedicineSearchField extends StatefulWidget {
  final TextEditingController controller;
  final ValueChanged<MedicineModel> onSelected;
  final ValueChanged<String> onChanged;

  const _MedicineSearchField({required this.controller, required this.onSelected, required this.onChanged});

  @override
  State<_MedicineSearchField> createState() => _MedicineSearchFieldState();
}

class _MedicineSearchFieldState extends State<_MedicineSearchField> {
  final FocusNode _focusNode = FocusNode();
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      if (_focusNode.hasFocus) {
        _showOverlay();
      } else {
        _hideOverlay();
      }
    });
  }

  @override
  void dispose() {
    _hideOverlay();
    _focusNode.dispose();
    super.dispose();
  }

  void _showOverlay() {
    _hideOverlay();
    final overlay = Overlay.of(context);
    _overlayEntry = _createOverlayEntry();
    overlay.insert(_overlayEntry!);
  }

  void _hideOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    final renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 4.h),
          child: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(8.r),
            color: Colors.white,
            child: Container(
              constraints: BoxConstraints(maxHeight: 250.h),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade200),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: StatefulBuilder(
                builder: (context, setOverlayState) {
                  final query = widget.controller.text.toLowerCase();
                  final meds = BranchDataService.getMedicines()
                      .where((m) => m.name.toLowerCase().contains(query) || m.barcodes.any((b) => b.contains(query)))
                      .take(8)
                      .toList();

                  if (meds.isEmpty) {
                    return Padding(
                      padding: EdgeInsets.all(12.w),
                      child: const Text(AppStrings.noMatchingSearchResults, textAlign: TextAlign.center),
                    );
                  }

                  return ListView.separated(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemCount: meds.length,
                    separatorBuilder: (context, index) => Divider(height: 1, color: Colors.grey.shade100),
                    itemBuilder: (context, index) {
                      final m = meds[index];
                      return ListTile(
                        dense: true,
                        title: ReusableText(m.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: ReusableText(AppStrings.priceStockFormat.replaceFirst('%s', formatMoney(m.sellPrice)).replaceFirst('%s', m.quantity.toString())),
                        onTap: () {
                          widget.onSelected(m);
                          _focusNode.unfocus();
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: ReusableInput(
        controller: widget.controller,
        focusNode: _focusNode,
        hint: AppStrings.itemOrSearchHint,
        onChanged: (v) {
          widget.onChanged(v);
          if (_overlayEntry != null) {
            _overlayEntry!.markNeedsBuild();
          }
        },
      ),
    );
  }
}
