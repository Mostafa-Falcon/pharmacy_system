// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'party_payment_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PartyPaymentModel _$PartyPaymentModelFromJson(Map<String, dynamic> json) {
  return _PartyPaymentModel.fromJson(json);
}

/// @nodoc
mixin _$PartyPaymentModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  int get number => throw _privateConstructorUsedError;
  @JsonKey(name: 'payment_date')
  DateTime get paymentDate => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
  PartyPaymentKind get kind => throw _privateConstructorUsedError;
  @JsonKey(name: 'party_id')
  String get partyId => throw _privateConstructorUsedError;
  @JsonKey(name: 'party_name')
  String get partyName => throw _privateConstructorUsedError;
  double get amount => throw _privateConstructorUsedError;
  @JsonKey(name: 'payment_method')
  String get paymentMethod => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
  PartyBalanceEffect? get balanceEffect => throw _privateConstructorUsedError;
  @JsonKey(name: 'purchase_receipt_id')
  String? get purchaseReceiptId => throw _privateConstructorUsedError;
  @JsonKey(name: 'purchase_receipt_number')
  String? get purchaseReceiptNumber => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_number')
  String? get referenceNumber => throw _privateConstructorUsedError;
  String? get notes => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_id')
  String get createdById => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_name')
  String? get createdByName => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PartyPaymentModelCopyWith<PartyPaymentModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PartyPaymentModelCopyWith<$Res> {
  factory $PartyPaymentModelCopyWith(
          PartyPaymentModel value, $Res Function(PartyPaymentModel) then) =
      _$PartyPaymentModelCopyWithImpl<$Res, PartyPaymentModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      int number,
      @JsonKey(name: 'payment_date') DateTime paymentDate,
      @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
      PartyPaymentKind kind,
      @JsonKey(name: 'party_id') String partyId,
      @JsonKey(name: 'party_name') String partyName,
      double amount,
      @JsonKey(name: 'payment_method') String paymentMethod,
      @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
      PartyBalanceEffect? balanceEffect,
      @JsonKey(name: 'purchase_receipt_id') String? purchaseReceiptId,
      @JsonKey(name: 'purchase_receipt_number') String? purchaseReceiptNumber,
      @JsonKey(name: 'reference_number') String? referenceNumber,
      String? notes,
      @JsonKey(name: 'created_by_id') String createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$PartyPaymentModelCopyWithImpl<$Res, $Val extends PartyPaymentModel>
    implements $PartyPaymentModelCopyWith<$Res> {
  _$PartyPaymentModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? number = null,
    Object? paymentDate = null,
    Object? kind = null,
    Object? partyId = null,
    Object? partyName = null,
    Object? amount = null,
    Object? paymentMethod = null,
    Object? balanceEffect = freezed,
    Object? purchaseReceiptId = freezed,
    Object? purchaseReceiptNumber = freezed,
    Object? referenceNumber = freezed,
    Object? notes = freezed,
    Object? createdById = null,
    Object? createdByName = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      number: null == number
          ? _value.number
          : number // ignore: cast_nullable_to_non_nullable
              as int,
      paymentDate: null == paymentDate
          ? _value.paymentDate
          : paymentDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      kind: null == kind
          ? _value.kind
          : kind // ignore: cast_nullable_to_non_nullable
              as PartyPaymentKind,
      partyId: null == partyId
          ? _value.partyId
          : partyId // ignore: cast_nullable_to_non_nullable
              as String,
      partyName: null == partyName
          ? _value.partyName
          : partyName // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as double,
      paymentMethod: null == paymentMethod
          ? _value.paymentMethod
          : paymentMethod // ignore: cast_nullable_to_non_nullable
              as String,
      balanceEffect: freezed == balanceEffect
          ? _value.balanceEffect
          : balanceEffect // ignore: cast_nullable_to_non_nullable
              as PartyBalanceEffect?,
      purchaseReceiptId: freezed == purchaseReceiptId
          ? _value.purchaseReceiptId
          : purchaseReceiptId // ignore: cast_nullable_to_non_nullable
              as String?,
      purchaseReceiptNumber: freezed == purchaseReceiptNumber
          ? _value.purchaseReceiptNumber
          : purchaseReceiptNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      referenceNumber: freezed == referenceNumber
          ? _value.referenceNumber
          : referenceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdById: null == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PartyPaymentModelImplCopyWith<$Res>
    implements $PartyPaymentModelCopyWith<$Res> {
  factory _$$PartyPaymentModelImplCopyWith(_$PartyPaymentModelImpl value,
          $Res Function(_$PartyPaymentModelImpl) then) =
      __$$PartyPaymentModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      int number,
      @JsonKey(name: 'payment_date') DateTime paymentDate,
      @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
      PartyPaymentKind kind,
      @JsonKey(name: 'party_id') String partyId,
      @JsonKey(name: 'party_name') String partyName,
      double amount,
      @JsonKey(name: 'payment_method') String paymentMethod,
      @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
      PartyBalanceEffect? balanceEffect,
      @JsonKey(name: 'purchase_receipt_id') String? purchaseReceiptId,
      @JsonKey(name: 'purchase_receipt_number') String? purchaseReceiptNumber,
      @JsonKey(name: 'reference_number') String? referenceNumber,
      String? notes,
      @JsonKey(name: 'created_by_id') String createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$PartyPaymentModelImplCopyWithImpl<$Res>
    extends _$PartyPaymentModelCopyWithImpl<$Res, _$PartyPaymentModelImpl>
    implements _$$PartyPaymentModelImplCopyWith<$Res> {
  __$$PartyPaymentModelImplCopyWithImpl(_$PartyPaymentModelImpl _value,
      $Res Function(_$PartyPaymentModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? number = null,
    Object? paymentDate = null,
    Object? kind = null,
    Object? partyId = null,
    Object? partyName = null,
    Object? amount = null,
    Object? paymentMethod = null,
    Object? balanceEffect = freezed,
    Object? purchaseReceiptId = freezed,
    Object? purchaseReceiptNumber = freezed,
    Object? referenceNumber = freezed,
    Object? notes = freezed,
    Object? createdById = null,
    Object? createdByName = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$PartyPaymentModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      number: null == number
          ? _value.number
          : number // ignore: cast_nullable_to_non_nullable
              as int,
      paymentDate: null == paymentDate
          ? _value.paymentDate
          : paymentDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      kind: null == kind
          ? _value.kind
          : kind // ignore: cast_nullable_to_non_nullable
              as PartyPaymentKind,
      partyId: null == partyId
          ? _value.partyId
          : partyId // ignore: cast_nullable_to_non_nullable
              as String,
      partyName: null == partyName
          ? _value.partyName
          : partyName // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as double,
      paymentMethod: null == paymentMethod
          ? _value.paymentMethod
          : paymentMethod // ignore: cast_nullable_to_non_nullable
              as String,
      balanceEffect: freezed == balanceEffect
          ? _value.balanceEffect
          : balanceEffect // ignore: cast_nullable_to_non_nullable
              as PartyBalanceEffect?,
      purchaseReceiptId: freezed == purchaseReceiptId
          ? _value.purchaseReceiptId
          : purchaseReceiptId // ignore: cast_nullable_to_non_nullable
              as String?,
      purchaseReceiptNumber: freezed == purchaseReceiptNumber
          ? _value.purchaseReceiptNumber
          : purchaseReceiptNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      referenceNumber: freezed == referenceNumber
          ? _value.referenceNumber
          : referenceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      notes: freezed == notes
          ? _value.notes
          : notes // ignore: cast_nullable_to_non_nullable
              as String?,
      createdById: null == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PartyPaymentModelImpl extends _PartyPaymentModel {
  const _$PartyPaymentModelImpl(
      {required this.id,
      @JsonKey(name: 'branch_id') required this.branchId,
      required this.number,
      @JsonKey(name: 'payment_date') required this.paymentDate,
      @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson) required this.kind,
      @JsonKey(name: 'party_id') required this.partyId,
      @JsonKey(name: 'party_name') this.partyName = '',
      required this.amount,
      @JsonKey(name: 'payment_method') this.paymentMethod = 'cash',
      @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
      this.balanceEffect,
      @JsonKey(name: 'purchase_receipt_id') this.purchaseReceiptId,
      @JsonKey(name: 'purchase_receipt_number') this.purchaseReceiptNumber,
      @JsonKey(name: 'reference_number') this.referenceNumber,
      this.notes,
      @JsonKey(name: 'created_by_id') required this.createdById,
      @JsonKey(name: 'created_by_name') this.createdByName,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : super._();

  factory _$PartyPaymentModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PartyPaymentModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  final int number;
  @override
  @JsonKey(name: 'payment_date')
  final DateTime paymentDate;
  @override
  @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
  final PartyPaymentKind kind;
  @override
  @JsonKey(name: 'party_id')
  final String partyId;
  @override
  @JsonKey(name: 'party_name')
  final String partyName;
  @override
  final double amount;
  @override
  @JsonKey(name: 'payment_method')
  final String paymentMethod;
  @override
  @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
  final PartyBalanceEffect? balanceEffect;
  @override
  @JsonKey(name: 'purchase_receipt_id')
  final String? purchaseReceiptId;
  @override
  @JsonKey(name: 'purchase_receipt_number')
  final String? purchaseReceiptNumber;
  @override
  @JsonKey(name: 'reference_number')
  final String? referenceNumber;
  @override
  final String? notes;
  @override
  @JsonKey(name: 'created_by_id')
  final String createdById;
  @override
  @JsonKey(name: 'created_by_name')
  final String? createdByName;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'PartyPaymentModel(id: $id, branchId: $branchId, number: $number, paymentDate: $paymentDate, kind: $kind, partyId: $partyId, partyName: $partyName, amount: $amount, paymentMethod: $paymentMethod, balanceEffect: $balanceEffect, purchaseReceiptId: $purchaseReceiptId, purchaseReceiptNumber: $purchaseReceiptNumber, referenceNumber: $referenceNumber, notes: $notes, createdById: $createdById, createdByName: $createdByName, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PartyPaymentModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.number, number) || other.number == number) &&
            (identical(other.paymentDate, paymentDate) ||
                other.paymentDate == paymentDate) &&
            (identical(other.kind, kind) || other.kind == kind) &&
            (identical(other.partyId, partyId) || other.partyId == partyId) &&
            (identical(other.partyName, partyName) ||
                other.partyName == partyName) &&
            (identical(other.amount, amount) || other.amount == amount) &&
            (identical(other.paymentMethod, paymentMethod) ||
                other.paymentMethod == paymentMethod) &&
            (identical(other.balanceEffect, balanceEffect) ||
                other.balanceEffect == balanceEffect) &&
            (identical(other.purchaseReceiptId, purchaseReceiptId) ||
                other.purchaseReceiptId == purchaseReceiptId) &&
            (identical(other.purchaseReceiptNumber, purchaseReceiptNumber) ||
                other.purchaseReceiptNumber == purchaseReceiptNumber) &&
            (identical(other.referenceNumber, referenceNumber) ||
                other.referenceNumber == referenceNumber) &&
            (identical(other.notes, notes) || other.notes == notes) &&
            (identical(other.createdById, createdById) ||
                other.createdById == createdById) &&
            (identical(other.createdByName, createdByName) ||
                other.createdByName == createdByName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      branchId,
      number,
      paymentDate,
      kind,
      partyId,
      partyName,
      amount,
      paymentMethod,
      balanceEffect,
      purchaseReceiptId,
      purchaseReceiptNumber,
      referenceNumber,
      notes,
      createdById,
      createdByName,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PartyPaymentModelImplCopyWith<_$PartyPaymentModelImpl> get copyWith =>
      __$$PartyPaymentModelImplCopyWithImpl<_$PartyPaymentModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PartyPaymentModelImplToJson(
      this,
    );
  }
}

abstract class _PartyPaymentModel extends PartyPaymentModel {
  const factory _PartyPaymentModel(
      {required final String id,
      @JsonKey(name: 'branch_id') required final String branchId,
      required final int number,
      @JsonKey(name: 'payment_date') required final DateTime paymentDate,
      @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
      required final PartyPaymentKind kind,
      @JsonKey(name: 'party_id') required final String partyId,
      @JsonKey(name: 'party_name') final String partyName,
      required final double amount,
      @JsonKey(name: 'payment_method') final String paymentMethod,
      @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
      final PartyBalanceEffect? balanceEffect,
      @JsonKey(name: 'purchase_receipt_id') final String? purchaseReceiptId,
      @JsonKey(name: 'purchase_receipt_number')
      final String? purchaseReceiptNumber,
      @JsonKey(name: 'reference_number') final String? referenceNumber,
      final String? notes,
      @JsonKey(name: 'created_by_id') required final String createdById,
      @JsonKey(name: 'created_by_name') final String? createdByName,
      @JsonKey(name: 'created_at') required final DateTime createdAt,
      @JsonKey(name: 'updated_at')
      required final DateTime updatedAt}) = _$PartyPaymentModelImpl;
  const _PartyPaymentModel._() : super._();

  factory _PartyPaymentModel.fromJson(Map<String, dynamic> json) =
      _$PartyPaymentModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  int get number;
  @override
  @JsonKey(name: 'payment_date')
  DateTime get paymentDate;
  @override
  @JsonKey(fromJson: _kindFromJson, toJson: _kindToJson)
  PartyPaymentKind get kind;
  @override
  @JsonKey(name: 'party_id')
  String get partyId;
  @override
  @JsonKey(name: 'party_name')
  String get partyName;
  @override
  double get amount;
  @override
  @JsonKey(name: 'payment_method')
  String get paymentMethod;
  @override
  @JsonKey(fromJson: _balanceEffectFromJson, toJson: _balanceEffectToJson)
  PartyBalanceEffect? get balanceEffect;
  @override
  @JsonKey(name: 'purchase_receipt_id')
  String? get purchaseReceiptId;
  @override
  @JsonKey(name: 'purchase_receipt_number')
  String? get purchaseReceiptNumber;
  @override
  @JsonKey(name: 'reference_number')
  String? get referenceNumber;
  @override
  String? get notes;
  @override
  @JsonKey(name: 'created_by_id')
  String get createdById;
  @override
  @JsonKey(name: 'created_by_name')
  String? get createdByName;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$PartyPaymentModelImplCopyWith<_$PartyPaymentModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
