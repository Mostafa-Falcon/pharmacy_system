// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'journal_entry_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

JournalEntryLineModel _$JournalEntryLineModelFromJson(
    Map<String, dynamic> json) {
  return _JournalEntryLineModel.fromJson(json);
}

/// @nodoc
mixin _$JournalEntryLineModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'account_id')
  String get accountId => throw _privateConstructorUsedError;
  @JsonKey(name: 'account_name')
  String get accountName => throw _privateConstructorUsedError;
  @JsonKey(name: 'account_code')
  String get accountCode => throw _privateConstructorUsedError;
  double get debit => throw _privateConstructorUsedError;
  double get credit => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $JournalEntryLineModelCopyWith<JournalEntryLineModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $JournalEntryLineModelCopyWith<$Res> {
  factory $JournalEntryLineModelCopyWith(JournalEntryLineModel value,
          $Res Function(JournalEntryLineModel) then) =
      _$JournalEntryLineModelCopyWithImpl<$Res, JournalEntryLineModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'account_id') String accountId,
      @JsonKey(name: 'account_name') String accountName,
      @JsonKey(name: 'account_code') String accountCode,
      double debit,
      double credit,
      String? description});
}

/// @nodoc
class _$JournalEntryLineModelCopyWithImpl<$Res,
        $Val extends JournalEntryLineModel>
    implements $JournalEntryLineModelCopyWith<$Res> {
  _$JournalEntryLineModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? accountId = null,
    Object? accountName = null,
    Object? accountCode = null,
    Object? debit = null,
    Object? credit = null,
    Object? description = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      accountId: null == accountId
          ? _value.accountId
          : accountId // ignore: cast_nullable_to_non_nullable
              as String,
      accountName: null == accountName
          ? _value.accountName
          : accountName // ignore: cast_nullable_to_non_nullable
              as String,
      accountCode: null == accountCode
          ? _value.accountCode
          : accountCode // ignore: cast_nullable_to_non_nullable
              as String,
      debit: null == debit
          ? _value.debit
          : debit // ignore: cast_nullable_to_non_nullable
              as double,
      credit: null == credit
          ? _value.credit
          : credit // ignore: cast_nullable_to_non_nullable
              as double,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$JournalEntryLineModelImplCopyWith<$Res>
    implements $JournalEntryLineModelCopyWith<$Res> {
  factory _$$JournalEntryLineModelImplCopyWith(
          _$JournalEntryLineModelImpl value,
          $Res Function(_$JournalEntryLineModelImpl) then) =
      __$$JournalEntryLineModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'account_id') String accountId,
      @JsonKey(name: 'account_name') String accountName,
      @JsonKey(name: 'account_code') String accountCode,
      double debit,
      double credit,
      String? description});
}

/// @nodoc
class __$$JournalEntryLineModelImplCopyWithImpl<$Res>
    extends _$JournalEntryLineModelCopyWithImpl<$Res,
        _$JournalEntryLineModelImpl>
    implements _$$JournalEntryLineModelImplCopyWith<$Res> {
  __$$JournalEntryLineModelImplCopyWithImpl(_$JournalEntryLineModelImpl _value,
      $Res Function(_$JournalEntryLineModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? accountId = null,
    Object? accountName = null,
    Object? accountCode = null,
    Object? debit = null,
    Object? credit = null,
    Object? description = freezed,
  }) {
    return _then(_$JournalEntryLineModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      accountId: null == accountId
          ? _value.accountId
          : accountId // ignore: cast_nullable_to_non_nullable
              as String,
      accountName: null == accountName
          ? _value.accountName
          : accountName // ignore: cast_nullable_to_non_nullable
              as String,
      accountCode: null == accountCode
          ? _value.accountCode
          : accountCode // ignore: cast_nullable_to_non_nullable
              as String,
      debit: null == debit
          ? _value.debit
          : debit // ignore: cast_nullable_to_non_nullable
              as double,
      credit: null == credit
          ? _value.credit
          : credit // ignore: cast_nullable_to_non_nullable
              as double,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$JournalEntryLineModelImpl extends _JournalEntryLineModel {
  const _$JournalEntryLineModelImpl(
      {required this.id,
      @JsonKey(name: 'account_id') required this.accountId,
      @JsonKey(name: 'account_name') this.accountName = '',
      @JsonKey(name: 'account_code') this.accountCode = '',
      this.debit = 0,
      this.credit = 0,
      this.description})
      : super._();

  factory _$JournalEntryLineModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$JournalEntryLineModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'account_id')
  final String accountId;
  @override
  @JsonKey(name: 'account_name')
  final String accountName;
  @override
  @JsonKey(name: 'account_code')
  final String accountCode;
  @override
  @JsonKey()
  final double debit;
  @override
  @JsonKey()
  final double credit;
  @override
  final String? description;

  @override
  String toString() {
    return 'JournalEntryLineModel(id: $id, accountId: $accountId, accountName: $accountName, accountCode: $accountCode, debit: $debit, credit: $credit, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$JournalEntryLineModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.accountId, accountId) ||
                other.accountId == accountId) &&
            (identical(other.accountName, accountName) ||
                other.accountName == accountName) &&
            (identical(other.accountCode, accountCode) ||
                other.accountCode == accountCode) &&
            (identical(other.debit, debit) || other.debit == debit) &&
            (identical(other.credit, credit) || other.credit == credit) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, accountId, accountName,
      accountCode, debit, credit, description);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$JournalEntryLineModelImplCopyWith<_$JournalEntryLineModelImpl>
      get copyWith => __$$JournalEntryLineModelImplCopyWithImpl<
          _$JournalEntryLineModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$JournalEntryLineModelImplToJson(
      this,
    );
  }
}

abstract class _JournalEntryLineModel extends JournalEntryLineModel {
  const factory _JournalEntryLineModel(
      {required final String id,
      @JsonKey(name: 'account_id') required final String accountId,
      @JsonKey(name: 'account_name') final String accountName,
      @JsonKey(name: 'account_code') final String accountCode,
      final double debit,
      final double credit,
      final String? description}) = _$JournalEntryLineModelImpl;
  const _JournalEntryLineModel._() : super._();

  factory _JournalEntryLineModel.fromJson(Map<String, dynamic> json) =
      _$JournalEntryLineModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'account_id')
  String get accountId;
  @override
  @JsonKey(name: 'account_name')
  String get accountName;
  @override
  @JsonKey(name: 'account_code')
  String get accountCode;
  @override
  double get debit;
  @override
  double get credit;
  @override
  String? get description;
  @override
  @JsonKey(ignore: true)
  _$$JournalEntryLineModelImplCopyWith<_$JournalEntryLineModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

JournalEntryModel _$JournalEntryModelFromJson(Map<String, dynamic> json) {
  return _JournalEntryModel.fromJson(json);
}

/// @nodoc
mixin _$JournalEntryModel {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'branch_id')
  String get branchId => throw _privateConstructorUsedError;
  @JsonKey(name: 'entry_number')
  int get entryNumber => throw _privateConstructorUsedError;
  @JsonKey(name: 'entry_date')
  DateTime get entryDate => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
  JournalEntryType get entryType => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_id')
  String? get referenceId => throw _privateConstructorUsedError;
  @JsonKey(name: 'reference_number')
  String? get referenceNumber => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  List<JournalEntryLineModel> get lines => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_debit')
  double get totalDebit => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_credit')
  double get totalCredit => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_id')
  String get createdById => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_by_name')
  String? get createdByName => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  DateTime get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $JournalEntryModelCopyWith<JournalEntryModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $JournalEntryModelCopyWith<$Res> {
  factory $JournalEntryModelCopyWith(
          JournalEntryModel value, $Res Function(JournalEntryModel) then) =
      _$JournalEntryModelCopyWithImpl<$Res, JournalEntryModel>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'entry_number') int entryNumber,
      @JsonKey(name: 'entry_date') DateTime entryDate,
      @JsonKey(
          fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
      JournalEntryType entryType,
      @JsonKey(name: 'reference_id') String? referenceId,
      @JsonKey(name: 'reference_number') String? referenceNumber,
      String? description,
      List<JournalEntryLineModel> lines,
      @JsonKey(name: 'total_debit') double totalDebit,
      @JsonKey(name: 'total_credit') double totalCredit,
      @JsonKey(name: 'created_by_id') String createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class _$JournalEntryModelCopyWithImpl<$Res, $Val extends JournalEntryModel>
    implements $JournalEntryModelCopyWith<$Res> {
  _$JournalEntryModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? entryNumber = null,
    Object? entryDate = null,
    Object? entryType = null,
    Object? referenceId = freezed,
    Object? referenceNumber = freezed,
    Object? description = freezed,
    Object? lines = null,
    Object? totalDebit = null,
    Object? totalCredit = null,
    Object? createdById = null,
    Object? createdByName = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      entryNumber: null == entryNumber
          ? _value.entryNumber
          : entryNumber // ignore: cast_nullable_to_non_nullable
              as int,
      entryDate: null == entryDate
          ? _value.entryDate
          : entryDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      entryType: null == entryType
          ? _value.entryType
          : entryType // ignore: cast_nullable_to_non_nullable
              as JournalEntryType,
      referenceId: freezed == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String?,
      referenceNumber: freezed == referenceNumber
          ? _value.referenceNumber
          : referenceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      lines: null == lines
          ? _value.lines
          : lines // ignore: cast_nullable_to_non_nullable
              as List<JournalEntryLineModel>,
      totalDebit: null == totalDebit
          ? _value.totalDebit
          : totalDebit // ignore: cast_nullable_to_non_nullable
              as double,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      createdById: null == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$JournalEntryModelImplCopyWith<$Res>
    implements $JournalEntryModelCopyWith<$Res> {
  factory _$$JournalEntryModelImplCopyWith(_$JournalEntryModelImpl value,
          $Res Function(_$JournalEntryModelImpl) then) =
      __$$JournalEntryModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'branch_id') String branchId,
      @JsonKey(name: 'entry_number') int entryNumber,
      @JsonKey(name: 'entry_date') DateTime entryDate,
      @JsonKey(
          fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
      JournalEntryType entryType,
      @JsonKey(name: 'reference_id') String? referenceId,
      @JsonKey(name: 'reference_number') String? referenceNumber,
      String? description,
      List<JournalEntryLineModel> lines,
      @JsonKey(name: 'total_debit') double totalDebit,
      @JsonKey(name: 'total_credit') double totalCredit,
      @JsonKey(name: 'created_by_id') String createdById,
      @JsonKey(name: 'created_by_name') String? createdByName,
      @JsonKey(name: 'created_at') DateTime createdAt,
      @JsonKey(name: 'updated_at') DateTime updatedAt});
}

/// @nodoc
class __$$JournalEntryModelImplCopyWithImpl<$Res>
    extends _$JournalEntryModelCopyWithImpl<$Res, _$JournalEntryModelImpl>
    implements _$$JournalEntryModelImplCopyWith<$Res> {
  __$$JournalEntryModelImplCopyWithImpl(_$JournalEntryModelImpl _value,
      $Res Function(_$JournalEntryModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? branchId = null,
    Object? entryNumber = null,
    Object? entryDate = null,
    Object? entryType = null,
    Object? referenceId = freezed,
    Object? referenceNumber = freezed,
    Object? description = freezed,
    Object? lines = null,
    Object? totalDebit = null,
    Object? totalCredit = null,
    Object? createdById = null,
    Object? createdByName = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
  }) {
    return _then(_$JournalEntryModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      branchId: null == branchId
          ? _value.branchId
          : branchId // ignore: cast_nullable_to_non_nullable
              as String,
      entryNumber: null == entryNumber
          ? _value.entryNumber
          : entryNumber // ignore: cast_nullable_to_non_nullable
              as int,
      entryDate: null == entryDate
          ? _value.entryDate
          : entryDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      entryType: null == entryType
          ? _value.entryType
          : entryType // ignore: cast_nullable_to_non_nullable
              as JournalEntryType,
      referenceId: freezed == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as String?,
      referenceNumber: freezed == referenceNumber
          ? _value.referenceNumber
          : referenceNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      lines: null == lines
          ? _value._lines
          : lines // ignore: cast_nullable_to_non_nullable
              as List<JournalEntryLineModel>,
      totalDebit: null == totalDebit
          ? _value.totalDebit
          : totalDebit // ignore: cast_nullable_to_non_nullable
              as double,
      totalCredit: null == totalCredit
          ? _value.totalCredit
          : totalCredit // ignore: cast_nullable_to_non_nullable
              as double,
      createdById: null == createdById
          ? _value.createdById
          : createdById // ignore: cast_nullable_to_non_nullable
              as String,
      createdByName: freezed == createdByName
          ? _value.createdByName
          : createdByName // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$JournalEntryModelImpl extends _JournalEntryModel {
  const _$JournalEntryModelImpl(
      {required this.id,
      @JsonKey(name: 'branch_id') required this.branchId,
      @JsonKey(name: 'entry_number') required this.entryNumber,
      @JsonKey(name: 'entry_date') required this.entryDate,
      @JsonKey(
          fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
      this.entryType = JournalEntryType.other,
      @JsonKey(name: 'reference_id') this.referenceId,
      @JsonKey(name: 'reference_number') this.referenceNumber,
      this.description,
      final List<JournalEntryLineModel> lines = const [],
      @JsonKey(name: 'total_debit') this.totalDebit = 0,
      @JsonKey(name: 'total_credit') this.totalCredit = 0,
      @JsonKey(name: 'created_by_id') required this.createdById,
      @JsonKey(name: 'created_by_name') this.createdByName,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt})
      : _lines = lines,
        super._();

  factory _$JournalEntryModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$JournalEntryModelImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'branch_id')
  final String branchId;
  @override
  @JsonKey(name: 'entry_number')
  final int entryNumber;
  @override
  @JsonKey(name: 'entry_date')
  final DateTime entryDate;
  @override
  @JsonKey(fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
  final JournalEntryType entryType;
  @override
  @JsonKey(name: 'reference_id')
  final String? referenceId;
  @override
  @JsonKey(name: 'reference_number')
  final String? referenceNumber;
  @override
  final String? description;
  final List<JournalEntryLineModel> _lines;
  @override
  @JsonKey()
  List<JournalEntryLineModel> get lines {
    if (_lines is EqualUnmodifiableListView) return _lines;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_lines);
  }

  @override
  @JsonKey(name: 'total_debit')
  final double totalDebit;
  @override
  @JsonKey(name: 'total_credit')
  final double totalCredit;
  @override
  @JsonKey(name: 'created_by_id')
  final String createdById;
  @override
  @JsonKey(name: 'created_by_name')
  final String? createdByName;
  @override
  @JsonKey(name: 'created_at')
  final DateTime createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final DateTime updatedAt;

  @override
  String toString() {
    return 'JournalEntryModel(id: $id, branchId: $branchId, entryNumber: $entryNumber, entryDate: $entryDate, entryType: $entryType, referenceId: $referenceId, referenceNumber: $referenceNumber, description: $description, lines: $lines, totalDebit: $totalDebit, totalCredit: $totalCredit, createdById: $createdById, createdByName: $createdByName, createdAt: $createdAt, updatedAt: $updatedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$JournalEntryModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.branchId, branchId) ||
                other.branchId == branchId) &&
            (identical(other.entryNumber, entryNumber) ||
                other.entryNumber == entryNumber) &&
            (identical(other.entryDate, entryDate) ||
                other.entryDate == entryDate) &&
            (identical(other.entryType, entryType) ||
                other.entryType == entryType) &&
            (identical(other.referenceId, referenceId) ||
                other.referenceId == referenceId) &&
            (identical(other.referenceNumber, referenceNumber) ||
                other.referenceNumber == referenceNumber) &&
            (identical(other.description, description) ||
                other.description == description) &&
            const DeepCollectionEquality().equals(other._lines, _lines) &&
            (identical(other.totalDebit, totalDebit) ||
                other.totalDebit == totalDebit) &&
            (identical(other.totalCredit, totalCredit) ||
                other.totalCredit == totalCredit) &&
            (identical(other.createdById, createdById) ||
                other.createdById == createdById) &&
            (identical(other.createdByName, createdByName) ||
                other.createdByName == createdByName) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      branchId,
      entryNumber,
      entryDate,
      entryType,
      referenceId,
      referenceNumber,
      description,
      const DeepCollectionEquality().hash(_lines),
      totalDebit,
      totalCredit,
      createdById,
      createdByName,
      createdAt,
      updatedAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$JournalEntryModelImplCopyWith<_$JournalEntryModelImpl> get copyWith =>
      __$$JournalEntryModelImplCopyWithImpl<_$JournalEntryModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$JournalEntryModelImplToJson(
      this,
    );
  }
}

abstract class _JournalEntryModel extends JournalEntryModel {
  const factory _JournalEntryModel(
      {required final String id,
      @JsonKey(name: 'branch_id') required final String branchId,
      @JsonKey(name: 'entry_number') required final int entryNumber,
      @JsonKey(name: 'entry_date') required final DateTime entryDate,
      @JsonKey(
          fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
      final JournalEntryType entryType,
      @JsonKey(name: 'reference_id') final String? referenceId,
      @JsonKey(name: 'reference_number') final String? referenceNumber,
      final String? description,
      final List<JournalEntryLineModel> lines,
      @JsonKey(name: 'total_debit') final double totalDebit,
      @JsonKey(name: 'total_credit') final double totalCredit,
      @JsonKey(name: 'created_by_id') required final String createdById,
      @JsonKey(name: 'created_by_name') final String? createdByName,
      @JsonKey(name: 'created_at') required final DateTime createdAt,
      @JsonKey(name: 'updated_at')
      required final DateTime updatedAt}) = _$JournalEntryModelImpl;
  const _JournalEntryModel._() : super._();

  factory _JournalEntryModel.fromJson(Map<String, dynamic> json) =
      _$JournalEntryModelImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'branch_id')
  String get branchId;
  @override
  @JsonKey(name: 'entry_number')
  int get entryNumber;
  @override
  @JsonKey(name: 'entry_date')
  DateTime get entryDate;
  @override
  @JsonKey(fromJson: _journalEntryTypeFromJson, toJson: _journalEntryTypeToJson)
  JournalEntryType get entryType;
  @override
  @JsonKey(name: 'reference_id')
  String? get referenceId;
  @override
  @JsonKey(name: 'reference_number')
  String? get referenceNumber;
  @override
  String? get description;
  @override
  List<JournalEntryLineModel> get lines;
  @override
  @JsonKey(name: 'total_debit')
  double get totalDebit;
  @override
  @JsonKey(name: 'total_credit')
  double get totalCredit;
  @override
  @JsonKey(name: 'created_by_id')
  String get createdById;
  @override
  @JsonKey(name: 'created_by_name')
  String? get createdByName;
  @override
  @JsonKey(name: 'created_at')
  DateTime get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  DateTime get updatedAt;
  @override
  @JsonKey(ignore: true)
  _$$JournalEntryModelImplCopyWith<_$JournalEntryModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
