import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import '../bloc/accounting_bloc.dart';
import '../../../core/widgets/index.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';
import '../../../core/utils/app_snackbar.dart';
import '../../../../app/routes/app_routes.dart';
import '../../../core/constants/strings/accounting_strings.dart';

class ExpensesView extends StatelessWidget {
  const ExpensesView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AccountingBloc, AccountingState>(
      builder: (context, state) {
        if (state.status == AccountingStatus.loading) {
          return const LoadingIndicator();
        }
        return Scaffold(
          backgroundColor: AppColors.backgroundOf(context),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: EdgeInsets.all(AppSpacing.md.w),
                child: ReusableButton(
                  text: AccountingStrings.expenseImportExcel,
                  prefixIcon: Icons.file_upload_rounded,
                  type: ButtonType.outlined,
                  onPressed: () => context.push(Routes.ACCOUNTING_EXPENSES_IMPORT),
                ),
              ),
              Expanded(
                child: state.expenses.isEmpty
                    ? const EmptyState(
                        icon: Icons.receipt_long_rounded,
                        title: AccountingStrings.accountingNoExpenses,
                        subtitle: AccountingStrings.accountingNoExpensesSubtitle,
                      )
                    : ListView.builder(
                        padding: EdgeInsets.all(AppSpacing.md.w),
                        physics: const BouncingScrollPhysics(),
                        itemCount: state.expenses.length,
                        itemBuilder: (context, index) {
                          final e = state.expenses[index];
                          return Padding(
                            padding: EdgeInsets.only(bottom: AppSpacing.sm.h),
                            child: TransactionCard(
                              icon: Icons.receipt_long_rounded,
                              iconColor: AppColors.error,
                              title: '${AccountingStrings.accountingExpensePrefix}${e.expenseNumber} - ${e.category}',
                              tags: e.description != null && e.description!.isNotEmpty
                                  ? [Tag(label: e.description!, color: AppColors.textSecondaryOf(context))]
                                  : const [],
                              amount: '${e.amount.toStringAsFixed(2)} ج.م',
                              date: _formatPaymentMethod(e.paymentMethod),
                              amountSubtext: e.expenseDate.toString().substring(0, 10),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
          floatingActionButton: ReusableFab(
            icon: Icons.add_rounded,
            onPressed: () => _showAddExpenseDialog(context),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
        );
      },
    );
  }

  String _formatPaymentMethod(String method) => switch (method) {
    'cash' => 'نقدي (الخزينة)',
    'card' => 'بطاقة بنكية',
    'bank_transfer' => 'تحويل بنكي',
    'mobile_wallet' => 'محفظة إلكترونية',
    _ => method,
  };

  void _showAddExpenseDialog(BuildContext context) {
    final descCtrl = TextEditingController();
    final amountCtrl = TextEditingController();
    String selectedMethod = 'cash';
    final categories = [
      'إيجار الفرع',
      'مرتبات موظفين',
      'فواتير ومرافق',
      'صيانة وتجهيزات',
      'تسويق ودعاية',
      'نقل وشحن',
      'أخرى',
    ];
    String selectedCategory = categories.first;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => ReusableDialog(
          title: 'تسجيل مصروفات جديد',
          headerIcon: const Icon(Icons.add_card_rounded),
          children: [
            ReusableDropdown<String>(
              labelText: 'تصنيف المصروف',
              hintText: 'اختر التصنيف الرئيسي',
              items: categories,
              value: selectedCategory,
              itemAsString: (s) => s,
              onChanged: (v) {
                if (v != null) setState(() => selectedCategory = v);
              },
            ),
            SizedBox(height: AppSpacing.sm.h),
            ReusableInput(
              label: 'البيان والتفاصيل',
              hint: 'اكتب تفاصيل المصروف هنا...',
              controller: descCtrl,
              maxLines: 2,
              textDirection: TextDirection.rtl,
            ),
            SizedBox(height: AppSpacing.sm.h),
            ReusableInput(
              label: 'القيمة المالية (ج.م)',
              hint: '0.00',
              controller: amountCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              prefixIcon: const Icon(Icons.payments_rounded, size: 18),
            ),
            SizedBox(height: AppSpacing.sm.h),
            ReusableDropdown<String>(
              labelText: 'طريقة الدفع',
              hintText: 'اختر حساب الدفع',
              items: const ['cash', 'card', 'bank_transfer', 'mobile_wallet'],
              value: selectedMethod,
              itemAsString: (s) =>
                  s == 'cash'
                      ? 'خزينة الصيدلية (نقدي)'
                      : s == 'card'
                      ? 'شبكة / بطاقة بنكية'
                      : s == 'bank_transfer'
                      ? 'تحويل بنكي'
                      : 'محفظة إلكترونية',
              onChanged: (v) {
                if (v != null) setState(() => selectedMethod = v);
              },
            ),
            SizedBox(height: AppSpacing.lg.h),
            DialogActions(
              confirmText: 'حفظ وترحيل القيد',
              onConfirm: () async {
                final amount = double.tryParse(amountCtrl.text);
                if (amount == null || amount <= 0) {
                  AppSnackbar.error('يرجى إدخال مبلغ صحيح');
                  return;
                }
                context.read<AccountingBloc>().add(
                  AddExpense(
                    category: selectedCategory,
                    description: descCtrl.text.isNotEmpty ? descCtrl.text : null,
                    amount: amount,
                    paymentMethod: selectedMethod,
                  ),
                );
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
