// views/party_payments_view.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:collection/collection.dart';
import '../bloc/party_payments_bloc.dart';
import '../models/party_payment_model.dart';
import '../models/party_payment_enums.dart';
import '../../../core/widgets/index.dart';
import '../../../core/models/customer/customer_model.dart';
import '../../../core/models/supplier/supplier_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';

class PartyPaymentsView extends StatelessWidget {
  const PartyPaymentsView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PartyPaymentsBloc, PartyPaymentsState>(
      builder: (context, state) {
        if (state.status == PartyPaymentsStatus.loading) {
          return const LoadingIndicator();
        }
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            backgroundColor: AppColors.backgroundOf(context),
            appBar: PreferredSize(
              preferredSize: Size.fromHeight(40.h),
              child: TabBar(
                tabs: const [
                  Tab(text: 'سندات مقبوضات العملاء'),
                  Tab(text: 'سندات مدفوعات الموردين'),
                ],
                labelStyle: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                ),
                unselectedLabelStyle: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w500,
                ),
                indicatorColor: Theme.of(context).colorScheme.primary,
                labelColor: Theme.of(context).colorScheme.primary,
                unselectedLabelColor: AppColors.textSecondaryOf(context),
              ),
            ),
            body: TabBarView(
              children: [
                _PaymentList(
                  payments: state.customerReceipts,
                  icon: Icons.archive_rounded,
                  color: AppColors.success,
                ),
                _PaymentList(
                  payments: state.supplierPayments,
                  icon: Icons.unarchive_rounded,
                  color: AppColors.error,
                ),
              ],
            ),
            floatingActionButton: ReusableFab(
              icon: Icons.add_rounded,
              onPressed: () => _showAddPaymentDialog(context),
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
          ),
        );
      },
    );
  }

  void _showAddPaymentDialog(BuildContext context) {
    final bloc = context.read<PartyPaymentsBloc>();
    final amountCtrl = TextEditingController();
    final notesCtrl = TextEditingController();

    PartyPaymentKind selectedKind = PartyPaymentKind.customerReceipt;
    String selectedPartyId = '';
    String selectedPartyName = '';
    String selectedMethod = 'cash';

    final kinds = [
      PartyPaymentKind.customerReceipt,
      PartyPaymentKind.supplierPayment,
    ];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => ReusableDialog(
          title: 'إنشاء إيصال مالي جديد',
          headerIcon: Icon(
            Icons.payment_rounded,
            color: Theme.of(context).colorScheme.primary,
            size: 20.sp,
          ),
          children: [
            ReusableDropdown<PartyPaymentKind>(
              labelText: 'نوع السند المالي',
              hintText: 'اختر نوع السند',
              items: kinds,
              value: selectedKind,
              itemAsString: (k) =>
                  k == PartyPaymentKind.customerReceipt
                      ? 'سند قبض نقدية من عميل'
                      : 'سند صرف نقدية لمورد',
              onChanged: (v) {
                if (v != null) {
                  setState(() {
                    selectedKind = v;
                    selectedPartyId = '';
                    selectedPartyName = '';
                  });
                }
              },
            ),
            SizedBox(height: AppSpacing.md.h),
            () {
              final isCustomer = selectedKind == PartyPaymentKind.customerReceipt;
              final items =
                  isCustomer
                      ? bloc.state.customers.toList()
                      : bloc.state.suppliers.toList();
              final selectedItem = items.firstWhereOrNull(
                (p) =>
                    (p is CustomerModel && p.id == selectedPartyId) ||
                    (p is SupplierModel && p.id == selectedPartyId),
              );

              return ReusableDropdown<dynamic>(
                labelText: isCustomer ? 'العميل المستهدف' : 'المورد المستهدف',
                hintText: 'اختر الحساب الجاري',
                items: items,
                value: selectedItem,
                itemAsString: (p) =>
                    p is CustomerModel
                        ? p.name
                        : p is SupplierModel
                        ? p.name
                        : 'حساب مجهول',
                onChanged: (v) {
                  if (v != null) {
                    setState(() {
                      if (v is CustomerModel) {
                        selectedPartyId = v.id;
                        selectedPartyName = v.name;
                      } else if (v is SupplierModel) {
                        selectedPartyId = v.id;
                        selectedPartyName = v.name;
                      }
                    });
                  }
                },
              );
            }(),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput(
              label: 'المبلغ المستحق (ج.م)',
              hint: '0.00',
              controller: amountCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableDropdown<String>(
              labelText: 'قناة الإيداع / الصرف',
              hintText: 'اختر طريقة التسوية',
              items: const ['cash', 'card', 'bank_transfer', 'mobile_wallet'],
              value: selectedMethod,
              itemAsString: (s) =>
                  s == 'cash'
                      ? 'نقداً بالخزينة'
                      : s == 'card'
                      ? 'مدفوعات بطاقة (شبكة)'
                      : s == 'bank_transfer'
                      ? 'تحويل بنكي مباشر'
                      : 'محفظة كاش إلكترونية',
              onChanged: (v) {
                if (v != null) setState(() => selectedMethod = v);
              },
            ),
            SizedBox(height: AppSpacing.md.h),
            ReusableInput.text(
              label: 'ملاحظات إضافية',
              hint: 'اختياري...',
              controller: notesCtrl,
            ),
            SizedBox(height: AppSpacing.lg.h),
            DialogActions(
              confirmText: 'اعتماد وترحيل السند',
              onConfirm: () async {
                final amount = double.tryParse(amountCtrl.text);
                if (amount == null || amount <= 0 || selectedPartyId.isEmpty) {
                  return;
                }
                if (selectedKind == PartyPaymentKind.customerReceipt) {
                  bloc.add(
                    PostCustomerReceipt(
                      customerId: selectedPartyId,
                      customerName: selectedPartyName,
                      amount: amount,
                      paymentMethod: selectedMethod,
                      notes: notesCtrl.text.isNotEmpty ? notesCtrl.text : null,
                    ),
                  );
                } else {
                  bloc.add(
                    PostSupplierPayment(
                      supplierId: selectedPartyId,
                      supplierName: selectedPartyName,
                      amount: amount,
                      paymentMethod: selectedMethod,
                      notes: notesCtrl.text.isNotEmpty ? notesCtrl.text : null,
                    ),
                  );
                }
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentList extends StatelessWidget {
  final List<PartyPaymentModel> payments;
  final IconData icon;
  final Color color;

  const _PaymentList({required this.payments, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    if (payments.isEmpty) {
      return EmptyState(
        icon: Icons.receipt_long_rounded,
        title: 'لا توجد إيصالات أو سندات مسجلة',
        subtitle: 'لم يتم إنشاء أي سندات مالية هنا بعد',
      );
    }
    return ListView.builder(
      padding: EdgeInsets.all(AppSpacing.md.w),
      physics: const BouncingScrollPhysics(),
      itemCount: payments.length,
      itemBuilder: (context, index) {
        final p = payments[index];
        return Padding(
          padding: EdgeInsets.only(bottom: 8.h),
          child: TransactionCard(
            icon: Icons.payments_rounded,
            iconColor: color,
            title: 'رقم السند: #${p.number} — الطرف: ${p.partyName} — القيمة: ${p.amount.toStringAsFixed(2)} ج.م',
            tags: p.notes != null && p.notes!.isNotEmpty
                ? [Tag(label: p.notes!, color: AppColors.textSecondaryOf(context))]
                : const [],
            amount: p.paymentDate.toString().substring(0, 10),
            date: 'طريقة التسوية: ${p.paymentMethod}',
          ),
        );
      },
    );
  }
}

