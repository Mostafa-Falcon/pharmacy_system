import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../bloc/accounting_bloc.dart';
import '../models/journal_entry_model.dart';
import '../../../core/widgets/index.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_sizes.dart';

class JournalView extends StatefulWidget {
  const JournalView({super.key});

  @override
  State<JournalView> createState() => _JournalViewState();
}

class _JournalViewState extends State<JournalView> {
  final DateTime _fromDate = DateTime.now().subtract(const Duration(days: 30));
  final DateTime _toDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<AccountingBloc>().add(LoadJournalsInRange(from: _fromDate, to: _toDate));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AccountingBloc, AccountingState>(
      builder: (context, state) {
        if (state.status == AccountingStatus.loading) {
          return const LoadingIndicator();
        }
        return Column(
          children: [
            AppCard(
              margin: EdgeInsets.all(AppSpacing.md.w),
              padding: EdgeInsets.all(AppSpacing.sm.w),
              child: Row(
                children: [
                  Expanded(
                    child: _DatePickerField(
                      label: 'من تاريخ',
                      initialDate: _fromDate,
                      onChanged: (d) {
                        context.read<AccountingBloc>().add(
                          LoadJournalsInRange(from: d, to: _toDate),
                        );
                      },
                    ),
                  ),
                  SizedBox(width: AppSpacing.sm.w),
                  Expanded(
                    child: _DatePickerField(
                      label: 'إلى تاريخ',
                      initialDate: _toDate,
                      onChanged: (d) {
                        context.read<AccountingBloc>().add(
                          LoadJournalsInRange(from: _fromDate, to: d),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: state.journalsInRange.isEmpty
                  ? const EmptyState(
                      icon: Icons.receipt_long_rounded,
                      title: 'لا توجد قيود في هذه الفترة',
                      subtitle: 'يرجى اختيار نطاق زمني آخر أو التأكد من وجود عمليات مسجلة.',
                    )
                  : ListView.separated(
                      padding: EdgeInsets.fromLTRB(
                        AppSpacing.md.w,
                        0,
                        AppSpacing.md.w,
                        AppSpacing.lg.h,
                      ),
                      physics: const BouncingScrollPhysics(),
                      itemCount: state.journalsInRange.length,
                      separatorBuilder: (_, index) => SizedBox(height: AppSpacing.sm.h),
                      itemBuilder: (context, index) {
                        return _JournalEntryCard(entry: state.journalsInRange[index]);
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}

class _DatePickerField extends StatelessWidget {
  final String label;
  final DateTime initialDate;
  final ValueChanged<DateTime> onChanged;

  const _DatePickerField({
    required this.label,
    required this.initialDate,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppColors.isDark(context);
    final scheme = Theme.of(context).colorScheme;
    
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: initialDate,
          firstDate: DateTime(2020),
          lastDate: DateTime.now().add(const Duration(days: 1)),
        );
        if (picked != null) onChanged(picked);
      },
      borderRadius: BorderRadius.circular(AppRadius.md.r),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: AppSpacing.sm.w,
          vertical: 10.h,
        ),
        decoration: BoxDecoration(
          color: scheme.surfaceContainerLow.withValues(alpha: 0.5),
          border: Border.all(
            color: AppColors.borderOf(context).withValues(alpha: isDark ? 0.2 : 0.3),
          ),
          borderRadius: BorderRadius.circular(AppRadius.md.r),
        ),
        child: Row(
          children: [
            Icon(
              Icons.calendar_today_rounded,
              size: 14.sp,
              color: scheme.primary,
            ),
            SizedBox(width: AppSpacing.xs.w),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                ReusableText(
                  label,
                  variant: ReusableTextVariant.caption,
                  style: TextStyle(fontSize: 9.sp),
                ),
                ReusableText(
                  '${initialDate.year}-${initialDate.month}-${initialDate.day}',
                  style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _JournalEntryCard extends StatefulWidget {
  final JournalEntryModel entry;
  const _JournalEntryCard({required this.entry});

  @override
  State<_JournalEntryCard> createState() => _JournalEntryCardState();
}

class _JournalEntryCardState extends State<_JournalEntryCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    final scheme = Theme.of(context).colorScheme;

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: EdgeInsets.all(AppSpacing.md.w),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: scheme.primary.withValues(alpha: 0.08),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.receipt_long_rounded,
                      size: 16.sp,
                      color: scheme.primary,
                    ),
                  ),
                  SizedBox(width: AppSpacing.md.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ReusableText(
                          'قيد رقم #${e.entryNumber}',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp),
                        ),
                        ReusableText(
                          '${e.entryDate.toString().substring(0, 10)} | ${_formatType(e.entryType.name)}',
                          style: TextStyle(fontSize: 11.sp, color: AppColors.textSecondaryOf(context)),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      ReusableText(
                        '${e.totalDebit.toStringAsFixed(2)} ج.م',
                        style: TextStyle(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.bold,
                          color: AppColors.success,
                        ),
                      ),
                      ReusableText(
                        'متوازن',
                        variant: ReusableTextVariant.caption,
                      ),
                    ],
                  ),
                  SizedBox(width: AppSpacing.sm.w),
                  Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    size: 18.sp,
                    color: AppColors.textMutedOf(context),
                  ),
                ],
              ),
            ),
          ),
          if (_expanded) ...[
            const Divider(height: 1),
            Container(
              padding: EdgeInsets.all(AppSpacing.md.w),
              color: scheme.surfaceContainerLow.withValues(alpha: 0.3),
              child: Column(
                children: [
                  ...e.lines.map((line) => Padding(
                        padding: EdgeInsets.symmetric(vertical: 4.h),
                        child: Row(
                          children: [
                            Icon(
                              Icons.subdirectory_arrow_left_rounded,
                              size: 12.sp,
                              color: scheme.primary.withValues(alpha: 0.5),
                            ),
                            SizedBox(width: 8.w),
                            Expanded(
                              flex: 4,
                              child: ReusableText(
                                line.accountName,
                                style: TextStyle(fontSize: 11.5.sp, fontWeight: FontWeight.w600),
                              ),
                            ),
                            if (line.debit > 0)
                              ReusableText(
                                '${line.debit.toStringAsFixed(2)} (مدين)',
                                style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold, color: AppColors.success),
                              ),
                            if (line.credit > 0)
                              ReusableText(
                                '${line.credit.toStringAsFixed(2)} (دائن)',
                                style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.bold, color: AppColors.error),
                              ),
                          ],
                        ),
                      )),
                  if (e.description?.isNotEmpty == true) ...[
                    SizedBox(height: AppSpacing.md.h),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(8.w),
                      decoration: BoxDecoration(
                        color: scheme.surface,
                        borderRadius: BorderRadius.circular(AppRadius.sm.r),
                        border: Border.all(color: scheme.outlineVariant.withValues(alpha: 0.3)),
                      ),
                      child: ReusableText(
                        'البيان: ${e.description!}',
                        style: TextStyle(fontSize: 11.sp, fontStyle: FontStyle.italic),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatType(String t) => switch (t) {
    'sale' => 'مبيعات',
    'purchase' => 'مشتريات',
    'expense' => 'مصروفات',
    _ => t,
  };
}
