import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/models/customer/customer_model.dart';
import '../../../core/models/supplier/supplier_model.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/customer/customer_service.dart';
import '../../../core/services/supplier/supplier_service.dart';
import '../../../core/utils/app_snackbar.dart';
import '../models/party_payment_enums.dart';
import '../models/party_payment_model.dart';
import '../services/party_payment_service.dart';

// ── أحداث سندات القبض والصرف ──
abstract class PartyPaymentsEvent extends Equatable {
  const PartyPaymentsEvent();
  @override
  List<Object?> get props => [];
}

class LoadPayments extends PartyPaymentsEvent {
  const LoadPayments();
}

class PostCustomerReceipt extends PartyPaymentsEvent {
  final String customerId;
  final String customerName;
  final double amount;
  final String paymentMethod;
  final String? notes;
  const PostCustomerReceipt({
    required this.customerId,
    required this.customerName,
    required this.amount,
    required this.paymentMethod,
    this.notes,
  });
  @override
  List<Object?> get props => [customerId, customerName, amount, paymentMethod, notes];
}

class PostSupplierPayment extends PartyPaymentsEvent {
  final String supplierId;
  final String supplierName;
  final double amount;
  final String paymentMethod;
  final String? notes;
  const PostSupplierPayment({
    required this.supplierId,
    required this.supplierName,
    required this.amount,
    required this.paymentMethod,
    this.notes,
  });
  @override
  List<Object?> get props => [supplierId, supplierName, amount, paymentMethod, notes];
}

class DeletePayment extends PartyPaymentsEvent {
  final String id;
  const DeletePayment({required this.id});
  @override
  List<Object?> get props => [id];
}

// ── حالة سندات القبض والصرف ──
enum PartyPaymentsStatus { initial, loading, loaded, error }

class PartyPaymentsState extends Equatable {
  final PartyPaymentsStatus status;
  final List<PartyPaymentModel> payments;
  final List<CustomerModel> customers;
  final List<SupplierModel> suppliers;
  final bool isPosting;
  final String? errorMessage;

  const PartyPaymentsState({
    this.status = PartyPaymentsStatus.initial,
    this.payments = const [],
    this.customers = const [],
    this.suppliers = const [],
    this.isPosting = false,
    this.errorMessage,
  });

  List<PartyPaymentModel> get customerReceipts =>
      payments.where((p) => p.kind == PartyPaymentKind.customerReceipt).toList();

  List<PartyPaymentModel> get supplierPayments =>
      payments.where((p) => p.kind == PartyPaymentKind.supplierPayment).toList();

  PartyPaymentsState copyWith({
    PartyPaymentsStatus? status,
    List<PartyPaymentModel>? payments,
    List<CustomerModel>? customers,
    List<SupplierModel>? suppliers,
    bool? isPosting,
    String? errorMessage,
  }) {
    return PartyPaymentsState(
      status: status ?? this.status,
      payments: payments ?? this.payments,
      customers: customers ?? this.customers,
      suppliers: suppliers ?? this.suppliers,
      isPosting: isPosting ?? this.isPosting,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, payments, customers, suppliers, isPosting, errorMessage];
}

// ── Bloc سندات القبض والصرف ──
class PartyPaymentsBloc extends Bloc<PartyPaymentsEvent, PartyPaymentsState> {
  PartyPaymentsBloc() : super(const PartyPaymentsState()) {
    on<LoadPayments>(_onLoadPayments);
    on<PostCustomerReceipt>(_onPostCustomerReceipt);
    on<PostSupplierPayment>(_onPostSupplierPayment);
    on<DeletePayment>(_onDeletePayment);
  }

  String get _branchId => AuthService.currentBranchId ?? '';
  String get _userId => AuthService.currentUser?.id ?? '';
  String get _userName => AuthService.currentUser?.name ?? '';

  Future<void> _onLoadPayments(
    LoadPayments event,
    Emitter<PartyPaymentsState> emit,
  ) async {
    emit(state.copyWith(status: PartyPaymentsStatus.loading));
    try {
      final payments = PartyPaymentService.getAll(branchId: _branchId);
      final customers = CustomerService.getAll(activeOnly: true);
      final suppliers = SupplierService.getAll(activeOnly: true);
      emit(state.copyWith(
        status: PartyPaymentsStatus.loaded,
        payments: payments,
        customers: customers,
        suppliers: suppliers,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: PartyPaymentsStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }

  Future<void> _onPostCustomerReceipt(
    PostCustomerReceipt event,
    Emitter<PartyPaymentsState> emit,
  ) async {
    if (state.isPosting) return;
    emit(state.copyWith(isPosting: true));
    try {
      final now = DateTime.now();
      await PartyPaymentService.create(PartyPaymentModel(
        id: const Uuid().v4(),
        branchId: _branchId,
        number: PartyPaymentService.nextNumber(_branchId),
        paymentDate: now,
        kind: PartyPaymentKind.customerReceipt,
        partyId: event.customerId,
        partyName: event.customerName,
        amount: event.amount,
        paymentMethod: event.paymentMethod,
        notes: event.notes,
        createdById: _userId,
        createdByName: _userName,
        createdAt: now,
        updatedAt: now,
      ));
      AppSnackbar.success('تم تسجيل سند القبض بنجاح');
      add(const LoadPayments());
    } catch (e) {
      AppSnackbar.error(e.toString());
    } finally {
      emit(state.copyWith(isPosting: false));
    }
  }

  Future<void> _onPostSupplierPayment(
    PostSupplierPayment event,
    Emitter<PartyPaymentsState> emit,
  ) async {
    if (state.isPosting) return;
    emit(state.copyWith(isPosting: true));
    try {
      final now = DateTime.now();
      await PartyPaymentService.create(PartyPaymentModel(
        id: const Uuid().v4(),
        branchId: _branchId,
        number: PartyPaymentService.nextNumber(_branchId),
        paymentDate: now,
        kind: PartyPaymentKind.supplierPayment,
        partyId: event.supplierId,
        partyName: event.supplierName,
        amount: event.amount,
        paymentMethod: event.paymentMethod,
        notes: event.notes,
        createdById: _userId,
        createdByName: _userName,
        createdAt: now,
        updatedAt: now,
      ));
      AppSnackbar.success('تم تسجيل سند الصرف بنجاح');
      add(const LoadPayments());
    } catch (e) {
      AppSnackbar.error(e.toString());
    } finally {
      emit(state.copyWith(isPosting: false));
    }
  }

  Future<void> _onDeletePayment(
    DeletePayment event,
    Emitter<PartyPaymentsState> emit,
  ) async {
    try {
      final box = Hive.box('party_payments');
      await box.delete(event.id);
      AppSnackbar.success('تم حذف السند');
      add(const LoadPayments());
    } catch (e) {
      AppSnackbar.error('فشل الحذف: $e');
    }
  }
}
