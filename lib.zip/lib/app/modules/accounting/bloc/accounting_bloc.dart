import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/utils/app_snackbar.dart';
import '../models/expense_model.dart';
import '../models/journal_entry_model.dart';
import '../services/accounting_projection_service.dart';
import '../services/expense_service.dart';
import '../services/journal_entry_service.dart';

// ── أحداث المحاسبة ──
abstract class AccountingEvent extends Equatable {
  const AccountingEvent();
  @override
  List<Object?> get props => [];
}

class LoadAccounting extends AccountingEvent {
  const LoadAccounting();
}

class AddExpense extends AccountingEvent {
  final String category;
  final String? description;
  final double amount;
  final String paymentMethod;
  const AddExpense({
    required this.category,
    this.description,
    required this.amount,
    required this.paymentMethod,
  });
  @override
  List<Object?> get props => [category, description, amount, paymentMethod];
}

class DeleteExpense extends AccountingEvent {
  final String id;
  const DeleteExpense({required this.id});
  @override
  List<Object?> get props => [id];
}

class DeleteJournalEntry extends AccountingEvent {
  final String id;
  const DeleteJournalEntry({required this.id});
  @override
  List<Object?> get props => [id];
}

class LoadJournalsInRange extends AccountingEvent {
  final DateTime from;
  final DateTime to;
  const LoadJournalsInRange({required this.from, required this.to});
  @override
  List<Object?> get props => [from, to];
}

class FilterJournals extends AccountingEvent {
  final String query;
  const FilterJournals({required this.query});
  @override
  List<Object?> get props => [query];
}

// ── حالة المحاسبة ──
enum AccountingStatus { initial, loading, loaded, error }

class AccountingState extends Equatable {
  final AccountingStatus status;
  final List<JournalEntryModel> journals;
  final List<ExpenseModel> expenses;
  final double totalRevenue;
  final double totalExpenses;
  final double netProfit;
  final List<JournalEntryModel> journalsInRange;
  final String? errorMessage;

  const AccountingState({
    this.status = AccountingStatus.initial,
    this.journals = const [],
    this.expenses = const [],
    this.totalRevenue = 0,
    this.totalExpenses = 0,
    this.netProfit = 0,
    this.journalsInRange = const [],
    this.errorMessage,
  });

  AccountingState copyWith({
    AccountingStatus? status,
    List<JournalEntryModel>? journals,
    List<ExpenseModel>? expenses,
    double? totalRevenue,
    double? totalExpenses,
    double? netProfit,
    List<JournalEntryModel>? journalsInRange,
    String? errorMessage,
  }) {
    return AccountingState(
      status: status ?? this.status,
      journals: journals ?? this.journals,
      expenses: expenses ?? this.expenses,
      totalRevenue: totalRevenue ?? this.totalRevenue,
      totalExpenses: totalExpenses ?? this.totalExpenses,
      netProfit: netProfit ?? this.netProfit,
      journalsInRange: journalsInRange ?? this.journalsInRange,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [
    status, journals, expenses, totalRevenue, totalExpenses,
    netProfit, journalsInRange, errorMessage,
  ];
}

// ── Bloc المحاسبة ──
class AccountingBloc extends Bloc<AccountingEvent, AccountingState> {
  AccountingBloc() : super(const AccountingState()) {
    on<LoadAccounting>(_onLoadAccounting);
    on<AddExpense>(_onAddExpense);
    on<DeleteExpense>(_onDeleteExpense);
    on<DeleteJournalEntry>(_onDeleteJournalEntry);
    on<LoadJournalsInRange>(_onLoadJournalsInRange);
    on<FilterJournals>(_onFilterJournals);
  }

  String get _branchId => AuthService.currentBranchId ?? '';

  Future<void> _onLoadAccounting(
    LoadAccounting event,
    Emitter<AccountingState> emit,
  ) async {
    emit(state.copyWith(status: AccountingStatus.loading));
    try {
      final journals = JournalEntryService.getAll(branchId: _branchId);
      final expenses = ExpenseService.getAll(branchId: _branchId);
      final summary = AccountingProjectionService.getSummary(branchId: _branchId);
      emit(state.copyWith(
        status: AccountingStatus.loaded,
        journals: journals,
        expenses: expenses,
        totalRevenue: summary.revenue,
        totalExpenses: summary.operatingExpenses,
        netProfit: summary.netProfit,
        journalsInRange: journals,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: AccountingStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }

  Future<void> _onAddExpense(
    AddExpense event,
    Emitter<AccountingState> emit,
  ) async {
    try {
      final expense = ExpenseModel(
        id: const Uuid().v4(),
        branchId: _branchId,
        expenseNumber: ExpenseService.nextNumber(_branchId),
        category: event.category,
        description: event.description,
        amount: event.amount,
        paymentMethod: event.paymentMethod,
        createdById: AuthService.currentUser?.id ?? '',
        createdByName: AuthService.currentUser?.name,
        expenseDate: DateTime.now(),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      await ExpenseService.post(
        draft: expense,
        actorId: AuthService.currentUser?.id ?? '',
      );
      AppSnackbar.success('تم تسجيل المصروف بنجاح');
      add(const LoadAccounting());
    } catch (e) {
      AppSnackbar.error('فشل تسجيل المصروف: $e');
    }
  }

  Future<void> _onDeleteExpense(
    DeleteExpense event,
    Emitter<AccountingState> emit,
  ) async {
    try {
      final box = Hive.box('expenses');
      await box.delete(event.id);
      AppSnackbar.success('تم حذف المصروف');
      add(const LoadAccounting());
    } catch (e) {
      AppSnackbar.error('فشل الحذف: $e');
    }
  }

  Future<void> _onDeleteJournalEntry(
    DeleteJournalEntry event,
    Emitter<AccountingState> emit,
  ) async {
    try {
      final box = Hive.box('journal_entries');
      await box.delete(event.id);
      AppSnackbar.success('تم حذف القيد');
      add(const LoadAccounting());
    } catch (e) {
      AppSnackbar.error('فشل الحذف: $e');
    }
  }

  void _onLoadJournalsInRange(
    LoadJournalsInRange event,
    Emitter<AccountingState> emit,
  ) {
    final end = DateTime(event.to.year, event.to.month, event.to.day, 23, 59, 59);
    final filtered = state.journals.where((j) =>
      j.entryDate.isAfter(event.from.subtract(const Duration(seconds: 1))) &&
      j.entryDate.isBefore(end.add(const Duration(seconds: 1))),
    ).toList();
    emit(state.copyWith(journalsInRange: filtered));
  }

  void _onFilterJournals(
    FilterJournals event,
    Emitter<AccountingState> emit,
  ) {
    if (event.query.isEmpty) {
      emit(state.copyWith(journalsInRange: state.journals));
      return;
    }
    final q = event.query.toLowerCase();
    final filtered = state.journals.where((j) =>
      j.description?.toLowerCase().contains(q) == true ||
      j.entryNumber.toString().contains(q) ||
      j.entryType.name.toLowerCase().contains(q),
    ).toList();
    emit(state.copyWith(journalsInRange: filtered));
  }
}
