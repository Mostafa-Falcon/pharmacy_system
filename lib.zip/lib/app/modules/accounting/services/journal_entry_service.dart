import 'package:hive/hive.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../models/journal_entry_model.dart';

class JournalEntryService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static List<JournalEntryModel> getAll({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = Hive.box('journal_entries');
    final entries = box.values
        .whereType<Map>()
        .map((e) => JournalEntryModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.branchId == bid)
        .toList();
    entries.sort((a, b) => b.entryDate.compareTo(a.entryDate));
    return entries;
  }

  static JournalEntryModel? getById(String id) {
    final box = Hive.box('journal_entries');
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return JournalEntryModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<void> create(JournalEntryModel entry) async {
    final box = Hive.box('journal_entries');
    await box.putSynced(entry.id, entry.toJson(), table: 'journal_entries', branchId: _currentBranchId);
  }

  static int nextNumber(String branchId) {
    final entries = getAll(branchId: branchId);
    if (entries.isEmpty) return 1;
    return entries.map((e) => e.entryNumber).reduce((a, b) => a > b ? a : b) + 1;
  }
}
