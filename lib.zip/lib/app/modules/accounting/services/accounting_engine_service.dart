import 'dart:math';
import 'package:uuid/uuid.dart';
import '../../../core/models/sales/sale_model.dart';
import '../../../core/models/sales/purchase_model.dart';
import '../../../core/models/sales/return_model.dart';
import '../models/journal_entry_model.dart';
import '../models/account_enums.dart';
import 'journal_entry_service.dart';

class SalesAccountingPolicy {
  final String cashAccountId;
  final String cardAccountId;
  final String bankAccountId;
  final String walletAccountId;
  final String receivablesAccountId;
  final String salesRevenueAccountId;
  final String taxPayableAccountId;
  final String inventoryAccountId;
  final String costOfGoodsSoldAccountId;

  const SalesAccountingPolicy({
    this.cashAccountId = 'system:cash',
    this.cardAccountId = 'system:card_clearing',
    this.bankAccountId = 'system:bank',
    this.walletAccountId = 'system:mobile_wallet',
    this.receivablesAccountId = 'system:accounts_receivable',
    this.salesRevenueAccountId = 'system:sales_revenue',
    this.taxPayableAccountId = 'system:tax_payable',
    this.inventoryAccountId = 'system:inventory',
    this.costOfGoodsSoldAccountId = 'system:cost_of_goods_sold',
  });
}

class PurchaseAccountingPolicy {
  final String inventoryAccountId;
  final String accountsPayableAccountId;
  final String cashAccountId;

  const PurchaseAccountingPolicy({
    this.inventoryAccountId = 'system:inventory',
    this.accountsPayableAccountId = 'system:accounts_payable',
    this.cashAccountId = 'system:cash',
  });
}

class ReturnAccountingPolicy {
  final String cashAccountId;
  final String cardAccountId;
  final String bankAccountId;
  final String walletAccountId;
  final String receivablesAccountId;
  final String salesRevenueAccountId;
  final String taxPayableAccountId;
  final String inventoryAccountId;
  final String costOfGoodsSoldAccountId;
  final String accountsPayableAccountId;

  const ReturnAccountingPolicy({
    this.cashAccountId = 'system:cash',
    this.cardAccountId = 'system:card_clearing',
    this.bankAccountId = 'system:bank',
    this.walletAccountId = 'system:mobile_wallet',
    this.receivablesAccountId = 'system:accounts_receivable',
    this.salesRevenueAccountId = 'system:sales_revenue',
    this.taxPayableAccountId = 'system:tax_payable',
    this.inventoryAccountId = 'system:inventory',
    this.costOfGoodsSoldAccountId = 'system:cost_of_goods_sold',
    this.accountsPayableAccountId = 'system:accounts_payable',
  });
}

class InventoryAccountingPolicy {
  final String inventoryAccountId;
  final String inventoryGainAccountId;
  final String inventoryLossAccountId;

  const InventoryAccountingPolicy({
    this.inventoryAccountId = 'system:inventory',
    this.inventoryGainAccountId = 'system:inventory_gain',
    this.inventoryLossAccountId = 'system:inventory_shrinkage',
  });
}

class SalesAccountingService {
  const SalesAccountingService({this.policy = const SalesAccountingPolicy()});
  final SalesAccountingPolicy policy;

  Future<JournalEntryModel> buildEntry({
    required SaleModel sale,
    required String actorId,
    double paidTotal = 0,
  }) async {
    final lines = <JournalEntryLineModel>[];
    final method = sale.paymentMethod;
    final amount = sale.finalAmount;
    final isCredit = method == 'credit';
    final isMixed = method == 'mixed';

    if (isCredit) {
      // آجل بالكامل → مديونية كاملة في الذمم.
      lines.add(_line(
        accountId: policy.receivablesAccountId,
        debit: amount,
        description: 'فاتورة آجلة ${sale.id}',
      ));
    } else if (isMixed) {
      // مختلط: المدفوع في حساب الدفع + المتبقي في الذمم (الآجل).
      final paid = _money(paidTotal.clamp(0, amount));
      final due = _money((amount - paid).clamp(0, double.infinity));
      if (paid > 0) {
        lines.add(_line(
          accountId: _paymentAccount('cash'),
          debit: paid,
          description: 'مدفوعات مختلطة ${sale.id}',
        ));
      }
      if (due > 0) {
        lines.add(_line(
          accountId: policy.receivablesAccountId,
          debit: due,
          description: 'مستحق آجل (مختلط) ${sale.id}',
        ));
      }
    } else {
      lines.add(_line(
        accountId: _paymentAccount(method),
        debit: amount,
        description: 'مدفوعات ${_methodLabel(method)}',
      ));
    }

    final revenue = amount;
    lines.add(_line(
      accountId: policy.salesRevenueAccountId,
      credit: revenue,
      description: 'إيراد مبيعات',
    ));

    final totalCost = sale.items.fold<double>(
      0,
      (sum, item) => sum + (item.costPrice * item.quantity),
    );
    if (totalCost > 0) {
      lines.add(_line(
        accountId: policy.costOfGoodsSoldAccountId,
        debit: totalCost,
        description: 'تكلفة البضاعة المباعة',
      ));
      lines.add(_line(
        accountId: policy.inventoryAccountId,
        credit: totalCost,
        description: 'تخفيض المخزون',
      ));
    }

    return _finalize(
      id: 'journal:sale:${sale.id}',
      branchId: sale.branchId,
      date: sale.createdAt,
      type: JournalEntryType.sales,
      referenceId: sale.id,
      referenceNumber: sale.id,
      description: 'فاتورة بيع #${sale.id.substring(0, 8)}',
      actorId: actorId,
      occurredAt: sale.createdAt,
      lines: lines,
    );
  }

  String _paymentAccount(String method) {
    switch (method) {
      case 'cash': return policy.cashAccountId;
      case 'card': return policy.cardAccountId;
      case 'bank': return policy.bankAccountId;
      case 'wallet': return policy.walletAccountId;
      default: return policy.cashAccountId;
    }
  }

  String _methodLabel(String m) {
    switch (m) {
      case 'cash': return 'نقدية';
      case 'card': return 'بطاقة';
      case 'bank': return 'تحويل بنكي';
      case 'wallet': return 'محفظة إلكترونية';
      default: return m;
    }
  }

  JournalEntryLineModel _line({
    required String accountId,
    double debit = 0,
    double credit = 0,
    String? description,
  }) {
    return JournalEntryLineModel(
      id: const Uuid().v4(),
      accountId: accountId,
      debit: _money(debit),
      credit: _money(credit),
      description: description,
    );
  }

  Future<JournalEntryModel> _finalize({
    required String id,
    required String branchId,
    required DateTime date,
    required JournalEntryType type,
    required String referenceId,
    required String referenceNumber,
    required String description,
    required String actorId,
    required DateTime occurredAt,
    required List<JournalEntryLineModel> lines,
  }) async {
    final debit = _money(lines.fold<double>(0, (sum, l) => sum + l.debit));
    final credit = _money(lines.fold<double>(0, (sum, l) => sum + l.credit));
    if ((debit - credit).abs() > 0.01) {
      throw StateError('قيود غير متزنة. الخصم: $debit, الدائن: $credit');
    }
    final entry = JournalEntryModel(
      id: id,
      branchId: branchId,
      entryNumber: JournalEntryService.nextNumber(branchId),
      entryDate: date,
      entryType: type,
      referenceId: referenceId,
      referenceNumber: referenceNumber,
      description: description,
      lines: lines,
      totalDebit: debit,
      totalCredit: credit,
      createdById: actorId,
      createdAt: occurredAt,
      updatedAt: occurredAt,
    );
    await JournalEntryService.create(entry);
    return entry;
  }

  double _money(double value) => (value * 100).roundToDouble() / 100;
}

class PurchaseAccountingService {
  const PurchaseAccountingService({this.policy = const PurchaseAccountingPolicy()});
  final PurchaseAccountingPolicy policy;

  Future<JournalEntryModel> buildEntry({
    required PurchaseModel purchase,
    required String actorId,
    required double paidAmount,
    required String paymentAccountId,
  }) async {
    final total = _money(purchase.totalAmount);
    final paid = _money(min(paidAmount, total));
    final due = _money(total - paid);

    final lines = <JournalEntryLineModel>[
      _line(
        accountId: policy.inventoryAccountId,
        debit: total,
        description: 'مخزون وارد',
      ),
      if (paid > 0)
        _line(
          accountId: paymentAccountId,
          credit: paid,
          description: 'مدفوعات للمورد',
        ),
      if (due > 0)
        _line(
          accountId: policy.accountsPayableAccountId,
          credit: due,
          description: 'مستحق للمورد',
        ),
    ];

    return _finalize(
      id: 'journal:purchase:${purchase.id}',
      branchId: purchase.branchId,
      date: purchase.createdAt,
      type: JournalEntryType.purchase,
      referenceId: purchase.id,
      referenceNumber: purchase.id,
      description: 'فاتورة شراء #${purchase.id.substring(0, 8)}',
      actorId: actorId,
      occurredAt: purchase.createdAt,
      lines: lines,
    );
  }

  JournalEntryLineModel _line({
    required String accountId,
    double debit = 0,
    double credit = 0,
    String? description,
  }) {
    return JournalEntryLineModel(
      id: const Uuid().v4(),
      accountId: accountId,
      debit: _money(debit),
      credit: _money(credit),
      description: description,
    );
  }

  Future<JournalEntryModel> _finalize({
    required String id,
    required String branchId,

    required DateTime date,
    required JournalEntryType type,
    required String referenceId,
    required String referenceNumber,
    required String description,
    required String actorId,
    required DateTime occurredAt,
    required List<JournalEntryLineModel> lines,
  }) async {
    final debit = _money(lines.fold<double>(0, (sum, l) => sum + l.debit));
    final credit = _money(lines.fold<double>(0, (sum, l) => sum + l.credit));
    if ((debit - credit).abs() > 0.01) {
      throw StateError('قيود مشتريات غير متزنة. الخصم: $debit, الدائن: $credit');
    }
    final entry = JournalEntryModel(
      id: id,
      branchId: branchId,
      entryNumber: JournalEntryService.nextNumber(branchId),
      entryDate: date,
      entryType: type,
      referenceId: referenceId,
      referenceNumber: referenceNumber,
      description: description,
      lines: lines,
      totalDebit: debit,
      totalCredit: credit,
      createdById: actorId,
      createdAt: occurredAt,
      updatedAt: occurredAt,
    );
    await JournalEntryService.create(entry);
    return entry;
  }

  double _money(double value) => (value * 100).roundToDouble() / 100;
}

class ReturnAccountingService {
  const ReturnAccountingService({this.policy = const ReturnAccountingPolicy()});
  final ReturnAccountingPolicy policy;

  Future<JournalEntryModel> buildSalesReturnEntry({
    required ReturnModel salesReturn,
    required String actorId,
  }) async {
    final gross = _money(salesReturn.totalAmount);
    final lines = <JournalEntryLineModel>[
      _line(
        accountId: policy.salesRevenueAccountId,
        debit: gross,
        description: 'عكس إيراد مبيعات',
      ),
      _line(
        accountId: policy.cashAccountId,
        credit: gross,
        description: 'مرتجع بيع',
      ),
    ];

    final totalCost = salesReturn.items.fold<double>(
      0, (sum, item) => sum + (item.costPrice * item.quantity),
    );
    if (totalCost > 0) {
      lines.add(_line(
        accountId: policy.inventoryAccountId,
        debit: totalCost,
        description: 'مخزون مرتجع',
      ));
      lines.add(_line(
        accountId: policy.costOfGoodsSoldAccountId,
        credit: totalCost,
        description: 'عكس تكلفة البضاعة',
      ));
    }

    return _finalize(
      id: 'journal:sales_return:${salesReturn.id}',
      branchId: salesReturn.branchId,
      date: salesReturn.createdAt,
      type: JournalEntryType.salesReturn,
      referenceId: salesReturn.id,
      referenceNumber: salesReturn.id,
      description: 'مرتجع بيع #${salesReturn.id.substring(0, 8)}',
      actorId: actorId,
      occurredAt: salesReturn.createdAt,
      lines: lines,
    );
  }

  Future<JournalEntryModel> buildPurchaseReturnEntry({
    required ReturnModel purchaseReturn,
    required String actorId,
  }) async {
    final total = _money(purchaseReturn.totalAmount);
    final lines = <JournalEntryLineModel>[
      _line(
        accountId: policy.accountsPayableAccountId,
        debit: total,
        description: 'تخفيض مستحق المورد',
      ),
      _line(
        accountId: policy.inventoryAccountId,
        credit: total,
        description: 'مخزون مرتجع للمورد',
      ),
    ];

    return _finalize(
      id: 'journal:purchase_return:${purchaseReturn.id}',
      branchId: purchaseReturn.branchId,
      date: purchaseReturn.createdAt,
      type: JournalEntryType.purchaseReturn,
      referenceId: purchaseReturn.id,
      referenceNumber: purchaseReturn.id,
      description: 'مرتجع شراء #${purchaseReturn.id.substring(0, 8)}',
      actorId: actorId,
      occurredAt: purchaseReturn.createdAt,
      lines: lines,
    );
  }

  JournalEntryLineModel _line({
    required String accountId,
    double debit = 0,
    double credit = 0,
    String? description,
  }) {
    return JournalEntryLineModel(
      id: const Uuid().v4(),
      accountId: accountId,
      debit: _money(debit),
      credit: _money(credit),
      description: description,
    );
  }

  Future<JournalEntryModel> _finalize({
    required String id,
    required String branchId,

    required DateTime date,
    required JournalEntryType type,
    required String referenceId,
    required String referenceNumber,
    required String description,
    required String actorId,
    required DateTime occurredAt,
    required List<JournalEntryLineModel> lines,
  }) async {
    final debit = _money(lines.fold<double>(0, (sum, l) => sum + l.debit));
    final credit = _money(lines.fold<double>(0, (sum, l) => sum + l.credit));
    if ((debit - credit).abs() > 0.01) {
      throw StateError('قيود مرتجع غير متزنة. الخصم: $debit, الدائن: $credit');
    }
    final entry = JournalEntryModel(
      id: id,
      branchId: branchId,
      entryNumber: JournalEntryService.nextNumber(branchId),
      entryDate: date,
      entryType: type,
      referenceId: referenceId,
      referenceNumber: referenceNumber,
      description: description,
      lines: lines,
      totalDebit: debit,
      totalCredit: credit,
      createdById: actorId,
      createdAt: occurredAt,
      updatedAt: occurredAt,
    );
    await JournalEntryService.create(entry);
    return entry;
  }

  double _money(double value) => (value * 100).roundToDouble() / 100;
}

class InventoryAccountingService {
  const InventoryAccountingService({this.policy = const InventoryAccountingPolicy()});
  final InventoryAccountingPolicy policy;

  Future<JournalEntryModel> buildAdjustmentEntry({
    required String medicineId,
    required String medicineName,
    required String branchId,
    required int oldQuantity,
    required int newQuantity,
    required double unitCost,
    required String actorId,
    required String reason,
  }) async {
    final diff = newQuantity - oldQuantity;
    final value = _money(diff.abs() * unitCost);
    final isIncrease = diff > 0;

    final lines = <JournalEntryLineModel>[];
    if (isIncrease) {
      lines.add(_line(
        accountId: policy.inventoryAccountId, debit: value,
        description: 'تسوية مخزون: $medicineName',
      ));
      lines.add(_line(
        accountId: policy.inventoryGainAccountId, credit: value,
        description: 'أرباح تسوية مخزون',
      ));
    } else {
      lines.add(_line(
        accountId: policy.inventoryLossAccountId, debit: value,
        description: 'خسائر تسوية مخزون: $medicineName',
      ));
      lines.add(_line(
        accountId: policy.inventoryAccountId, credit: value,
        description: 'تسوية مخزون: $medicineName',
      ));
    }

    return _finalize(
      id: 'journal:adjustment:${medicineId}_${DateTime.now().millisecondsSinceEpoch}',
      branchId: branchId,
      date: DateTime.now(),
      type: JournalEntryType.adjustment,
      referenceId: medicineId,
      referenceNumber: reason,
      description: 'تسوية مخزون: $medicineName',
      actorId: actorId,
      occurredAt: DateTime.now(),
      lines: lines,
    );
  }

  JournalEntryLineModel _line({
    required String accountId, double debit = 0, double credit = 0, String? description,
  }) {
    return JournalEntryLineModel(
      id: const Uuid().v4(), accountId: accountId,
      debit: _money(debit), credit: _money(credit), description: description,
    );
  }

  Future<JournalEntryModel> _finalize({
    required String id, required String branchId,
    required DateTime date, required JournalEntryType type,
    required String referenceId, required String referenceNumber,
    required String description, required String actorId,
    required DateTime occurredAt, required List<JournalEntryLineModel> lines,
  }) async {
    final debit = _money(lines.fold<double>(0, (sum, l) => sum + l.debit));
    final credit = _money(lines.fold<double>(0, (sum, l) => sum + l.credit));
    if ((debit - credit).abs() > 0.01) {
      throw StateError('قيود تسوية غير متزنة. الخصم: $debit, الدائن: $credit');
    }
    final entry = JournalEntryModel(
      id: id, branchId: branchId,
      entryNumber: JournalEntryService.nextNumber(branchId),
      entryDate: date, entryType: type,
      referenceId: referenceId, referenceNumber: referenceNumber,
      description: description, lines: lines,
      totalDebit: debit, totalCredit: credit,
      createdById: actorId, createdAt: occurredAt, updatedAt: occurredAt,
    );
    await JournalEntryService.create(entry);
    return entry;
  }

  double _money(double value) => (value * 100).roundToDouble() / 100;
}
