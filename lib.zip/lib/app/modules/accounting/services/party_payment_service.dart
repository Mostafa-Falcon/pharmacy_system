import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../../../core/services/customer/customer_ledger_service.dart';
import '../../../core/services/supplier/supplier_ledger_service.dart';
import '../models/party_payment_model.dart';
import '../models/party_payment_enums.dart';
import '../models/journal_entry_model.dart';
import '../models/account_enums.dart';
import 'journal_entry_service.dart';

class PartyPaymentService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static List<PartyPaymentModel> getAll({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = Hive.box('party_payments');
    final payments = box.values
        .whereType<Map>()
        .map((e) => PartyPaymentModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.branchId == bid)
        .toList();
    payments.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return payments;
  }

  static List<PartyPaymentModel> getByKind(PartyPaymentKind kind,
      {String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = Hive.box('party_payments');
    return box.values
        .whereType<Map>()
        .map((e) => PartyPaymentModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.branchId == bid && e.kind == kind)
        .toList()
      ..sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
  }

  static Future<void> create(PartyPaymentModel payment) async {
    final box = Hive.box('party_payments');
    await box.putSynced(payment.id, payment.toJson(), table: 'party_payments', branchId: _currentBranchId);

    await _updateLedger(payment);

    await _createJournalEntry(payment);
  }

  static Future<void> _updateLedger(PartyPaymentModel payment) async {
    switch (payment.kind) {
      case PartyPaymentKind.customerReceipt:
        await CustomerLedgerService.recordCustomerPayment(
          customerId: payment.partyId,
          branchId: payment.branchId,
          amount: payment.amount,
          createdBy: payment.createdById,
          notes: payment.notes,
          referenceId: payment.id,
        );
        break;
      case PartyPaymentKind.supplierPayment:
        await SupplierLedgerService.recordSupplierPayment(
          supplierId: payment.partyId,
          branchId: payment.branchId,
          amount: payment.amount,
          createdBy: payment.createdById,
          notes: payment.notes,
          referenceId: payment.id,
        );
        break;
      case PartyPaymentKind.supplierReceipt:
        await SupplierLedgerService.recordAdditionNotice(
          supplierId: payment.partyId,
          branchId: payment.branchId,
          amount: payment.amount,
          createdBy: payment.createdById,
          notes: payment.notes ?? 'استلام نقدية من المورد',
          referenceId: payment.id,
        );
        break;
      case PartyPaymentKind.supplierAdditionNote:
        await SupplierLedgerService.recordAdditionNotice(
          supplierId: payment.partyId,
          branchId: payment.branchId,
          amount: payment.amount,
          createdBy: payment.createdById,
          notes: payment.notes,
          referenceId: payment.id,
        );
        break;
      case PartyPaymentKind.supplierDiscountNote:
        await SupplierLedgerService.recordDiscountNotice(
          supplierId: payment.partyId,
          branchId: payment.branchId,
          amount: payment.amount,
          createdBy: payment.createdById,
          notes: payment.notes,
          referenceId: payment.id,
        );
        break;
      case PartyPaymentKind.supplierOpeningBalance:
        if (payment.effectiveBalanceEffect == PartyBalanceEffect.increase) {
          await SupplierLedgerService.recordOpeningBalanceDirect(
            supplierId: payment.partyId,
            branchId: payment.branchId,
            amount: payment.amount,
            createdBy: payment.createdById,
            notes: payment.notes,
            referenceId: payment.id,
          );
        } else {
          await SupplierLedgerService.recordOpeningBalanceAsCredit(
            supplierId: payment.partyId,
            branchId: payment.branchId,
            amount: payment.amount,
            createdBy: payment.createdById,
            notes: payment.notes,
            referenceId: payment.id,
          );
        }
        break;
    }
  }

  static Future<void> _createJournalEntry(PartyPaymentModel payment) async {
    final amount = payment.amount;
    final settAccount = _settlementAccount(payment.paymentMethod);
    final entryType = _journalEntryType(payment.kind);
    final entryNumber = JournalEntryService.nextNumber(payment.branchId);

    List<JournalEntryLineModel> lines;
    String description;

    switch (payment.kind) {
      case PartyPaymentKind.customerReceipt:
        description = 'مقبوضات من ${payment.partyName}';
        lines = [
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: settAccount,
            accountName: _accountName(payment.paymentMethod),
            debit: amount,
            credit: 0,
            description: payment.number.toString(),
          ),
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'accounts_receivable',
            accountName: 'العملاء',
            debit: 0,
            credit: amount,
            description: 'تخفيض رصيد العميل',
          ),
        ];
        break;
      case PartyPaymentKind.supplierPayment:
        description = 'مدفوعات لـ ${payment.partyName}';
        lines = [
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'accounts_payable',
            accountName: 'الموردون',
            debit: amount,
            credit: 0,
            description: 'تخفيض رصيد المورد',
          ),
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: settAccount,
            accountName: _accountName(payment.paymentMethod),
            debit: 0,
            credit: amount,
            description: payment.number.toString(),
          ),
        ];
        break;
      case PartyPaymentKind.supplierReceipt:
        description = 'مقبوضات من المورد ${payment.partyName}';
        lines = [
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: settAccount,
            accountName: _accountName(payment.paymentMethod),
            debit: amount,
            credit: 0,
            description: payment.number.toString(),
          ),
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'accounts_payable',
            accountName: 'الموردون',
            debit: 0,
            credit: amount,
            description: 'مقبوضات مورد',
          ),
        ];
        break;
      case PartyPaymentKind.supplierAdditionNote:
        description = 'إشعار إضافة مورد ${payment.partyName}';
        lines = [
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'supplier_adjustments',
            accountName: 'تسويات موردين',
            debit: amount,
            credit: 0,
            description: description,
          ),
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'accounts_payable',
            accountName: 'الموردون',
            debit: 0,
            credit: amount,
            description: description,
          ),
        ];
        break;
      case PartyPaymentKind.supplierDiscountNote:
        description = 'إشعار خصم مورد ${payment.partyName}';
        lines = [
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'accounts_payable',
            accountName: 'الموردون',
            debit: amount,
            credit: 0,
            description: description,
          ),
          JournalEntryLineModel(
            id: const Uuid().v4(),
            accountId: 'purchase_discounts',
            accountName: 'خصومات مشتريات',
            debit: 0,
            credit: amount,
            description: description,
          ),
        ];
        break;
      case PartyPaymentKind.supplierOpeningBalance:
        description = 'رصيد افتتاحي ${payment.partyName}';
        final isIncrease =
            payment.effectiveBalanceEffect == PartyBalanceEffect.increase;
        lines = isIncrease
            ? [
                JournalEntryLineModel(
                  id: const Uuid().v4(),
                  accountId: 'opening_balance_equity',
                  accountName: 'حقوق ملكية افتتاحية',
                  debit: amount,
                  credit: 0,
                  description: description,
                ),
                JournalEntryLineModel(
                  id: const Uuid().v4(),
                  accountId: 'accounts_payable',
                  accountName: 'الموردون',
                  debit: 0,
                  credit: amount,
                  description: description,
                ),
              ]
            : [
                JournalEntryLineModel(
                  id: const Uuid().v4(),
                  accountId: 'accounts_payable',
                  accountName: 'الموردون',
                  debit: amount,
                  credit: 0,
                  description: description,
                ),
                JournalEntryLineModel(
                  id: const Uuid().v4(),
                  accountId: 'opening_balance_equity',
                  accountName: 'حقوق ملكية افتتاحية',
                  debit: 0,
                  credit: amount,
                  description: description,
                ),
              ];
        break;
    }

    final journalEntry = JournalEntryModel(
      id: const Uuid().v4(),
      branchId: payment.branchId,
      entryNumber: entryNumber,
      entryDate: payment.paymentDate,
      entryType: entryType,
      referenceId: payment.id,
      referenceNumber: payment.number.toString(),
      description: description,
      lines: lines,
      totalDebit: amount,
      totalCredit: amount,
      createdById: payment.createdById,
      createdByName: payment.createdByName,
      createdAt: payment.createdAt,
      updatedAt: payment.updatedAt,
    );
    await JournalEntryService.create(journalEntry);
  }

  static JournalEntryType _journalEntryType(PartyPaymentKind kind) {
    switch (kind) {
      case PartyPaymentKind.customerReceipt:
      case PartyPaymentKind.supplierReceipt:
        return JournalEntryType.receipt;
      case PartyPaymentKind.supplierPayment:
        return JournalEntryType.payment;
      case PartyPaymentKind.supplierAdditionNote:
      case PartyPaymentKind.supplierDiscountNote:
      case PartyPaymentKind.supplierOpeningBalance:
        return JournalEntryType.adjustment;
    }
  }

  static String _settlementAccount(String method) {
    switch (method) {
      case 'card':
        return 'card_clearing';
      case 'bank_transfer':
        return 'bank';
      case 'mobile_wallet':
        return 'mobile_wallet';
      default:
        return 'cash';
    }
  }

  static String _accountName(String method) {
    switch (method) {
      case 'card':
        return 'تسويات البطاقات';
      case 'bank_transfer':
        return 'البنك';
      case 'mobile_wallet':
        return 'المحفظة الإلكترونية';
      default:
        return 'الخزينة';
    }
  }

  static int nextNumber(String branchId) {
    final payments = getAll(branchId: branchId);
    if (payments.isEmpty) return 1;
    return payments.map((e) => e.number).reduce((a, b) => a > b ? a : b) + 1;
  }
}
