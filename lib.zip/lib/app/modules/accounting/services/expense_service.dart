import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../../core/services/auth/auth_service.dart';
import '../../../core/services/sync_box_extension.dart';
import '../models/expense_model.dart';
import '../models/journal_entry_model.dart';
import '../models/account_enums.dart';
import 'journal_entry_service.dart';

class ExpensePostResult {
  final ExpenseModel expense;
  final JournalEntryModel journal;
  final bool alreadyPosted;

  const ExpensePostResult({
    required this.expense,
    required this.journal,
    this.alreadyPosted = false,
  });
}

class ExpenseService {
  static String get _currentBranchId => AuthService.currentBranchId ?? '';

  static List<ExpenseModel> getAll({String? branchId}) {
    final bid = branchId ?? _currentBranchId;
    final box = Hive.box('expenses');
    final expenses = box.values
        .whereType<Map>()
        .map((e) => ExpenseModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.branchId == bid)
        .toList();
    expenses.sort((a, b) => b.expenseDate.compareTo(a.expenseDate));
    return expenses;
  }

  static ExpenseModel? getById(String id) {
    final box = Hive.box('expenses');
    final data = box.get(id);
    if (data == null || data is! Map) return null;
    return ExpenseModel.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<ExpensePostResult> post({
    required ExpenseModel draft,
    required String actorId,
  }) async {
    _validate(draft, actorId: actorId);
    final box = Hive.box('expenses');
    final existing = box.get(draft.id);
    if (existing != null) {
      return ExpensePostResult(
        expense: ExpenseModel.fromJson(Map<String, dynamic>.from(existing)),
        journal: JournalEntryModel(
          id: 'journal:expense:${draft.id}',
          branchId: draft.branchId,
          entryNumber: JournalEntryService.nextNumber(draft.branchId),
          entryDate: draft.expenseDate,
          entryType: JournalEntryType.expense,
          referenceId: draft.id,
          description: draft.description ?? draft.category,
          lines: [],
          totalDebit: 0,
          totalCredit: 0,
          createdById: actorId,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        ),
        alreadyPosted: true,
      );
    }

    final occurredAt = DateTime.now();
    final expense = ExpenseModel(
      id: draft.id,
      branchId: draft.branchId,
      expenseNumber: draft.expenseNumber,
      expenseDate: draft.expenseDate,
      category: draft.category.trim(),
      description: draft.description?.trim(),
      amount: _money(draft.amount),
      paymentMethod: draft.paymentMethod,
      createdById: actorId,
      createdByName: draft.createdByName,
      notes: draft.notes?.trim().isEmpty == true ? null : draft.notes?.trim(),
      createdAt: draft.createdAt,
      updatedAt: occurredAt,
    );

    final journal = _buildJournal(expense, actorId, occurredAt);

    await box.putSynced(expense.id, expense.toJson(), table: 'expenses', branchId: _currentBranchId);
    await JournalEntryService.create(journal);

    _recordAuditLog(expense, actorId);

    return ExpensePostResult(expense: expense, journal: journal);
  }

  static JournalEntryModel _buildJournal(
    ExpenseModel expense,
    String actorId,
    DateTime occurredAt,
  ) {
    final amount = expense.amount;
    final paymentAccount = _paymentAccount(expense.paymentMethod);
    final categoryKey = expense.category.trim().toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\u0600-\u06ff]+'), '_');

    return JournalEntryModel(
      id: 'journal:expense:${expense.id}',
      branchId: expense.branchId,
      entryNumber: JournalEntryService.nextNumber(expense.branchId),
      entryDate: expense.expenseDate,
      entryType: JournalEntryType.expense,
      referenceId: expense.id,
      referenceNumber: expense.expenseNumber.toString(),
      description: expense.description,
      lines: [
        JournalEntryLineModel(
          id: const Uuid().v4(),
          accountId: 'system:expense:$categoryKey',
          accountName: expense.category,
          debit: amount,
          credit: 0,
          description: expense.description,
        ),
        JournalEntryLineModel(
          id: const Uuid().v4(),
          accountId: paymentAccount,
          accountName: _paymentAccountName(expense.paymentMethod),
          debit: 0,
          credit: amount,
          description: expense.description,
        ),
      ],
      totalDebit: amount,
      totalCredit: amount,
      createdById: actorId,
      createdByName: expense.createdByName,
      createdAt: occurredAt,
      updatedAt: occurredAt,
    );
  }

  static void _recordAuditLog(ExpenseModel expense, String actorId) {
    final auditBox = Hive.box('admin_audit_logs');
    auditBox.put(
      'audit:expense:${expense.id}',
      {
        'id': 'audit:expense:${expense.id}',
        'branchId': expense.branchId,
        'action': 'expense.posted',
        'entityType': 'expense',
        'entityId': expense.id,
        'actorId': actorId,
        'occurredAt': DateTime.now().toIso8601String(),
        'summary': {
          'expenseNumber': expense.expenseNumber,
          'category': expense.category,
          'amount': expense.amount,
          'paymentMethod': expense.paymentMethod,
        },
      },
    );
  }

  static String _paymentAccount(String? method) {
    switch (method) {
      case 'card': return 'system:card_clearing';
      case 'bank_transfer': return 'system:bank';
      case 'mobile_wallet': return 'system:mobile_wallet';
      default: return 'system:cash';
    }
  }

  static String _paymentAccountName(String? method) {
    switch (method) {
      case 'card': return 'تسويات البطاقات';
      case 'bank_transfer': return 'البنك';
      case 'mobile_wallet': return 'المحفظة الإلكترونية';
      default: return 'الخزينة';
    }
  }

  static void _validate(ExpenseModel value, {required String actorId}) {
    if (value.id.trim().isEmpty) {
      throw const FormatException('معرف المصروف مطلوب');
    }
    if (value.branchId.trim().isEmpty) {
      throw const FormatException('الفرع مطلوب');
    }
    if (value.category.trim().isEmpty) {
      throw const FormatException('تصنيف المصروف مطلوب');
    }
    if (value.description == null || value.description!.trim().isEmpty) {
      throw const FormatException('وصف المصروف مطلوب');
    }
    if (value.amount <= 0) {
      throw StateError('قيمة المصروف يجب أن تكون موجبة');
    }
    if (value.paymentMethod == 'credit') {
      throw StateError('المصروفات لا يمكن أن تكون آجلة');
    }
    if (actorId.trim().isEmpty) {
      throw const FormatException('المستخدم مطلوب');
    }
  }

  static int nextNumber(String branchId) {
    final expenses = getAll(branchId: branchId);
    if (expenses.isEmpty) return 1;
    return expenses.map((e) => e.expenseNumber).reduce((a, b) => a > b ? a : b) + 1;
  }

  static double _money(double value) => (value * 100).roundToDouble() / 100;
}
