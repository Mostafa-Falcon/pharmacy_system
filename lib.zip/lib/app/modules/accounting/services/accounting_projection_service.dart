import 'package:hive/hive.dart';
import '../models/expense_model.dart';
import '../models/journal_entry_model.dart';
import '../models/account_enums.dart';

class AccountBalanceProjection {
  final String accountId;
  final String accountName;
  final AccountType type;
  final double debit;
  final double credit;
  final double balance;

  const AccountBalanceProjection({
    required this.accountId,
    required this.accountName,
    required this.type,
    required this.debit,
    required this.credit,
    required this.balance,
  });
}

class AccountingSummaryProjection {
  final double revenue;
  final double costOfGoodsSold;
  final double operatingExpenses;
  final double grossProfit;
  final double netProfit;
  final double assets;
  final double liabilities;
  final double totalDebit;
  final double totalCredit;

  const AccountingSummaryProjection({
    required this.revenue,
    required this.costOfGoodsSold,
    required this.operatingExpenses,
    required this.grossProfit,
    required this.netProfit,
    required this.assets,
    required this.liabilities,
    required this.totalDebit,
    required this.totalCredit,
  });

  bool get balanced => (totalDebit - totalCredit).abs() < 0.01;
}

class AccountingProjectionService {
  static const Map<String, String> _arabicNames = {
    'system:cash': 'الخزينة الرئيسية',
    'system:bank': 'البنك',
    'system:card_clearing': 'تسويات البطاقات',
    'system:mobile_wallet': 'المحافظ الإلكترونية',
    'system:accounts_receivable': 'العملاء',
    'system:accounts_payable': 'الموردون',
    'system:inventory': 'المخزون',
    'system:sales_revenue': 'إيرادات المبيعات',
    'system:tax_payable': 'ضريبة مستحقة',
    'system:cost_of_goods_sold': 'تكلفة البضاعة المباعة',
    'system:inventory_gain': 'أرباح تسويات المخزون',
    'system:inventory_shrinkage': 'عجز وتالف المخزون',
    'system:supplier_adjustments': 'تسويات موردين',
    'system:purchase_discounts': 'خصومات مشتريات',
    'system:opening_balance_equity': 'حقوق ملكية افتتاحية',
  };

  static List<JournalEntryModel> getJournals({
    String? branchId,
    DateTime? from,
    DateTime? to,
  }) {
    final box = Hive.box('journal_entries');
    var entries = box.values
        .whereType<Map>()
        .map((e) => JournalEntryModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => branchId == null || e.branchId == branchId)
        .where((e) {
          if (from != null && e.entryDate.isBefore(_startOfDay(from))) return false;
          if (to != null && e.entryDate.isAfter(_endOfDay(to))) return false;
          return true;
        })
        .toList();
    entries.sort((a, b) => b.entryDate.compareTo(a.entryDate));
    return entries;
  }

  static List<ExpenseModel> getExpenses({
    String? branchId,
    DateTime? from,
    DateTime? to,
  }) {
    final box = Hive.box('expenses');
    var expenses = box.values
        .whereType<Map>()
        .map((e) => ExpenseModel.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => branchId == null || e.branchId == branchId)
        .where((e) {
          if (from != null && e.expenseDate.isBefore(_startOfDay(from))) return false;
          if (to != null && e.expenseDate.isAfter(_endOfDay(to))) return false;
          return true;
        })
        .toList();
    expenses.sort((a, b) => b.expenseDate.compareTo(a.expenseDate));
    return expenses;
  }

  static List<AccountBalanceProjection> getBalances({
    String? branchId,
    DateTime? from,
    DateTime? to,
  }) {
    final journals = getJournals(branchId: branchId, from: from, to: to);
    final totals = <String, _MutableBalance>{};

    for (final entry in journals) {
      for (final line in entry.lines) {
        final current = totals.putIfAbsent(
          line.accountId,
          () => _MutableBalance(
            accountId: line.accountId,
            name: _accountName(line.accountId, line.accountName),
            type: _accountType(line.accountId),
          ),
        );
        current.debit += line.debit;
        current.credit += line.credit;
      }
    }

    final values = totals.values.map((v) {
      final naturalDebit = v.type == AccountType.asset || v.type == AccountType.expense;
      final balance = naturalDebit ? v.debit - v.credit : v.credit - v.debit;
      return AccountBalanceProjection(
        accountId: v.accountId,
        accountName: v.name,
        type: v.type,
        debit: _money(v.debit),
        credit: _money(v.credit),
        balance: _money(balance),
      );
    }).toList();

    values.sort((a, b) {
      final byType = a.type.index.compareTo(b.type.index);
      return byType == 0 ? a.accountName.compareTo(b.accountName) : byType;
    });
    return values;
  }

  static AccountingSummaryProjection getSummary({
    String? branchId,
    DateTime? from,
    DateTime? to,
  }) {
    final values = getBalances(branchId: branchId, from: from, to: to);
    var revenue = 0.0;
    var costOfGoodsSold = 0.0;
    var operatingExpenses = 0.0;
    var assets = 0.0;
    var liabilities = 0.0;
    var totalDebit = 0.0;
    var totalCredit = 0.0;

    for (final v in values) {
      totalDebit += v.debit;
      totalCredit += v.credit;
      if (v.type == AccountType.asset) assets += v.balance;
      if (v.type == AccountType.liability) liabilities += v.balance;
      if (v.type == AccountType.income) revenue += v.balance;
      if (v.accountId == 'system:cost_of_goods_sold') {
        costOfGoodsSold += v.balance;
      } else if (v.type == AccountType.expense) {
        operatingExpenses += v.balance;
      }
    }

    final grossProfit = revenue - costOfGoodsSold;
    return AccountingSummaryProjection(
      revenue: _money(revenue),
      costOfGoodsSold: _money(costOfGoodsSold),
      operatingExpenses: _money(operatingExpenses),
      grossProfit: _money(grossProfit),
      netProfit: _money(grossProfit - operatingExpenses),
      assets: _money(assets),
      liabilities: _money(liabilities),
      totalDebit: _money(totalDebit),
      totalCredit: _money(totalCredit),
    );
  }

  static List<Map<String, dynamic>> getRecentActivity({
    String? branchId,
    int limit = 10,
  }) {
    final activities = <Map<String, dynamic>>[];
    final journalBox = Hive.box('journal_entries');
    for (final data in journalBox.values.whereType<Map>()) {
      final entry = JournalEntryModel.fromJson(Map<String, dynamic>.from(data));
      if (branchId == null || entry.branchId == branchId) {
        activities.add({
          'type': 'journal',
          'id': entry.id,
          'date': entry.entryDate,
          'number': entry.entryNumber,
          'description': entry.description ?? 'قيد يومي',
          'amount': entry.totalDebit,
        });
      }
    }
    final expensesBox = Hive.box('expenses');
    for (final data in expensesBox.values.whereType<Map>()) {
      final expense = ExpenseModel.fromJson(Map<String, dynamic>.from(data));
      if (branchId == null || expense.branchId == branchId) {
        activities.add({
          'type': 'expense',
          'id': expense.id,
          'date': expense.expenseDate,
          'number': expense.expenseNumber,
          'description': expense.description ?? expense.category,
          'amount': expense.amount,
        });
      }
    }
    activities.sort((a, b) => (b['date'] as DateTime).compareTo(a['date'] as DateTime));
    return activities.take(limit).toList();
  }

  static AccountType _accountType(String accountId) {
    if (accountId.startsWith('system:expense:') ||
        accountId == 'system:cost_of_goods_sold' ||
        accountId == 'system:inventory_shrinkage') {
      return AccountType.expense;
    }
    if (accountId == 'system:sales_revenue' || accountId == 'system:inventory_gain') {
      return AccountType.income;
    }
    if (accountId == 'system:accounts_payable' || accountId == 'system:tax_payable') {
      return AccountType.liability;
    }
    if (accountId.startsWith('system:equity')) return AccountType.equity;
    return AccountType.asset;
  }

  static String _accountName(String accountId, String? supplied) {
    if (supplied?.trim().isNotEmpty == true) return supplied!.trim();
    if (_arabicNames.containsKey(accountId)) return _arabicNames[accountId]!;
    if (accountId.startsWith('system:expense:')) {
      return accountId.substring('system:expense:'.length).replaceAll('_', ' ');
    }
    return accountId;
  }

  static DateTime _startOfDay(DateTime value) => DateTime(value.year, value.month, value.day);
  static DateTime _endOfDay(DateTime value) => DateTime(value.year, value.month, value.day, 23, 59, 59, 999);
  static double _money(double value) => (value * 100).roundToDouble() / 100;
}

class _MutableBalance {
  final String accountId;
  final String name;
  final AccountType type;
  double debit = 0;
  double credit = 0;
  _MutableBalance({required this.accountId, required this.name, required this.type});
}
